/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Public API exports for Aether Runtime Engine
export type { ASTNode, Statement, Expression, AetherEvent, StreamListener } from './runtime/types';
export { ValidationError } from './runtime/types';
export { Environment } from './runtime/environment';
export { EventBus } from './runtime/event-bus';
export { StreamRegistry } from './runtime/stream-registry';
export type { StreamDef } from './runtime/stream-registry';
export { Executor } from './runtime/executor';
export type { ExecutionTraceLog } from './runtime/executor';

// Builtins
export { hash, sign, verify, uuid, now } from './builtins/crypto';
export { validate } from './builtins/validate';
export { AetherResponse } from './builtins/response';

// Targets
export { NodeRuntimeAdapter } from './targets/node';
export { BrowserRuntimeAdapter } from './targets/browser';
export { WorkerRuntimeAdapter } from './targets/worker';

// Compiler
export { ASTOptimizer } from './compiler/optimizer';
export { JSEmitter } from './compiler/js-emit';

import { EventBus } from './runtime/event-bus';
import { StreamRegistry } from './runtime/stream-registry';
import { NodeRuntimeAdapter } from './targets/node';
import { BrowserRuntimeAdapter } from './targets/browser';
import { WorkerRuntimeAdapter } from './targets/worker';

/**
 * Main factory to bootstrap an Aether instance
 */
export function createAetherRuntime(config?: { envVars?: Record<string, string> }) {
  const eventBus = new EventBus();
  const streamRegistry = new StreamRegistry(eventBus);

  const nodeAdapter = new NodeRuntimeAdapter(eventBus, config?.envVars);
  const browserAdapter = new BrowserRuntimeAdapter(eventBus);
  const workerAdapter = new WorkerRuntimeAdapter(eventBus);

  return {
    eventBus,
    streamRegistry,
    adapters: {
      node: nodeAdapter,
      browser: browserAdapter,
      worker: workerAdapter
    }
  };
}
