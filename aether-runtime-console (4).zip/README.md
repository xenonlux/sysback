# AETHER Autonomous Network Mesh — Adaptive Protocol Layer

The **AETHER Network Mesh** is an adaptive, high-throughput protocol layer designed to route backend and client communications over the most optimal transport channel. By abstracting transport boundaries from service logic, systems communicate transparently with zero-overhead loops when run in-process, or dynamically scale up to TCP stream pipes, HTTP, full-duplex WebSockets, or direct WebRTC peer connections.

---

## ═══════════════════════════════════════
## NETWORK ARCHITECTURE & MESSAGE PIPELINE
## ═══════════════════════════════════════

```
 ┌─────────────────────────────────────────────────────────┐
 │               AETHER CLIENT CONSOLE APP / UI            │
 └────────────────────────────┬────────────────────────────┘
                              │
                    [ Fluent Method Call ]
                              │
                    ┌─────────▼─────────┐
                    │     ES6 Proxy     │ (Accumulates path target)
                    └─────────┬─────────┘
                              │
                              ▼
                    ┌───────────────────┐
                    │   Load Balancer   │ (Round-Robin / Least-Connections)
                    └─────────┬─────────┘
                              │
                              ▼
                    ┌───────────────────┐
                    │  Circuit Breaker  │ (Closed / Open / Half-Open safeguard)
                    └─────────┬─────────┘
                              │
                              ▼
                    ┌───────────────────┐
                    │    Mesh Router    │ (Auto-selects optimal transport)
                    └─────────┬─────────┘
                              │
            ┌─────────────────┼────────────────────────┐
            │                 │                        │
            ▼                 ▼                        ▼
     ┌─────────────┐   ┌─────────────┐          ┌─────────────┐
     │  Local Loop │   │ TCP Socket  │          │ WebSockets  │ ...[Other Transports]
     │ (In-process)│   │ (Binary MTU)│          │ (Bidirect)  │
     └──────┬──────┘   └──────┬──────┘          └──────┬──────┘
            │                 │                        │
            │          [Length Prefixed]        [JSON / MsgPack]
            │          [ MessagePack   ]               │
            ▼                 ▼                        ▼
 ┌─────────────────────────────────────────────────────────┐
 │                 MultiTransportServer                    │
 └────────────────────────────┬────────────────────────────┘
                              │
                     [ Schema Validator ]
                              │
                    ┌─────────▼─────────┐
                    │  Handler Registry │ (Exact Match & Wildcard Glob Router)
                    └─────────┬─────────┘
                              │
                              ▼
 ┌─────────────────────────────────────────────────────────┐
 │                  Target Service Exec                    │
 └─────────────────────────────────────────────────────────┘
```

---

## Technical Deliverables

### 1. Mesh Infrastructure (`src/mesh/`)
*   **`router.ts`**: Transparent routing hub. Inspects target socket descriptors and selects the optimal transport handler:
    *   `local://*` $\rightarrow$ Loopback in-memory call (Zero network footprint).
    *   `tcp://*` / raw ports $\rightarrow$ Stateful raw TCP binary socket streams.
    *   `ws://*` $\rightarrow$ WebSockets full-duplex persistent pipelines.
    *   `webrtc://*` $\rightarrow$ Dynamic P2P low-latency WebRTC channels.
    *   `http://*` $\rightarrow$ Secure HTTP request/response loops.
*   **`message.ts`**: Implements strict schema types, dynamic auto-correlation factory (`createAetherMessage`), and strict validations following the AETHER message standard:
    ```typescript
    {
      id: "uuid-string",
      type: "call" | "event" | "stream",
      target: "users.get.profile",
      payload: { ... },
      meta: {
        source: "client-source",
        timestamp: "2026-06-10T19:32:15Z",
        traceId: "correlated-uuid"
      }
    }
    ```

### 2. Physical Transports (`src/transports/`)
*   **`local.ts`**: Zero-allocation directly triggered local function pipeline.
*   **`tcp.ts`**: High-performance TCP adapter wrapping Node’s native `net` sockets in production, supported by length-prefixed stream framing. Includes a virtual TCP network bridge for the client frame-sandbox.
*   **`http.ts`**: Standard stateless POST channel running Express on Node, using fetch elsewhere.
*   **`websocket.ts`**: Streaming WebSockets client/server full-duplex implementation.
*   **`webrtc.ts`**: Simulates direct P2P connection lifecycle negotiation including SDP exchange, candidate gathering, and open direct data channels.

### 3. Binary & Framing Protocols (`src/protocols/`)
*   **`codec.ts`**: Implements a high-speed, custom, pure-TypeScript **MessagePack Binary Codec** in addition to JSON. Bypasses compile hurdles of native bindings under serverless/browser targets.
*   **`framing.ts`**: Solves TCP TCP segmentation issues by applying 32-bit (4-byte Big-Endian) length-prefix headers to streams. Unpacks split chunks using a sliding byte accumulator.

### 4. Client Resiliency Engines (`src/client/`)
*   **`proxy.ts`**: Builds dynamic property chains using an ES6 Proxy handler, converting paths into RPC target endpoints (e.g. `client.auth.users.get(101)` triggers `auth.users.get` message). Handles correlation, timeouts, and callbacks transparently.
*   **`retry.ts`**: Exponential backoff task runner with adjustable scale factors and a three-state **Circuit Breaker** (CLOSED, OPEN, HALF-OPEN) preventing cascade failures.
*   **`load-balancer.ts`**: Distributes queries via configurable Round-Robin or active Least Connections tracking list selectors.

### 5. Server Dispatch (`src/server/`)
*   **`handler-registry.ts`**: Compiles target namespaces to trigger functions. Supports hierarchical namespace glob/wildcards (e.g., `analytics.*` matches `analytics.events.view`).
*   **`listener.ts`**: Central MultiTransportServer. Mounts multiple physical listeners simultaneously and handles correlations, tracing, input schemas validation, and output replies.

---

## Quickstart Examples

### Instantiating Client RPC Proxy
```typescript
import {
  MeshRouter,
  LoadBalancer,
  CircuitBreaker,
  createAetherClientProxy
} from './src/index';

const router = new MeshRouter();
const balancer = new LoadBalancer(['local://srv-a', 'local://srv-b'], 'round-robin');
const breaker = new CircuitBreaker({ failureThreshold: 3, cooldownPeriodMs: 5000 });

// Construct Proxy client
const client = createAetherClientProxy({
  router,
  loadBalancer: balancer,
  circuitBreaker: breaker,
  timeoutMs: 3000
});

// Fluent invocation triggers RPC over best resolved channel!
const data = await client.users.profile.fetch({ uid: 'usr-928' });
console.log('User profile profile data received:', data);
```

### Instantiating Multi-Transport Server listener
```typescript
import {
  HandlerRegistry,
  MultiTransportServer,
  TcpTransportServer,
  HttpTransportServer
} from './src/index';

const registry = new HandlerRegistry();

// Register clean endpoint handler
registry.register('users.profile.fetch', async (payload) => {
  return { uid: payload.uid, name: 'Grace Hopper', clearance: 'CORE' };
});

const server = new MultiTransportServer(registry);

// Listen on TCP & HTTP bounds concurrently
server.registerServer('tcp', new TcpTransportServer());
server.registerServer('http', new HttpTransportServer());

await server.listenAll({
  tcp: '127.0.0.1:4000',
  http: '127.0.0.1:3000'
});
console.log('Aether Multi-Protocol server is standing by and listening!');
```
