/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { sha3_256Sync } from '../crypto/hash';

/**
 * Generates an Aether DID from public keys
 */
export function generateDID(dilithiumPub: Uint8Array, classicPubHex: string): string {
  // Combine public keys
  const dilithiumHex = Array.from(dilithiumPub).map(b => b.toString(16).padStart(2, '0')).join('');
  const combined = `${dilithiumHex}_${classicPubHex}`;
  
  // Hash to get fingerprint
  const fingerprint = sha3_256Sync(combined);
  return `did:aether:${fingerprint}`;
}

/**
 * Parses an Aether DID string
 */
export function parseDID(did: string): { prefix: string; method: string; fingerprint: string } {
  if (!did.startsWith('did:aether:')) {
    throw new Error('Invalid Aether DID format');
  }
  const parts = did.split(':');
  return {
    prefix: parts[0],
    method: parts[1],
    fingerprint: parts[2]
  };
}

/**
 * Validates a DID string integrity
 */
export function validateDIDFormat(did: string): boolean {
  try {
    const parsed = parseDID(did);
    return parsed.fingerprint.length === 64; // SHA3-256 is 64 hex characters
  } catch {
    return false;
  }
}
