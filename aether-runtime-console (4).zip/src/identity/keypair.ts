/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { generateKyberKeyPair, KyberKeyPair } from '../crypto/kyber';
import { generateDilithiumKeyPair, DilithiumKeyPair } from '../crypto/dilithium';
import { generateECDSAKeyPair, ClassicalKeyPair } from '../crypto/classic';
import { generateDID } from './did';

export interface AetherIdentity {
  did: string;
  createdAt: string;
  kyber: KyberKeyPair;
  dilithium: DilithiumKeyPair;
  classic: ClassicalKeyPair;
}

/**
 * Generates an Aether composite identity comprising classical and post-quantum keys
 */
export async function generateAetherIdentity(): Promise<AetherIdentity> {
  const [kyber, dilithium, classic] = await Promise.all([
    generateKyberKeyPair(),
    generateDilithiumKeyPair(),
    generateECDSAKeyPair()
  ]);

  const did = generateDID(dilithium.publicKey, classic.publicKeyHex);

  return {
    did,
    createdAt: new Date().toISOString(),
    kyber,
    dilithium,
    classic
  };
}

/**
 * Packs public materials securely for cross-node transport
 */
export function getPublicIdentityPack(identity: AetherIdentity) {
  return {
    did: identity.did,
    kyberPublicKey: identity.kyber.publicKeyHex,
    dilithiumPublicKey: identity.dilithium.publicKeyHex,
    classicPublicKey: identity.classic.publicKeyHex
  };
}
