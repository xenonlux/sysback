/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dilithiumSign, dilithiumVerify } from '../crypto/dilithium';
import { signECDSA, verifyECDSA } from '../crypto/classic';

export interface TokenClaims {
  iss: string; // Issuer DID
  sub: string; // Subject DID
  aud: string; // Audience descriptor
  exp: number; // Expiry timestamp
  iat: number; // Issued At timestamp
  jti: string; // Unique token identifier
  roles?: string[];
  [key: string]: any;
}

/**
 * Helper to encode values into base64 url format
 */
function base64UrlEncode(str: string): string {
  let b64 = '';
  if (typeof btoa !== 'undefined') {
    b64 = btoa(unescape(encodeURIComponent(str)));
  } else {
    b64 = Buffer.from(str).toString('base64');
  }
  return b64.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

/**
 * Helper to decode values from base64 url format
 */
function base64UrlDecode(str: string): string {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  if (typeof atob !== 'undefined') {
    return decodeURIComponent(escape(atob(base64)));
  } else {
    return Buffer.from(base64, 'base64').toString('utf8');
  }
}

/**
 * Signs and packages a post-quantum hybrid token
 */
export async function signAetherToken(
  claims: TokenClaims,
  dilithiumPrivateKey: Uint8Array,
  classicPrivateKey: any,
  fallbackClassicPrivKeyHex?: string
): Promise<string> {
  const header = {
    alg: 'ML-DSA-65+P256',
    typ: 'AETHER-PQ-JWT'
  };

  const headerEncoded = base64UrlEncode(JSON.stringify(header));
  const payloadEncoded = base64UrlEncode(JSON.stringify(claims));
  const messageToSign = `${headerEncoded}.${payloadEncoded}`;

  // Sign with CRYSTALS-Dilithium
  const dilithiumSig = await dilithiumSign(messageToSign, dilithiumPrivateKey);
  const dilithiumSigHex = Array.from(dilithiumSig)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  // Sign with classical ECDSA
  const ecdsaSigHex = await signECDSA(messageToSign, classicPrivateKey, fallbackClassicPrivKeyHex);

  const combinedSignature = base64UrlEncode(`${dilithiumSigHex}:${ecdsaSigHex}`);
  return `${headerEncoded}.${payloadEncoded}.${combinedSignature}`;
}

/**
 * Decrypts, parses and verifies an Aether token
 */
export async function verifyAetherToken(
  token: string,
  dilithiumPublicKey: Uint8Array,
  classicPublicKey: any,
  fallbackClassicPubKeyHex?: string
): Promise<TokenClaims> {
  if (!token || typeof token !== 'string') {
    throw new Error('Invalid token type');
  }

  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Malformed token envelope');
  }

  const [headerEncoded, payloadEncoded, signatureEncoded] = parts;
  const messageToVerify = `${headerEncoded}.${payloadEncoded}`;

  const decodedSig = base64UrlDecode(signatureEncoded);
  const [dilithiumSigHex, ecdsaSigHex] = decodedSig.split(':');

  if (!dilithiumSigHex || !ecdsaSigHex) {
    throw new Error('Missing token signature materials');
  }

  // 1. Verify Post-Quantum Crystals-Dilithium
  const dilBytes = new Uint8Array(
    dilithiumSigHex.match(/.{1,2}/g)!.map((byte) => parseInt(byte, 16))
  );
  const pqVerified = await dilithiumVerify(messageToVerify, dilBytes, dilithiumPublicKey);
  if (!pqVerified) {
    throw new Error('Post-Quantum ML-DSA Signature verification failed');
  }

  // 2. Verify Classical ECDSA
  const classicVerified = await verifyECDSA(
    messageToVerify,
    ecdsaSigHex,
    classicPublicKey,
    fallbackClassicPubKeyHex
  );
  if (!classicVerified) {
    throw new Error('Classical ECDSA Signature verification failed');
  }

  // 3. Extract and check claims
  const claimsJson = base64UrlDecode(payloadEncoded);
  const claims = JSON.parse(claimsJson) as TokenClaims;

  const nowSecs = Math.floor(Date.now() / 1000);
  if (claims.exp < nowSecs) {
    throw new Error('Token has expired');
  }

  return claims;
}
