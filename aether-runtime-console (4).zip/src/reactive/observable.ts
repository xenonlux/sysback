/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { deepFreeze } from '../flow/event';

/**
 * Ensures slow subscription handlers get events buffered and delivered sequentially, 
 * precluding dropouts or stack overflows during event delivery.
 */
export class BufferedSubscriber<T> {
  private queue: T[] = [];
  private processing = false;

  constructor(
    private readonly callback: (value: T) => Promise<void> | void,
    private readonly onError?: (error: any) => void
  ) {}

  /**
   * Pushes a new item into the subscriber buffer.
   */
  public push(value: T): void {
    this.queue.push(value);
    this.trigger();
  }

  /**
   * Evaluates the subscriber loop asynchronously.
   */
  private async trigger(): Promise<void> {
    if (this.processing) return;
    this.processing = true;

    while (this.queue.length > 0) {
      const next = this.queue.shift();
      if (next !== undefined) {
        try {
          await this.callback(next);
        } catch (err: any) {
          if (this.onError) {
            this.onError(err);
          } else {
            console.error('Aether reactive subscriber handler failed:', err);
          }
        }
      }
    }

    this.processing = false;
  }

  /**
   * Cleans the backlog buffer.
   */
  public clear(): void {
    this.queue = [];
  }

  /**
   * Inspect current backlog length.
   */
  public get backlogSize(): number {
    return this.queue.length;
  }
}

/**
 * A reactive Observable implementation custom tailored for AETHER Flow updates.
 */
export class Observable<T> {
  private readonly subscribers = new Set<BufferedSubscriber<T>>();

  constructor(
    private readonly onSubscribe?: (obs: Observable<T>) => (() => void) | void
  ) {}

  /**
   * Attaches subscription. Delivers elements in real-time.
   */
  public subscribe(
    callback: (value: T) => Promise<void> | void,
    onError?: (error: any) => void
  ): { unsubscribe: () => void } {
    const buffered = new BufferedSubscriber<T>(callback, onError);
    this.subscribers.add(buffered);

    const cleanFn = this.onSubscribe ? this.onSubscribe(this) : undefined;

    return {
      unsubscribe: () => {
        buffered.clear();
        this.subscribers.delete(buffered);
        if (cleanFn) {
          cleanFn();
        }
      },
    };
  }

  /**
   * Broadcaster: safely distributes event packets to matches.
   */
  public emit(value: T): void {
    const frozen = deepFreeze(value);
    // Convert to array to prevent modifications to the set during emission
    const subsArray = Array.from(this.subscribers);
    for (const sub of subsArray) {
      sub.push(frozen);
    }
  }

  /**
   * Map Operator: chains data transformations.
   */
  public map<U>(mapper: (value: T) => U): Observable<U> {
    const mappedObservable = new Observable<U>();
    this.subscribe((val) => {
      mappedObservable.emit(mapper(val));
    });
    return mappedObservable;
  }

  /**
   * Filter Operator: screens stream of events.
   */
  public filter(predicate: (value: T) => boolean): Observable<T> {
    const filteredObservable = new Observable<T>();
    this.subscribe((val) => {
      if (predicate(val)) {
        filteredObservable.emit(val);
      }
    });
    return filteredObservable;
  }

  /**
   * Clears all subscribers (for memory leak checks and teardowns).
   */
  public clearAllSubscribers(): void {
    for (const sub of this.subscribers) {
      sub.clear();
    }
    this.subscribers.clear();
  }
}
