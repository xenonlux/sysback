/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement, Expression } from '../runtime/types';

export class JSEmitter {
  /**
   * Compiles any AETHER AST statements list into a standard executable JavaScript function body string.
   * Can evaluate to an async performance block.
   */
  public emit(nodes: Statement[]): string {
    const lines: string[] = [];
    lines.push('// Compiled AETHER Runtime Bytecode');
    lines.push('// Optimized for JS virtual machines');
    lines.push('async function __aether_flow(env, eventBus, builtins) {');
    lines.push('  let _yield = null;');
    lines.push('  ');

    for (const node of nodes) {
      lines.push('  ' + this.compileStatement(node));
    }

    lines.push('  return _yield;');
    lines.push('}');
    lines.push('return __aether_flow(env, eventBus, builtins);');

    return lines.join('\n');
  }

  /**
   * Translate statement node to JS
   */
  private compileStatement(node: Statement): string {
    switch (node.type) {
      case 'LetStatement': {
        const valStr = this.compileExpression(node.value);
        return `env.declare(${JSON.stringify(node.name)}, ${valStr});`;
      }

      case 'FlowStatement': {
        const inner = node.steps.map(s => this.compileStatement(s)).join('\n  ');
        return `{\n  ${inner}\n}`;
      }

      case 'EmitStatement': {
        const dataStr = this.compileExpression(node.data);
        return `await eventBus.emit(${JSON.stringify(node.signal)}, ${dataStr});`;
      }

      case 'YieldStatement': {
        const valStr = this.compileExpression(node.value);
        return `_yield = ${valStr};\nenv.assign('_yield', _yield);`;
      }

      case 'IfStatement': {
        const condStr = this.compileExpression(node.condition);
        const consStr = node.consequent.map(s => this.compileStatement(s)).join('\n  ');
        const altStr = node.alternate 
          ? ` else {\n  ${node.alternate.map(s => this.compileStatement(s)).join('\n  ')}\n}`
          : '';
        return `if (Boolean(${condStr})) {\n  ${consStr}\n}${altStr}`;
      }

      case 'ExpressionStatement': {
        return `${this.compileExpression(node.expression)};`;
      }

      default:
        return `/* Unknown Statement type: ${(node as any).type} */`;
    }
  }

  /**
   * Translate expression to JS statement string
   */
  private compileExpression(expr: Expression): string {
    switch (expr.type) {
      case 'Literal': {
        if (typeof expr.value === 'string') {
          return JSON.stringify(expr.value);
        }
        if (expr.value === null) {
          return 'null';
        }
        return String(expr.value);
      }

      case 'Identifier': {
        // Retrieve variable value by looking up on the Environment instance or event fields
        if (expr.name.startsWith('event.')) {
          const subField = expr.name.split('.')[1];
          return `(env.get('event') ? env.get('event').${subField} : undefined)`;
        }
        return `env.get(${JSON.stringify(expr.name)})`;
      }

      case 'BinaryExpression': {
        const leftStr = this.compileExpression(expr.left);
        const rightStr = this.compileExpression(expr.right);

        switch (expr.operator) {
          case 'and':
            return `(${leftStr} && ${rightStr})`;
          case 'or':
            return `(${leftStr} || ${rightStr})`;
          case '==':
            return `(${leftStr} == ${rightStr})`;
          case '!=':
            return `(${leftStr} != ${rightStr})`;
          default:
            return `(${leftStr} ${expr.operator} ${rightStr})`;
        }
      }

      case 'CallExpression': {
        const argsStr = expr.arguments.map(arg => this.compileExpression(arg)).join(', ');
        
        // Match specific builtins
        if (['validate', 'hash', 'sign', 'verify', 'uuid', 'now', 'emit', 'log'].includes(expr.callee)) {
          return `await builtins.${expr.callee}(${argsStr})`;
        }
        
        // Dynamically invoke from user variables if needed
        return `await (env.get(${JSON.stringify(expr.callee)}) ?? (() => { throw new Error("Callee ${expr.callee} is undefined"); }))(${argsStr})`;
      }

      case 'AwaitExpression': {
        const valStr = this.compileExpression(expr.value);
        return `await (${valStr})`;
      }

      default:
        return `undefined`;
    }
  }
}
