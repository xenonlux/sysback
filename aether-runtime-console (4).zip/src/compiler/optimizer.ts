/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement, Expression, ASTNode } from '../runtime/types';

export class ASTOptimizer {
  /**
   * Optimizes an array of AST Statements recursively (Constant Folding & Dead Code Elimination)
   */
  public optimize(nodes: Statement[]): Statement[] {
    const optimized: Statement[] = [];

    for (const node of nodes) {
      const optNode = this.optimizeStatement(node);
      if (optNode) {
        optimized.push(optNode);
      }
    }

    return optimized;
  }

  /**
   * Optimize statement node. Can return null if statement is discarded as dead code.
   */
  private optimizeStatement(node: Statement): Statement | null {
    switch (node.type) {
      case 'LetStatement': {
        return {
          type: 'LetStatement',
          name: node.name,
          value: this.optimizeExpression(node.value)
        };
      }

      case 'FlowStatement': {
        const optimizedSteps = this.optimize(node.steps);
        return {
          type: 'FlowStatement',
          steps: optimizedSteps
        };
      }

      case 'EmitStatement': {
        return {
          type: 'EmitStatement',
          signal: node.signal,
          data: this.optimizeExpression(node.data)
        };
      }

      case 'YieldStatement': {
        return {
          type: 'YieldStatement',
          value: this.optimizeExpression(node.value)
        };
      }

      case 'IfStatement': {
        const optCond = this.optimizeExpression(node.condition);

        // Constant Folding / Dead Code Elimination on condition
        if (optCond.type === 'Literal') {
          const conditionIsTruthy = Boolean(optCond.value);
          this.logOptimization(`Dead code elimination: 'if' condition is constant [${optCond.value}]. Pruning alternate branches.`);
          if (conditionIsTruthy) {
            // Flatten block or return sequential flow
            return {
              type: 'FlowStatement',
              steps: this.optimize(node.consequent)
            };
          } else {
            return node.alternate 
              ? { type: 'FlowStatement', steps: this.optimize(node.alternate) }
              : null; // Discard completely
          }
        }

        return {
          type: 'IfStatement',
          condition: optCond,
          consequent: this.optimize(node.consequent),
          alternate: node.alternate ? this.optimize(node.alternate) : undefined
        };
      }

      case 'ExpressionStatement': {
        return {
          type: 'ExpressionStatement',
          expression: this.optimizeExpression(node.expression)
        };
      }

      default:
        return node;
    }
  }

  /**
   * Optimize expressions (specifically folding arithmetic or static lookups)
   */
  private optimizeExpression(expr: Expression): Expression {
    switch (expr.type) {
      case 'BinaryExpression': {
        const leftOpt = this.optimizeExpression(expr.left);
        const rightOpt = this.optimizeExpression(expr.right);

        // If both sides are constants (Folding)
        if (leftOpt.type === 'Literal' && rightOpt.type === 'Literal') {
          const lVal = leftOpt.value;
          const rVal = rightOpt.value;

          let foldedValue: any;
          switch (expr.operator) {
            case '+': foldedValue = lVal + rVal; break;
            case '-': foldedValue = lVal - rVal; break;
            case '*': foldedValue = lVal * rVal; break;
            case '/': foldedValue = lVal / rVal; break;
            case '==': foldedValue = lVal == rVal; break;
            case '!=': foldedValue = lVal != rVal; break;
            case '>': foldedValue = lVal > rVal; break;
            case '<': foldedValue = lVal < rVal; break;
            case 'and': foldedValue = lVal && rVal; break;
            case 'or': foldedValue = lVal || rVal; break;
            default: return { type: 'BinaryExpression', operator: expr.operator, left: leftOpt, right: rightOpt };
          }

          this.logOptimization(`Constant folded: ${lVal} ${expr.operator} ${rVal} → ${foldedValue}`);
          return {
            type: 'Literal',
            value: foldedValue
          };
        }

        return {
          type: 'BinaryExpression',
          operator: expr.operator,
          left: leftOpt,
          right: rightOpt
        };
      }

      case 'CallExpression': {
        return {
          type: 'CallExpression',
          callee: expr.callee,
          arguments: expr.arguments.map(arg => this.optimizeExpression(arg))
        };
      }

      case 'AwaitExpression': {
        return {
          type: 'AwaitExpression',
          value: this.optimizeExpression(expr.value)
        };
      }

      default:
        return expr;
    }
  }

  private logOptimization(msg: string): void {
    console.log(`[AETHER Optimizer] ${msg}`);
  }
}
