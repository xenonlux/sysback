/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ZeroTrustVerifier } from '../zero-trust/verifier';
import { PolicyEngine, AccessPolicy } from '../zero-trust/policy';
import { ImmutableAuditLogger, AuditRecord } from '../zero-trust/audit';
import { QuantumStatement, QuantumGuardConfig, QuantumDefenseStatus } from './language-types';
import { AetherMessage } from '../mesh/message';

/**
 * Supervised runtime plugin integrating Quantum Guard security seamlessly.
 */
export class AetherQuantumRuntimePlugin {
  private verifier: ZeroTrustVerifier;
  private policyEngine: PolicyEngine;
  private auditLogger: ImmutableAuditLogger;
  private config: QuantumGuardConfig;

  // Identity storage (Trust Anchors)
  private trustAnchors: Record<string, {
    did: string;
    dilithiumPubKey: Uint8Array;
    classicPubKey: any;
    fallbackClassicKeyHex?: string;
  }> = {};

  // Status tracking
  private intrusionCount = 0;
  private lastIntrusionSubject = '';

  constructor(
    config: QuantumGuardConfig = {
      minimumKeyStrength: 'ML-KEM-768',
      signatureStandard: 'ML-DSA-65',
      enforceZeroTrust: true,
      rejectDowngrades: true,
      shaVariant: 'SHA3-256'
    }
  ) {
    this.config = config;
    this.policyEngine = new PolicyEngine();
    this.auditLogger = new ImmutableAuditLogger();

    this.verifier = new ZeroTrustVerifier({
      policyEngine: this.policyEngine,
      auditLogger: this.auditLogger,
      dilithiumPublicKeys: {},
      classicPublicKeys: {},
      fallbackClassicKeysHex: {}
    });
  }

  /**
   * Registers a decentralized identity as a trusted anchor in the system
   */
  public registerTrustAnchor(identityPack: {
    did: string;
    dilithiumPubKey: Uint8Array;
    classicPubKey: any;
    fallbackClassicKeyHex?: string;
  }): void {
    this.trustAnchors[identityPack.did] = identityPack;

    // Refresh verifier keys directories
    const dils: Record<string, Uint8Array> = {};
    const classics: Record<string, any> = {};
    const fallbacks: Record<string, string> = {};

    for (const did of Object.keys(this.trustAnchors)) {
      dils[did] = this.trustAnchors[did].dilithiumPubKey;
      classics[did] = this.trustAnchors[did].classicPubKey;
      if (this.trustAnchors[did].fallbackClassicKeyHex) {
        fallbacks[did] = this.trustAnchors[did].fallbackClassicKeyHex!;
      }
    }

    this.verifier = new ZeroTrustVerifier({
      policyEngine: this.policyEngine,
      auditLogger: this.auditLogger,
      dilithiumPublicKeys: dils,
      classicPublicKeys: classics,
      fallbackClassicKeysHex: fallbacks
    });
  }

  public registerAccessPolicy(policy: AccessPolicy): void {
    this.policyEngine.addPolicy(policy);
  }

  public clearRules(): void {
    this.policyEngine.setPolicies([]);
    this.auditLogger.clear();
    this.trustAnchors = {};
    this.intrusionCount = 0;
    this.lastIntrusionSubject = '';
  }

  /**
   * Intercepts and validates execution statements that carry a "quantum" modifier
   */
  public async interceptExecution(
    node: QuantumStatement,
    message: AetherMessage
  ): Promise<{
    allowed: boolean;
    error?: string;
    auditRecord?: AuditRecord;
  }> {
    const isQuantumEnabled = node.modifiers?.includes('quantum') || node.quantumRequired || false;

    if (!isQuantumEnabled) {
      if (this.config.enforceZeroTrust) {
        // Under strict full Zero-Trust mode, all node requests must be checked.
        // Proceed to evaluation
      } else {
        // Classic path bypasses quantum checking
        return { allowed: true };
      }
    }

    // Run verification
    const verification = await this.verifier.verifyRequest(message, 'invoke');

    if (!verification.authorized) {
      this.intrusionCount++;
      this.lastIntrusionSubject = message.meta?.source || 'unknown-intruder';
      
      return {
        allowed: false,
        error: verification.error || 'Zero-Trust access denied',
        auditRecord: verification.auditRecord
      };
    }

    return {
      allowed: true,
      auditRecord: verification.auditRecord
    };
  }

  /**
   * Gets current defenses telemetry
   */
  public getTelemetry(): QuantumDefenseStatus {
    const history = this.auditLogger.getHistory();
    const lastHash = history.length > 0 ? history[history.length - 1].hash : 'Genesis';

    return {
      quantumLayerActive: true,
      totalVerifiedPostQuantumCalls: history.filter(h => h.decision === 'allow').length,
      totalBlockedIntrusions: this.intrusionCount,
      lastIntrusionVector: this.lastIntrusionSubject || undefined,
      trustAnchorsCount: Object.keys(this.trustAnchors).length,
      auditChainHash: lastHash
    };
  }

  public getAuditHistory(): AuditRecord[] {
    return this.auditLogger.getHistory();
  }

  public getAuditLogger(): ImmutableAuditLogger {
    return this.auditLogger;
  }
}
