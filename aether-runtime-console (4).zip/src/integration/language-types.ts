/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement } from '../runtime/types';

/**
 * Extends standard Statements to define AETHER "quantum" security modifier AST tags
 */
export type QuantumStatement = Statement & {
  modifiers?: string[]; // e.g. ["quantum"]
  securityPolicyId?: string;
  quantumRequired?: boolean;
};

/**
 * Config structure for runtime handlers and triggers of "quantum" flows
 */
export interface QuantumGuardConfig {
  minimumKeyStrength: 'ML-KEM-768' | 'ML-KEM-1024';
  signatureStandard: 'ML-DSA-65' | 'ML-DSA-85';
  enforceZeroTrust: boolean;
  rejectDowngrades: boolean;
  shaVariant: 'SHA3-256' | 'SHA3-512';
}

/**
 * State container representing active system quantum defenses
 */
export interface QuantumDefenseStatus {
  quantumLayerActive: boolean;
  totalVerifiedPostQuantumCalls: number;
  totalBlockedIntrusions: number;
  lastIntrusionVector?: string;
  trustAnchorsCount: number;
  auditChainHash: string;
}
