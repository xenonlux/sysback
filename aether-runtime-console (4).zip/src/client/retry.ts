/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CircuitBreakerConfig {
  failureThreshold: number; // Number of failed transactions before opening circuit
  cooldownPeriodMs: number; // Settle downtime before probing with test loads
}

/**
 * Clean self-monitoring state machine guarding sensitive target pipelines.
 */
export class CircuitBreaker {
  private state: 'CLOSED' | 'OPEN' | 'HALF-OPEN' = 'CLOSED';
  private failureCount = 0;
  private lastFailureTime = 0;

  constructor(private readonly config: CircuitBreakerConfig) {}

  public getState(): 'CLOSED' | 'OPEN' | 'HALF-OPEN' {
    this.checkExpiration();
    return this.state;
  }

  public forceState(state: 'CLOSED' | 'OPEN' | 'HALF-OPEN'): void {
    this.state = state;
    if (state === 'CLOSED') {
      this.failureCount = 0;
    } else if (state === 'OPEN') {
      this.lastFailureTime = Date.now();
    }
  }

  private checkExpiration(): void {
    if (this.state === 'OPEN') {
      const elapsed = Date.now() - this.lastFailureTime;
      if (elapsed >= this.config.cooldownPeriodMs) {
        this.state = 'HALF-OPEN';
      }
    }
  }

  /**
   * Evaluates task execution, managing failure metrics.
   */
  public async execute<T>(fn: () => Promise<T>): Promise<T> {
    this.checkExpiration();

    if (this.state === 'OPEN') {
      throw new Error('CircuitBreaker: Circuit is in OPEN state. Execution blocked.');
    }

    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (err) {
      this.recordFailure();
      throw err;
    }
  }

  private recordSuccess(): void {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }

  private recordFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    
    if (this.state === 'HALF-OPEN' || this.failureCount >= this.config.failureThreshold) {
      this.state = 'OPEN';
    }
  }
}

/**
 * Exponential backoff helper retrying transient connectivity concerns.
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxAttempts = 3,
  initialDelayMs = 100,
  backoffFactor = 2
): Promise<T> {
  let attempt = 0;
  while (true) {
    try {
      return await fn();
    } catch (err) {
      attempt++;
      if (attempt >= maxAttempts) {
        throw err;
      }
      const delay = initialDelayMs * Math.pow(backoffFactor, attempt - 1);
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
}
