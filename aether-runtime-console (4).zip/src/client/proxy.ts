/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MeshRouter } from '../mesh/router';
import { LoadBalancer } from './load-balancer';
import { CircuitBreaker } from './retry';
import { createAetherMessage, AetherMessage } from '../mesh/message';

export interface ProxyClientConfig {
  router: MeshRouter;
  loadBalancer?: LoadBalancer;
  circuitBreaker?: CircuitBreaker;
  timeoutMs?: number;
  sourceId?: string;
}

/**
 * ES6 dynamic client proxy layer allowing clean fluent RPC syntax calls on top of Aether Message channels.
 */
export function createAetherClientProxy(config: ProxyClientConfig): any {
  const pendingRequests = new Map<
    string,
    { resolve: (val: any) => void; reject: (err: any) => void; timeout: NodeJS.Timeout }
  >();
  const timeoutMs = config.timeoutMs ?? 5000;
  const router = config.router;
  const source = config.sourceId || 'proxy-client';
  const transportListeners = new Set<string>();

  const makeProxy = (path: string[] = []): any => {
    return new Proxy(() => {}, {
      get(_target, prop: string) {
        if (typeof prop === 'string') {
          // Safeguard primitive lookups during runtime inspections or console prints
          if (
            prop === 'then' ||
            prop === 'catch' ||
            prop === 'finally' ||
            prop === 'toString' ||
            prop === 'inspect'
          ) {
            return undefined;
          }
          return makeProxy([...path, prop]);
        }
        return undefined;
      },
      apply(_target, _thisArg, args) {
        const targetPath = path.join('.');
        const payload = args[0] !== undefined ? args[0] : null;

        return new Promise(async (resolve, reject) => {
          let address = 'local';
          if (config.loadBalancer) {
            try {
              address = config.loadBalancer.select();
            } catch (err) {
              return reject(err);
            }
          }

          if (config.loadBalancer) {
            config.loadBalancer.incrementConnection(address);
          }

          const callMsg = createAetherMessage('call', targetPath, payload, { source });
          
          let targetTransport;
          try {
            targetTransport = router.selectTransport(address);
          } catch (err) {
            if (config.loadBalancer) {
              config.loadBalancer.decrementConnection(address);
            }
            return reject(err);
          }

          // Dynamically bind to bidirectional responses from this transport if not yet bound
          if (!transportListeners.has(targetTransport.name)) {
            targetTransport.onMessage((reply) => {
              // Match reply using standard correlation fields
              const req = pendingRequests.get(reply.id) || pendingRequests.get(reply.meta.traceId);
              if (req) {
                clearTimeout(req.timeout);
                pendingRequests.delete(reply.id);
                pendingRequests.delete(reply.meta.traceId);
                req.resolve(reply.payload);
              }
            });
            transportListeners.add(targetTransport.name);
          }

          const timeout = setTimeout(() => {
            pendingRequests.delete(callMsg.id);
            if (config.loadBalancer) {
              config.loadBalancer.decrementConnection(address);
            }
            reject(
              new Error(
                `AETHER RPC Proxy Timeout: Call to "${targetPath}" on target address "${address}" expired after ${timeoutMs}ms.`
              )
            );
          }, timeoutMs);

          pendingRequests.set(callMsg.id, {
            resolve: (val) => {
              if (config.loadBalancer) {
                config.loadBalancer.decrementConnection(address);
              }
              resolve(val);
            },
            reject: (err) => {
              if (config.loadBalancer) {
                config.loadBalancer.decrementConnection(address);
              }
              reject(err);
            },
            timeout,
          });

          const deliverMsg = async () => {
            // Guarantee transport is actively established before sending
            await router.connect(address);
            await targetTransport.send(callMsg);
          };

          try {
            if (config.circuitBreaker) {
              await config.circuitBreaker.execute(deliverMsg);
            } else {
              await deliverMsg();
            }
          } catch (err) {
            clearTimeout(timeout);
            pendingRequests.delete(callMsg.id);
            if (config.loadBalancer) {
              config.loadBalancer.decrementConnection(address);
            }
            reject(err);
          }
        });
      },
    });
  };

  return makeProxy();
}
