/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type LoadBalancingStrategy = 'round-robin' | 'least-connections';

/**
 * Traffic controller distributing incoming network loads across service target endpoints.
 */
export class LoadBalancer {
  private currentIndex = 0;
  private readonly connectionCounts = new Map<string, number>();

  constructor(
    private addresses: string[],
    private strategy: LoadBalancingStrategy = 'round-robin'
  ) {
    this.syncAddresses(addresses);
  }

  public setStrategy(strategy: LoadBalancingStrategy): void {
    this.strategy = strategy;
  }

  public getStrategy(): LoadBalancingStrategy {
    return this.strategy;
  }

  /**
   * Resets or aligns endpoints maintaining prior active counts intact.
   */
  public syncAddresses(addresses: string[]): void {
    this.addresses = addresses;
    for (const addr of addresses) {
      if (!this.connectionCounts.has(addr)) {
        this.connectionCounts.set(addr, 0);
      }
    }
    // Prune deprecated targets
    for (const key of Array.from(this.connectionCounts.keys())) {
      if (!addresses.includes(key)) {
        this.connectionCounts.delete(key);
      }
    }
    // Prevent out-of-index states
    if (this.currentIndex >= this.addresses.length) {
      this.currentIndex = 0;
    }
  }

  /**
   * Chooses optimal target path according to active routing policy.
   */
  public select(): string {
    if (this.addresses.length === 0) {
      throw new Error('LoadBalancer: Target pool is completely empty.');
    }

    if (this.strategy === 'round-robin') {
      const selected = this.addresses[this.currentIndex];
      this.currentIndex = (this.currentIndex + 1) % this.addresses.length;
      return selected;
    } else {
      // Least-connections strategy selection
      let selected = this.addresses[0];
      let minConns = this.connectionCounts.get(selected) ?? 0;

      for (const addr of this.addresses) {
        const conns = this.connectionCounts.get(addr) ?? 0;
        if (conns < minConns) {
          minConns = conns;
          selected = addr;
        }
      }
      return selected;
    }
  }

  public incrementConnection(address: string): void {
    const current = this.connectionCounts.get(address) ?? 0;
    this.connectionCounts.set(address, current + 1);
  }

  public decrementConnection(address: string): void {
    const current = this.connectionCounts.get(address) ?? 0;
    if (current > 0) {
      this.connectionCounts.set(address, current - 1);
    }
  }

  public getConnectionCounts(): Record<string, number> {
    const counters: Record<string, number> = {};
    for (const [addr, count] of this.connectionCounts.entries()) {
      counters[addr] = count;
    }
    return counters;
  }
}
