/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Executor } from '../runtime/executor';
import { Environment } from '../runtime/environment';
import { EventBus } from '../runtime/event-bus';
import { Statement } from '../runtime/types';

export class NodeRuntimeAdapter {
  private executor: Executor;
  private rootEnv: Environment;
  private mockFs: Map<string, string> = new Map();

  constructor(eventBus: EventBus, envVars: Record<string, string> = {}) {
    this.executor = new Executor(eventBus);
    this.rootEnv = new Environment();

    // Load static environment variables
    for (const [key, val] of Object.entries(envVars)) {
      this.rootEnv.declare(`process.env.${key}`, val);
    }

    // Set up standard platform details
    this.rootEnv.declare('PLATFORM', 'NodeJS');
    this.rootEnv.declare('ARCH', 'x64');

    // Register basic OS filesystem simulators in lexical environment
    this.rootEnv.declare('fs_readFile', async (path: string) => {
      if (this.mockFs.has(path)) {
        return this.mockFs.get(path);
      }
      throw new Error(`ENOENT: no such file or directory, read '${path}'`);
    });

    this.rootEnv.declare('fs_writeFile', async (path: string, content: string) => {
      this.mockFs.set(path, content);
      return true;
    });
  }

  /**
   * Helper to write a test file prior to execution
   */
  public writeFile(path: string, content: string): void {
    this.mockFs.set(path, content);
  }

  /**
   * Helper to read a file
   */
  public readFile(path: string): string | undefined {
    return this.mockFs.get(path);
  }

  /**
   * Execute AST block in this NodeJS system environment
   */
  public async execute(nodes: Statement | Statement[]): Promise<any> {
    this.executor.clearLogs();
    const result = await this.executor.execute(nodes, this.rootEnv);
    return {
      result,
      logs: this.executor.getLogs(),
      environment: this.rootEnv.getLocalBinds()
    };
  }
}
