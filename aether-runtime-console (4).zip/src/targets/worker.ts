/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Executor } from '../runtime/executor';
import { Environment } from '../runtime/environment';
import { EventBus } from '../runtime/event-bus';
import { Statement } from '../runtime/types';

export class WorkerRuntimeAdapter {
  private executor: Executor;
  private rootEnv: Environment;
  private onMessageCallback: ((event: { data: any }) => void) | null = null;
  private postedMessages: any[] = [];

  constructor(eventBus: EventBus) {
    this.executor = new Executor(eventBus);
    this.rootEnv = new Environment();

    this.rootEnv.declare('PLATFORM', 'WebWorker');
    this.rootEnv.declare('IS_WORKER', true);

    // Register active postMessage and onmessage binds inside worker
    this.rootEnv.declare('postMessage', (data: any) => {
      this.postedMessages.push(data);
    });

    this.rootEnv.declare('setOnMessage', (callback: (e: any) => void) => {
      this.onMessageCallback = callback;
    });
  }

  /**
   * Post message into the running worker environment
   */
  public receiveTask(data: any): void {
    if (this.onMessageCallback) {
      this.onMessageCallback({ data });
    }
  }

  /**
   * Get messages sent out from this worker environment
   */
  public getPostedMessages(): any[] {
    return this.postedMessages;
  }

  /**
   * Clear outer posted message cash
   */
  public clearPostedMessages(): void {
    this.postedMessages = [];
  }

  public async execute(nodes: Statement | Statement[]): Promise<any> {
    this.executor.clearLogs();
    const result = await this.executor.execute(nodes, this.rootEnv);
    return {
      result,
      logs: this.executor.getLogs(),
      environment: this.rootEnv.getLocalBinds()
    };
  }
}
