/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Executor } from '../runtime/executor';
import { Environment } from '../runtime/environment';
import { EventBus } from '../runtime/event-bus';
import { Statement } from '../runtime/types';

export class BrowserRuntimeAdapter {
  private executor: Executor;
  private rootEnv: Environment;
  private messageListeners: Set<(msg: any) => void> = new Set();

  constructor(eventBus: EventBus) {
    this.executor = new Executor(eventBus);
    this.rootEnv = new Environment();

    this.rootEnv.declare('PLATFORM', 'Browser');
    this.rootEnv.declare('USER_AGENT', 'Mozilla/5.0 Sandboxed');

    // Implement browser postMessage/addEventListener style interactions
    this.rootEnv.declare('window_postMessage', (data: any) => {
      // Simulate asynchronous posting
      setTimeout(() => {
        for (const listener of this.messageListeners) {
          listener({ data });
        }
      }, 0);
    });

    this.rootEnv.declare('window_addEventListener', (type: string, callback: (msg: any) => void) => {
      if (type === 'message') {
        this.messageListeners.add(callback);
      }
    });
  }

  /**
   * Triggers an simulated incoming postMessage message into the browser sandbox
   */
  public simulateMessage(data: any): void {
    for (const listener of this.messageListeners) {
      listener({ data });
    }
  }

  public async execute(nodes: Statement | Statement[]): Promise<any> {
    this.executor.clearLogs();
    const result = await this.executor.execute(nodes, this.rootEnv);
    return {
      result,
      logs: this.executor.getLogs(),
      environment: this.rootEnv.getLocalBinds()
    };
  }
}
