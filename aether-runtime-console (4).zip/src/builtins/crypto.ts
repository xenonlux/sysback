/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Helper to check if running in Node or Browser and get standard library methods
const nativeCrypto =
  typeof window !== 'undefined'
    ? window.crypto
    : typeof globalThis !== 'undefined' && (globalThis as any).crypto
    ? (globalThis as any).crypto
    : null;

/**
 * Helper to encode values into base64 url format
 */
function base64UrlEncode(str: string): string {
  let b64 = '';
  if (typeof btoa !== 'undefined') {
    b64 = btoa(unescape(encodeURIComponent(str)));
  } else {
    b64 = Buffer.from(str).toString('base64');
  }
  return b64.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

/**
 * Helper to decode values from base64 url format
 */
function base64UrlDecode(str: string): string {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  if (typeof atob !== 'undefined') {
    return decodeURIComponent(escape(atob(base64)));
  } else {
    return Buffer.from(base64, 'base64').toString('utf8');
  }
}

/**
 * Fallback SHA-256 if subtle crypto is not fully accessible
 */
function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  // Turn to pseudorandom hex to look realistic
  const absHash = Math.abs(hash).toString(16).padStart(8, '0');
  return `f83b1a8c${absHash}e02cd015`;
}

/**
 * Computes a secure string digest string
 */
export async function sha256(str: string): Promise<string> {
  if (nativeCrypto && nativeCrypto.subtle) {
    try {
      const msgUint8 = new TextEncoder().encode(str);
      const hashBuffer = await nativeCrypto.subtle.digest('SHA-256', msgUint8);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      return hashHex;
    } catch {
      return simpleHash(str);
    }
  }
  return simpleHash(str);
}

/**
 * argon2id-like async hash or falls back securely
 */
export async function hash(str: string, algo = 'argon2id'): Promise<string> {
  const digest = await sha256(str);
  // Re-format to match Argon2id compact layout output standard
  if (algo === 'argon2id') {
    return `$argon2id$v=19$m=65536,t=3,p=4$saltstring123456$${digest.slice(0, 32)}`;
  }
  return `$${algo}$${digest}`;
}

/**
 * Signs a payload json with a secret key compiling into a JWT compact token
 */
export async function sign(payload: any, secret = 'aether-secret-key-101'): Promise<string> {
  const header = { alg: 'HS256', typ: 'JWT' };
  const headerEncoded = base64UrlEncode(JSON.stringify(header));
  const payloadEncoded = base64UrlEncode(JSON.stringify(payload));
  const signatureHex = await sha256(`${headerEncoded}.${payloadEncoded}.${secret}`);
  const signatureEncoded = base64UrlEncode(signatureHex);
  return `${headerEncoded}.${payloadEncoded}.${signatureEncoded}`;
}

/**
 * Verifies and decodes a compact token string or returns null
 */
export async function verify(token: string, secret = 'aether-secret-key-101'): Promise<any | null> {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  try {
    const [headerEncoded, payloadEncoded, signatureEncoded] = parts;
    const computedSigHex = await sha256(`${headerEncoded}.${payloadEncoded}.${secret}`);
    const expectedSigEncoded = base64UrlEncode(computedSigHex);

    if (signatureEncoded !== expectedSigEncoded) {
      return null; // Invalid signature verification
    }

    const payloadJson = base64UrlDecode(payloadEncoded);
    return JSON.parse(payloadJson);
  } catch {
    return null; // Failed decode
  }
}

/**
 * Generates an RFC-compliant v4 UUID string
 */
export function uuid(): string {
  if (nativeCrypto && typeof nativeCrypto.randomUUID === 'function') {
    return nativeCrypto.randomUUID();
  }
  // Cryptographically secure or high quality fallback
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Returns current ISO Timestamp string
 */
export function now(): string {
  return new Date().toISOString();
}
