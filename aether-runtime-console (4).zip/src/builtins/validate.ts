/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ValidationSchema, ValidationError } from '../runtime/types';

/**
 * Validates any object or value against a ValidationSchema.
 * Returns the sanitized dataset or throws a ValidationError.
 */
export function validate(data: any, schema: ValidationSchema): any {
  if (!schema) {
    return data;
  }

  const errors: string[] = [];

  // 1. Check primary types
  const dataType = typeof data;
  if (schema.type === 'object') {
    if (!data || Array.isArray(data) || dataType !== 'object') {
      throw new ValidationError([`Expected an object dataset, but received '${dataType}'`]);
    }

    const validatedObject: Record<string, any> = {};

    // 2. Validate fields if properties exist
    const props = schema.properties || {};
    const requiredFields = schema.required || [];

    // Check required keys
    for (const reqField of requiredFields) {
      if (!(reqField in data) || data[reqField] === undefined || data[reqField] === null) {
        errors.push(`Missing required field: '${reqField}'`);
      }
    }

    // Check individual property types
    for (const key of Object.keys(props)) {
      const propRule = props[key];
      const val = data[key];

      if (val === undefined || val === null) {
        if (propRule.required) {
          errors.push(`Missing required property field: '${key}'`);
        }
        continue;
      }

      const valType = typeof val;
      if (propRule.type && valType !== propRule.type) {
        errors.push(`Key '${key}' type mismatch: Expected '${propRule.type}', got '${valType}'`);
      } else {
        validatedObject[key] = val;
      }
    }

    // Collect any extra unmapped fields as-is
    for (const key of Object.keys(data)) {
      if (!(key in props)) {
        validatedObject[key] = data[key];
      }
    }

    if (errors.length > 0) {
      throw new ValidationError(errors);
    }

    return validatedObject;
  } else {
    // Scalar validation (string, number, boolean)
    if (dataType !== schema.type) {
      throw new ValidationError([`Type mismatch: Expected value to be of type '${schema.type}', got '${dataType}'`]);
    }
    return data;
  }
}
