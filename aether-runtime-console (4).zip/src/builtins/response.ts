/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AetherResponseInit {
  status?: number;
  statusText?: string;
  headers?: Record<string, string>;
}

export class AetherResponse {
  public status: number;
  public statusText: string;
  public headers: Map<string, string>;
  private _body: any;

  constructor(body?: any, init?: AetherResponseInit) {
    this.status = init?.status ?? 200;
    this.statusText = init?.statusText ?? 'OK';
    this.headers = new Map(Object.entries(init?.headers ?? {}));
    this._body = body;

    if (!this.headers.has('Content-Type')) {
      if (typeof body === 'object') {
        this.headers.set('Content-Type', 'application/json');
      } else {
        this.headers.set('Content-Type', 'text/plain');
      }
    }
  }

  /**
   * Access response body or serialized JSON
   */
  public async json(): Promise<any> {
    if (typeof this._body === 'string') {
      try {
        return JSON.parse(this._body);
      } catch {
        return this._body;
      }
    }
    return this._body;
  }

  /**
   * Read response raw body text representation
   */
  public async text(): Promise<string> {
    if (typeof this._body === 'object') {
      return JSON.stringify(this._body, null, 2);
    }
    return String(this._body ?? '');
  }

  /**
   * Convenient chainable static constructor for JSON responses
   */
  public static json(data: any, init?: AetherResponseInit): AetherResponse {
    const responseInit = {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init?.headers ?? {})
      }
    };
    return new AetherResponse(data, responseInit);
  }

  /**
   * Convenient chainable static constructor for text content
   */
  public static text(data: string, init?: AetherResponseInit): AetherResponse {
    return new AetherResponse(data, init);
  }
}
