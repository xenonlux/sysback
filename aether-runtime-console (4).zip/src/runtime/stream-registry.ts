/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { StreamListener, AetherEvent } from './types';
import { EventBus } from './event-bus';

export interface StreamDef {
  id: string;
  signal: string;
  handlerAST: any; // AST node to evaluate when event fires
  filter?: (event: AetherEvent) => boolean;
}

export class StreamRegistry {
  private eventBus: EventBus;
  private activeStreams: Map<string, { definition: StreamDef; unsubscribe: () => void }> = new Map();

  constructor(eventBus: EventBus) {
    this.eventBus = eventBus;
  }

  /**
   * Register and start a stream listener.
   * Runs the evaluation compiler/executor when a message triggers.
   */
  public registerStream(
    def: StreamDef,
    executeHandler: (handlerAST: any, event: AetherEvent) => Promise<void>
  ): void {
    // If stream already exists, tear it down first to avoid duplicate bindings
    this.unregisterStream(def.id);

    const listener: StreamListener = {
      id: def.id,
      signal: def.signal,
      filter: def.filter,
      handler: async (event: AetherEvent) => {
        await executeHandler(def.handlerAST, event);
      }
    };

    const unsubscribe = this.eventBus.subscribe(def.signal, listener);
    this.activeStreams.set(def.id, {
      definition: def,
      unsubscribe
    });
  }

  /**
   * Stop an active stream and release its resources
   */
  public unregisterStream(streamId: string): boolean {
    const entry = this.activeStreams.get(streamId);
    if (entry) {
      entry.unsubscribe();
      this.activeStreams.delete(streamId);
      return true;
    }
    return false;
  }

  /**
   * Get all registered active streams
   */
  public getActiveStreams(): StreamDef[] {
    return Array.from(this.activeStreams.values()).map(entry => entry.definition);
  }

  /**
   * Tear down all streams
   */
  public clear(): void {
    for (const entry of this.activeStreams.values()) {
      entry.unsubscribe();
    }
    this.activeStreams.clear();
  }
}
