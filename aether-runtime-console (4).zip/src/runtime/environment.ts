/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class Environment {
  private values: Map<string, any> = new Map();
  private parent: Environment | null = null;

  constructor(parent: Environment | null = null) {
    this.parent = parent;
  }

  /**
   * Declare a variable in the current scope
   */
  public declare(name: string, value: any): void {
    this.values.set(name, value);
  }

  /**
   * Assign a new value to an existing variable in the closest scope
   */
  public assign(name: string, value: any): void {
    if (this.values.has(name)) {
      this.values.set(name, value);
      return;
    }

    if (this.parent) {
      this.parent.assign(name, value);
      return;
    }

    // Default to declaring in current scope if not declared anywhere, preventing crash but ensuring assignment
    this.declare(name, value);
  }

  /**
   * Retrieve a variable value from the current or ancestral scope
   */
  public get(name: string): any {
    if (this.values.has(name)) {
      return this.values.get(name);
    }

    if (this.parent) {
      return this.parent.get(name);
    }

    return undefined;
  }

  /**
   * Check if a variable exists in any visible scope
   */
  public has(name: string): boolean {
    if (this.values.has(name)) {
      return true;
    }
    if (this.parent) {
      return this.parent.has(name);
    }
    return false;
  }

  /**
   * Get all declared variables in the local scope for inspector purposes
   */
  public getLocalBinds(): Record<string, any> {
    const record: Record<string, any> = {};
    for (const [key, val] of this.values.entries()) {
      record[key] = val;
    }
    return record;
  }
}
