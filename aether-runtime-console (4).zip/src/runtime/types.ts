/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ASTNode = Statement | Expression;

export type Statement =
  | LetStatement
  | FlowStatement
  | EmitStatement
  | YieldStatement
  | IfStatement
  | ExpressionStatement;

export type Expression =
  | LiteralExpression
  | IdentifierExpression
  | BinaryExpression
  | CallExpression
  | AwaitExpression;

export interface LetStatement {
  type: 'LetStatement';
  name: string;
  value: Expression;
}

export interface FlowStatement {
  type: 'FlowStatement';
  steps: Statement[];
}

export interface EmitStatement {
  type: 'EmitStatement';
  signal: string;
  data: Expression;
}

export interface YieldStatement {
  type: 'YieldStatement';
  value: Expression;
}

export interface IfStatement {
  type: 'IfStatement';
  condition: Expression;
  consequent: Statement[];
  alternate?: Statement[];
}

export interface ExpressionStatement {
  type: 'ExpressionStatement';
  expression: Expression;
}

export interface LiteralExpression {
  type: 'Literal';
  value: any;
}

export interface IdentifierExpression {
  type: 'Identifier';
  name: string;
}

export interface BinaryExpression {
  type: 'BinaryExpression';
  operator: '+' | '-' | '*' | '/' | '==' | '!=' | '>' | '<' | 'and' | 'or';
  left: Expression;
  right: Expression;
}

export interface CallExpression {
  type: 'CallExpression';
  callee: string;
  arguments: Expression[];
}

export interface AwaitExpression {
  type: 'AwaitExpression';
  value: Expression;
}

// Runtime Structures
export interface AetherEvent {
  id: string;
  signal: string;
  timestamp: string;
  data: any;
}

export interface StreamListener {
  id: string;
  signal: string;
  filter?: (event: AetherEvent) => boolean;
  handler: (event: AetherEvent) => Promise<void>;
}

export interface ValidationSchema {
  type: 'object' | 'string' | 'number' | 'boolean';
  properties?: Record<string, { type: string; required?: boolean }>;
  required?: string[];
}

export class ValidationError extends Error {
  public valErrors: string[];
  constructor(errors: string[]) {
    super(`Validation failed: ${errors.join(', ')}`);
    this.name = 'ValidationError';
    this.valErrors = errors;
  }
}
