/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherEvent, StreamListener } from './types';

export class EventBus {
  private listeners: Map<string, Set<StreamListener>> = new Map();
  private globalListeners: Set<(event: AetherEvent) => void> = new Set();
  private errorHandlers: Set<(error: Error, event: AetherEvent, listenerId: string) => void> = new Set();

  /**
   * Subscribe to a signal name or glob-like pattern (e.g., 'user.*', '*')
   */
  public subscribe(signal: string, listener: StreamListener): () => void {
    if (!this.listeners.has(signal)) {
      this.listeners.set(signal, new Set());
    }
    this.listeners.get(signal)!.add(listener);

    return () => {
      const set = this.listeners.get(signal);
      if (set) {
        set.delete(listener);
        if (set.size === 0) {
          this.listeners.delete(signal);
        }
      }
    };
  }

  /**
   * Subscribe to all passing events (used for global loggers or UI inspectors)
   */
  public subscribeAll(callback: (event: AetherEvent) => void): () => void {
    this.globalListeners.add(callback);
    return () => {
      this.globalListeners.delete(callback);
    };
  }

  /**
   * Register a failure handler to catch individual listener bubbles
   */
  public onError(handler: (error: Error, event: AetherEvent, listenerId: string) => void): void {
    this.errorHandlers.add(handler);
  }

  /**
   * Check if a signal pattern covers the emitted signal
   */
  private matchSignal(pattern: string, signal: string): boolean {
    if (pattern === '*' || pattern === signal) {
      return true;
    }
    if (pattern.includes('*')) {
      const regexStr = '^' + pattern.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$';
      const regex = new RegExp(regexStr);
      return regex.test(signal);
    }
    return false;
  }

  /**
   * Emits an event with a payload, routing to all matching listeners concurrently or sequentially
   */
  public async emit(signal: string, data: any): Promise<void> {
    const event: AetherEvent = {
      id: Math.random().toString(36).substring(2, 11),
      signal,
      timestamp: new Date().toISOString(),
      data
    };

    // Trigger global inspectors
    for (const callback of this.globalListeners) {
      try {
        callback(event);
      } catch (err) {
        console.error('Error in EventBus global listener:', err);
      }
    }

    const promises: Promise<void>[] = [];

    // Find all matching listener registration patterns
    for (const [pattern, set] of this.listeners.entries()) {
      if (this.matchSignal(pattern, signal)) {
        for (const listener of set) {
          // Check custom filter function if any
          if (listener.filter && !listener.filter(event)) {
            continue;
          }

          const promise = (async () => {
            try {
              await listener.handler(event);
            } catch (err: any) {
              // Isolated error handling per handler
              const errorObj = err instanceof Error ? err : new Error(String(err));
              for (const errHandler of this.errorHandlers) {
                try {
                  errHandler(errorObj, event, listener.id);
                } catch (internalErr) {
                  console.error('Err callback threw:', internalErr);
                }
              }
            }
          })();

          promises.push(promise);
        }
      }
    }

    // Wait for all matched handlers to trigger
    await Promise.all(promises);
  }

  /**
   * Clear all sub chains
   */
  public clear(): void {
    this.listeners.clear();
    this.globalListeners.clear();
    this.errorHandlers.clear();
  }
}
