/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ASTNode, Statement, Expression, ValidationError } from './types';
import { Environment } from './environment';
import { EventBus } from './event-bus';
import { validate } from '../builtins/validate';
import { hash, sign, verify, uuid, now } from '../builtins/crypto';

export interface ExecutionTraceLog {
  timestamp: string;
  type: 'log' | 'info' | 'error' | 'success';
  message: string;
}

export class Executor {
  private eventBus: EventBus;
  private logs: ExecutionTraceLog[] = [];
  private yieldValue: any = null;

  constructor(eventBus: EventBus) {
    this.eventBus = eventBus;
  }

  /**
   * Return the accumulated code output details
   */
  public getLogs(): ExecutionTraceLog[] {
    return this.logs;
  }

  /**
   * Clear trace lists
   */
  public clearLogs(): void {
    this.logs = [];
    this.yieldValue = null;
  }

  /**
   * Push a trace item
   */
  private trace(type: 'log' | 'info' | 'error' | 'success', message: string): void {
    this.logs.push({
      timestamp: new Date().toLocaleTimeString(),
      type,
      message
    });
  }

  /**
   * Returns the final yielded value if any
   */
  public getYieldValue(): any {
    return this.yieldValue;
  }

  /**
   * Main entrypoint to execute a top-level statement or sequence of statement AST nodes
   */
  public async execute(nodes: Statement | Statement[], env: Environment): Promise<any> {
    const list = Array.isArray(nodes) ? nodes : [nodes];
    for (const node of list) {
      await this.executeStatement(node, env);
    }
    return this.yieldValue;
  }

  /**
   * Walks and executes a single structural statement node
   */
  private async executeStatement(node: Statement, env: Environment): Promise<void> {
    switch (node.type) {
      case 'LetStatement': {
        const val = await this.evaluateExpression(node.value, env);
        env.declare(node.name, val);
        this.trace('info', `Declared let: ${node.name} = ${JSON.stringify(val)}`);
        break;
      }

      case 'FlowStatement': {
        this.trace('info', `Entering sequential Flow block (${node.steps.length} steps)...`);
        // Establish matching scope wrapper block
        const nestedEnv = new Environment(env);
        for (const subStmt of node.steps) {
          await this.executeStatement(subStmt, nestedEnv);
        }
        this.trace('info', `Exited sequential Flow block.`);
        break;
      }

      case 'EmitStatement': {
        const evaluatedData = await this.evaluateExpression(node.data, env);
        this.trace('info', `Emitting event '${node.signal}' with data ${JSON.stringify(evaluatedData)}`);
        // Trigger async execution of subscribers through EventBus
        await this.eventBus.emit(node.signal, evaluatedData);
        break;
      }

      case 'YieldStatement': {
        const payload = await this.evaluateExpression(node.value, env);
        this.yieldValue = payload;
        // Also save yielded state under special '_yield' variable context
        env.assign('_yield', payload);
        this.trace('success', `Yielded value: ${JSON.stringify(payload)}`);
        break;
      }

      case 'IfStatement': {
        const rawCond = await this.evaluateExpression(node.condition, env);
        const cond = Boolean(rawCond);
        this.trace('info', `Evaluating condition: resolved to ${cond}`);

        if (cond) {
          const nested = new Environment(env);
          for (const step of node.consequent) {
            await this.executeStatement(step, nested);
          }
        } else if (node.alternate) {
          const nested = new Environment(env);
          for (const step of node.alternate) {
            await this.executeStatement(step, nested);
          }
        }
        break;
      }

      case 'ExpressionStatement': {
        await this.evaluateExpression(node.expression, env);
        break;
      }

      default:
        throw new Error(`Execution failure: Unhandled statement type "${(node as any).type}"`);
    }
  }

  /**
   * Helper to resolve mathematical and logical expressions
   */
  private async evaluateExpression(expr: Expression, env: Environment): Promise<any> {
    switch (expr.type) {
      case 'Literal':
        return expr.value;

      case 'Identifier': {
        const val = env.get(expr.name);
        if (val === undefined) {
          // If referencing active event variables inside event listener flows:
          // e.g., 'event.data' or similar path handles
          if (expr.name.startsWith('event')) {
            const ev = env.get('event');
            if (ev) {
              if (expr.name === 'event.data') return ev.data;
              if (expr.name === 'event.signal') return ev.signal;
              if (expr.name === 'event.timestamp') return ev.timestamp;
              if (expr.name === 'event.id') return ev.id;
            }
          }
          this.trace('info', `ReferenceWarning: identifier '${expr.name}' was not initialized in scope, falling back to undefined`);
        }
        return val;
      }

      case 'BinaryExpression': {
        const leftValue = await this.evaluateExpression(expr.left, env);
        const rightValue = await this.evaluateExpression(expr.right, env);

        switch (expr.operator) {
          case '+':
            return leftValue + rightValue;
          case '-':
            return leftValue - rightValue;
          case '*':
            return leftValue * rightValue;
          case '/':
            return leftValue / rightValue;
          case '==':
            return leftValue == rightValue;
          case '!=':
            return leftValue != rightValue;
          case '>':
            return leftValue > rightValue;
          case '<':
            return leftValue < rightValue;
          case 'and':
            return leftValue && rightValue;
          case 'or':
            return leftValue || rightValue;
          default:
            throw new Error(`Unknown binary operator: ${(expr as any).operator}`);
        }
      }

      case 'CallExpression': {
        return await this.evaluateCall(expr.callee, expr.arguments, env);
      }

      case 'AwaitExpression': {
        const promiseOrValue = await this.evaluateExpression(expr.value, env);
        // Seamlessly await if a promise has been returned, otherwise exit value
        const res = await promiseOrValue;
        return res;
      }

      default:
        throw new Error(`Evaluation failure: Unhandled expression type "${(expr as any).type}"`);
    }
  }

  /**
   * Resolves and executes build-in capabilities with exact requirements matching
   */
  private async evaluateCall(callee: string, args: Expression[], env: Environment): Promise<any> {
    const evaluatedArgs: any[] = [];
    for (const arg of args) {
      evaluatedArgs.push(await this.evaluateExpression(arg, env));
    }

    switch (callee) {
      case 'validate': {
        const [data, schema] = evaluatedArgs;
        try {
          const res = validate(data, schema);
          this.trace('success', `validate(): dataset matches configuration schema safely.`);
          return res;
        } catch (err) {
          if (err instanceof ValidationError) {
            this.trace('error', `validate() failed: ${err.message}`);
            return err; // Returns ValidationError instance as instructed
          }
          throw err;
        }
      }

      case 'hash': {
        const [text, algo] = evaluatedArgs;
        if (typeof text !== 'string') {
          throw new Error('hash(): first parameter text must be a string format');
        }
        this.trace('info', `Computing async cryptographic hash using ${algo || 'argon2id'}...`);
        const result = await hash(text, algo);
        return result;
      }

      case 'sign': {
        const [payload, secret] = evaluatedArgs;
        this.trace('info', `Signing payload securely...`);
        const jwtString = await sign(payload, secret);
        return jwtString;
      }

      case 'verify': {
        const [token, secret] = evaluatedArgs;
        this.trace('info', `Verifying token signature...`);
        const decoded = await verify(token, secret);
        if (decoded) {
          this.trace('success', `verify(): Signature validated successfully!`);
        } else {
          this.trace('error', `verify(): Signature verification failed! Returning null.`);
        }
        return decoded;
      }

      case 'uuid': {
        const generatedUid = uuid();
        return generatedUid;
      }

      case 'now': {
        return now();
      }

      case 'emit': {
        const [signal, data] = evaluatedArgs;
        if (typeof signal !== 'string') {
          throw new Error('emit(): First argument signal name must be string');
        }
        this.trace('info', `emit() called: sending ${signal} with data: ${JSON.stringify(data)}`);
        await this.eventBus.emit(signal, data);
        return;
      }

      case 'log': {
        const formatted = evaluatedArgs.map(val => 
          typeof val === 'object' ? JSON.stringify(val) : String(val)
        ).join(' ');
        this.trace('log', formatted);
        return;
      }

      default: {
        // Fallback to searching Environment defined functions or throwing error
        const customFunc = env.get(callee);
        if (typeof customFunc === 'function') {
          return await customFunc(...evaluatedArgs);
        }
        throw new Error(`AETHER Error: Specified function callee '${callee}' is not supported as a built-in.`);
      }
    }
  }
}
