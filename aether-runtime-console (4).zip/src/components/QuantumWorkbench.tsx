/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Shield,
  KeyRound,
  FileCheck2,
  Lock,
  Unlock,
  RefreshCw,
  Plus,
  Play,
  AlertTriangle,
  History,
  CheckCircle2,
  XCircle,
  Database,
  ArrowRight,
  Terminal,
  Server,
  Zap,
  Fingerprint
} from 'lucide-react';
import {
  AetherQuantumRuntimePlugin,
  generateAetherIdentity,
  getPublicIdentityPack,
  signAetherToken,
  AetherIdentity,
  AuditRecord,
  QuantumDefenseStatus
} from '../index';

export default function QuantumWorkbench() {
  const [plugin] = useState(() => {
    const p = new AetherQuantumRuntimePlugin();
    // Pre-register some baseline policies
    p.registerAccessPolicy({
      id: 'pol-user-ledger-read',
      name: 'Read Ledger Base Policy',
      effect: 'allow',
      resources: ['vault.ledger.read', 'api.telemetry'],
      actions: ['read', 'invoke'],
      subjectRoles: ['USER', 'AUDITOR', 'ADMIN']
    });
    p.registerAccessPolicy({
      id: 'pol-admin-quantum-core',
      name: 'System Root Policy',
      effect: 'allow',
      resources: ['vault.core.*', 'vault.ledger.write'],
      actions: ['*'],
      subjectRoles: ['ADMIN']
    });
    return p;
  });

  const [identities, setIdentities] = useState<AetherIdentity[]>([]);
  const [selectedIdentity, setSelectedIdentity] = useState<AetherIdentity | null>(null);
  
  // Logs & Logs-chain state
  const [auditLogs, setAuditLogs] = useState<AuditRecord[]>([]);
  const [isChainValid, setIsChainValid] = useState<boolean | null>(null);
  const [telemetry, setTelemetry] = useState<QuantumDefenseStatus | null>(null);

  // Playground simulation states
  const [simulationLogs, setSimulationLogs] = useState<{ type: 'info' | 'success' | 'warn' | 'error'; msg: string }[]>([]);
  const [evalTarget, setEvalTarget] = useState('vault.ledger.read');
  const [evalAction, setEvalAction] = useState('read');
  const [evalRole, setEvalRole] = useState('USER');
  const [evalIsQuantumNode, setEvalIsQuantumNode] = useState(true);

  // Generation Loading
  const [isGenerating, setIsGenerating] = useState(false);

  // On mount, sync telemetry
  useEffect(() => {
    syncState();
    logSim('info', 'AETHER Quantum Guard Engine initialized.');
    logSim('info', 'Zero-Trust Policy Rulebook loaded with 2 policies.');
    logSim('info', 'Cryptographic block-chained ledger is live at Genesis.');
  }, []);

  const syncState = () => {
    setTelemetry(plugin.getTelemetry());
    setAuditLogs(plugin.getAuditHistory());
  };

  const logSim = (type: 'info' | 'success' | 'warn' | 'error', msg: string) => {
    setSimulationLogs(prev => [...prev, { type, msg }]);
  };

  const clearSimLogs = () => {
    setSimulationLogs([]);
  };

  const handleCreateIdentity = async () => {
    setIsGenerating(true);
    logSim('info', 'Generating new Post-Quantum composite identity...');
    setTimeout(async () => {
      try {
        const id = await generateAetherIdentity();
        plugin.registerTrustAnchor({
          did: id.did,
          dilithiumPubKey: id.dilithium.publicKey,
          classicPubKey: id.classic.publicKey,
          fallbackClassicKeyHex: id.classic.publicKeyHex
        });

        setIdentities(prev => [...prev, id]);
        if (!selectedIdentity) {
          setSelectedIdentity(id);
        }

        logSim('success', `Identity DNA created successfully! DID: ${id.did.slice(0, 24)}...`);
        logSim('info', '→ Registered ML-KEM-768 Kyber & ML-DSA-65 Dilithium public trust anchors.');
        syncState();
      } catch (err: any) {
        logSim('error', `Generation failed: ${err.message}`);
      } finally {
        setIsGenerating(false);
      }
    }, 50);
  };

  const handleVerifyLedgerChain = () => {
    const valid = plugin.getAuditLogger().verifyLedger();
    setIsChainValid(valid);
    if (valid) {
      logSim('success', 'Blockchain ledger validation result: VERIFIED (Every SHA3 hash-link is perfect)');
    } else {
      logSim('error', 'Ledger validation error: chain link integrity broken!');
    }
  };

  // Evaluate Custom Request Check
  const handleRunCustomEvaluation = async () => {
    if (!selectedIdentity) {
      logSim('warn', 'Please create an Identity DNA anchor first.');
      return;
    }

    logSim('info', `Simulating request on resource '${evalTarget}' [Action: ${evalAction}]...`);

    try {
      // 1. Issue an Aether token with claims
      const claims = {
        iss: selectedIdentity.did,
        sub: selectedIdentity.did,
        aud: 'aether:sandbox',
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + 600,
        jti: 'session_' + Math.random().toString(36).substring(4),
        roles: [evalRole]
      };

      const token = await signAetherToken(
        claims,
        selectedIdentity.dilithium.privateKey,
        selectedIdentity.classic.privateKey,
        selectedIdentity.classic.privateKeyHex
      );

      // 2. Wrap as message
      const msg: any = {
        id: 'msg_' + Math.random().toString(12),
        type: 'call',
        target: evalTarget,
        payload: { accessRequested: true },
        meta: {
          token,
          source: 'workbench-sandbox',
          traceId: 'tr_' + Math.random().toString(36).substring(4)
        }
      };

      // 3. Define quantum statement
      const stmt: any = {
        type: 'EmitStatement',
        signal: evalTarget,
        data: { type: 'Literal', value: {} },
        modifiers: evalIsQuantumNode ? ['quantum'] : [],
        quantumRequired: evalIsQuantumNode
      };

      const result = await plugin.interceptExecution(stmt, msg);

      if (result.allowed) {
        logSim('success', `✔ ACCESS GRANTED: Request verified and permitted by policies. Logged to block #${result.auditRecord?.index}`);
      } else {
        logSim('error', `❌ REJECTED: Access denied! Reason: ${result.error}`);
      }
      syncState();
    } catch (err: any) {
      logSim('error', `Evaluation error: ${err.message}`);
    }
  };

  // SIMULATED ATTACKS
  const triggerReplayAttack = async () => {
    if (!selectedIdentity) {
      logSim('warn', 'Please create an Identity DNA anchor first.');
      return;
    }
    logSim('warn', '⚠️ CYBERATTACK DETECTED: Triggering simulated Replay Attack (resubmitting expired credential token)');

    try {
      // Create is already expired claims
      const expiredClaims = {
        iss: selectedIdentity.did,
        sub: selectedIdentity.did,
        aud: 'aether:sandbox',
        iat: Math.floor(Date.now() / 1000) - 3600,
        exp: Math.floor(Date.now() / 1000) - 100, // Expired
        jti: 'replay-token-9988'
      };

      const token = await signAetherToken(
        expiredClaims,
        selectedIdentity.dilithium.privateKey,
        selectedIdentity.classic.privateKey,
        selectedIdentity.classic.privateKeyHex
      );

      const msg: any = {
        id: 'msg_replay',
        type: 'call',
        target: evalTarget,
        payload: {},
        meta: {
          token,
          source: 'replayed-intercept-vector',
          traceId: 'tr_replay_001'
        }
      };

      const stmt: any = {
        type: 'EmitStatement',
        signal: evalTarget,
        data: { type: 'Literal', value: {} },
        modifiers: ['quantum'],
        quantumRequired: true
      };

      const result = await plugin.interceptExecution(stmt, msg);

      if (result.allowed) {
        logSim('error', '💀 CRITICAL SEVERITY: System vulnerable! Expired replay token was successfully executed.');
      } else {
        logSim('success', `🛡️ SECURED: Replay attack mitigated! Rejection recorded in block #${result.auditRecord?.index}`);
        logSim('info', `→ Logger Reason: "${result.error}"`);
      }
      syncState();
    } catch (err: any) {
      logSim('error', `Simulation handling crash: ${err.message}`);
    }
  };

  const triggerMITMAttack = async () => {
    if (!selectedIdentity) {
      logSim('warn', 'Please create an Identity DNA anchor first.');
      return;
    }
    logSim('warn', '⚠️ CYBERATTACK DETECTED: Triggering simulated Man-in-the-Middle (MITM) tampering attack');

    try {
      const claims = {
        iss: selectedIdentity.did,
        sub: selectedIdentity.did,
        aud: 'aether:sandbox',
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + 600,
        jti: 'mitm_token_01',
        roles: ['USER'] // Signed as USER
      };

      const token = await signAetherToken(
        claims,
        selectedIdentity.dilithium.privateKey,
        selectedIdentity.classic.privateKey,
        selectedIdentity.classic.privateKeyHex
      );

      // MITM Intercept: Change claims payload in base64 buffer without keys
      const parts = token.split('.');
      const decoded = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
      
      // Intruder modifies the role to ADMIN to elevate rights!
      decoded.roles = ['ADMIN'];
      
      const modifiedPayloadB64 = btoa(JSON.stringify(decoded))
        .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

      const tamperedToken = `${parts[0]}.${modifiedPayloadB64}.${parts[2]}`;

      const msg: any = {
        id: 'msg_tamper',
        type: 'call',
        target: 'vault.core.secrets', // Trying to read admin secrets
        payload: {},
        meta: {
          token: tamperedToken,
          source: 'mitm-malicious-router',
          traceId: 'tr_mitm_002'
        }
      };

      const stmt: any = {
        type: 'EmitStatement',
        signal: 'vault.core.secrets',
        data: { type: 'Literal', value: {} },
        modifiers: ['quantum'],
        quantumRequired: true
      };

      const result = await plugin.interceptExecution(stmt, msg);

      if (result.allowed) {
        logSim('error', '💀 CRITICAL SEVERITY: MITM signature bypass occurred! Tampered packet executed.');
      } else {
        logSim('success', `🛡️ SECURED: MITM tampering block successful! Rejection written to block #${result.auditRecord?.index}`);
        logSim('info', `→ Logger Reason: "${result.error}"`);
      }
      syncState();
    } catch (err: any) {
      logSim('error', `Simulation error: ${err.message}`);
    }
  };

  const triggerDowngradeAttack = async () => {
    if (!selectedIdentity) {
      logSim('warn', 'Please create an Identity DNA anchor first.');
      return;
    }
    logSim('warn', '⚠️ CYBERATTACK DETECTED: Triggering signature Downgrade Attack (submitting token with post-quantum key stripped)');

    try {
      const claims = {
        iss: selectedIdentity.did,
        sub: selectedIdentity.did,
        aud: 'aether:sandbox',
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + 600,
        jti: 'downgrade_token_22',
        roles: ['ADMIN']
      };

      const token = await signAetherToken(
        claims,
        selectedIdentity.dilithium.privateKey,
        selectedIdentity.classic.privateKey,
        selectedIdentity.classic.privateKeyHex
      );

      // Stripping ML-DSA signature portion, keeping classical ECDSA only
      const parts = token.split('.');
      const sigB64 = parts[2];
      const decodedSig = atob(sigB64.replace(/-/g, '+').replace(/_/g, '/'));
      const [dilithiumSigHex, ecdsaSigHex] = decodedSig.split(':');

      // Strip dilithium
      const strippedSigB64 = btoa(`:${ecdsaSigHex}`)
        .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

      const downgradedToken = `${parts[0]}.${parts[1]}.${strippedSigB64}`;

      const msg: any = {
        id: 'msg_downgrade',
        type: 'call',
        target: 'vault.ledger.write',
        payload: {},
        meta: {
          token: downgradedToken,
          source: 'downgrade-interceptor',
          traceId: 'tr_dg_003'
        }
      };

      const stmt: any = {
        type: 'EmitStatement',
        signal: 'vault.ledger.write',
        data: { type: 'Literal', value: {} },
        modifiers: ['quantum'],
        quantumRequired: true
      };

      const result = await plugin.interceptExecution(stmt, msg);

      if (result.allowed) {
        logSim('error', '💀 CRITICAL SEVERITY: Protocol downgrade accepted! Executed token stripped of post-quantum defenses.');
      } else {
        logSim('success', `🛡️ SECURED: Downgrade attempt blocked! Post-quantum signature verification enforced. Logged in block #${result.auditRecord?.index}`);
        logSim('info', `→ Logger Reason: "${result.error}"`);
      }
      syncState();
    } catch (err: any) {
      logSim('error', `Simulation error: ${err.message}`);
    }
  };

  const handleClearPluginData = () => {
    plugin.clearRules();
    // Re-add default policies
    plugin.registerAccessPolicy({
      id: 'pol-user-ledger-read',
      name: 'Read Ledger Base Policy',
      effect: 'allow',
      resources: ['vault.ledger.read', 'api.telemetry'],
      actions: ['read', 'invoke'],
      subjectRoles: ['USER', 'AUDITOR', 'ADMIN']
    });
    plugin.registerAccessPolicy({
      id: 'pol-admin-quantum-core',
      name: 'System Root Policy',
      effect: 'allow',
      resources: ['vault.core.*', 'vault.ledger.write'],
      actions: ['*'],
      subjectRoles: ['ADMIN']
    });
    setIdentities([]);
    setSelectedIdentity(null);
    setIsChainValid(null);
    syncState();
    clearSimLogs();
    logSim('info', 'Active quantum guard storage flushed. Restored standard configurations.');
  };

  return (
    <div className="space-y-8 animate-fade-in" id="quantum-guard-workbench">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-indigo-950 p-6 rounded-3xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="absolute top-0 right-0 h-40 w-40 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center space-x-4">
          <div className="p-3.5 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/30">
            <Shield className="h-7 w-7 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400 bg-indigo-950/50 px-2 py-0.5 border border-indigo-900/50 rounded-md">
              Adaptive Cryptography
            </span>
            <h1 className="text-xl font-bold text-slate-100 mt-1">AETHER Quantum Guard</h1>
            <p className="text-xs text-slate-400 mt-1">
              Zero-Trust compilation & runtime security layer resistant to quantum computer attacks.
            </p>
          </div>
        </div>

        <button
          onClick={handleClearPluginData}
          className="px-4 py-2 bg-slate-950 hover:bg-slate-900 text-slate-300 hover:text-white rounded-lg border border-slate-800 transition text-xs flex items-center space-x-2 cursor-pointer"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span>Reset Guard Defenses</span>
        </button>
      </div>

      {/* Grid: Identity Creator and Request Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Identity & Policy Config (Left Columns) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Identity panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="identity-panel">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Fingerprint className="h-4 w-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-slate-200">Registered Trust Anchors</h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded font-mono">
                {identities.length} Registered
              </span>
            </div>

            <button
              onClick={handleCreateIdentity}
              disabled={isGenerating}
              className="w-full py-2 px-4 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 transition cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>Computing Lattice Math...</span>
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4" />
                  <span>Generate Identity DNA</span>
                </>
              )}
            </button>

            {identities.length > 0 ? (
              <div className="mt-4 space-y-3 max-h-[170px] overflow-y-auto pr-1">
                {identities.map((id, index) => (
                  <div
                    key={id.did}
                    onClick={() => setSelectedIdentity(id)}
                    className={`p-3 rounded-xl border transition text-[11px] cursor-pointer ${
                      selectedIdentity?.did === id.did
                        ? 'bg-indigo-950/20 border-indigo-500/50 text-indigo-200'
                        : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200">Actor Identity #{index + 1}</span>
                      <span className="text-[9px] text-slate-500 font-mono">PQC + Classic</span>
                    </div>
                    <p className="font-mono text-[9px] text-indigo-400 mt-1 truncate">{id.did}</p>
                    <div className="grid grid-cols-3 gap-1 mt-2 text-[8px] font-mono text-center text-slate-500">
                      <span className="py-0.5 px-1 bg-slate-900 rounded">Kyber-768</span>
                      <span className="py-0.5 px-1 bg-slate-900 rounded">DSA-65</span>
                      <span className="py-0.5 px-1 bg-slate-900 rounded">ECDSA</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-950 border border-slate-900 rounded-xl p-6 text-center mt-4">
                <Shield className="h-6 w-6 text-slate-600 mx-auto opacity-40" />
                <p className="text-[10px] text-slate-500 mt-2">
                  No post-quantum identities registered yet. Click generate above.
                </p>
              </div>
            )}
          </div>

          {/* Access policies Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="policies-panel">
            <div className="flex items-center space-x-2 mb-3">
              <KeyRound className="h-4 w-4 text-sky-400" />
              <h3 className="text-xs font-bold text-slate-200">Active Access Rules (ABAC)</h3>
            </div>
            
            <div className="space-y-3">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-[10px]">
                <div className="flex items-center justify-between font-mono font-bold text-slate-300">
                  <span>pol-user-ledger-read</span>
                  <span className="text-emerald-400 bg-emerald-500/5 px-1.5 py-0.2 rounded">ALLOW</span>
                </div>
                <p className="text-[9px] text-slate-500 mt-1">Resource: vault.ledger.read</p>
                <p className="text-[9px] text-slate-500">Roles: USER, AUDITOR, ADMIN</p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-[10px]">
                <div className="flex items-center justify-between font-mono font-bold text-slate-300">
                  <span>pol-admin-quantum-core</span>
                  <span className="text-emerald-400 bg-emerald-500/5 px-1.5 py-0.2 rounded">ALLOW</span>
                </div>
                <p className="text-[9px] text-slate-500 mt-1">Resource: vault.core.* (All core resources)</p>
                <p className="text-[9px] text-slate-500">Roles: ADMIN</p>
              </div>
            </div>
          </div>

        </div>

        {/* Security Playground Center Panel (8 columns combined) */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center space-x-2 mb-4">
              <Server className="h-4 w-4 text-indigo-400" />
              <h3 className="text-xs font-bold text-slate-200">Zero-Trust request playground</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-slate-950 border border-slate-800/80 rounded-xl text-xs mb-4">
              <div>
                <label className="block text-[10px] text-slate-400 font-semibold mb-1">Target Resource</label>
                <select
                  value={evalTarget}
                  onChange={e => setEvalTarget(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-300 text-xs font-mono"
                >
                  <option value="vault.ledger.read">vault.ledger.read</option>
                  <option value="vault.ledger.write">vault.ledger.write</option>
                  <option value="vault.core.secrets">vault.core.secrets</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-semibold mb-1">Action Type</label>
                <select
                  value={evalAction}
                  onChange={e => setEvalAction(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-300 text-xs font-mono"
                >
                  <option value="read">read</option>
                  <option value="write">write</option>
                  <option value="invoke">invoke</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-semibold mb-1">Subject Role Assertion</label>
                <select
                  value={evalRole}
                  onChange={e => setEvalRole(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-300 text-xs font-mono"
                >
                  <option value="USER">USER</option>
                  <option value="AUDITOR">AUDITOR</option>
                  <option value="ADMIN">ADMIN</option>
                  <option value="GUEST">GUEST</option>
                </select>
              </div>

              <div className="flex flex-col justify-end">
                <div className="flex items-center space-x-2 h-9">
                  <input
                    type="checkbox"
                    id="is-post-quantum"
                    checked={evalIsQuantumNode}
                    onChange={e => setEvalIsQuantumNode(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-800 text-indigo-600 focus:ring-0 cursor-pointer"
                  />
                  <label htmlFor="is-post-quantum" className="text-[10px] text-slate-300 font-bold select-none cursor-pointer">
                    Enforce PQ defense
                  </label>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={handleRunCustomEvaluation}
                className="py-2.5 px-4 bg-slate-950 hover:bg-slate-800 border border-slate-850 hover:border-slate-700 text-indigo-400 hover:text-indigo-300 font-bold rounded-xl text-xs flex items-center space-x-2 transition cursor-pointer"
              >
                <Play className="h-4 w-4" />
                <span>Simulate Call</span>
              </button>

              <button
                onClick={triggerReplayAttack}
                className="py-2.5 px-3 bg-red-950/20 hover:bg-red-950/30 border border-red-900/30 hover:border-red-800/40 text-red-400 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition cursor-pointer"
              >
                <AlertTriangle className="h-4 w-4" />
                <span>Simulate Replay Attack</span>
              </button>

              <button
                onClick={triggerMITMAttack}
                className="py-2.5 px-3 bg-amber-950/20 hover:bg-amber-950/30 border border-amber-900/30 hover:border-amber-800/40 text-amber-400 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition cursor-pointer"
              >
                <AlertTriangle className="h-4 w-4" />
                <span>Simulate MITM Tamper</span>
              </button>

              <button
                onClick={triggerDowngradeAttack}
                className="py-2.5 px-3 bg-orange-950/20 hover:bg-orange-950/30 border border-orange-900/30 hover:border-orange-800/40 text-orange-400 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition cursor-pointer"
              >
                <AlertTriangle className="h-4 w-4" />
                <span>Simulate Downgrade</span>
              </button>
            </div>
          </div>

          {/* Core Simulator Console outputs */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <Terminal className="h-4 w-4 text-indigo-400" />
                <h3 className="text-xs font-bold text-slate-300">Defense Interceptor Output Tracing</h3>
              </div>
              <button
                onClick={clearSimLogs}
                className="text-[9px] font-bold text-slate-500 hover:text-slate-300 uppercase transition cursor-pointer"
              >
                Clear log
              </button>
            </div>

            <div className="bg-slate-950 border border-slate-900 rounded-xl p-4 h-[220px] overflow-y-auto font-mono text-[10px] space-y-2 pr-1">
              {simulationLogs.map((log, idx) => (
                <div
                  key={idx}
                  className={`flex items-start space-x-2 ${
                    log.type === 'error'
                      ? 'text-red-400'
                      : log.type === 'warn'
                      ? 'text-amber-400'
                      : log.type === 'success'
                      ? 'text-emerald-400'
                      : 'text-slate-300 font-semibold'
                  }`}
                >
                  <span className="text-slate-600">[{new Date().toLocaleTimeString()}]</span>
                  <span>{log.msg}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* BLOCKCHAIN LEDGER & VERIFICATION */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="audit-ledger-panel">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6 border-b border-slate-800/80 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <History className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-200">Chain-of-Trust audit log (SHA3-256 Ledger)</h3>
              <p className="text-[10px] text-slate-400">
                Every authorization event adds a linked node. The current anchor updates using SHA-3 cryptographic recursion formulas.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3.5">
            {isChainValid !== null && (
              <div className={`py-1.5 px-3 rounded-lg text-xs font-bold font-mono flex items-center space-x-2 border ${
                isChainValid
                  ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                  : 'bg-red-950/30 border-red-500/30 text-red-300'
              }`}>
                {isChainValid ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                <span>{isChainValid ? 'Ledger Chain: SECURED' : 'Ledger Chain: BROKEN!'}</span>
              </div>
            )}

            <button
              onClick={handleVerifyLedgerChain}
              disabled={auditLogs.length === 0}
              className="py-2 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition cursor-pointer"
            >
              <FileCheck2 className="h-4 w-4" />
              <span>Verify Block Integrity</span>
            </button>
          </div>
        </div>

        {/* Telemetry quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center text-xs">
          <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl">
            <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider">Audit Chain Anchor</p>
            <p className="font-mono text-[10px] text-indigo-400 mt-1 truncate">
              {telemetry?.auditChainHash || 'Genesis'}
            </p>
          </div>

          <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl">
            <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider">Blocked Intrusions</p>
            <p className="text-lg font-black text-rose-500 mt-0.5">
              {telemetry?.totalBlockedIntrusions || 0}
            </p>
          </div>

          <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl">
            <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider">Verified PQ Requests</p>
            <p className="text-lg font-black text-emerald-400 mt-0.5">
              {telemetry?.totalVerifiedPostQuantumCalls || 0}
            </p>
          </div>

          <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl">
            <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider">Key standard</p>
            <p className="text-xs font-mono font-black text-sky-400 mt-1.5 uppercase">
              Kyber768 + DSA65
            </p>
          </div>
        </div>

        {/* Audit Blocks timeline */}
        {auditLogs.length > 0 ? (
          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {[...auditLogs].reverse().map((record, index) => (
              <div
                key={record.index}
                className="bg-slate-950 border border-slate-850 p-4 rounded-2xl relative overflow-hidden text-[11px] font-mono text-slate-300"
              >
                <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2 border-b border-slate-900 pb-2 mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="py-0.5 px-1.5 bg-indigo-500/10 text-indigo-300 rounded font-bold">
                      Block #{record.index}
                    </span>
                    <span className="text-slate-500 text-[10px]">{record.timestamp}</span>
                  </div>
                  <div className={`font-bold px-2 py-0.5 rounded text-[10px] text-center self-start md:self-auto ${
                    record.decision === 'allow'
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'bg-rose-500/10 text-rose-400'
                  }`}>
                    {record.decision === 'allow' ? 'ALLOW (VERIFIED)' : 'REJECT (BLOCKED)'}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-y-2 gap-x-4">
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase font-bold">Subject DID</span>
                    <span className="text-slate-300 text-[10px] block truncate">{record.subjectDid}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase font-bold">Trace ID</span>
                    <span className="text-indigo-400 text-[10px] block truncate">{record.traceId}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase font-bold">Invocation target</span>
                    <span className="text-slate-300 text-[10px] block truncate">{record.resource}</span>
                  </div>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-900/60 grid grid-cols-1 md:grid-cols-2 gap-2 text-[9px] text-slate-500">
                  <div className="truncate">
                    <span>Parent SHA-3: </span>
                    <span className="font-mono text-slate-500 hover:text-slate-400 transition">{record.previousHash}</span>
                  </div>
                  <div className="truncate text-left md:text-right">
                    <span>Block Hash: </span>
                    <span className="font-mono text-slate-400">{record.hash}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-slate-950 border border-slate-900 rounded-2xl p-10 text-center">
            <History className="h-8 w-8 text-slate-700 mx-auto opacity-30 animate-pulse" />
            <p className="text-slate-500 text-xs mt-3 font-semibold uppercase tracking-wider">Audit logs vacant</p>
            <p className="text-slate-600 text-[10px] max-w-sm mx-auto mt-1">
              Initialize some transactions, custom request check queries, or run attack simulations above to populate the ledger blocks!
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
