/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Activity,
  Cpu,
  Layers,
  Sparkles,
  Play,
  RotateCcw,
  Zap,
  Globe,
  Database,
  Terminal,
  Settings,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Radio,
  FileCode,
  Check,
  Code2,
  Copy,
  ChevronRight,
  Gauge,
  Plus,
  Trash2,
  RefreshCw,
  Sliders,
  History,
  Timer
} from 'lucide-react';

import {
  MemoryStore,
  FileStore,
  FlowStore,
  FlowEvent,
  FlowSnapshot
} from '../index';

export default function FlowWorkbench() {
  // Persistence backend selections
  const [selectedBackendType, setSelectedBackendType] = useState<'memory' | 'file'>('memory');
  
  // Instance state
  const [store, setStore] = useState(() => new FlowStore(new MemoryStore()));
  const [activeFlows, setActiveFlows] = useState<string[]>(['flow.users', 'flow.metrics', 'flow.alerts']);
  const [selectedFlowName, setSelectedFlowName] = useState('flow.users');
  
  // Event state lists
  const [eventsList, setEventsList] = useState<FlowEvent<any>[]>([]);
  const [materializedRecords, setMaterializedRecords] = useState<any[]>([]);
  const [snapshotsCount, setSnapshotsCount] = useState(0);

  // Write Form states
  const [customPayloadStr, setCustomPayloadStr] = useState('{\n  "id": "usr_a1",\n  "name": "Jane Doe",\n  "email": "jane@aether.io",\n  "active": true,\n  "age": 28\n}');
  const [writeSource, setWriteSource] = useState('workbench-test');
  const [writeError, setWriteError] = useState<string | null>(null);

  // Lazy Query Builder fields
  const [queryWhereField, setQueryWhereField] = useState('active');
  const [queryWhereValue, setQueryWhereValue] = useState('true');
  const [queryMapField, setQueryMapField] = useState('name');
  const [queryReduceField, setQueryReduceField] = useState('age');
  
  const [queryResult, setQueryResult] = useState<any>(null);
  const [queryTraceLog, setQueryTraceLog] = useState<string[]>([]);
  
  // Real-time subscribe updates
  const [liveLogList, setLiveLogList] = useState<{ id: string; time: string; msg: string }[]>([]);
  const [slowSubscriberEnabled, setSlowSubscriberEnabled] = useState(false);
  const [backloggedQueueSize, setBackloggedQueueSize] = useState(0);

  // Time Travel states
  const [timeTravelPoint, setTimeTravelPoint] = useState<number>(-1);
  const [timeTravelRecordState, setTimeTravelRecordState] = useState<any[]>([]);

  // Benchmarking states
  const [isBenchmarking, setIsBenchmarking] = useState(false);
  const [benchStats, setBenchStats] = useState<{ duration: number; writeRate: number; searchDuration: number } | null>(null);

  // Re-seed backend store whenever backend selection changes
  useEffect(() => {
    const backend = selectedBackendType === 'memory' ? new MemoryStore() : new FileStore();
    const newStore = new FlowStore(backend);
    setStore(newStore);
    
    // Seed initial demo data for smooth user evaluation on first click
    seedInitialDemoData(newStore);
  }, [selectedBackendType]);

  // Handle active stream loading and refreshing
  const refreshFlowData = async () => {
    const flows = await store.getActiveFlows();
    if (flows.length > 0) {
      // Keep dynamic flows tracked
      const union = Array.from(new Set([...activeFlows, ...flows]));
      setActiveFlows(union);
    }

    const flow = store.get(selectedFlowName);
    // Force loading historical events
    await flow.ensureInitialized();
    const allEvents = await flow.query().evaluate();
    setEventsList(allEvents);

    // Materialize current state snapshot
    const snap = await flow.snapshot();
    setMaterializedRecords(snap.all());
    setSnapshotsCount(allEvents.length);
    
    // Reset time travel point when logs increment
    setTimeTravelPoint(allEvents.length - 1);
  };

  useEffect(() => {
    refreshFlowData();
  }, [store, selectedFlowName]);

  // Listen to live events via reactive subscription
  useEffect(() => {
    const flow = store.get(selectedFlowName);
    
    const sub = flow.subscribe(async (event) => {
      // Simulate slow subscriber with async delays
      if (slowSubscriberEnabled) {
        setBackloggedQueueSize(prev => prev + 1);
        await new Promise(resolve => setTimeout(resolve, 800));
        setBackloggedQueueSize(prev => Math.max(0, prev - 1));
      }

      setLiveLogList(prev => [
        {
          id: event.id,
          time: new Date(event.timestamp).toLocaleTimeString(),
          msg: `Incoming: flow.${event.stream} <- data=${JSON.stringify(event.data)}`
        },
        ...prev.slice(0, 24)
      ]);
      
      // Update displays
      const allEvents = await flow.query().evaluate();
      setEventsList(allEvents);
      const snap = await flow.snapshot();
      setMaterializedRecords(snap.all());
    });

    return () => {
      sub.unsubscribe();
    };
  }, [store, selectedFlowName, slowSubscriberEnabled]);

  // Time travel playback handler
  useEffect(() => {
    if (timeTravelPoint < 0 || eventsList.length === 0) {
      setTimeTravelRecordState([]);
      return;
    }

    const selectedEvents = eventsList.slice(0, timeTravelPoint + 1);
    
    // Build snapshot up to this historical point
    const tempRecords = new Map<string, any>();
    for (const ev of selectedEvents) {
      const data = ev.data;
      const key = data?.id || data?.uid || data?.email || String(tempRecords.size);
      
      if (data && data._deleted === true) {
        tempRecords.delete(String(key));
      } else {
        const existing = tempRecords.get(String(key));
        if (existing && typeof existing === 'object' && typeof data === 'object') {
          tempRecords.set(String(key), { ...existing, ...data });
        } else {
          tempRecords.set(String(key), data);
        }
      }
    }
    setTimeTravelRecordState(Array.from(tempRecords.values()));
  }, [timeTravelPoint, eventsList]);

  // Seed standard helper data
  const seedInitialDemoData = async (targetStore: FlowStore) => {
    const userFlow = targetStore.get<any>('flow.users');
    await userFlow.write({ id: 'usr_a1', name: 'Alice Smith', email: 'alice@aether.io', active: true, age: 31 });
    await userFlow.write({ id: 'usr_b2', name: 'Bob Johnson', email: 'bob@aether.io', active: false, age: 42 });
    await userFlow.write({ id: 'usr_c3', name: 'Carol Danvers', email: 'carol@aether.io', active: true, age: 29 });
    // update Alice Smith's age
    await userFlow.write({ id: 'usr_a1', name: 'Alice Smith', email: 'alice@aether.io', active: true, age: 32 });

    const metricFlow = targetStore.get<any>('flow.metrics');
    await metricFlow.write({ key: 'cpu', val: 34 });
    await metricFlow.write({ key: 'ram', val: 76 });
    await metricFlow.write({ key: 'cpu', val: 89 });

    const alertsFlow = targetStore.get<any>('flow.alerts');
    await alertsFlow.write({ level: 'warning', message: 'CPU throttling detected' });
    await alertsFlow.write({ level: 'info', message: 'Node online cluster heartbeat' });

    await refreshFlowData();
  };

  // Perform a test write append
  const appendFormPayload = async () => {
    setWriteError(null);
    try {
      let parsed = JSON.parse(customPayloadStr);
      const flow = store.get(selectedFlowName);
      
      await flow.write(parsed, {
        source: writeSource,
        version: 1,
        causedBy: 'flow-interactive-sandbox'
      });

      // Update payload helper with incremented id to avoid collides on clicks
      if (parsed.id) {
        const numPart = parsed.id.match(/\d+/);
        if (numPart) {
          const nextNum = parseInt(numPart[0], 10) + 1;
          const nextId = parsed.id.replace(/\d+/, String(nextNum));
          let updated = { ...parsed, id: nextId };
          setCustomPayloadStr(JSON.stringify(updated, null, 2));
        }
      }

      await refreshFlowData();
    } catch (err: any) {
      setWriteError(err.message || 'Validation error: Failed to parse event JSON');
    }
  };

  // Run dynamic lazy queries using current inputs
  const executeUserQuery = async () => {
    setQueryTraceLog([]);
    const flow = store.get(selectedFlowName);
    
    setQueryTraceLog(prev => [...prev, `[INIT] Lazy FlowQuery triggered for stream: ${selectedFlowName}`]);
    let queryChain = flow.query();

    // 1. Where predicate mapping
    if (queryWhereField) {
      setQueryTraceLog(prev => [...prev, `[OPT] Adding filter operator -> where '${queryWhereField}' === ${queryWhereValue}`]);
      queryChain = queryChain.where((data: any) => {
        if (!data || typeof data !== 'object') return false;
        const val = data[queryWhereField];
        
        let targetVal: any = queryWhereValue;
        if (queryWhereValue === 'true') targetVal = true;
        if (queryWhereValue === 'false') targetVal = false;
        if (!isNaN(Number(queryWhereValue))) targetVal = Number(queryWhereValue);

        return val === targetVal;
      });
    }

    // 2. Map payload transform
    if (queryMapField) {
      setQueryTraceLog(prev => [...prev, `[OPT] Adding mapper operator -> project field '${queryMapField}'`]);
      // Let's execute map on the data fields
      queryChain = queryChain.map((data: any) => {
        if (data && typeof data === 'object' && queryMapField in data) {
          return data[queryMapField];
        }
        return data;
      }) as any;
    }

    // 3. Final terminal evaluation
    try {
      setQueryTraceLog(prev => [...prev, `[EXEC] Query compiled. Evaluating lazy pipeline loops...`]);
      const res = await queryChain.evaluate();
      
      // Calculate reduce value helper as well
      const matchingEvents = await flow.query().evaluate();
      const sumReduceOpt = matchingEvents.reduce((acc: number, ev: any) => {
        const item = ev.data;
        if (item && typeof item === 'object' && typeof item[queryReduceField] === 'number') {
          return acc + item[queryReduceField];
        }
        return acc;
      }, 0);

      setQueryTraceLog(prev => [
        ...prev,
        `[SUCCESS] Result returned ${res.length} matches.`,
        `[FACT] Reduce accumulator score on '${queryReduceField}' field sum is: ${sumReduceOpt}`
      ]);

      setQueryResult({
        matchesCount: res.length,
        items: res.map(ev => ev.data),
        reduceSum: sumReduceOpt
      });
    } catch (err: any) {
      setQueryTraceLog(prev => [...prev, `[FATAL] Pipeline failed: ${err.message}`]);
    }
  };

  // Stress-test performance using 100,000 events
  const run100kPerformanceStressTest = async () => {
    setIsBenchmarking(true);
    setBenchStats(null);

    const stressStore = new FlowStore(new MemoryStore());
    const stressFlow = stressStore.get<{ num: number }>('flow.stress');
    
    const payload = { num: 42 };
    const batchSize = 1000;
    const totalWrites = 100000;

    const t0 = performance.now();
    for (let i = 0; i < totalWrites; i += batchSize) {
      const promises = [];
      for (let j = 0; j < batchSize; j++) {
        promises.push(stressFlow.write(payload));
      }
      await Promise.all(promises);
    }
    const duration = performance.now() - t0;
    const writeRate = Math.round(totalWrites / (duration / 1000));

    // Measure range lookup performance via high-speed B-Tree range query
    const tSearch0 = performance.now();
    const queryResult = await stressFlow.query().evaluate();
    const searchDuration = performance.now() - tSearch0;

    setBenchStats({
      duration: Math.round(duration),
      writeRate,
      searchDuration: Number(searchDuration.toFixed(2))
    });
    setIsBenchmarking(false);
  };

  // Preset payload helper
  const loadPayloadTemplate = (type: string) => {
    if (type === 'flow.users') {
      setCustomPayloadStr('{\n  "id": "usr_a1",\n  "name": "Jane Doe",\n  "email": "jane@aether.io",\n  "active": true,\n  "age": 28\n}');
    } else if (type === 'flow.metrics') {
      setCustomPayloadStr('{\n  "id": "met_b1",\n  "key": "cpu",\n  "val": 64,\n  "node": "node-central-europe"\n}');
    } else if (type === 'flow.alerts') {
      setCustomPayloadStr('{\n  "id": "alt_c1",\n  "level": "critical",\n  "message": "Out of memory crash stack"\n}');
    }
  };

  return (
    <div className="space-y-6" id="flow-engine-workbench">
      
      {/* Top Config Frame & Statistics Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="workbench-setup-row">
        
        {/* Stream controller selections */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between" id="flow-config-panel">
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Settings className="h-4 w-4 text-indigo-400" /> Storage Engine Settings
            </h3>
            
            <div className="space-y-2">
              <label className="text-xs text-slate-400">Select Storage Backend</label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                <button
                  id="select-memory-backend-btn"
                  onClick={() => setSelectedBackendType('memory')}
                  className={`py-2 px-3 rounded-lg font-semibold transition-all ${
                    selectedBackendType === 'memory'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  MemoryStore
                </button>
                <button
                  id="select-file-backend-btn"
                  onClick={() => setSelectedBackendType('file')}
                  className={`py-2 px-3 rounded-lg font-semibold transition-all ${
                    selectedBackendType === 'file'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  FileStore (NDJSON)
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-slate-400">Active Immutable Flow Streams</label>
              <div className="space-y-1.5" id="flow-streams-list flex flex-col flex-wrap">
                {activeFlows.map((flowName) => (
                  <button
                    id={`select-flow-${flowName}`}
                    key={flowName}
                    onClick={() => {
                      setSelectedFlowName(flowName);
                      loadPayloadTemplate(flowName);
                    }}
                    className={`w-full text-left p-3 rounded-xl border flex items-center justify-between transition-all ${
                      selectedFlowName === flowName
                        ? 'bg-indigo-600/10 border-indigo-500/40 text-white'
                        : 'bg-slate-950 border-slate-900 text-slate-400 hover:bg-slate-900'
                    }`}
                  >
                    <span className="font-mono text-xs">{flowName}</span>
                    <ChevronRight className="h-4 w-4 text-slate-600" />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1 pt-1">
              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                <Clock className="h-3 w-3" /> System Time: 2026-06-10 (Simulation ISO Clock)
              </span>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800/80 mt-6 flex justify-between gap-2" id="db-resets">
            <button
              id="wipe-stream-button"
              onClick={async () => {
                const flowName = selectedFlowName;
                await store.backend.clear(flowName);
                await refreshFlowData();
              }}
              className="flex-1 py-2.5 px-3 bg-slate-950 text-rose-450 border border-slate-900 hover:bg-slate-900 text-xs font-bold rounded-xl transition-all cursor-pointer text-center"
            >
              Clear Stream Logs
            </button>
            <button
              id="reset-playground-btn"
              onClick={async () => {
                await store.reset();
                setSelectedFlowName('flow.users');
                await seedInitialDemoData(store);
              }}
              className="flex-1 py-2.5 px-3 bg-rose-950/10 text-rose-400 border border-rose-500/10 hover:bg-rose-950/20 text-xs font-bold rounded-xl transition-all cursor-pointer text-center"
            >
              Master Reset Store
            </button>
          </div>
        </div>

        {/* Dynamic Event Append Write forms */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4" id="append-form-card">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Plus className="h-4 w-4 text-emerald-400" /> Append Write Operations
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-sans">
            Every record insertion is an append to an immutable log queue. Existing states are recalculated by reducing history.
          </p>

          <div className="space-y-1">
            <div className="flex justify-between text-[11px] text-slate-400 font-mono">
              <span>JSON Payload Entry</span>
              <button 
                onClick={() => loadPayloadTemplate(selectedFlowName)}
                className="text-indigo-400 font-bold"
              >
                Reset Template
              </button>
            </div>
            <textarea
              id="flow-payload-editor"
              value={customPayloadStr}
              onChange={(e) => setCustomPayloadStr(e.target.value)}
              spellCheck="false"
              className="w-full h-40 p-3 bg-slate-950 text-emerald-400 border border-slate-800 rounded-xl font-mono text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-500 text-[10px]">Source Scope</label>
              <input
                id="event-source-scoped"
                type="text"
                value={writeSource}
                onChange={(e) => setWriteSource(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 font-mono text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="text-slate-500 text-[10px]">Envelope Meta</label>
              <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-[10px] text-slate-500 font-mono">
                version: 1.0 (Auto)
              </div>
            </div>
          </div>

          {writeError && (
            <div className="p-2.5 bg-rose-950/20 text-rose-450 border border-rose-500/20 rounded-xl text-[10px] font-mono leading-relaxed truncate" id="write-error-box">
              {writeError}
            </div>
          )}

          <button
            id="append-log-write-button"
            onClick={appendFormPayload}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2.5 text-xs font-mono"
          >
            <Play className="h-3.5 w-3.5 fill-current text-white shrink-0 animate-pulse" />
            <span>Append: {selectedFlowName} &lt;─ data</span>
          </button>
        </div>

        {/* Real-time subscription event observer backpressure details */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between" id="subscribe-log-card">
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Radio className="h-4 w-4 text-indigo-400 animate-pulse animate-duration-1000" /> Flow Subscription Logs
            </h3>
            
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <input
                    id="checkbox-backpressure"
                    type="checkbox"
                    checked={slowSubscriberEnabled}
                    onChange={(e) => setSlowSubscriberEnabled(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 bg-slate-900 border-slate-800 focus:ring-indigo-500 focus:ring-opacity-25 rounded cursor-pointer"
                  />
                  <div>
                    <label htmlFor="checkbox-backpressure" className="text-xs font-bold text-slate-300 cursor-pointer block leading-none">
                      Slow Subscriber Mode
                    </label>
                  </div>
                </div>
                <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full ${
                  slowSubscriberEnabled ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-500'
                }`}>
                  {slowSubscriberEnabled ? 'ACTIVE' : 'OFF'}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 leading-relaxed font-sans">
                Applies backpressure by sequential buffer queue processing. Slow subscribers buffer incoming items without dropouts.
              </p>

              {slowSubscriberEnabled && (
                <div className="flex items-center justify-between text-xs font-mono py-1 border-t border-slate-900 mt-1" id="backpressure-score">
                  <span className="text-slate-400">Queue Buffer Accumulator:</span>
                  <span className={`font-black ${backloggedQueueSize > 0 ? 'text-amber-400 animate-pulse' : 'text-slate-600'}`}>{backloggedQueueSize} items waiting</span>
                </div>
              )}
            </div>

            <div className="h-48 overflow-y-auto font-mono text-[10px] space-y-1.5 pr-2" id="live-subscriber-events-log">
              {liveLogList.length === 0 ? (
                <div className="text-slate-600 text-center py-12">
                  No notifications recorded. Appends will show up here live.
                </div>
              ) : (
                liveLogList.map((log, index) => (
                  <div key={index} className="p-2 bg-slate-950 rounded-lg text-indigo-300 border border-slate-910 leading-relaxed font-mono truncate">
                    <span className="text-slate-500 mr-2">[{log.time}]</span>
                    <span>{log.msg}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          <button
            onClick={() => setLiveLogList([])}
            className="w-full mt-4 py-2 text-center text-[10px] text-slate-500 hover:text-slate-300 font-bold uppercase tracking-wider"
          >
            Clear Screen Logs
          </button>
        </div>

      </div>

      {/* Main split workbench area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="workbench-core-panels">
        
        {/* Left Column: Immutable event log stream & Time Travel slider */}
        <div className="lg:col-span-8 space-y-6" id="stream-logs-and-timetravel">
          
          {/* Continuous Immutable Event Stream card logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="immutable-log-cards">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800/80 pb-3 mb-4 gap-4">
              <div>
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-widest flex items-center gap-1.5 font-mono">
                  <Database className="h-4 w-4" /> COMPACTION LOG: flow.{selectedFlowName}
                </span>
                <p className="text-[11px] text-slate-400 mt-1">
                  Complete chronological immutable operations list. Indices use auto B-Trees.
                </p>
              </div>
              <div className="flex items-center space-x-2 text-xs">
                <span className="font-mono text-indigo-400 font-bold bg-indigo-500/10 px-2.5 py-1 rounded-lg border border-indigo-500/20">
                  {eventsList.length} total writes
                </span>
              </div>
            </div>

            <div className="max-h-96 overflow-y-auto pr-2 space-y-3 font-mono text-[10px]" id="flow-event-items-scroller">
              {eventsList.length === 0 ? (
                <div className="text-slate-500 py-16 text-center font-sans space-y-2">
                  <Layers className="h-8 w-8 text-slate-700 mx-auto" />
                  <p>Stream logs are empty. Append events to populate.</p>
                </div>
              ) : (
                eventsList.map((ev, index) => (
                  <div key={ev.id} className="p-3.5 bg-slate-950 rounded-2xl border border-slate-900 relative group overflow-hidden hover:border-slate-800" id={`flow-item-view-${index}`}>
                    {/* Immutability watermarks */}
                    <div className="absolute right-3 top-3.5 bg-indigo-500/5 text-[9px] font-bold text-indigo-400 px-2 py-0.5 rounded-md border border-indigo-500/10 tracking-widest uppercase">
                      IMMUTABLE LOG Entry #{index}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <div className="flex items-center space-x-1 text-slate-500">
                          <Timer className="h-3.5 w-3.5" />
                          <span>Timestamp: <span className="text-slate-300 font-mono">{ev.timestamp}</span></span>
                        </div>
                        <div className="text-[11px] font-bold text-emerald-400 break-all">
                          ID: <span className="font-mono text-slate-400">{ev.id}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          Meta: <span className="text-slate-400">source="{ev.meta.source}" version={ev.meta.version}</span>
                        </div>
                      </div>
                      <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-910 shrink-0 font-mono text-emerald-400">
                        <span className="text-slate-500 block text-[9.5px] border-b border-slate-950 pb-1 mb-1 font-sans">EVENT PAYLOAD FIELD DATA</span>
                        {JSON.stringify(ev.data, null, 2)}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Time travel player scrubber */}
            {eventsList.length > 0 && (
              <div className="border-t border-slate-800/80 mt-6 pt-6 space-y-4" id="time-travel-scrubber-pane">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <History className="h-4 w-4 text-indigo-400" /> Historical State Time-Travel Playback
                  </h4>
                  <span className="text-[10px] font-mono text-slate-500 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-right">
                    Timeline: Record {timeTravelPoint + 1} of {eventsList.length}
                  </span>
                </div>

                <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <div className="flex items-center space-x-3">
                    <button
                      id="reset-timeline-btn"
                      onClick={() => setTimeTravelPoint(eventsList.length - 1)}
                      className="p-2 bg-slate-900 hover:bg-slate-800 hover:text-white border border-slate-800 rounded-xl font-bold text-[10px] tracking-wide text-slate-400 shrink-0 transition-all cursor-pointer"
                    >
                      LIVE NOW
                    </button>
                    
                    <input
                      id="timeline-range-slider"
                      type="range"
                      min="0"
                      max={eventsList.length - 1}
                      value={timeTravelPoint}
                      onChange={(e) => setTimeTravelPoint(Number(e.target.value))}
                      className="flex-1 accent-indigo-500 h-1 bg-slate-900 border border-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 leading-relaxed leading-3">
                    Scrub back along the chronological path to view the precise database state reconstructed by aggregate reductions at any point in history.
                  </p>

                  {/* Render the reconstructed table view */}
                  <div className="mt-3 overflow-x-auto border-t border-slate-900 pt-3" id="timeline-reconstructed-table">
                    <span className="text-[10px] text-indigo-300 block mb-2 font-mono uppercase tracking-wider">State Matrix Reconstructed: at timeline point</span>
                    {timeTravelRecordState.length === 0 ? (
                      <span className="text-[10px] text-slate-500 font-mono">No record entries materialized at this moment.</span>
                    ) : (
                      <table className="w-full text-left font-mono text-[10px] text-slate-300">
                        <thead>
                          <tr className="border-b border-slate-900 text-slate-500">
                            <th className="pb-1.5">Record Identifier key</th>
                            <th className="pb-1.5">Aggregate Record Payload Fields</th>
                          </tr>
                        </thead>
                        <tbody>
                          {timeTravelRecordState.map((rec, idx) => {
                            const key = rec?.id || rec?.uid || rec?.email || String(idx);
                            return (
                              <tr key={idx} className="border-b border-slate-910 last:border-b-0">
                                <td className="py-2 text-indigo-400 font-bold">{key}</td>
                                <td className="py-2 text-emerald-400 truncate max-w-lg">{JSON.stringify(rec)}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Right Column: Materialized Views state and Dynamic query analyzer */}
        <div className="lg:col-span-4 space-y-6" id="materialized-views-and-analyzer">
          
          {/* Materialized views Consolidator */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="materialized-cons-card">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 border-b border-slate-800 pb-3 mb-4">
              <Layers className="h-4 w-4 text-amber-500" /> Current Materialized View
            </h3>
            
            <p className="text-xs text-slate-500 leading-relaxed font-sans mb-4">
              Consolidated database records table generated in real-time by folding and reducing past events in memory.
            </p>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1" id="materialized-view-table-body">
              {materializedRecords.length === 0 ? (
                <div className="text-slate-600 text-[11px] font-mono text-center py-10">
                  No consolidated records. Log events to trigger reductions.
                </div>
              ) : (
                materializedRecords.map((record, index) => {
                  const key = record?.id || record?.uid || record?.email || String(index);
                  return (
                    <div key={key} className="p-3 bg-slate-950 border border-slate-800/80 rounded-xl space-y-1.5 font-mono" id={`materialized-rec-${key}`}>
                      <div className="flex items-center justify-between text-xs border-b border-slate-900 pb-1">
                        <span className="text-indigo-400 font-extrabold font-mono truncate max-w-40" title={key}>Record: {key}</span>
                        <span className="text-[10px] text-slate-500">Status: Active</span>
                      </div>
                      <pre className="text-[10px] text-emerald-500 overflow-x-auto leading-relaxed max-h-24">
                        {JSON.stringify(record, null, 2)}
                      </pre>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Flow Query Constructor and test console */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4" id="query-builder-card">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 border-b border-slate-800 pb-2">
              <Code2 className="h-4 w-4 text-indigo-400" /> Lazy Query Pipeline Builder
            </h3>

            <div className="space-y-3 text-xs" id="operators-forms">
              
              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800/60 workspace-sub-elements space-y-2">
                <span className="font-mono text-[10px] text-indigo-400 font-bold block uppercase">Step 1: .where() filter predicate</span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <input
                    id="filter-where-field"
                    type="text"
                    value={queryWhereField}
                    onChange={(e) => setQueryWhereField(e.target.value)}
                    placeholder="Field name: active"
                    className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 font-mono"
                  />
                  <input
                    id="filter-where-val"
                    type="text"
                    value={queryWhereValue}
                    onChange={(e) => setQueryWhereValue(e.target.value)}
                    placeholder="Value match: true"
                    className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 font-mono"
                  />
                </div>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800/60 workspace-sub-elements space-y-2">
                <span className="font-mono text-[10px] text-indigo-400 font-bold block uppercase">Step 2: .map() project payload field</span>
                <input
                  id="mapper-projection"
                  type="text"
                  value={queryMapField}
                  onChange={(e) => setQueryMapField(e.target.value)}
                  placeholder="Mapping projection field: name"
                  className="w-full p-2 bg-slate-900 border border-slate-800 rounded-lg text-[11px] text-slate-300 font-mono"
                />
              </div>

              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800/60 workspace-sub-elements space-y-2">
                <span className="font-mono text-[10px] text-indigo-400 font-bold block uppercase">Step 3: .reduce() accumulator field</span>
                <input
                  id="reducer-fold"
                  type="text"
                  value={queryReduceField}
                  onChange={(e) => setQueryReduceField(e.target.value)}
                  placeholder="Summation accumulator on: age"
                  className="w-full p-2 bg-slate-900 border border-slate-800 rounded-lg text-[11px] text-slate-300 font-mono"
                />
              </div>

            </div>

            <button
              id="execute-query-builder-pipeline-btn"
              onClick={executeUserQuery}
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all cursor-pointer text-center font-mono"
            >
              Run Lazy Pipeline Chains
            </button>

            {/* Query result output display */}
            {queryResult && (
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 mt-4 font-mono text-[11px]" id="query-results-bucket">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block">Query Execution Report:</span>
                <div className="space-y-1.5 text-slate-300">
                  <div>Matches Found: <span className="text-white font-extrabold">{queryResult.matchesCount}</span></div>
                  <div>Mapped Field Values: <span className="text-white truncate block shrink-0">{JSON.stringify(queryResult.items)}</span></div>
                  <div>Reduced Accumulator Score Sum: <span className="text-amber-400 font-extrabold">{queryResult.reduceSum}</span></div>
                </div>
              </div>
            )}

            {/* Query evaluation logs */}
            {queryTraceLog.length > 0 && (
              <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80 font-mono text-[10px] space-y-1 max-h-40 overflow-y-auto" id="pipeline-debugger">
                <span className="text-[9.5px] text-slate-500 uppercase tracking-wide block border-b border-slate-900 pb-1 mb-1 font-sans">Pipeline execution steps logging</span>
                {queryTraceLog.map((log, i) => (
                  <div key={i} className="text-slate-400 tracking-tight leading-relaxed">{log}</div>
                ))}
              </div>
            )}

          </div>

          {/* 100k Performance benchmarking test suite trigger panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4" id="benchmark-stress-trigger">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 border-b border-slate-800 pb-2">
              <Cpu className="h-4 w-4 text-emerald-400 animate-pulse" /> 100k Performance Loop Check
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed font-sans">
              Measures index propagation write and range-query lookup speed. Pushes 100,000 writes in micro-batches to demonstrate design scalability.
            </p>

            <button
              id="trigger-100k-stress-loop-btn"
              disabled={isBenchmarking}
              onClick={run100kPerformanceStressTest}
              className="w-full py-3 bg-slate-950 text-white font-bold text-xs rounded-xl border border-slate-800 hover:bg-slate-900 shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2 font-mono"
            >
              <Gauge className="h-4 w-4 text-emerald-500 shrink-0" />
              <span>{isBenchmarking ? 'Appending & Indexing 100k events...' : 'Trigger 100k Volume Stress Test'}</span>
            </button>

            {benchStats && (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-xs space-y-1.5 text-slate-300 mt-4" id="benchmarking-results-stats">
                <div className="flex justify-between border-b border-slate-910 py-1">
                  <span className="text-slate-500">100k Writes Appended + Indexed:</span>
                  <span className="text-white font-bold">{benchStats.duration} ms</span>
                </div>
                <div className="flex justify-between border-b border-slate-910 py-1">
                  <span className="text-slate-500">Effective Write Speed:</span>
                  <span className="text-emerald-400 font-extrabold">{benchStats.writeRate.toLocaleString()} writes/sec</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">B-Tree Range Evaluate query:</span>
                  <span className="text-sky-400 font-bold">{benchStats.searchDuration} ms</span>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
