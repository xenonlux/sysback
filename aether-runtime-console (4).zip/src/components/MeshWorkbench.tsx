/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Globe,
  Cpu,
  Database,
  Activity,
  Zap,
  ShieldAlert,
  Terminal,
  Play,
  Send,
  Layers,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  Sliders
} from 'lucide-react';
import { runAetherMeshTests, TestResult } from '../../tests/mesh.test';
import {
  createAetherMessage,
  MeshRouter,
  LoadBalancer,
  CircuitBreaker,
  createAetherClientProxy,
  HandlerRegistry,
  MultiTransportServer,
  JSONCodec,
  MessagePackCodec,
  AetherMessage,
  LocalTransportServer,
  TcpTransportServer,
  HttpTransportServer,
  WebSocketTransportServer,
  WebrtcTransportServer
} from '../index';

export default function MeshWorkbench() {
  // Test runner state
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [runningTests, setRunningTests] = useState(false);
  const [testSummary, setTestSummary] = useState<{ passed: number; failed: number } | null>(null);

  // Client Proxy Sandbox state
  const [proxyRoute, setProxyRoute] = useState('auth.users.get');
  const [proxyPayload, setProxyPayload] = useState('{\n  "uid": "usr-101",\n  "clearance": "L3_CORE"\n}');
  const [selectedTransport, setSelectedTransport] = useState<'local' | 'tcp' | 'http' | 'websocket' | 'webrtc'>('local');
  const [proxyLogs, setProxyLogs] = useState<Array<{ time: string; action: string; type: 'info' | 'success' | 'warn' | 'error'; detail?: string }>>([]);
  const [responseOutput, setResponseOutput] = useState<string>('');

  // Circuit Breaker settings and indicators
  const [breakerThreshold, setBreakerThreshold] = useState(3);
  const [breakerCooldown, setBreakerCooldown] = useState(3000);
  const [breakerState, setBreakerState] = useState<'CLOSED' | 'OPEN' | 'HALF-OPEN'>('CLOSED');
  const [circuitBreakerInstance, setCircuitBreakerInstance] = useState<CircuitBreaker | null>(null);

  // Load Balancer state
  const [lbStrategy, setLbStrategy] = useState<'round-robin' | 'least-connections'>('round-robin');
  const [nodes, setNodes] = useState<string[]>(['k8s-pod.aether.node-1:3000', 'k8s-pod.aether.node-2:3000', 'k8s-pod.aether.node-3:3000']);
  const [nodeStats, setNodeStats] = useState<Record<string, number>>({});
  const [loadBalancerInstance, setLoadBalancerInstance] = useState<LoadBalancer | null>(null);

  // Server Packet Logs
  const [serverLogs, setServerLogs] = useState<Array<{
    timestamp: string;
    transport: string;
    target: string;
    type: string;
    status: 'success' | 'error';
    errorDetail?: string;
    traceId: string;
    payload: string;
  }>>([]);

  // Initialize instances
  useEffect(() => {
    const cb = new CircuitBreaker({ failureThreshold: breakerThreshold, cooldownPeriodMs: breakerCooldown });
    setCircuitBreakerInstance(cb);
    setBreakerState(cb.getState());

    const lb = new LoadBalancer(nodes, lbStrategy);
    setLoadBalancerInstance(lb);
    setNodeStats(lb.getConnectionCounts());

    // Populate initial explanation
    setProxyLogs([{
      time: new Date().toLocaleTimeString(),
      action: 'AETHER Mesh Sandbox Instantiated',
      type: 'info',
      detail: 'Dynamic ES6 Proxies and client loopback channels stand ready.'
    }]);
  }, []);

  // Sync state machine loop triggers
  useEffect(() => {
    if (circuitBreakerInstance) {
      const interval = setInterval(() => {
        setBreakerState(circuitBreakerInstance.getState());
      }, 500);
      return () => clearInterval(interval);
    }
  }, [circuitBreakerInstance]);

  // Sync load balancer parameters
  const updateLbStrategy = (strategy: 'round-robin' | 'least-connections') => {
    setLbStrategy(strategy);
    if (loadBalancerInstance) {
      loadBalancerInstance.setStrategy(strategy);
      setNodeStats(loadBalancerInstance.getConnectionCounts());
    }
  };

  const handleRunMeshTests = async () => {
    setRunningTests(true);
    setTestResults([]);
    setTestSummary(null);

    try {
      const resp = await runAetherMeshTests();
      setTestResults(resp);
      const passed = resp.filter(r => r.status === 'passed').length;
      const failed = resp.filter(r => r.status === 'failed').length;
      setTestSummary({ passed, failed });
    } catch (err: any) {
      console.error(err);
    } finally {
      setRunningTests(false);
    }
  };

  const executeProxyCall = async (simulateFailure = false) => {
    const timeStr = () => new Date().toLocaleTimeString();
    
    // Clear outputs
    setResponseOutput('');

    let parsedPayload = {};
    try {
      parsedPayload = JSON.parse(proxyPayload);
    } catch {
      setProxyLogs(prev => [
        { time: timeStr(), action: 'Validation Check Collapsed', type: 'error', detail: 'Invalid JSON entered into Payload input.' },
        ...prev
      ]);
      return;
    }

    if (!circuitBreakerInstance || !loadBalancerInstance) return;

    // Resolve address context
    let prefix = 'local';
    let suffix = 'test-endpoint';
    if (selectedTransport === 'tcp') { prefix = 'tcp'; suffix = '127.0.0.1:9099'; }
    if (selectedTransport === 'http') { prefix = 'http'; suffix = 'http://127.0.0.1:8080'; }
    if (selectedTransport === 'websocket') { prefix = 'websocket'; suffix = 'ws://127.0.0.1:7771'; }
    if (selectedTransport === 'webrtc') { prefix = 'webrtc'; suffix = 'webrtc://peer-node-a'; }

    const resolvedAddress = `${prefix}://${suffix}`;

    // Update Load Balancer stats visually
    const nodeAddress = loadBalancerInstance.select();
    loadBalancerInstance.incrementConnection(nodeAddress);
    setNodeStats(loadBalancerInstance.getConnectionCounts());

    setProxyLogs(prev => [
      {
        time: timeStr(),
        action: `Routing client.${proxyRoute}() via ${selectedTransport.toUpperCase()}`,
        type: 'info',
        detail: `Address resolved: ${resolvedAddress} - Node target: ${nodeAddress}`
      },
      ...prev
    ]);

    // Setup simulated Mock Server
    const registry = new HandlerRegistry();
    if (simulateFailure) {
      registry.register(proxyRoute, () => {
        throw new Error('Downstream microservice failed or timeout exceeded.');
      });
    } else {
      registry.register(proxyRoute, (payload) => {
        return {
          ok: true,
          timestamp: new Date().toISOString(),
          transportSelected: selectedTransport,
          receivedPayload: payload,
          meshAetherStatus: 'CONNECTED_ROUTED_OK'
        };
      });
    }

    const router = new MeshRouter();
    const serverInstance = selectedTransport === 'local' ? new LocalTransportServer() :
                           selectedTransport === 'tcp' ? new TcpTransportServer() :
                           selectedTransport === 'http' ? new HttpTransportServer() :
                           selectedTransport === 'websocket' ? new WebSocketTransportServer() :
                           new WebrtcTransportServer();

    const multiServer = new MultiTransportServer(registry);
    multiServer.registerServer(selectedTransport, serverInstance as any);

    try {
      await serverInstance.listen(resolvedAddress);
      
      const clientInstance = router.selectTransport(resolvedAddress);
      await clientInstance.connect(resolvedAddress);

      // Setup proxy client
      const proxyClient = createAetherClientProxy({
        router,
        loadBalancer: new LoadBalancer([resolvedAddress], 'round-robin'),
        circuitBreaker: circuitBreakerInstance,
        timeoutMs: 2000
      });

      // Split proxy route dot notation
      const routeKeys = proxyRoute.split('.');
      let callable: any = proxyClient;
      for (const k of routeKeys) {
        if (callable[k] !== undefined) {
          callable = callable[k];
        } else {
          // Dynamic Proxy catches it regardless
          callable = callable[k];
        }
      }

      // Execute with circuit breaker wrapper
      const result = await callable(parsedPayload);
      
      setResponseOutput(JSON.stringify(result, null, 2));
      setBreakerState(circuitBreakerInstance.getState());

      setProxyLogs(prev => [
        { time: timeStr(), action: 'RPC Complete Success', type: 'success', detail: `Response payload arrived in client frame.` },
        ...prev
      ]);

      // Push to server activity log table
      setServerLogs(prev => [
        {
          timestamp: new Date().toISOString(),
          transport: selectedTransport,
          target: proxyRoute,
          type: 'call',
          status: 'success',
          traceId: 'trace-' + Math.random().toString(36).substring(4, 10),
          payload: JSON.stringify(parsedPayload)
        },
        ...prev
      ]);

    } catch (err: any) {
      setBreakerState(circuitBreakerInstance.getState());
      setProxyLogs(prev => [
        { time: timeStr(), action: 'RPC Failure Blocked / FAILED', type: 'error', detail: err.message },
        ...prev
      ]);

      setServerLogs(prev => [
        {
          timestamp: new Date().toISOString(),
          transport: selectedTransport,
          target: proxyRoute,
          type: 'call',
          status: 'error',
          errorDetail: err.message,
          traceId: 'trace-err-' + Math.random().toString(36).substring(4, 10),
          payload: JSON.stringify(parsedPayload)
        },
        ...prev
      ]);
    } finally {
      loadBalancerInstance.decrementConnection(nodeAddress);
      setNodeStats(loadBalancerInstance.getConnectionCounts());
      await serverInstance.close();
    }
  };

  const handleForceBreaker = (status: 'CLOSED' | 'OPEN' | 'HALF-OPEN') => {
    if (circuitBreakerInstance) {
      circuitBreakerInstance.forceState(status);
      setBreakerState(status);
      setProxyLogs(prev => [
        {
          time: new Date().toLocaleTimeString(),
          action: `Force Breaker Override`,
          type: status === 'CLOSED' ? 'success' : status === 'OPEN' ? 'warn' : 'info',
          detail: `Circuit state manually overridden to ${status}.`
        },
        ...prev
      ]);
    }
  };

  return (
    <div className="space-y-8" id="mesh-workbench-root">
      
      {/* Title Header Hero Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 relative overflow-hidden" id="mesh-hero">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none" />
        <div className="flex items-center space-x-4">
          <div className="p-3.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-2xl">
            <Globe className="h-7 w-7 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-extrabold text-white tracking-tight">AETHER Network Mesh Wing</h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] uppercase font-mono font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                Protocol Layer v2.1
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1 max-w-2xl">
              An intelligent client/server communications bus layer that continuously analyzes environmental constraints to bind calls to optimal physical channels.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Controls & Sandboxing (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* CLIENT PROXY CLIENT CONSOLE */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="client-proxy-box">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800/60 pb-3">
              <div className="flex items-center space-x-2">
                <Cpu className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-200">Interactive ES6 Proxy Sandbox</h3>
              </div>
              <span className="text-[10px] font-mono text-slate-500">CLIENT-SIDE INVOCATION</span>
            </div>

            <div className="space-y-4 text-xs">
              
              {/* TARGET METHOD PROPERTY */}
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1.5 uppercase tracking-wider">Dynamic Proxy Chain Target Namespace</label>
                <div className="flex items-center space-x-2 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
                  <span className="text-slate-500 font-mono select-none">client.</span>
                  <input
                    type="text"
                    value={proxyRoute}
                    onChange={(e) => setProxyRoute(e.target.value)}
                    placeholder="auth.users.get"
                    className="bg-transparent text-slate-200 font-mono outline-none flex-1 mt-0 text-xs"
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">Property names compile dynamically back into the network message target string.</p>
              </div>

              {/* TRANSPORT LAYERS */}
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1.5 uppercase tracking-wider">Auto-Selected Physical Transport</label>
                <div className="grid grid-cols-5 gap-2" id="transport-toggle-grid">
                  {(['local', 'tcp', 'http', 'websocket', 'webrtc'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setSelectedTransport(t)}
                      className={`p-2 rounded-xl border text-[11px] font-bold capitalize transition-all cursor-pointer text-center ${
                        selectedTransport === t
                          ? 'bg-indigo-600/15 border-indigo-500 text-indigo-300'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* PAYLOAD ENTER */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1.5 uppercase tracking-wider">AetherMessage Payload (JSON)</label>
                  <textarea
                    rows={4}
                    value={proxyPayload}
                    onChange={(e) => setProxyPayload(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1.5 uppercase tracking-wider">Unframed Reply Response</label>
                  <div className="w-full h-[98px] bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px] text-emerald-400 overflow-y-auto whitespace-pre">
                    {responseOutput || '// Standby for RPC trigger responses...'}
                  </div>
                </div>
              </div>

              {/* TRIGGER RUNNERS */}
              <div className="flex items-center space-x-3 pt-2">
                <button
                  onClick={() => executeProxyCall(false)}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer text-xs"
                >
                  <Send className="h-4 w-4" />
                  <span>Execute Proxy.Call()</span>
                </button>
                <button
                  onClick={() => executeProxyCall(true)}
                  className="flex-1 bg-red-950/40 border border-red-500/20 text-red-400 hover:bg-red-900/30 font-bold py-2.5 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer text-xs"
                >
                  <ShieldAlert className="h-4 w-4" />
                  <span>Simulate Outage Error</span>
                </button>
              </div>

            </div>
          </div>

          {/* SANDBOX PACKETS LOGGER */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="mesh-terminal-box">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Terminal className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-200">Local Sandbox Proxy Stream</h3>
              </div>
              <button
                onClick={() => setProxyLogs([])}
                className="text-[10px] text-slate-500 hover:text-slate-300 underline underline-offset-2 cursor-pointer"
              >
                Clear Terminal
              </button>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 h-56 overflow-y-auto font-mono text-[10px] space-y-2">
              {proxyLogs.length === 0 ? (
                <div className="text-slate-600 text-center py-12">No logs recorded. Execute calls to start packet capture.</div>
              ) : (
                proxyLogs.map((log, idx) => (
                  <div key={idx} className="border-b border-slate-900 last:border-0 pb-1.5 flex items-start space-x-2">
                    <span className="text-slate-500 select-none">[{log.time}]</span>
                    <div className="flex-1">
                      <span className={`font-bold mr-1 ${
                        log.type === 'success' ? 'text-emerald-400' :
                        log.type === 'error' ? 'text-red-400' :
                        log.type === 'warn' ? 'text-amber-400' : 'text-indigo-400'
                      }`}>
                        {log.action}
                      </span>
                      {log.detail && <p className="text-slate-400 mt-0.5 text-[9.5px] leading-relaxed">{log.detail}</p>}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Resiliency & Test Suite (5 cols) */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* COMPATIBILITY TESTS PORTAL */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="compatibility-suite-portal">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800/60 pb-3">
              <div className="flex items-center space-x-2">
                <Layers className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-200">AETHER Compatibility Suite</h3>
              </div>
              <button
                onClick={handleRunMeshTests}
                disabled={runningTests}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800/50 text-white font-bold py-1 px-3 rounded-lg flex items-center space-x-1.5 transition-all cursor-pointer text-[10px] uppercase"
              >
                {runningTests ? (
                  <>
                    <RefreshCw className="h-3 w-3 animate-spin" />
                    <span>Running</span>
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3" />
                    <span>Run Suite</span>
                  </>
                )}
              </button>
            </div>

            {testSummary && (
              <div className="grid grid-cols-2 gap-4 mb-4" id="tests-summary-box">
                <div className="bg-emerald-950/20 border border-emerald-500/25 px-3 py-2 rounded-xl flex items-center justify-between">
                  <span className="text-emerald-400 text-[10px] font-bold tracking-wider">PASSED</span>
                  <span className="text-lg font-extrabold text-emerald-400 font-mono">{testSummary.passed}</span>
                </div>
                <div className="bg-red-950/20 border border-red-500/25 px-3 py-2 rounded-xl flex items-center justify-between">
                  <span className="text-red-400 text-[10px] font-bold tracking-wider">FAILED</span>
                  <span className="text-lg font-extrabold text-red-400 font-mono">{testSummary.failed}</span>
                </div>
              </div>
            )}

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {testResults.length === 0 ? (
                <div className="text-slate-500 text-center py-12 text-xs">
                  Click <strong className="text-slate-300">Run Suite</strong> above to coordinate strict offline assertions.
                </div>
              ) : (
                testResults.map((res, idx) => (
                  <div
                    key={idx}
                    className="flex items-start justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/50 text-[11px]"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center space-x-1.5">
                        <span className="px-1.5 py-0.2 bg-slate-900 border border-slate-800 rounded font-mono text-[9px] text-slate-400">
                          {res.category}
                        </span>
                        <h4 className="font-bold text-slate-300 leading-none">{res.name}</h4>
                      </div>
                      {res.errorMessage && <p className="text-red-400 text-[9.5px] font-mono leading-normal">{res.errorMessage}</p>}
                    </div>
                    <div className="flex items-center space-x-2 shrink-0">
                      <span className="text-slate-500 font-mono text-[10px]">{res.durationMs}ms</span>
                      {res.status === 'passed' ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-400" />
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* CIRCUIT BREAKER TELEMETRY */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="circuit-breaker-card">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-200">Circuit Breaker Telemetry</h3>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className={`h-2.5 w-2.5 rounded-full ${
                  breakerState === 'CLOSED' ? 'bg-emerald-400 animate-pulse' :
                  breakerState === 'OPEN' ? 'bg-red-500 animate-ping' : 'bg-amber-400 animate-pulse'
                }`} />
                <span className="font-mono text-xs font-black text-slate-300">{breakerState}</span>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/60 flex justify-between gap-4 text-[11px] font-mono">
                <div>
                  <span className="text-slate-500 block">THRESHOLD</span>
                  <span className="text-slate-300 font-bold">{breakerThreshold} Failures</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">COOLDOWN</span>
                  <span className="text-slate-300 font-bold">{breakerCooldown}ms</span>
                </div>
              </div>

              {/* OVERWRITE TOGGLES */}
              <div>
                <span className="block text-[10px] font-mono text-slate-500 mb-2 uppercase">Manual Diagnostic Override</span>
                <div className="grid grid-cols-3 gap-2" id="override-breaker-btns">
                  <button
                    onClick={() => handleForceBreaker('CLOSED')}
                    className="py-1 px-2 rounded-lg border border-slate-800 bg-slate-950 text-emerald-400 hover:bg-emerald-900/10 font-bold text-[10px] uppercase transition-all cursor-pointer text-center"
                  >
                    Force Close
                  </button>
                  <button
                    onClick={() => handleForceBreaker('OPEN')}
                    className="py-1 px-2 rounded-lg border border-slate-800 bg-slate-950 text-red-400 hover:bg-red-900/10 font-bold text-[10px] uppercase transition-all cursor-pointer text-center"
                  >
                    Force Trip
                  </button>
                  <button
                    onClick={() => handleForceBreaker('HALF-OPEN')}
                    className="py-1 px-2 rounded-lg border border-slate-800 bg-slate-950 text-amber-400 hover:bg-amber-900/10 font-bold text-[10px] uppercase transition-all cursor-pointer text-center"
                  >
                    Force Probe
                  </button>
                </div>
              </div>

            </div>
          </div>

          {/* TRAFFIC CONTROLLERS (LOAD BALANCER) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5" id="load-balancer-card">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800/60 pb-3">
              <div className="flex items-center space-x-2">
                <Sliders className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-200">AETHER Dynamic Distributer</h3>
              </div>
              
              <div className="flex bg-slate-950 p-[3px] rounded-lg border border-slate-800 text-[10px]">
                <button
                  onClick={() => updateLbStrategy('round-robin')}
                  className={`py-1 px-2 rounded font-bold transition-all whitespace-nowrap cursor-pointer ${
                    lbStrategy === 'round-robin' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Round Robin
                </button>
                <button
                  onClick={() => updateLbStrategy('least-connections')}
                  className={`py-1 px-2 rounded font-bold transition-all whitespace-nowrap cursor-pointer ${
                    lbStrategy === 'least-connections' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Least Conns
                </button>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="space-y-2.5">
                {nodes.map((node, i) => {
                  const val = nodeStats[node] ?? 0;
                  // Dynamic percentage based bar representation
                  const pct = Math.min(100, (val / 10) * 100);
                  
                  return (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between items-center text-[11px] font-mono">
                        <span className="text-slate-300 truncate max-w-[200px]">{node}</span>
                        <span className="text-slate-500">{val} conns</span>
                      </div>
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                        <div
                          className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.max(5, pct)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* FOOTER SECTION: SERVER LISTENER LOGSactivity table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="server-packet-log-desk">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800/60 pb-3">
          <div className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-slate-200">MultiTransportServer Inbound Packet Telemetry</h3>
          </div>
          <span className="text-[10px] font-mono text-emerald-400">STATUS: ACTIVE STANDBY</span>
        </div>

        <div className="overflow-x-auto text-[11px]" id="server-logs-table-box">
          {serverLogs.length === 0 ? (
            <div className="py-8 text-center text-slate-600 font-mono">
              [SYSTEM] Listening on multi-protocol socket ports. Trigger mock Proxy.Call() requests to display live telemetry.
            </div>
          ) : (
            <table className="w-full text-left font-mono border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 text-[10px]">
                  <th className="pb-2 font-bold uppercase tracking-wider">Timestamp</th>
                  <th className="pb-2 font-bold uppercase tracking-wider">Transport</th>
                  <th className="pb-2 font-bold uppercase tracking-wider">Target Route</th>
                  <th className="pb-2 font-bold uppercase tracking-wider">Trace ID</th>
                  <th className="pb-2 font-bold uppercase tracking-wider">Payload</th>
                  <th className="pb-2 font-bold uppercase tracking-wider text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {serverLogs.map((log, idx) => (
                  <tr key={idx} className="hover:bg-slate-950/30">
                    <td className="py-2.5 text-slate-500">{log.timestamp.slice(11, 19)}</td>
                    <td className="py-2.5 uppercase font-bold text-indigo-400">{log.transport}</td>
                    <td className="py-2.5 font-bold text-slate-200">{log.target}</td>
                    <td className="py-2.5 text-slate-500">{log.traceId}</td>
                    <td className="py-2.5 max-w-[200px] truncate text-slate-400" title={log.payload}>{log.payload}</td>
                    <td className="py-2.5 text-right font-bold">
                      {log.status === 'success' ? (
                        <span className="text-emerald-400 font-bold bg-emerald-900/10 border border-emerald-500/20 px-2 py-0.5 rounded-md text-[10px]">SUCCESS</span>
                      ) : (
                        <span className="text-red-400 font-bold bg-red-900/10 border border-red-500/20 px-2 py-0.5 rounded-md text-[10px]" title={log.errorDetail}>FAILED</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

    </div>
  );
}
