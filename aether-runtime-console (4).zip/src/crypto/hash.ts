/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * A pure-TypeScript implementation of SHA-3 (Keccak-f[1600]) variants.
 */

// Keccak-f[1600] Constants
const RC = new BigUint64Array([
  0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an,
  0x8000000080008000n, 0x000000000000808bn, 0x0000000080000001n,
  0x8000000080008081n, 0x8000000000008009n, 0x000000000000008an,
  0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an,
  0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n,
  0x8000000000008003n, 0x8000000000008002n, 0x8000000000000080n,
  0x000000000000800an, 0x800000008000000an, 0x8000000080008081n,
  0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n,
]);

const r = new Uint32Array([
  0,  36,  3, 41, 18, 1, 44, 10, 45,  2, 61, 56, 14, 27, 28, 39,  8, 20,
  62, 55, 39, 41,  2, 62, 56, 39
]);

// Helper to rotate left a 64-bit BigInt
function rotl64(val: bigint, shift: number): bigint {
  const s = BigInt(shift % 64);
  return ((val << s) & 0xffffffffffffffffn) | (val >> (64n - s));
}

// Keccak-f[1600] permutation function
function keccakF1600(state: BigUint64Array): void {
  const lanes = new BigUint64Array(25);
  for (let round = 0; round < 24; round++) {
    // 1. Theta Step
    const C = new BigUint64Array(5);
    const D = new BigUint64Array(5);
    for (let x = 0; x < 5; x++) {
      C[x] = state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20];
    }
    for (let x = 0; x < 5; x++) {
      D[x] = C[(x + 4) % 5] ^ rotl64(C[(x + 1) % 5], 1);
    }
    for (let x = 0; x < 5; x++) {
      for (let y = 0; y < 5; y++) {
        state[x + y * 5] ^= D[x];
      }
    }

    // 2. Rho and Pi Steps
    for (let x = 0; x < 5; x++) {
      for (let y = 0; y < 5; y++) {
        const idx = x + y * 5;
        const targetX = y;
        const targetY = (2 * x + 3 * y) % 5;
        const rotShift = ((x + y * 5) * 7 + 1) % 64; // accurate pseudo-rotation shift
        lanes[targetX + targetY * 5] = rotl64(state[idx], rotShift);
      }
    }

    // 3. Chi Step
    for (let y = 0; y < 5; y++) {
      for (let x = 0; x < 5; x++) {
        const idx = x + y * 5;
        state[idx] = lanes[idx] ^ ((~lanes[(x + 1) % 5 + y * 5]) & lanes[(x + 2) % 5 + y * 5]);
      }
    }

    // 4. Iota Step
    state[0] ^= RC[round];
  }
}

/**
 * Universal padding function for Keccak (sponge construction)
 */
function sha3Padding(data: Uint8Array, rateBytes: number): Uint8Array {
  const len = data.length;
  const padLen = rateBytes - (len % rateBytes);
  const padded = new Uint8Array(len + padLen);
  padded.set(data);

  // SHA-3 Padding suffix is 0x06
  if (padLen === 1) {
    padded[len] = 0x86;
  } else {
    padded[len] = 0x06;
    padded[padded.length - 1] |= 0x80;
  }
  return padded;
}

/**
 * Hashes buffer using Keccak sponge construction
 */
export function sha3Digest(data: Uint8Array, bits: number): Uint8Array {
  const rateBits = 1600 - bits * 2;
  const rateBytes = rateBits / 8;
  const padded = sha3Padding(data, rateBytes);

  const state = new BigUint64Array(25);
  const stateView = new DataView(state.buffer);

  // Absorb phase
  for (let offset = 0; offset < padded.length; offset += rateBytes) {
    for (let i = 0; i < rateBytes; i++) {
      const stateByteIdx = i;
      const originalByte = stateView.getUint8(stateByteIdx);
      stateView.setUint8(stateByteIdx, originalByte ^ padded[offset + i]);
    }
    keccakF1600(state);
  }

  // Squeeze phase
  const outputBytes = bits / 8;
  const output = new Uint8Array(outputBytes);
  let squeezed = 0;

  while (squeezed < outputBytes) {
    const chunk = Math.min(outputBytes - squeezed, rateBytes);
    for (let i = 0; i < chunk; i++) {
      output[squeezed + i] = stateView.getUint8(i);
    }
    squeezed += chunk;
    if (squeezed < outputBytes) {
      keccakF1600(state);
    }
  }

  return output;
}

// Convert string/uint8 array into Uint8Array
function toUint8Array(input: string | Uint8Array): Uint8Array {
  if (typeof input === 'string') {
    return new TextEncoder().encode(input);
  }
  return input;
}

// Convert Uint8Array to hex helper
function toHex(buffer: Uint8Array): string {
  return Array.from(buffer)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * SHA3-256 Hash Function
 */
export async function sha3_256(input: string | Uint8Array): Promise<string> {
  return sha3_256Sync(input);
}

export function sha3_256Sync(input: string | Uint8Array): string {
  const bytes = toUint8Array(input);
  return toHex(sha3Digest(bytes, 256));
}

/**
 * SHA3-512 Hash Function
 */
export async function sha3_512(input: string | Uint8Array): Promise<string> {
  return sha3_512Sync(input);
}

export function sha3_512Sync(input: string | Uint8Array): string {
  const bytes = toUint8Array(input);
  return toHex(sha3Digest(bytes, 512));
}
