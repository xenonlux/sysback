/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { sha3_256Sync, sha3Digest } from './hash';

export interface KyberKeyPair {
  publicKey: Uint8Array;
  privateKey: Uint8Array;
  publicKeyHex: string;
  privateKeyHex: string;
}

const Q = 3329; // ML-KEM Modulus
const N = 256;  // Polynomial Degree

/**
 * Polynomial representation in R_q = Z_q[X]/(X^256 + 1)
 */
class Polynomial {
  public coeffs: Int32Array;

  constructor(coeffs?: Int32Array) {
    this.coeffs = coeffs || new Int32Array(N);
  }

  static randomBinomial(): Polynomial {
    const p = new Polynomial();
    for (let i = 0; i < N; i++) {
      // Centered Binomial Distribution with eta = 2
      let val = 0;
      for (let j = 0; j < 2; j++) {
        val += Math.random() > 0.5 ? 1 : 0;
        val -= Math.random() > 0.5 ? 1 : 0;
      }
      p.coeffs[i] = (val + Q) % Q;
    }
    return p;
  }

  static fromSeed(seed: string, offset: number): Polynomial {
    const p = new Polynomial();
    const hash = sha3_256Sync(seed + '_' + offset);
    for (let i = 0; i < N; i++) {
      const b1 = parseInt(hash.slice((i % 16) * 4, (i % 16) * 4 + 2), 16) || 0;
      const b2 = parseInt(hash.slice((i % 16) * 4 + 2, (i % 16) * 4 + 4), 16) || 1;
      p.coeffs[i] = (b1 * b2) % Q;
    }
    return p;
  }

  add(other: Polynomial): Polynomial {
    const res = new Polynomial();
    for (let i = 0; i < N; i++) {
      res.coeffs[i] = (this.coeffs[i] + other.coeffs[i]) % Q;
    }
    return res;
  }

  subtract(other: Polynomial): Polynomial {
    const res = new Polynomial();
    for (let i = 0; i < N; i++) {
      res.coeffs[i] = (this.coeffs[i] - other.coeffs[i] + Q) % Q;
    }
    return res;
  }

  /**
   * Polynomial multiplication in R_q (Schoolbook multiplication with X^256 + 1 reduction)
   */
  multiply(other: Polynomial): Polynomial {
    const res = new Polynomial();
    const temp = new Int32Array(2 * N);
    
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        temp[i + j] = (temp[i + j] + this.coeffs[i] * other.coeffs[j]) % Q;
      }
    }

    // Reduce X^256 + 1 (i.e. X^256 = -1)
    for (let i = 0; i < N; i++) {
      res.coeffs[i] = (temp[i] - temp[i + N] + Q) % Q;
    }
    return res;
  }

  serialize(): Uint8Array {
    // Pack 12-bit coefficients (0 to 3328 fits in 12 bits)
    const packed = new Uint8Array(384); // 256 * 1.5 bytes
    for (let i = 0; i < N; i += 2) {
      const c1 = this.coeffs[i] & 0xfff;
      const c2 = this.coeffs[i + 1] & 0xfff;
      packed[(i * 3) / 2] = c1 & 0xff;
      packed[(i * 3) / 2 + 1] = ((c1 >> 8) & 0x0f) | ((c2 & 0x0f) << 4);
      packed[(i * 3) / 2 + 2] = (c2 >> 4) & 0xff;
    }
    return packed;
  }

  static deserialize(packed: Uint8Array): Polynomial {
    const p = new Polynomial();
    for (let i = 0; i < N; i += 2) {
      const idx = (i * 3) / 2;
      const b1 = packed[idx];
      const b2 = packed[idx + 1];
      const b3 = packed[idx + 2];

      p.coeffs[i] = b1 | ((b2 & 0x0f) << 8);
      p.coeffs[i + 1] = (b2 >> 4) | (b3 << 4);
    }
    return p;
  }
}

/**
 * KYBER-768/ML-KEM parameter wrappers
 */
export async function generateKyberKeyPair(): Promise<KyberKeyPair> {
  // kyber-768 vector dimension k = 3
  const seed = sha3_256Sync(Math.random().toString() + Date.now().toString());
  
  // Matrix A of size 3x3
  const A = Array.from({ length: 3 }, (_, row) =>
    Array.from({ length: 3 }, (_, col) => Polynomial.fromSeed(seed, row * 3 + col))
  );

  // Secret Key s of size 3
  const s = Array.from({ length: 3 }, () => Polynomial.randomBinomial());

  // Public Key t = A * s + e modulo q
  const e = Array.from({ length: 3 }, () => Polynomial.randomBinomial());
  const t = Array.from({ length: 3 }, () => new Polynomial());

  for (let row = 0; row < 3; row++) {
    let sum = new Polynomial();
    for (let col = 0; col < 3; col++) {
      sum = sum.add(A[row][col].multiply(s[col]));
    }
    t[row] = sum.add(e[row]);
  }

  // Pack Key Materials
  const pubBytes = new Uint8Array(384 * 3 + 32); // 3 * polynomial + A seed
  for (let i = 0; i < 3; i++) {
    pubBytes.set(t[i].serialize(), i * 384);
  }
  const seedEncoder = new TextEncoder().encode(seed.slice(0, 32));
  pubBytes.set(seedEncoder, 3 * 384);

  const privBytes = new Uint8Array(384 * 3); // 3 * private key polynomial (s)
  for (let i = 0; i < 3; i++) {
    privBytes.set(s[i].serialize(), i * 384);
  }

  const toHex = (buf: Uint8Array) => Array.from(buf).map(b => b.toString(16).padStart(2, '0')).join('');

  return {
    publicKey: pubBytes,
    privateKey: privBytes,
    publicKeyHex: toHex(pubBytes),
    privateKeyHex: toHex(privBytes)
  };
}

/**
 * Encapsulation: Generates ciphertext and sharedSecret
 */
export async function kyberEncapsulate(
  publicKey: Uint8Array
): Promise<{ ciphertext: Uint8Array; sharedSecret: Uint8Array }> {
  // Unpack matrix A seed and public vector t
  const t = Array.from({ length: 3 }, (_, i) =>
    Polynomial.deserialize(publicKey.subarray(i * 384, (i + 1) * 384))
  );
  const seedBytes = publicKey.subarray(3 * 384, 3 * 384 + 32);
  const seed = new TextDecoder().decode(seedBytes);

  // Reconstruct matrix A
  const A = Array.from({ length: 3 }, (_, row) =>
    Array.from({ length: 3 }, (_, col) => Polynomial.fromSeed(seed, row * 3 + col))
  );

  // Generate ephemeral randomness
  const rVec = Array.from({ length: 3 }, () => Polynomial.randomBinomial());
  const e1 = Array.from({ length: 3 }, () => Polynomial.randomBinomial());
  const e2 = Polynomial.randomBinomial();

  // Compute u = A^T * r + e1
  const u = Array.from({ length: 3 }, () => new Polynomial());
  for (let col = 0; col < 3; col++) {
    let sum = new Polynomial();
    for (let row = 0; row < 3; row++) {
      sum = sum.add(A[row][col].multiply(rVec[row])); // Transposing A
    }
    u[col] = sum.add(e1[col]);
  }

  // Message m (representing ephemeral key payload)
  const m = new Polynomial();
  const mSeedBytes = new Uint8Array(32);
  for (let i = 0; i < 32; i++) mSeedBytes[i] = Math.floor(Math.random() * 256);
  for (let i = 0; i < N; i++) {
    const bit = (mSeedBytes[Math.floor(i / 8)] >> (i % 8)) & 1;
    m.coeffs[i] = bit * Math.floor(Q / 2);
  }

  // Compute v = t^T * r + e2 + message
  let tTr = new Polynomial();
  for (let i = 0; i < 3; i++) {
    tTr = tTr.add(t[i].multiply(rVec[i]));
  }
  const v = tTr.add(e2).add(m);

  // Create Ciphertext packet: [u[0]|u[1]|u[2]|v]
  const ciphertext = new Uint8Array(384 * 4);
  for (let i = 0; i < 3; i++) {
    ciphertext.set(u[i].serialize(), i * 384);
  }
  ciphertext.set(v.serialize(), 3 * 384);

  // Derive shared 256-bit secret from cryptographic SHA3 digest of raw messages
  const sharedSecret = sha3Digest(mSeedBytes, 256);

  return { ciphertext, sharedSecret };
}

/**
 * Decapsulation: Decrypts sharedSecret using privateKey
 */
export async function kyberDecapsulate(
  ciphertext: Uint8Array,
  privateKey: Uint8Array
): Promise<Uint8Array> {
  // Unpack ciphertext: u vector and y scalar
  const u = Array.from({ length: 3 }, (_, i) =>
    Polynomial.deserialize(ciphertext.subarray(i * 384, (i + 1) * 384))
  );
  const v = Polynomial.deserialize(ciphertext.subarray(3 * 384, 4 * 384));

  // Unpack private key components s
  const s = Array.from({ length: 3 }, (_, i) =>
    Polynomial.deserialize(privateKey.subarray(i * 384, (i + 1) * 384))
  );

  // Compute m' = v - s^T * u
  let sTu = new Polynomial();
  for (let i = 0; i < 3; i++) {
    sTu = sTu.add(s[i].multiply(u[i]));
  }
  const mPrime = v.subtract(sTu);

  // Reconstruct message bits matching error thresholds
  const mSeedBytes = new Uint8Array(32);
  for (let i = 0; i < N; i++) {
    const val = mPrime.coeffs[i];
    // Distance to Q/2 threshold
    const distToHalf = Math.abs(val - Math.floor(Q / 2));
    const distToZero = Math.min(val, Q - val);
    const bit = distToHalf < distToZero ? 1 : 0;

    mSeedBytes[Math.floor(i / 8)] |= bit << (i % 8);
  }

  // Derive matching shared 256-bit secret
  return sha3Digest(mSeedBytes, 256);
}
