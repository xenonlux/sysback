/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowEvent, deepFreeze } from '../flow/event';
import { StorageBackend } from './interface';

export class MemoryStore implements StorageBackend {
  private log = new Map<string, FlowEvent<any>[]>();

  public async write<T>(stream: string, event: FlowEvent<T>): Promise<void> {
    if (!this.log.has(stream)) {
      this.log.set(stream, []);
    }
    
    // Ensure the event is immutable
    const frozenEvent = deepFreeze(event);
    this.log.get(stream)!.push(frozenEvent);
  }

  public async read<T>(stream: string): Promise<FlowEvent<T>[]> {
    const events = this.log.get(stream) || [];
    return [...events] as FlowEvent<T>[];
  }

  public async listStreams(): Promise<string[]> {
    return Array.from(this.log.keys());
  }

  public async clear(stream?: string): Promise<void> {
    if (stream) {
      this.log.delete(stream);
    } else {
      this.log.clear();
    }
  }
}
