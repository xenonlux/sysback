/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowEvent } from '../flow/event';

export interface StorageBackend {
  /**
   * Appends an event to a named stream.
   */
  write<T>(stream: string, event: FlowEvent<T>): Promise<void>;

  /**
   * Reads all historical events for a named stream.
   */
  read<T>(stream: string): Promise<FlowEvent<T>[]>;

  /**
   * Lists all existing stream names.
   */
  listStreams(): Promise<string[]>;

  /**
   * Wipes database stream logs completely (helpful for resets and testing).
   */
  clear(stream?: string): Promise<void>;
}
