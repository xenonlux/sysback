/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowEvent, deepFreeze } from '../flow/event';
import { StorageBackend } from './interface';

export class FileStore implements StorageBackend {
  private filePathResolver: (stream: string) => string;
  private isNode: boolean;
  private browserStorage = new Map<string, string[]>();

  constructor(baseDirectoryOrResolver?: string | ((stream: string) => string)) {
    // Detect environment accurately
    this.isNode = typeof process !== 'undefined' && process.versions && process.versions.node !== undefined;
    
    if (typeof baseDirectoryOrResolver === 'function') {
      this.filePathResolver = baseDirectoryOrResolver;
    } else {
      const baseDir = baseDirectoryOrResolver || './data';
      this.filePathResolver = (stream) => `${baseDir}/${stream}.ndjson`;
    }
  }

  public async write<T>(stream: string, event: FlowEvent<T>): Promise<void> {
    const frozenEvent = deepFreeze(event);
    const line = JSON.stringify(frozenEvent) + '\n';

    if (this.isNode) {
      try {
        const fs = await import('fs');
        const path = await import('path');
        const fullPath = this.filePathResolver(stream);
        let hostDir = path.dirname(fullPath);
        // Correct path joining to allow relative paths
        if (hostDir.startsWith('.')) {
          hostDir = path.resolve(process.cwd(), hostDir);
        }
        await fs.promises.mkdir(hostDir, { recursive: true });
        await fs.promises.appendFile(path.resolve(process.cwd(), fullPath), line, 'utf-8');
      } catch (err) {
        console.warn('FileStore node writing fallback initiated due to error:', err);
        this.writeBrowserFallback(stream, frozenEvent);
      }
    } else {
      this.writeBrowserFallback(stream, frozenEvent);
    }
  }

  private writeBrowserFallback<T>(stream: string, event: FlowEvent<T>): void {
    const fullPath = this.filePathResolver(stream);
    let lines = this.browserStorage.get(fullPath);
    if (!lines) {
      lines = [];
      this.browserStorage.set(fullPath, lines);
    }
    lines.push(JSON.stringify(event));
    
    try {
      localStorage.setItem(`aether_file_store_${fullPath}`, JSON.stringify(lines));
    } catch {
      // In-memory buffer fallback
    }
  }

  public async read<T>(stream: string): Promise<FlowEvent<T>[]> {
    const fullPath = this.filePathResolver(stream);
    
    if (this.isNode) {
      try {
        const fs = await import('fs');
        const path = await import('path');
        const resolvedPath = path.resolve(process.cwd(), fullPath);
        const content = await fs.promises.readFile(resolvedPath, 'utf-8');
        const lines = content.split('\n');
        const events: FlowEvent<T>[] = [];
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed) {
            events.push(deepFreeze(JSON.parse(trimmed)));
          }
        }
        return events;
      } catch (err: any) {
        if (err.code === 'ENOENT') {
          return [];
        }
        return this.readBrowserFallback(stream);
      }
    } else {
      return this.readBrowserFallback(stream);
    }
  }

  private readBrowserFallback<T>(stream: string): FlowEvent<T>[] {
    const fullPath = this.filePathResolver(stream);
    let lines: string[] = [];
    try {
      const data = localStorage.getItem(`aether_file_store_${fullPath}`);
      if (data) {
        lines = JSON.parse(data);
      } else {
        lines = this.browserStorage.get(fullPath) || [];
      }
    } catch {
      lines = this.browserStorage.get(fullPath) || [];
    }
    return lines.map((l) => deepFreeze(JSON.parse(l)));
  }

  public async listStreams(): Promise<string[]> {
    if (this.isNode) {
      try {
        const fs = await import('fs');
        const path = await import('path');
        const dirPath = path.resolve(process.cwd(), './data');
        const files = await fs.promises.readdir(dirPath);
        return files
          .filter(f => f.endsWith('.ndjson'))
          .map(f => f.replace('.ndjson', ''));
      } catch {
        return this.listStreamsBrowserFallback();
      }
    } else {
      return this.listStreamsBrowserFallback();
    }
  }

  private listStreamsBrowserFallback(): string[] {
    const streams = new Set<string>();
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('aether_file_store_')) {
          const stream = key
            .replace('aether_file_store_', '')
            .replace('./data/', '')
            .replace('.ndjson', '');
          streams.add(stream);
        }
      }
    } catch {
      // ignore
    }
    for (const key of this.browserStorage.keys()) {
      const stream = key.replace('./data/', '').replace('.ndjson', '');
      streams.add(stream);
    }
    return Array.from(streams);
  }

  public async clear(stream?: string): Promise<void> {
    if (this.isNode) {
      try {
        const fs = await import('fs');
        const path = await import('path');
        
        if (stream) {
          const fullPath = this.filePathResolver(stream);
          const resolvedPath = path.resolve(process.cwd(), fullPath);
          try {
            await fs.promises.unlink(resolvedPath);
          } catch (err: any) {
            if (err.code !== 'ENOENT') throw err;
          }
        } else {
          const dirPath = path.resolve(process.cwd(), './data');
          try {
            const files = await fs.promises.readdir(dirPath);
            for (const file of files) {
              if (file.endsWith('.ndjson')) {
                await fs.promises.unlink(path.join(dirPath, file));
              }
            }
          } catch {
            // ignore folder read failures
          }
        }
      } catch {
        // fallback
      }
    }

    // Always keep browser state updated
    if (stream) {
      const fullPath = this.filePathResolver(stream);
      this.browserStorage.delete(fullPath);
      try {
        localStorage.removeItem(`aether_file_store_${fullPath}`);
      } catch {}
    } else {
      this.browserStorage.clear();
      try {
        const keysToRemove: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith('aether_file_store_')) {
            keysToRemove.push(key);
          }
        }
        for (const k of keysToRemove) {
          localStorage.removeItem(k);
        }
      } catch {}
    }
  }
}
