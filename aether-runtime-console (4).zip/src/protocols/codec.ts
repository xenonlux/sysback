/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Codec {
  name: 'json' | 'msgpack';
  encode(data: any): Uint8Array;
  decode(buffer: Uint8Array): any;
}

export class JSONCodec implements Codec {
  public readonly name = 'json';

  public encode(data: any): Uint8Array {
    const jsonStr = JSON.stringify(data);
    return new TextEncoder().encode(jsonStr);
  }

  public decode(buffer: Uint8Array): any {
    const jsonStr = new TextDecoder().decode(buffer);
    return JSON.parse(jsonStr);
  }
}

/**
 * A highly-optimized, compliant, lightweight MessagePack encoder and decoder in pure TypeScript.
 * Bypasses native C++ binding complexities under serverless or browser environments.
 */
export class MessagePackCodec implements Codec {
  public readonly name = 'msgpack';

  public encode(data: any): Uint8Array {
    const chunks: Uint8Array[] = [];
    this.pack(data, chunks);
    
    // Concatenate chunks
    let totalLength = 0;
    for (const chunk of chunks) {
      totalLength += chunk.length;
    }
    const result = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }
    return result;
  }

  public decode(buffer: Uint8Array): any {
    const state = { offset: 0, buffer };
    return this.unpack(state);
  }

  private pack(val: any, chunks: Uint8Array[]): void {
    if (val === null) {
      chunks.push(new Uint8Array([0xc0]));
      return;
    }
    if (val === undefined) {
      // MessagePack maps undefined to nil (0xc0)
      chunks.push(new Uint8Array([0xc0]));
      return;
    }
    if (typeof val === 'boolean') {
      chunks.push(new Uint8Array([val ? 0xc3 : 0xc2]));
      return;
    }
    if (typeof val === 'number') {
      if (Number.isInteger(val)) {
        if (val >= 0 && val <= 127) {
          // positive fixint
          chunks.push(new Uint8Array([val]));
        } else if (val >= -32 && val < 0) {
          // negative fixint
          chunks.push(new Uint8Array([0xe0 | (val + 32)]));
        } else if (val > 0 && val <= 0xff) {
          // uint 8
          chunks.push(new Uint8Array([0xcc, val]));
        } else if (val > 0 && val <= 0xffff) {
          // uint 16
          const buf = new Uint8Array(3);
          buf[0] = 0xcd;
          new DataView(buf.buffer).setUint16(1, val, false);
          chunks.push(buf);
        } else if (val > 0 && val <= 0xffffffff) {
          // uint 32
          const buf = new Uint8Array(5);
          buf[0] = 0xce;
          new DataView(buf.buffer).setUint32(1, val, false);
          chunks.push(buf);
        } else {
          // int 32 signed (default generic integer fallback)
          const buf = new Uint8Array(5);
          buf[0] = 0xd2;
          new DataView(buf.buffer).setInt32(1, val, false);
          chunks.push(buf);
        }
      } else {
        // float 64 (double)
        const buf = new Uint8Array(9);
        buf[0] = 0xcb;
        new DataView(buf.buffer).setFloat64(1, val, false);
        chunks.push(buf);
      }
      return;
    }
    if (typeof val === 'string') {
      const encodedStr = new TextEncoder().encode(val);
      const len = encodedStr.length;
      if (len <= 31) {
        // fixstr
        const header = new Uint8Array([0xa0 | len]);
        chunks.push(header, encodedStr);
      } else if (len <= 0xff) {
        // str 8
        const header = new Uint8Array([0xd9, len]);
        chunks.push(header, encodedStr);
      } else if (len <= 0xffff) {
        // str 16
        const header = new Uint8Array(3);
        header[0] = 0xda;
        new DataView(header.buffer).setUint16(1, len, false);
        chunks.push(header, encodedStr);
      } else {
        // str 32
        const header = new Uint8Array(5);
        header[0] = 0xdb;
        new DataView(header.buffer).setUint32(1, len, false);
        chunks.push(header, encodedStr);
      }
      return;
    }
    if (Array.isArray(val)) {
      const len = val.length;
      if (len <= 15) {
        // fixarray
        chunks.push(new Uint8Array([0x90 | len]));
      } else if (len <= 0xffff) {
        // array 16
        const header = new Uint8Array(3);
        header[0] = 0xdc;
        new DataView(header.buffer).setUint16(1, len, false);
        chunks.push(header);
      } else {
        // array 32
        const header = new Uint8Array(5);
        header[0] = 0xdd;
        new DataView(header.buffer).setUint32(1, len, false);
        chunks.push(header);
      }
      for (const item of val) {
        this.pack(item, chunks);
      }
      return;
    }
    if (typeof val === 'object') {
      const keys = Object.keys(val);
      const len = keys.length;
      if (len <= 15) {
        // fixmap
        chunks.push(new Uint8Array([0x80 | len]));
      } else if (len <= 0xffff) {
        // map 16
        const header = new Uint8Array(3);
        header[0] = 0xde;
        new DataView(header.buffer).setUint16(1, len, false);
        chunks.push(header);
      } else {
        // map 32
        const header = new Uint8Array(5);
        header[0] = 0xdf;
        new DataView(header.buffer).setUint32(1, len, false);
        chunks.push(header);
      }
      for (const k of keys) {
        this.pack(k, chunks);
        this.pack(val[k], chunks);
      }
      return;
    }
  }

  private unpack(state: { offset: number; buffer: Uint8Array }): any {
    if (state.offset >= state.buffer.length) {
      throw new Error('MessagePack Decode Error: Unexpected EOF');
    }
    const byte = state.buffer[state.offset++];

    // positive fixint
    if ((byte & 0x80) === 0x00) {
      return byte;
    }
    // fixmap
    if ((byte & 0xf0) === 0x80) {
      const len = byte & 0x0f;
      const obj: Record<string, any> = {};
      for (let i = 0; i < len; i++) {
        const k = this.unpack(state);
        const v = this.unpack(state);
        obj[k] = v;
      }
      return obj;
    }
    // fixarray
    if ((byte & 0xf0) === 0x90) {
      const len = byte & 0x0f;
      const arr: any[] = [];
      for (let i = 0; i < len; i++) {
        arr.push(this.unpack(state));
      }
      return arr;
    }
    // fixstr
    if ((byte & 0xe0) === 0xa0) {
      const len = byte & 0x1f;
      return this.readString(state, len);
    }
    // negative fixint
    if ((byte & 0xe0) === 0xe0) {
      return (byte & 0x1f) - 32;
    }

    switch (byte) {
      case 0xc0: // nil / null
        return null;
      case 0xc2: // false
        return false;
      case 0xc3: // true
        return true;
      case 0xcc: // uint 8
        return state.buffer[state.offset++];
      case 0xcd: { // uint 16
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 2);
        const val = view.getUint16(0, false);
        state.offset += 2;
        return val;
      }
      case 0xce: { // uint 32
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 4);
        const val = view.getUint32(0, false);
        state.offset += 4;
        return val;
      }
      case 0xd2: { // int 32
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 4);
        const val = view.getInt32(0, false);
        state.offset += 4;
        return val;
      }
      case 0xcb: { // float 64 (double)
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 8);
        const val = view.getFloat64(0, false);
        state.offset += 8;
        return val;
      }
      case 0xd9: { // str 8
        const len = state.buffer[state.offset++];
        return this.readString(state, len);
      }
      case 0xda: { // str 16
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 2);
        const len = view.getUint16(0, false);
        state.offset += 2;
        return this.readString(state, len);
      }
      case 0xdb: { // str 32
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 4);
        const len = view.getUint32(0, false);
        state.offset += 4;
        return this.readString(state, len);
      }
      case 0xdc: { // array 16
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 2);
        const len = view.getUint16(0, false);
        state.offset += 2;
        const arr = [];
        for (let i = 0; i < len; i++) {
          arr.push(this.unpack(state));
        }
        return arr;
      }
      case 0xdd: { // array 32
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 4);
        const len = view.getUint32(0, false);
        state.offset += 4;
        const arr = [];
        for (let i = 0; i < len; i++) {
          arr.push(this.unpack(state));
        }
        return arr;
      }
      case 0xde: { // map 16
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 2);
        const len = view.getUint16(0, false);
        state.offset += 2;
        const obj: Record<string, any> = {};
        for (let i = 0; i < len; i++) {
          const k = this.unpack(state);
          const v = this.unpack(state);
          obj[k] = v;
        }
        return obj;
      }
      case 0xdf: { // map 32
        const view = new DataView(state.buffer.buffer, state.buffer.byteOffset + state.offset, 4);
        const len = view.getUint32(0, false);
        state.offset += 4;
        const obj: Record<string, any> = {};
        for (let i = 0; i < len; i++) {
          const k = this.unpack(state);
          const v = this.unpack(state);
          obj[k] = v;
        }
        return obj;
      }
      default:
        throw new Error(`MessagePack Decode Error: Unsupported type byte: 0x${byte.toString(16)}`);
    }
  }

  private readString(state: { offset: number; buffer: Uint8Array }, len: number): string {
    if (state.offset + len > state.buffer.length) {
      throw new Error('MessagePack Decode Error: Unexpected EOF reading string');
    }
    const chunk = state.buffer.subarray(state.offset, state.offset + len);
    state.offset += len;
    return new TextDecoder().decode(chunk);
  }
}
