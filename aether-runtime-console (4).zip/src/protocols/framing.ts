/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Prepends a 4-byte Big-Endian length header to the payload
 */
export function frame(payload: Uint8Array): Uint8Array {
  const len = payload.length;
  const result = new Uint8Array(4 + len);
  const view = new DataView(result.buffer);
  view.setUint32(0, len, false); // Big-Endian length prefix
  result.set(payload, 4);
  return result;
}

/**
 * Stateful packet reassembler that processes byte stream chunks and emits complete messages.
 */
export class LengthPrefixedUnframer {
  private buffer: Uint8Array | null = null;

  constructor(private readonly onMessage: (msg: Uint8Array) => void) {}

  /**
   * Appends incoming binary bytes to internal sliding buffer and unpacks all completed frames.
   */
  public append(chunk: Uint8Array): void {
    if (!chunk || chunk.length === 0) return;

    if (this.buffer === null) {
      this.buffer = chunk;
    } else {
      const merged = new Uint8Array(this.buffer.length + chunk.length);
      merged.set(this.buffer, 0);
      merged.set(chunk, this.buffer.length);
      this.buffer = merged;
    }

    while (this.buffer && this.buffer.length >= 4) {
      const view = new DataView(this.buffer.buffer, this.buffer.byteOffset, 4);
      const expectedLen = view.getUint32(0, false);

      if (this.buffer.length >= 4 + expectedLen) {
        // Copy subarray to avoid keeping huge backing buffer reference
        const msg = this.buffer.slice(4, 4 + expectedLen);
        this.onMessage(msg);

        if (this.buffer.length === 4 + expectedLen) {
          this.buffer = null;
        } else {
          this.buffer = this.buffer.slice(4 + expectedLen);
        }
      } else {
        break; // Wait for more data chunks
      }
    }
  }

  /**
   * Discards any backlogged partial buffer bytes
   */
  public clear(): void {
    this.buffer = null;
  }
}
