/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';

export type HandlerFn = (payload: any, message: AetherMessage) => any | Promise<any>;

/**
 * Maps message target routing strings (with wildcard expression fallback) to async functional handlers.
 */
export class HandlerRegistry {
  private readonly handlers = new Map<string, HandlerFn>();

  /**
   * Registers a callback handler for exact or pattern-matched namespace targets
   */
  public register(target: string, handler: HandlerFn): void {
    this.handlers.set(target, handler);
  }

  /**
   * Resolves the matching handler function (handling exact or dot-notated wildcard matches)
   */
  public getHandler(target: string): HandlerFn | null {
    if (this.handlers.has(target)) {
      return this.handlers.get(target)!;
    }

    // Performance-focused wildcard lookups (e.g., 'auth.*' matches 'auth.login')
    for (const [pattern, handler] of this.handlers.entries()) {
      if (pattern.includes('*')) {
        const regexStr = '^' + pattern.replace(/\./g, '\\.').replace(/\*/g, '[^\\.]+') + '$';
        const regex = new RegExp(regexStr);
        if (regex.test(target)) {
          return handler;
        }
      }
    }

    return null;
  }

  /**
   * Coordinates message execution, returning the response payload.
   */
  public async dispatch(message: AetherMessage): Promise<any> {
    const handler = this.getHandler(message.target);
    if (!handler) {
      throw new Error(`HandlerRegistry: Route handler not found for target namespace: "${message.target}"`);
    }
    return await handler(message.payload, message);
  }

  public clear(): void {
    this.handlers.clear();
  }
}
