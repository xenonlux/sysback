/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TransportServer } from '../transports/interface';
import { HandlerRegistry } from './handler-registry';
import { createAetherMessage, validateAetherMessage, AetherMessage } from '../mesh/message';

export interface ServerEventLog {
  timestamp: string;
  transport: string;
  target: string;
  type: string;
  payload: any;
  status: 'success' | 'error';
  errorDetail?: string;
  traceId: string;
}

/**
 * High-performance, multi-protocol hub listening simultaneously on all specified channels.
 */
export class MultiTransportServer {
  private readonly servers = new Map<string, TransportServer>();
  private readonly eventLogs: ServerEventLog[] = [];
  private onLogCallback: ((log: ServerEventLog) => void) | null = null;

  constructor(public readonly registry: HandlerRegistry) {}

  /**
   * Mounts a standard transport server (e.g., TcpTransportServer, HttpTransportServer)
   */
  public registerServer(name: string, server: TransportServer): void {
    this.servers.set(name, server);
    
    // Attach universal message processing and automated response generation loop
    server.onMessage(async (message, reply) => {
      const startTime = new Date().toISOString();
      
      // 1. Structural message validation check
      const schemaErr = validateAetherMessage(message);
      if (schemaErr) {
        const errorMsg = `Structure Validation Failed: ${schemaErr}`;
        this.logEvent({
          timestamp: startTime,
          transport: server.name,
          target: message?.target || 'unknown',
          type: message?.type || 'unknown',
          payload: message?.payload,
          status: 'error',
          errorDetail: errorMsg,
          traceId: message?.id || 'unknown',
        });
        
        // Pushes validation error back to peer client 
        await reply(
          createAetherMessage('event', (message?.target || 'target') + '.error', {
            error: errorMsg,
          }, {
            traceId: message?.id || 'unknown',
            source: 'server.core'
          })
        );
        return;
      }

      // 2. Dispatch to matching route handlers
      try {
        const result = await this.registry.dispatch(message);
        
        this.logEvent({
          timestamp: startTime,
          transport: server.name,
          target: message.target,
          type: message.type,
          payload: message.payload,
          status: 'success',
          traceId: message.id,
        });

        // 3. Return successfully computed callback payload
        await reply(
          createAetherMessage('event', message.target + '.reply', result, {
            traceId: message.id,
            source: 'server.core',
          })
        );
      } catch (err: any) {
        const errorDetail = err.message || 'Unknown handler dispatch failure';
        
        this.logEvent({
          timestamp: startTime,
          transport: server.name,
          target: message.target,
          type: message.type,
          payload: message.payload,
          status: 'error',
          errorDetail,
          traceId: message.id,
        });

        // 4. Return functional execution failure to client Promise
        await reply(
          createAetherMessage('event', message.target + '.error', {
            error: errorDetail,
          }, {
            traceId: message.id,
            source: 'server.core',
          })
        );
      }
    });
  }

  /**
   * Starts all registered servers listening on their specific addresses
   */
  public async listenAll(config: Record<string, string>): Promise<void> {
    for (const [name, server] of this.servers.entries()) {
      const address = config[name];
      if (address) {
        await server.listen(address);
      }
    }
  }

  /**
   * Gracefully shuts down all active listeners
   */
  public async closeAll(): Promise<void> {
    for (const server of this.servers.values()) {
      await server.close();
    }
    this.servers.clear();
  }

  public getServers(): Map<string, TransportServer> {
    return this.servers;
  }

  public getEventLogs(): ServerEventLog[] {
    return this.eventLogs;
  }

  public onLog(callback: (log: ServerEventLog) => void): void {
    this.onLogCallback = callback;
  }

  private logEvent(event: ServerEventLog): void {
    this.eventLogs.unshift(event);
    if (this.eventLogs.length > 200) {
      this.eventLogs.pop();
    }
    if (this.onLogCallback) {
      this.onLogCallback(event);
    }
  }
}
