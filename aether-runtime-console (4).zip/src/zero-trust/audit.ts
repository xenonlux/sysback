/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { sha3_256Sync } from '../crypto/hash';

export interface AuditRecord {
  index: number;
  timestamp: string;
  traceId: string;
  subjectDid: string;
  resource: string;
  action: string;
  decision: 'allow' | 'deny';
  reason: string;
  appliedPolicies: string[];
  previousHash: string;
  hash: string;
}

/**
 * Blockchained Immutable Audit Ledger
 */
export class ImmutableAuditLogger {
  private ledger: AuditRecord[] = [];
  private currentHash = '0000000000000000000000000000000000000000000000000000000000000000'; // Genesis anchor

  constructor() {
    this.ledger = [];
  }

  /**
   * Appends and seals an audit record to the ledger
   */
  public log(params: {
    traceId: string;
    subjectDid: string;
    resource: string;
    action: string;
    decision: 'allow' | 'deny';
    reason: string;
    appliedPolicies: string[];
  }): AuditRecord {
    const timestamp = new Date().toISOString();
    const index = this.ledger.length;
    const previousHash = this.currentHash;

    const payloadString = JSON.stringify({
      index,
      timestamp,
      traceId: params.traceId,
      subjectDid: params.subjectDid,
      resource: params.resource,
      action: params.action,
      decision: params.decision,
      reason: params.reason,
      appliedPolicies: params.appliedPolicies,
      previousHash
    });

    const hash = sha3_256Sync(payloadString);

    const record: AuditRecord = {
      index,
      timestamp,
      traceId: params.traceId,
      subjectDid: params.subjectDid,
      resource: params.resource,
      action: params.action,
      decision: params.decision,
      reason: params.reason,
      appliedPolicies: params.appliedPolicies,
      previousHash,
      hash
    };

    this.ledger.push(record);
    this.currentHash = hash;

    return record;
  }

  /**
   * Verifies the cryptographic chain integrity of the ledger
   */
  public verifyLedger(): boolean {
    let lastHash = '0000000000000000000000000000000000000000000000000000000000000000';

    for (const record of this.ledger) {
      if (record.previousHash !== lastHash) {
        return false; // Chain broken
      }

      // Recompute payload representation hash
      const payloadString = JSON.stringify({
        index: record.index,
        timestamp: record.timestamp,
        traceId: record.traceId,
        subjectDid: record.subjectDid,
        resource: record.resource,
        action: record.action,
        decision: record.decision,
        reason: record.reason,
        appliedPolicies: record.appliedPolicies,
        previousHash: record.previousHash
      });

      const recomputed = sha3_256Sync(payloadString);
      if (recomputed !== record.hash) {
        return false; // Content modified
      }

      lastHash = record.hash;
    }

    return true;
  }

  public getHistory(): AuditRecord[] {
    return [...this.ledger];
  }

  public clear(): void {
    this.ledger = [];
    this.currentHash = '0000000000000000000000000000000000000000000000000000000000000000';
  }
}
