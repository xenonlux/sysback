/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PolicyCondition {
  field: string; // e.g., 'payload.amount', 'metadata.timestamp', 'subject.roles'
  operator: 'equals' | 'notEquals' | 'contains' | 'greaterThan' | 'lessThan' | 'in' | 'startsWith';
  value: any;
}

export interface AccessPolicy {
  id: string;
  name: string;
  effect: 'allow' | 'deny';
  subjectRoles?: string[];
  resources: string[]; // Glob patterns supported, e.g. ["db.users.*", "api.payment.process"]
  actions: string[];   // e.g. ["read", "write", "invoke"]
  conditions?: PolicyCondition[];
}

export interface PolicyContext {
  subject: {
    did: string;
    roles?: string[];
    [key: string]: any;
  };
  resource: string;
  action: string;
  metadata?: {
    timestamp: string;
    sourceIp?: string;
    [key: string]: any;
  };
  payload?: any;
}

/**
 * Access Policy Engine enforcing strict evaluation
 */
export class PolicyEngine {
  private policies: AccessPolicy[] = [];

  constructor(policies: AccessPolicy[] = []) {
    this.policies = policies;
  }

  public addPolicy(policy: AccessPolicy): void {
    this.policies.push(policy);
  }

  public setPolicies(policies: AccessPolicy[]): void {
    this.policies = policies;
  }

  public getPolicies(): AccessPolicy[] {
    return this.policies;
  }

  /**
   * Helper to check if resource/action match pattern g. "users.*"
   */
  private matchPattern(pattern: string, target: string): boolean {
    if (pattern === '*') return true;
    if (pattern.endsWith('.*')) {
      const prefix = pattern.slice(0, -2);
      return target === prefix || target.startsWith(prefix + '.');
    }
    return pattern === target;
  }

  /**
   * Safe value extraction from nested dot-notation paths
   */
  private extractValue(obj: any, path: string): any {
    try {
      return path.split('.').reduce((acc, part) => (acc ? acc[part] : undefined), obj);
    } catch {
      return undefined;
    }
  }

  /**
   * Evaluates a single condition against the context
   */
  private evaluateCondition(condition: PolicyCondition, context: PolicyContext): boolean {
    const value = this.extractValue(context, condition.field);
    const expected = condition.value;

    if (value === undefined) return false;

    switch (condition.operator) {
      case 'equals':
        return value === expected;
      case 'notEquals':
        return value !== expected;
      case 'contains':
        if (Array.isArray(value)) {
          return value.includes(expected);
        }
        if (typeof value === 'string') {
          return value.includes(expected);
        }
        return false;
      case 'greaterThan':
        return Number(value) > Number(expected);
      case 'lessThan':
        return Number(value) < Number(expected);
      case 'in':
        if (Array.isArray(expected)) {
          return expected.includes(value);
        }
        return false;
      case 'startsWith':
        if (typeof value === 'string') {
          return value.startsWith(expected);
        }
        return false;
      default:
        return false;
    }
  }

  /**
   * Evaluates the policy context against general rules.
   * Defaults to DENY (Zero-Trust principle)
   */
  public evaluate(context: PolicyContext): {
    authorized: boolean;
    reason: string;
    appliedPolicies: string[];
  } {
    const appliedPolicies: string[] = [];
    let hasAllow = false;
    let hasDeny = false;

    for (const policy of this.policies) {
      // 1. Match Resource Pattern
      const resourceMatched = policy.resources.some((r) => this.matchPattern(r, context.resource));
      if (!resourceMatched) continue;

      // 2. Match Action Pattern
      const actionMatched = policy.actions.some((a) => this.matchPattern(a, context.action));
      if (!actionMatched) continue;

      // 3. Match Roles if specified
      if (policy.subjectRoles) {
        const userRoles = context.subject.roles || [];
        const roleMatch = policy.subjectRoles.some((r) => userRoles.includes(r));
        if (!roleMatch) continue;
      }

      // 4. Validate all conditions
      if (policy.conditions) {
        const conditionsPassed = policy.conditions.every((cond) =>
          this.evaluateCondition(cond, context)
        );
        if (!conditionsPassed) continue;
      }

      // Policy matches!
      appliedPolicies.push(policy.id);
      if (policy.effect === 'deny') {
        hasDeny = true;
      } else if (policy.effect === 'allow') {
        hasAllow = true;
      }
    }

    if (hasDeny) {
      return {
        authorized: false,
        reason: 'Explicit policy DENY matches context',
        appliedPolicies
      };
    }

    if (hasAllow) {
      return {
        authorized: true,
        reason: 'Authorized via active ALLOW policies',
        appliedPolicies
      };
    }

    return {
      authorized: false,
      reason: 'No explicit ALLOW policies apply (Default Zero-Trust Deny)',
      appliedPolicies
    };
  }
}
