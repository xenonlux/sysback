/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { verifyAetherToken, TokenClaims } from '../identity/token';
import { PolicyEngine, PolicyContext } from './policy';
import { ImmutableAuditLogger, AuditRecord } from './audit';
import { AetherMessage } from '../mesh/message';

export interface VerifierConfig {
  policyEngine: PolicyEngine;
  auditLogger: ImmutableAuditLogger;
  dilithiumPublicKeys: Record<string, Uint8Array>; // Map of DID to PubKey bytes
  classicPublicKeys: Record<string, any>;         // Map of DID to Classical Keys
  fallbackClassicKeysHex?: Record<string, string>; // Map of DID to Classical Keys Hex
}

/**
 * Gatekeeper verifier executing absolute Zero-Trust pipeline checks
 */
export class ZeroTrustVerifier {
  private config: VerifierConfig;

  constructor(config: VerifierConfig) {
    this.config = config;
  }

  /**
   * Evaluates and validates an incoming AETHER network message call
   */
  public async verifyRequest(
    message: AetherMessage,
    actionNeeded = 'invoke'
  ): Promise<{
    authorized: boolean;
    claims?: TokenClaims;
    error?: string;
    auditRecord: AuditRecord;
  }> {
    const traceId = (message.meta as any)?.traceId || 'trace-unsigned-' + Math.random().toString(36).substring(4);
    const mockDid = 'did:aether:unsigned_unknown_actor';
    const resourceTarget = message.target;

    // 1. Extract Token from meta.token
    const token = (message.meta as any)?.token;
    if (!token || typeof token !== 'string') {
      const decision = 'deny';
      const reason = 'Zero-Trust Rejection: No credential token attached in request payload meta';
      const record = this.config.auditLogger.log({
        traceId,
        subjectDid: mockDid,
        resource: resourceTarget,
        action: actionNeeded,
        decision,
        reason,
        appliedPolicies: []
      });

      return { authorized: false, error: reason, auditRecord: record };
    }

    try {
      // 2. Decode claims (unverified first to retrieve DID issuer)
      const tokenParts = token.split('.');
      if (tokenParts.length !== 3) {
        throw new Error('Token envelope is malformed');
      }

      const rawClaims = JSON.parse(
        typeof atob !== 'undefined'
          ? decodeURIComponent(escape(atob(tokenParts[1].replace(/-/g, '+').replace(/_/g, '/'))))
          : Buffer.from(tokenParts[1], 'base64').toString('utf8')
      ) as TokenClaims;

      const subjectDid = rawClaims.sub;

      const dilPublic = this.config.dilithiumPublicKeys[subjectDid];
      const classicPublic = this.config.classicPublicKeys[subjectDid];
      const fallbackClassic = this.config.fallbackClassicKeysHex?.[subjectDid];

      if (!dilPublic) {
        throw new Error(`Trust Anchors lack registered post-quantum key material for subject DID: ${subjectDid}`);
      }

      // 3. Perform fully robust signature cryptographic verification
      const verifiedClaims = await verifyAetherToken(
        token,
        dilPublic,
        classicPublic,
        fallbackClassic
      );

      // 4. Construct verification Context
      const context: PolicyContext = {
        subject: {
          did: verifiedClaims.sub,
          roles: verifiedClaims.roles || []
        },
        resource: resourceTarget,
        action: actionNeeded,
        metadata: {
          timestamp: new Date().toISOString(),
          sourceIp: (message.meta as any)?.source || 'mesh-source'
        },
        payload: message.payload
      };

      // 5. Query Policy Engine
      const policyDecision = this.config.policyEngine.evaluate(context);

      const decision = policyDecision.authorized ? 'allow' : 'deny';
      const auditRec = this.config.auditLogger.log({
        traceId,
        subjectDid: verifiedClaims.sub,
        resource: resourceTarget,
        action: actionNeeded,
        decision,
        reason: policyDecision.reason,
        appliedPolicies: policyDecision.appliedPolicies
      });

      if (!policyDecision.authorized) {
        return {
          authorized: false,
          claims: verifiedClaims,
          error: `Policy Engine Rejection: ${policyDecision.reason}`,
          auditRecord: auditRec
        };
      }

      return {
        authorized: true,
        claims: verifiedClaims,
        auditRecord: auditRec
      };

    } catch (err: any) {
      const decision = 'deny';
      const errorMsg = `Cryptographic Verification Collapse: ${err.message}`;
      const record = this.config.auditLogger.log({
        traceId,
        subjectDid: mockDid,
        resource: resourceTarget,
        action: actionNeeded,
        decision,
        reason: errorMsg,
        appliedPolicies: []
      });

      return {
        authorized: false,
        error: errorMsg,
        auditRecord: record
      };
    }
  }
}
