/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';
import { Transport, TransportServer } from './interface';
import { JSONCodec, Codec } from '../protocols/codec';

// Global virtual HTTP routing map for Browser environment testing
const virtualHttpNetwork = new Map<string, HttpTransportServer>();

export class HttpTransport implements Transport {
  public readonly name = 'http';
  private address: string = '';
  private codec: Codec = new JSONCodec();
  private messageCallback: ((msg: AetherMessage) => void | Promise<void>) | null = null;
  private isNode: boolean;

  constructor(opt?: { codec?: Codec }) {
    this.isNode = typeof process !== 'undefined' && process.versions && process.versions.node !== undefined;
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async connect(address: string): Promise<void> {
    this.address = address;
    if (!this.isNode) {
      const server = virtualHttpNetwork.get(address);
      if (!server) {
        console.warn(`HttpTransport (Virtual): No virtual endpoint active at: ${address}. Proceeding in connection-less mode.`);
      }
    }
  }

  public async send(message: AetherMessage): Promise<void> {
    if (!this.address) {
      throw new Error('HttpTransport: Connection address not established.');
    }

    const payloadBytes = this.codec.encode(message);

    if (this.isNode) {
      try {
        const url = this.address.startsWith('http') ? this.address : `http://${this.address}`;
        const targetUrl = url.endsWith('/') ? `${url}api/message` : `${url}/api/message`;

        const res = await fetch(targetUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/octet-stream',
            'X-Aether-Codec': this.codec.name,
          },
          body: payloadBytes,
        });

        if (!res.ok) {
          throw new Error(`HttpTransport: Server responded with error status ${res.status}`);
        }

        const resBuffer = await res.arrayBuffer();
        if (resBuffer.byteLength > 0 && this.messageCallback) {
          const decodedReply = this.codec.decode(new Uint8Array(resBuffer));
          await this.messageCallback(decodedReply);
        }
      } catch (err) {
        // Fall back to virtual HTTP network if it failed or address wasn't a valid physical endpoint
        const server = virtualHttpNetwork.get(this.address);
        if (server) {
          await this.sendVirtual(payloadBytes);
        } else {
          throw err;
        }
      }
    } else {
      await this.sendVirtual(payloadBytes);
    }
  }

  private async sendVirtual(payloadBytes: Uint8Array): Promise<void> {
    const server = virtualHttpNetwork.get(this.address);
    if (!server) {
      throw new Error(`HttpTransport: Target HTTP endpoint unreachable at: ${this.address}`);
    }

    await server.receiveVirtualRequest(payloadBytes, this.codec, async (replyBytes) => {
      if (replyBytes.byteLength > 0 && this.messageCallback) {
        const decodedReply = this.codec.decode(replyBytes);
        await this.messageCallback(decodedReply);
      }
    });
  }

  public onMessage(callback: (message: AetherMessage) => void | Promise<void>): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    // Standard connectionless close
  }
}

export class HttpTransportServer implements TransportServer {
  public readonly name = 'http';
  private expressApp: any = null;
  private expressServer: any = null;
  private codec: Codec = new JSONCodec();
  private address: string | null = null;
  private isNode: boolean;
  private messageCallback:
    | ((message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>)
    | null = null;

  constructor(opt?: { codec?: Codec }) {
    this.isNode = typeof process !== 'undefined' && process.versions && process.versions.node !== undefined;
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async listen(address: string): Promise<void> {
    this.address = address;
    virtualHttpNetwork.set(address, this);

    if (this.isNode) {
      try {
        const express = await import('express');
        const app = express.default();
        this.expressApp = app;

        let port = 3000;
        if (address.includes(':')) {
          const parts = address.split(':');
          port = parseInt(parts[1], 10) || 3000;
        } else if (!isNaN(Number(address))) {
          port = parseInt(address, 10);
        }

        // Catch raw binary payloads cleanly
        app.use(express.raw({ type: '*/*', limit: '10mb' }));

        app.post('/api/message', async (req: any, res: any) => {
          try {
            const rawBody = req.body;
            if (!rawBody || rawBody.length === 0) {
              return res.status(400).send('Empty payload');
            }

            const reqCodecName = req.headers['x-aether-codec'] || 'json';
            const reqCodec = reqCodecName === 'msgpack' ? new JSONCodec() : this.codec; // safe check

            const message = reqCodec.decode(new Uint8Array(rawBody));
            
            if (this.messageCallback) {
              let responded = false;
              await this.messageCallback(message, async (reply) => {
                responded = true;
                const encodedReply = reqCodec.encode(reply);
                res.status(200).send(Buffer.from(encodedReply));
              });

              if (!responded) {
                // Return empty success if listener did not push any reply back
                res.status(204).end();
              }
            } else {
              res.status(404).send('No registry handler active');
            }
          } catch (err: any) {
            console.error('HttpTransportServer: Inbound request error:', err);
            res.status(500).send(err.message);
          }
        });

        // Set up server listening
        return new Promise<void>((resolve, reject) => {
          this.expressServer = app.listen(port, '0.0.0.0', () => {
            resolve();
          });
          this.expressServer.on('error', (err: any) => {
            reject(err);
          });
        });
      } catch (err) {
        console.warn('HttpTransportServer: Local express server bootstrap offline or inside container context.', err);
      }
    }
  }

  public onMessage(
    callback: (message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>
  ): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.address) {
      virtualHttpNetwork.delete(this.address);
      this.address = null;
    }
    if (this.expressServer) {
      await new Promise<void>((resolve) => {
        this.expressServer.close(() => resolve());
      });
      this.expressServer = null;
      this.expressApp = null;
    }
  }

  /**
   * Mock interface processing virtual connection post requests in-browser.
   */
  public async receiveVirtualRequest(
    payloadBytes: Uint8Array,
    clientCodec: Codec,
    sendResponseBytes: (responseBytes: Uint8Array) => Promise<void> | void
  ): Promise<void> {
    if (!this.messageCallback) {
      throw new Error('HttpTransportServer (Virtual): No registered message callback handler exists.');
    }

    const decodedMsg = clientCodec.decode(payloadBytes);
    
    await this.messageCallback(decodedMsg, async (reply) => {
      const encodedReply = clientCodec.encode(reply);
      await sendResponseBytes(encodedReply);
    });
  }
}
