/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';
import { Transport, TransportServer } from './interface';
import { LengthPrefixedUnframer, frame } from '../protocols/framing';
import { MessagePackCodec, Codec } from '../protocols/codec';

// Global virtual TCP channel bus for Browser runtime testing
const virtualTcpNetwork = new Map<string, TcpTransportServer>();

export class TcpTransport implements Transport {
  public readonly name = 'tcp';
  private socket: any = null;
  private codec: Codec = new MessagePackCodec();
  private messageCallback: ((msg: AetherMessage) => void | Promise<void>) | null = null;
  private isNode: boolean;
  private virtualClientCallback: ((msg: AetherMessage) => void) | null = null;

  constructor(opt?: { codec?: Codec }) {
    this.isNode = typeof process !== 'undefined' && process.versions && process.versions.node !== undefined;
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async connect(address: string): Promise<void> {
    if (this.isNode) {
      try {
        const net = await import('net');
        let host = '127.0.0.1';
        let port = 8080;

        if (address.includes(':')) {
          const parts = address.split(':');
          host = parts[0] || '127.0.0.1';
          port = parseInt(parts[1], 10) || 8080;
        } else if (!isNaN(Number(address))) {
          port = parseInt(address, 10);
        }

        return new Promise((resolve, reject) => {
          const client = net.createConnection({ host, port }, () => {
            this.socket = client;
            
            // Set up stateful reassembler framing unframer
            const unframer = new LengthPrefixedUnframer((msgBytes) => {
              try {
                const message = this.codec.decode(msgBytes);
                if (this.messageCallback) {
                  this.messageCallback(message);
                }
              } catch (err) {
                console.error('TcpTransport: Decoding inbound frame collapsed', err);
              }
            });

            client.on('data', (data) => {
              unframer.append(data);
            });

            client.on('error', (err) => {
              console.warn('TcpTransport client socket warning:', err);
              reject(err);
            });

            resolve();
          });

          // Handle early errors
          client.on('error', (err) => {
            reject(err);
          });
        });
      } catch (err) {
        console.warn('TcpTransport: Node TCP connection failed or fallback needed. Switched to virtual TCP.', err);
        return this.connectVirtual(address);
      }
    } else {
      return this.connectVirtual(address);
    }
  }

  private async connectVirtual(address: string): Promise<void> {
    const server = virtualTcpNetwork.get(address);
    if (!server) {
      throw new Error(`TcpTransport (Virtual): Could not reach server at ${address}`);
    }
    
    // Register back-channel for mock responses
    server.registerVirtualClient(address, this);
  }

  public async send(message: AetherMessage): Promise<void> {
    const payloadBytes = this.codec.encode(message);
    const framedBytes = frame(payloadBytes);

    if (this.socket) {
      return new Promise<void>((resolve, reject) => {
        this.socket.write(framedBytes, (err: any) => {
          if (err) reject(err);
          else resolve();
        });
      });
    } else {
      // Virtual delivery
      const server = Array.from(virtualTcpNetwork.values()).find(s => s.isVirtualClientRegistered(this));
      if (!server) {
        throw new Error('TcpTransport: Socket disconnected or virtual link unavailable.');
      }
      
      await server.receiveFromVirtualClient(framedBytes, this);
    }
  }

  public onMessage(callback: (message: AetherMessage) => void | Promise<void>): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    // Remove virtual linkages
    for (const [addr, server] of virtualTcpNetwork.entries()) {
      if (server.isVirtualClientRegistered(this)) {
        server.removeVirtualClient(this);
      }
    }
  }

  /**
   * Virtual reception from virtual socket server pipeline.
   */
  public receiveVirtualFrame(framed: Uint8Array): void {
    const unframer = new LengthPrefixedUnframer((msgBytes) => {
      try {
        const decoded = this.codec.decode(msgBytes);
        if (this.messageCallback) {
          this.messageCallback(decoded);
        }
      } catch (err) {
        console.error('TcpTransport: Virtual raw packet decapsulation issue:', err);
      }
    });
    unframer.append(framed);
  }
}

export class TcpTransportServer implements TransportServer {
  public readonly name = 'tcp';
  private server: any = null;
  private codec: Codec = new MessagePackCodec();
  private isNode: boolean;
  private address: string | null = null;
  private messageCallback:
    | ((message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>)
    | null = null;

  // Virtual registry mappings
  private readonly virtualConnectedClients = new Set<TcpTransport>();

  constructor(opt?: { codec?: Codec }) {
    this.isNode = typeof process !== 'undefined' && process.versions && process.versions.node !== undefined;
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async listen(address: string): Promise<void> {
    this.address = address;
    virtualTcpNetwork.set(address, this);

    if (this.isNode) {
      try {
        const net = await import('net');
        let port = 8080;
        let host = '0.0.0.0';

        if (address.includes(':')) {
          const parts = address.split(':');
          host = parts[0] || '0.0.0.0';
          port = parseInt(parts[1], 10) || 8080;
        } else if (!isNaN(Number(address))) {
          port = parseInt(address, 10);
        }

        return new Promise((resolve, reject) => {
          const listener = net.createServer((socket) => {
            const unframer = new LengthPrefixedUnframer(async (msgBytes) => {
              try {
                const message = this.codec.decode(msgBytes);
                if (this.messageCallback) {
                  await this.messageCallback(message, async (reply) => {
                    const encodedReply = this.codec.encode(reply);
                    const framedReply = frame(encodedReply);
                    socket.write(framedReply);
                  });
                }
              } catch (err) {
                console.error('TcpServer: Inbound packet reduction failure:', err);
              }
            });

            socket.on('data', (data) => {
              unframer.append(data);
            });

            socket.on('error', (err) => {
              console.warn('TcpServer socket connection warn:', err);
            });
          });

          listener.on('error', (err) => {
            reject(err);
          });

          this.server = listener;
          listener.listen(port, host, () => {
            resolve();
          });
        });
      } catch (err) {
        console.warn('TcpServer: Node net.createServer failed or fallback needed. Switched to virtual TCP server.', err);
      }
    }
  }

  public onMessage(
    callback: (message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>
  ): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.address) {
      virtualTcpNetwork.delete(this.address);
      this.address = null;
    }
    if (this.server) {
      await new Promise<void>((resolve) => {
        this.server.close(() => resolve());
      });
      this.server = null;
    }
    this.virtualConnectedClients.clear();
  }

  // Virtual client orchestration methods for Browser mock simulations
  public registerVirtualClient(addr: string, client: TcpTransport): void {
    this.virtualConnectedClients.add(client);
  }

  public removeVirtualClient(client: TcpTransport): void {
    this.virtualConnectedClients.delete(client);
  }

  public isVirtualClientRegistered(client: TcpTransport): boolean {
    return this.virtualConnectedClients.has(client);
  }

  public async receiveFromVirtualClient(framedBytes: Uint8Array, client: TcpTransport): Promise<void> {
    const unframer = new LengthPrefixedUnframer(async (msgBytes) => {
      try {
        const decoded = this.codec.decode(msgBytes);
        if (this.messageCallback) {
          await this.messageCallback(decoded, async (reply) => {
            const encodedReply = this.codec.encode(reply);
            const framedReply = frame(encodedReply);
            // Push response framed packet back to virtual client
            client.receiveVirtualFrame(framedReply);
          });
        }
      } catch (err) {
        console.error('TcpServer (Virtual): Decoding virtual client frame failed', err);
      }
    });
    unframer.append(framedBytes);
  }
}
