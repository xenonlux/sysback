/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';

/**
 * Common bidirectional transport connection interface.
 */
export interface Transport {
  readonly name: string;
  connect(address: string): Promise<void>;
  send(message: AetherMessage): Promise<void>;
  onMessage(callback: (message: AetherMessage) => void | Promise<void>): void;
  close(): Promise<void>;
}

/**
 * Standard server listener abstract contract.
 */
export interface TransportServer {
  readonly name: string;
  listen(address: string): Promise<void>;
  onMessage(
    callback: (message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>
  ): void;
  close(): Promise<void>;
}
