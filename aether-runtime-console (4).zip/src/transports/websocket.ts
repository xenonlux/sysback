/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';
import { Transport, TransportServer } from './interface';
import { JSONCodec, Codec } from '../protocols/codec';

// Global virtual WebSocket routing bus for testing in single-container contexts and browser frames
const virtualWsNetwork = new Map<string, WebSocketTransportServer>();

export class WebSocketTransport implements Transport {
  public readonly name = 'websocket';
  private socket: any = null;
  private codec: Codec = new JSONCodec();
  private messageCallback: ((msg: AetherMessage) => void | Promise<void>) | null = null;
  private address: string = '';
  private isBrowserWs: boolean;

  constructor(opt?: { codec?: Codec }) {
    this.isBrowserWs = typeof globalThis !== 'undefined' && 'WebSocket' in globalThis;
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async connect(address: string): Promise<void> {
    this.address = address;
    const isRealUrl = address.startsWith('ws://') || address.startsWith('wss://');

    if (this.isBrowserWs && isRealUrl) {
      return new Promise<void>((resolve, reject) => {
        try {
          const wsClass = (globalThis as any).WebSocket;
          const client = new wsClass(address);
          this.socket = client;

          client.binaryType = 'arraybuffer';

          client.onopen = () => {
            resolve();
          };

          client.onmessage = async (event: any) => {
            try {
              let arrayBuffer: ArrayBuffer;
              if (event.data instanceof ArrayBuffer) {
                arrayBuffer = event.data;
              } else {
                // If text fallback
                arrayBuffer = new TextEncoder().encode(event.data).buffer;
              }

              const message = this.codec.decode(new Uint8Array(arrayBuffer));
              if (this.messageCallback) {
                await this.messageCallback(message);
              }
            } catch (err) {
              console.error('WebSocketTransport decoding failed:', err);
            }
          };

          client.onerror = (err: any) => {
            reject(err);
          };
        } catch (err) {
          reject(err);
        }
      });
    } else {
      // Connect to virtual full-duplex network socket
      const server = virtualWsNetwork.get(address);
      if (!server) {
        console.warn(`WebSocketTransport (Virtual): Target WS Server is not active at: ${address}. Registering client callback standby.`);
      } else {
        server.registerVirtualClient(address, this);
      }
    }
  }

  public async send(message: AetherMessage): Promise<void> {
    const payloadBytes = this.codec.encode(message);

    if (this.socket && this.socket.readyState === 1 /* OPEN */) {
      if (typeof Buffer !== 'undefined' && this.socket.send.name === 'write') {
        this.socket.send(Buffer.from(payloadBytes));
      } else {
        this.socket.send(payloadBytes);
      }
    } else {
      // Virtual delivery to full-duplex endpoint
      const server = virtualWsNetwork.get(this.address);
      if (!server) {
        throw new Error(`WebSocketTransport: Virtual connection lost or server inactive at: ${this.address}`);
      }
      await server.receiveFromVirtualClient(payloadBytes, this);
    }
  }

  public onMessage(callback: (message: AetherMessage) => void | Promise<void>): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    const server = virtualWsNetwork.get(this.address);
    if (server) {
      server.removeVirtualClient(this);
    }
  }

  /**
   * Received backpressured / responsive trigger from virtual server socket.
   */
  public receiveVirtualFrame(payloadBytes: Uint8Array): void {
    try {
      const decoded = this.codec.decode(payloadBytes);
      if (this.messageCallback) {
        this.messageCallback(decoded);
      }
    } catch (err) {
      console.error('WebSocketTransport (Virtual): frame extraction failure:', err);
    }
  }
}

export class WebSocketTransportServer implements TransportServer {
  public readonly name = 'websocket';
  private address: string | null = null;
  private codec: Codec = new JSONCodec();
  private messageCallback:
    | ((message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>)
    | null = null;
  private readonly virtualConnectedClients = new Set<WebSocketTransport>();

  constructor(opt?: { codec?: Codec }) {
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async listen(address: string): Promise<void> {
    this.address = address;
    virtualWsNetwork.set(address, this);

    // In a real Node environment, we can dynamically compile ws server adapter 
    // if a websocket broker port triggers, but virtual WebSocket delivers robust standard loop.
  }

  public onMessage(
    callback: (message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>
  ): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.address) {
      virtualWsNetwork.delete(this.address);
      this.address = null;
    }
    this.virtualConnectedClients.clear();
  }

  // Virtual subscription hooks
  public registerVirtualClient(addr: string, client: WebSocketTransport): void {
    this.virtualConnectedClients.add(client);
  }

  public removeVirtualClient(client: WebSocketTransport): void {
    this.virtualConnectedClients.delete(client);
  }

  /**
   * Triggers packet decoding and runs the handler back on virtual connection.
   */
  public async receiveFromVirtualClient(payloadBytes: Uint8Array, client: WebSocketTransport): Promise<void> {
    if (!this.messageCallback) return;

    try {
      const message = this.codec.decode(payloadBytes);
      await this.messageCallback(message, async (reply) => {
        const replyBytes = this.codec.encode(reply);
        client.receiveVirtualFrame(replyBytes);
      });
    } catch (err) {
      console.error('WebSocketServer (Virtual) receiving payload failed:', err);
    }
  }

  /**
   * Admin streaming method: Server can broadcast/push message directly to a specific connected client.
   */
  public async pushToClient(client: WebSocketTransport, message: AetherMessage): Promise<void> {
    if (this.virtualConnectedClients.has(client)) {
      const payloadBytes = this.codec.encode(message);
      client.receiveVirtualFrame(payloadBytes);
    }
  }
}
