/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';
import { Transport, TransportServer } from './interface';

// Registry tracking in-process active local stream paths
const activeLocalRegistry = new Map<string, LocalTransportServer>();

/**
 * Direct in-process zero-overhead client transport.
 */
export class LocalTransport implements Transport {
  public readonly name = 'local';
  private targetServer: LocalTransportServer | null = null;
  private messageCallback: ((msg: AetherMessage) => void | Promise<void>) | null = null;

  public async connect(address: string): Promise<void> {
    const server = activeLocalRegistry.get(address);
    if (!server) {
      throw new Error(`LocalTransport: Cannot connect. No receiver registered at address: ${address}`);
    }
    this.targetServer = server;
    // Register back-channel for bidirectional response signals
    server.registerClientConnection(address, this);
  }

  public async send(message: AetherMessage): Promise<void> {
    if (!this.targetServer) {
      throw new Error('LocalTransport: Cannot send. Transport not connected or closed.');
    }
    
    // Direct zero-overhead functional loop call
    await this.targetServer.receiveFromClient(message, async (reply) => {
      if (this.messageCallback) {
        await this.messageCallback(reply);
      }
    });
  }

  public onMessage(callback: (message: AetherMessage) => void | Promise<void>): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    this.targetServer = null;
  }

  /**
   * Internal hook for server back-channel responses.
   */
  public receiveFromServer(message: AetherMessage): void {
    if (this.messageCallback) {
      this.messageCallback(message);
    }
  }
}

/**
 * Direct in-process local server listener.
 */
export class LocalTransportServer implements TransportServer {
  public readonly name = 'local';
  private address: string | null = null;
  private messageCallback:
    | ((message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>)
    | null = null;
  private readonly connectedClients = new Map<string, LocalTransport>();

  public async listen(address: string): Promise<void> {
    this.address = address;
    activeLocalRegistry.set(address, this);
  }

  public onMessage(
    callback: (message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>
  ): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.address) {
      activeLocalRegistry.delete(this.address);
      this.address = null;
    }
    this.connectedClients.clear();
  }

  /**
   * Server-side receive hook triggered by local client.
   */
  public async receiveFromClient(message: AetherMessage, clientReplyChan: (response: AetherMessage) => Promise<void>): Promise<void> {
    if (this.messageCallback) {
      await this.messageCallback(message, clientReplyChan);
    }
  }

  /**
   * Server tracks its peer client for out-of-band streaming pushes.
   */
  public registerClientConnection(addr: string, client: LocalTransport): void {
    this.connectedClients.set(addr, client);
  }
}
