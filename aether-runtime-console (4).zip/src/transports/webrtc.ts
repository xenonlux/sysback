/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AetherMessage } from '../mesh/message';
import { Transport, TransportServer } from './interface';
import { JSONCodec, Codec } from '../protocols/codec';

// Global WebRTC mock signaling coordinator
const webrtcEndpoints = new Map<string, WebrtcTransportServer>();

export class WebrtcTransport implements Transport {
  public readonly name = 'webrtc';
  private codec: Codec = new JSONCodec();
  private messageCallback: ((msg: AetherMessage) => void | Promise<void>) | null = null;
  private address: string = '';
  private connectionState: 'new' | 'connecting' | 'connected' | 'closed' = 'new';
  private targetServer: WebrtcTransportServer | null = null;

  constructor(opt?: { codec?: Codec }) {
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public getConnectionState(): 'new' | 'connecting' | 'connected' | 'closed' {
    return this.connectionState;
  }

  public async connect(address: string): Promise<void> {
    this.address = address;
    this.connectionState = 'connecting';

    // Simulate WebRTC ICE gathering and negotiation exchange delays
    await new Promise((resolve) => setTimeout(resolve, 150));

    const server = webrtcEndpoints.get(address);
    if (!server) {
      this.connectionState = 'closed';
      throw new Error(`WebRTC: Peer listener at address ${address} not registered.`);
    }

    this.targetServer = server;
    this.connectionState = 'connected';
    server.registerPeer(this);
  }

  public async send(message: AetherMessage): Promise<void> {
    if (this.connectionState !== 'connected' || !this.targetServer) {
      throw new Error('WebRTC: DataChannel is closed or not fully negotiated.');
    }

    const payloadBytes = this.codec.encode(message);
    
    // WebRTC DataChannel delivery simulation
    await this.targetServer.receiveFromPeer(payloadBytes, this);
  }

  public onMessage(callback: (message: AetherMessage) => void | Promise<void>): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    this.connectionState = 'closed';
    if (this.targetServer) {
      this.targetServer.removePeer(this);
      this.targetServer = null;
    }
  }

  /**
   * Raw bytes incoming from P2P peer delivery.
   */
  public receiveIncomingPeerData(payloadBytes: Uint8Array): void {
    if (this.connectionState !== 'connected') return;

    try {
      const decoded = this.codec.decode(payloadBytes);
      if (this.messageCallback) {
        this.messageCallback(decoded);
      }
    } catch (err) {
      console.error('WebRTC: Failed decoding incoming Direct DataChannel stream frame:', err);
    }
  }
}

export class WebrtcTransportServer implements TransportServer {
  public readonly name = 'webrtc';
  private address: string | null = null;
  private codec: Codec = new JSONCodec();
  private messageCallback:
    | ((message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>)
    | null = null;
  private readonly connectedPeers = new Set<WebrtcTransport>();

  constructor(opt?: { codec?: Codec }) {
    if (opt?.codec) {
      this.codec = opt.codec;
    }
  }

  public async listen(address: string): Promise<void> {
    this.address = address;
    webrtcEndpoints.set(address, this);
  }

  public onMessage(
    callback: (message: AetherMessage, reply: (response: AetherMessage) => Promise<void>) => void | Promise<void>
  ): void {
    this.messageCallback = callback;
  }

  public async close(): Promise<void> {
    if (this.address) {
      webrtcEndpoints.delete(this.address);
      this.address = null;
    }
    for (const peer of this.connectedPeers) {
      peer.close();
    }
    this.connectedPeers.clear();
  }

  // WebRTC P2P coordinator callbacks
  public registerPeer(peer: WebrtcTransport): void {
    this.connectedPeers.add(peer);
  }

  public removePeer(peer: WebrtcTransport): void {
    this.connectedPeers.delete(peer);
  }

  public async receiveFromPeer(payloadBytes: Uint8Array, peer: WebrtcTransport): Promise<void> {
    if (!this.messageCallback) return;

    try {
      const message = this.codec.decode(payloadBytes);
      
      // Direct DataChannel response replication
      await this.messageCallback(message, async (reply) => {
        const replyBytes = this.codec.encode(reply);
        // Direct response send on client data channel
        peer.receiveIncomingPeerData(replyBytes);
      });
    } catch (err) {
      console.error('WebRTC Server: Error processing peer frame payload:', err);
    }
  }
}
