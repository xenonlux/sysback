/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Transport } from '../transports/interface';
import { LocalTransport } from '../transports/local';
import { TcpTransport } from '../transports/tcp';
import { HttpTransport } from '../transports/http';
import { WebSocketTransport } from '../transports/websocket';
import { WebrtcTransport } from '../transports/webrtc';
import { AetherMessage } from './message';

export type TransportType = 'local' | 'tcp' | 'http' | 'websocket' | 'webrtc';

/**
 * Intelligent networking hub that inspects address context and routes using the optimal protocol.
 */
export class MeshRouter {
  private readonly transports = new Map<string, Transport>();

  constructor() {
    // Prime of standard suite models
    this.transports.set('local', new LocalTransport());
    this.transports.set('tcp', new TcpTransport());
    this.transports.set('http', new HttpTransport());
    this.transports.set('websocket', new WebSocketTransport());
    this.transports.set('webrtc', new WebrtcTransport());
  }

  /**
   * Automatically targets and instantiates the correct transport mechanism according to context prefix.
   */
  public selectTransport(address: string): Transport {
    const cleanAddr = address.trim().toLowerCase();

    if (cleanAddr.startsWith('local://') || cleanAddr === 'local' || cleanAddr.startsWith('mem://')) {
      return this.transports.get('local')!;
    }
    if (cleanAddr.startsWith('ws://') || cleanAddr.startsWith('wss://') || cleanAddr.startsWith('websocket://')) {
      return this.transports.get('websocket')!;
    }
    if (cleanAddr.startsWith('webrtc://') || cleanAddr.startsWith('rtc://') || cleanAddr.startsWith('p2p://')) {
      return this.transports.get('webrtc')!;
    }
    if (cleanAddr.startsWith('tcp://') || cleanAddr.startsWith('raw://') || /^\d+$/.test(cleanAddr)) {
      return this.transports.get('tcp')!;
    }
    if (cleanAddr.startsWith('http://') || cleanAddr.startsWith('https://') || cleanAddr.startsWith('http://')) {
      return this.transports.get('http')!;
    }

    // Smart default heuristics
    if (cleanAddr.includes(':')) {
      // e.g. 127.0.0.1:4000 or my-server:9000 -> default to TCP/IP
      return this.transports.get('tcp')!;
    }

    // Default universal fallback
    return this.transports.get('http')!;
  }

  /**
   * Instantiates or reuses connection pipeline.
   */
  public async connect(address: string): Promise<Transport> {
    const transport = this.selectTransport(address);
    // Strip prefixes to support raw socket connections if required, or keep intact
    await transport.connect(address);
    return transport;
  }

  /**
   * Directly forwards standard Aether messages over matched channel infrastructure.
   */
  public async routeMessage(address: string, message: AetherMessage): Promise<void> {
    const transport = this.selectTransport(address);
    await transport.connect(address);
    await transport.send(message);
  }

  public registerCustomTransport(name: string, transport: Transport): void {
    this.transports.set(name, transport);
  }

  public getTransports(): Map<string, Transport> {
    return this.transports;
  }
}
