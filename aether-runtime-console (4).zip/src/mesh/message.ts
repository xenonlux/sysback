/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { uuid, now } from '../builtins/crypto';

export type AetherMessageType = 'call' | 'event' | 'stream';

export interface AetherMessageMeta {
  source: string;
  timestamp: string;
  traceId: string;
}

export interface AetherMessage<T = any> {
  id: string;
  type: AetherMessageType;
  target: string;
  payload: T;
  meta: AetherMessageMeta;
}

/**
 * Factory helper for creating clean standard Aether messages
 */
export function createAetherMessage<T = any>(
  type: AetherMessageType,
  target: string,
  payload: T,
  meta?: Partial<AetherMessageMeta>
): AetherMessage<T> {
  const trace = meta?.traceId || uuid();
  return {
    id: uuid(),
    type,
    target,
    payload,
    meta: {
      source: meta?.source || 'mesh.local',
      timestamp: meta?.timestamp || now(),
      traceId: trace,
    },
  };
}

/**
 * Strict validator for Message payload schema enforcement
 * Returns error string if invalid, or null if fully conforming
 */
export function validateAetherMessage(msg: any): string | null {
  if (!msg || typeof msg !== 'object') {
    return 'Message must be an object';
  }
  if (typeof msg.id !== 'string' || !msg.id) {
    return 'Message "id" is required and must be a non-empty string';
  }
  if (msg.type !== 'call' && msg.type !== 'event' && msg.type !== 'stream') {
    return 'Message "type" must be "call", "event", or "stream"';
  }
  if (typeof msg.target !== 'string' || !msg.target) {
    return 'Message "target" is required and must be a non-empty string';
  }
  if (msg.payload === undefined) {
    return 'Message "payload" is required and cannot be empty';
  }
  if (!msg.meta || typeof msg.meta !== 'object') {
    return 'Message "meta" must be a non-null object';
  }
  if (typeof msg.meta.source !== 'string' || !msg.meta.source) {
    return 'Message "meta.source" is required and must be a string';
  }
  if (typeof msg.meta.timestamp !== 'string' || !msg.meta.timestamp) {
    return 'Message "meta.timestamp" must be an ISO string';
  }
  if (typeof msg.meta.traceId !== 'string' || !msg.meta.traceId) {
    return 'Message "meta.traceId" is required for trace tracking';
  }
  return null;
}
