/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BTree } from './btree';
import { FlowEvent } from './event';

/**
 * Automates B-Tree indexing of FlowEvents by timestamp and common search terms.
 */
export class FlowQueryIndex<T> {
  public readonly timestampIndex = new BTree<string, FlowEvent<T>>();
  private readonly fieldIndices = new Map<string, BTree<string | number, FlowEvent<T>>>();

  constructor(
    private readonly commonFields: string[] = ['id', 'uid', 'email', 'status', 'active']
  ) {}

  /**
   * Evaluates and inserts fields of the event into the B-Tree index registers.
   */
  public index(event: FlowEvent<T>): void {
    // 1. Index by timestamp
    this.timestampIndex.insert(event.timestamp, event);

    // 2. Index common fields from event.data object
    const dataObj = event.data as any;
    if (dataObj && typeof dataObj === 'object') {
      for (const field of this.commonFields) {
        if (field in dataObj) {
          const val = dataObj[field];
          if (typeof val === 'string' || typeof val === 'number') {
            let tree = this.fieldIndices.get(field);
            if (!tree) {
              tree = new BTree<string | number, FlowEvent<T>>();
              this.fieldIndices.set(field, tree);
            }
            tree.insert(val, event);
          } else if (typeof val === 'boolean') {
            const numVal = val ? 1 : 0;
            let tree = this.fieldIndices.get(field);
            if (!tree) {
              tree = new BTree<string | number, FlowEvent<T>>();
              this.fieldIndices.set(field, tree);
            }
            tree.insert(numVal, event);
          }
        }
      }
    }
  }

  /**
   * Returns matching items within bounds using B-Tree range search.
   */
  public queryByTimestamp(start: string | null, end: string | null): FlowEvent<T>[] {
    return this.timestampIndex.rangeQuery(start, end);
  }

  /**
   * Retrieves events from a field B-Tree index.
   */
  public queryByField(field: string, value: string | number | boolean): FlowEvent<T>[] {
    const queryVal = typeof value === 'boolean' ? (value ? 1 : 0) : value;
    const tree = this.fieldIndices.get(field);
    return tree ? tree.search(queryVal) : [];
  }

  /**
   * Returns all indexed events in sorted order of timestamps.
   */
  public all(): FlowEvent<T>[] {
    return this.timestampIndex.all();
  }
}
