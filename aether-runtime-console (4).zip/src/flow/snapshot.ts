/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowEvent } from './event';

export class FlowSnapshot<T> {
  constructor(
    public readonly streamName: string,
    public readonly timestamp: string, // exact logical time of creation
    public readonly records: Map<string, T>, // key -> record state
    public readonly eventsCount: number
  ) {}

  /**
   * Retrieves a specific materialised record state.
   */
  public get(key: string): T | undefined {
    return this.records.get(key);
  }

  /**
   * Gets all aggregated records inside this view.
   */
  public all(): T[] {
    return Array.from(this.records.values());
  }

  /**
   * Gets the count of active unique records.
   */
  public get size(): number {
    return this.records.size;
  }
}

export class SnapshotEngine {
  /**
   * Translates an array of raw event streams into a coherent state snapshot.
   */
  public materialize<T>(
    events: FlowEvent<T>[],
    options?: {
      idResolver?: (data: T) => string;
      reducer?: (state: Map<string, T>, event: FlowEvent<T>) => void;
    }
  ): FlowSnapshot<T> {
    const records = new Map<string, T>();
    const defaultIdResolver = (d: any) => {
      if (!d || typeof d !== 'object') return undefined;
      return d.id || d.uid || d.email;
    };
    const resolveId = options?.idResolver || defaultIdResolver;

    if (options?.reducer) {
      for (const ev of events) {
        options.reducer(records, ev);
      }
    } else {
      for (const ev of events) {
        const data = ev.data;
        const key = resolveId(data);
        
        if (key !== undefined && key !== null) {
          const keyStr = String(key);
          const asAny = data as any;
          
          if (asAny && asAny._deleted === true) {
            records.delete(keyStr);
          } else {
            const existing = records.get(keyStr);
            if (existing && typeof existing === 'object' && typeof data === 'object') {
              records.set(keyStr, { ...existing, ...data });
            } else {
              records.set(keyStr, data);
            }
          }
        } else {
          // Fallback if no specific record key was resolved: treat as append-only collection
          records.set(String(records.size), data);
        }
      }
    }

    const snapshotTimestamp = events.length > 0 ? events[events.length - 1].timestamp : new Date().toISOString();
    const streamName = events.length > 0 ? events[0].stream : 'unknown';

    return new FlowSnapshot<T>(
      streamName,
      snapshotTimestamp,
      records,
      events.length
    );
  }
}
