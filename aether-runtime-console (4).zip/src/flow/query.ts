/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowEvent, deepFreeze } from './event';
import { FlowQueryIndex } from './index-btree';

export class FlowQuery<T> {
  // Ordered operations to execute sequentially
  private steps: Array<(events: FlowEvent<any>[]) => FlowEvent<any>[]> = [];

  constructor(
    private readonly fetchEvents: () => Promise<FlowEvent<T>[]>,
    private readonly index?: FlowQueryIndex<T>
  ) {}

  /**
   * Filters the stream based on a predicate matching task data and envelope metadata.
   */
  public where(predicate: (data: T, event: FlowEvent<T>) => boolean): FlowQuery<T> {
    const nextQuery = new FlowQuery<T>(this.fetchEvents, this.index);
    nextQuery.steps = [...this.steps, (events) => events.filter(ev => predicate(ev.data, ev))];
    return nextQuery;
  }

  /**
   * Maps current stream item data payloads into a new generic type.
   */
  public map<U>(mapper: (data: T, event: FlowEvent<T>) => U): FlowQuery<U> {
    const nextQuery = new FlowQuery<U>(async () => {
      const results = await this.evaluate();
      return results as any;
    });

    nextQuery.steps = [
      (events) => {
        return events.map((ev) => {
          const mappedData = mapper(ev.data, ev);
          const newEv: FlowEvent<U> = {
            id: ev.id,
            timestamp: ev.timestamp,
            stream: ev.stream,
            data: mappedData,
            meta: { ...ev.meta },
          };
          return deepFreeze(newEv);
        });
      },
    ];

    return nextQuery;
  }

  /**
   * Time-travel operator limiting events up to the specified ISO timestamp or Date (inclusive).
   */
  public at(timestamp: string | Date): FlowQuery<T> {
    const ISOString = typeof timestamp === 'string' ? timestamp : timestamp.toISOString();
    
    // Leverage B-Tree performance if this is the initial filter
    const query = new FlowQuery<T>(
      this.index && this.steps.length === 0
        ? () => Promise.resolve(this.index!.queryByTimestamp(null, ISOString))
        : this.fetchEvents,
      this.index
    );

    query.steps = [...this.steps, (events) => events.filter(ev => ev.timestamp <= ISOString)];
    return query;
  }

  /**
   * Filter query restricting results to events at or after the start ISO timestamp (inclusive).
   */
  public since(timestamp: string | Date): FlowQuery<T> {
    const ISOString = typeof timestamp === 'string' ? timestamp : timestamp.toISOString();

    // Leverage B-Tree performance if this is the initial filter
    const query = new FlowQuery<T>(
      this.index && this.steps.length === 0
        ? () => Promise.resolve(this.index!.queryByTimestamp(ISOString, null))
        : this.fetchEvents,
      this.index
    );

    query.steps = [...this.steps, (events) => events.filter(ev => ev.timestamp >= ISOString)];
    return query;
  }

  /**
   * Evaluator terminal: applies all query pipeline operators.
   */
  public async evaluate(): Promise<FlowEvent<T>[]> {
    let events = await this.fetchEvents();
    for (const step of this.steps) {
      events = step(events);
    }
    return events;
  }

  /**
   * Terminal operator retrieving the last n event items.
   */
  public async latest(n: number): Promise<FlowEvent<T>[]> {
    const events = await this.evaluate();
    return events.slice(-n);
  }

  /**
   * Terminal operator folding all events into a single value.
   */
  public async reduce<U>(
    reducer: (acc: U, data: T, event: FlowEvent<T>) => U,
    initialValue: U
  ): Promise<U> {
    const events = await this.evaluate();
    return events.reduce((acc, ev) => reducer(acc, ev.data, ev), initialValue);
  }
}
