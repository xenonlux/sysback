/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FlowEvent<T> {
  readonly id: string; // UUID
  readonly timestamp: string; // ISO String
  readonly stream: string; // Stream name (e.g. flow.users)
  readonly data: T;
  readonly meta: {
    readonly source: string;
    readonly version: number;
    readonly causedBy?: string;
  };
}

/**
 * Deep freezes an object recursively to satisfy the Aether Flow immutability requirement.
 * Any mutation attempt in strict mode throws a TypeError.
 */
export function deepFreeze<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  if (Object.isFrozen(obj)) {
    return obj;
  }
  const propNames = Reflect.ownKeys(obj);
  for (const name of propNames) {
    const value = (obj as any)[name];
    if (value && typeof value === 'object') {
      try {
        deepFreeze(value);
      } catch {
        // Handle non-extensible objects or system arrays
      }
    }
  }
  return Object.freeze(obj);
}

/**
 * Generates a standard RFC4122 v4 UUID.
 */
export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * FlowEvent factory function that creates an immutable event.
 */
export function createFlowEvent<T>(
  stream: string,
  data: T,
  meta?: { source?: string; version?: number; causedBy?: string }
): FlowEvent<T> {
  const event: FlowEvent<T> = {
    id: generateUUID(),
    timestamp: new Date().toISOString(),
    stream,
    data,
    meta: {
      source: meta?.source || 'system',
      version: meta?.version || 1,
      causedBy: meta?.causedBy,
    },
  };
  return deepFreeze(event);
}
