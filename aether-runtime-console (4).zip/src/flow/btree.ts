/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * A node of our multi-value B-Tree.
 * Supports duplicate keys by storing an array of values for each key.
 */
export class BTreeNode<K, V> {
  public keys: K[] = [];
  public values: V[][] = []; // each key maps to an array of values
  public children: BTreeNode<K, V>[] = [];
  public isLeaf: boolean;

  constructor(isLeaf: boolean = true) {
    this.isLeaf = isLeaf;
  }
}

/**
 * A highly robust, generic, multi-value B-Tree.
 * Perfect for disk-block matching operations, indexing, and fast range queries.
 */
export class BTree<K extends string | number, V> {
  private root: BTreeNode<K, V>;
  private t: number; // minimum degree (number of keys will be t-1 to 2t-1)

  constructor(t: number = 3) {
    this.root = new BTreeNode<K, V>(true);
    this.t = t;
  }

  /**
   * Inserts a key-value pair into the B-Tree.
   */
  public insert(key: K, value: V): void {
    const r = this.root;
    if (r.keys.length === 2 * this.t - 1) {
      const s = new BTreeNode<K, V>(false);
      this.root = s;
      s.children.push(r);
      this.splitChild(s, 0, r);
      this.insertNonFull(s, key, value);
    } else {
      this.insertNonFull(r, key, value);
    }
  }

  /**
   * Splits index node to maintain balanced B-tree heuristics.
   */
  private splitChild(parent: BTreeNode<K, V>, i: number, child: BTreeNode<K, V>): void {
    const t = this.t;
    const z = new BTreeNode<K, V>(child.isLeaf);
    
    // Split key and values around index t-1
    parent.children.splice(i + 1, 0, z);
    parent.keys.splice(i, 0, child.keys[t - 1]);
    parent.values.splice(i, 0, child.values[t - 1]);

    z.keys = child.keys.slice(t);
    z.values = child.values.slice(t);
    child.keys = child.keys.slice(0, t - 1);
    child.values = child.values.slice(0, t - 1);

    if (!child.isLeaf) {
      z.children = child.children.slice(t);
      child.children = child.children.slice(0, t);
    }
  }

  /**
   * Inserts into a node which has space.
   */
  private insertNonFull(node: BTreeNode<K, V>, key: K, value: V): void {
    let i = node.keys.length - 1;

    // Check if key already exists, if so append to values
    const existingIndex = node.keys.indexOf(key);
    if (existingIndex !== -1) {
      node.values[existingIndex].push(value);
      return;
    }

    if (node.isLeaf) {
      while (i >= 0 && key < node.keys[i]) {
        i--;
      }
      node.keys.splice(i + 1, 0, key);
      node.values.splice(i + 1, 0, [value]);
    } else {
      while (i >= 0 && key < node.keys[i]) {
        i--;
      }
      i++;
      // Check if child contains the key already before splitting or traversing
      const childExistIndex = node.children[i].keys.indexOf(key);
      if (childExistIndex !== -1) {
        this.insertNonFull(node.children[i], key, value);
        return;
      }
      if (node.children[i].keys.length === 2 * this.t - 1) {
        this.splitChild(node, i, node.children[i]);
        if (key > node.keys[i]) {
          i++;
        }
      }
      this.insertNonFull(node.children[i], key, value);
    }
  }

  /**
   * Find all values associated with a precise key.
   */
  public search(key: K): V[] {
    return this.searchNode(this.root, key);
  }

  private searchNode(node: BTreeNode<K, V>, key: K): V[] {
    let i = 0;
    while (i < node.keys.length && key > node.keys[i]) {
      i++;
    }
    if (i < node.keys.length && key === node.keys[i]) {
      return node.values[i];
    }
    if (node.isLeaf) {
      return [];
    }
    return this.searchNode(node.children[i], key);
  }

  /**
   * Range query: returns an array of values sorted by corporate key ordering between start and end (inclusive).
   */
  public rangeQuery(start: K | null, end: K | null): V[] {
    const results: V[] = [];
    this.rangeQueryNode(this.root, start, end, results);
    return results;
  }

  private rangeQueryNode(node: BTreeNode<K, V>, start: K | null, end: K | null, results: V[]): void {
    let i = 0;
    while (i < node.keys.length) {
      const key = node.keys[i];
      
      // Recurse left child before visiting current key
      if (!node.isLeaf && (start === null || key >= start)) {
        this.rangeQueryNode(node.children[i], start, end, results);
      }

      // Visit current key
      const inStart = start === null || key >= start;
      const inEnd = end === null || key <= end;
      if (inStart && inEnd) {
        results.push(...node.values[i]);
      }

      if (end !== null && key > end) {
        // Bound exceeded, subsequent records will also exceed bound
        return;
      }

      i++;
    }

    // Recurse right-most child
    if (!node.isLeaf) {
      this.rangeQueryNode(node.children[i], start, end, results);
    }
  }

  /**
   * Gets all values in sorted order.
   */
  public all(): V[] {
    return this.rangeQuery(null, null);
  }
}
