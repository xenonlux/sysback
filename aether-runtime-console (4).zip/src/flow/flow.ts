/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowEvent, createFlowEvent } from './event';
import { FlowQuery } from './query';
import { FlowQueryIndex } from './index-btree';
import { FlowSnapshot, SnapshotEngine } from './snapshot';
import { StorageBackend } from '../storage/interface';
import { Observable } from '../reactive/observable';

export class Flow<T> {
  public readonly index = new FlowQueryIndex<T>();
  private readonly observable = new Observable<FlowEvent<T>>();
  private initialized = false;

  constructor(
    public readonly name: string,
    private readonly backend: StorageBackend,
    private readonly snapshotEngine = new SnapshotEngine()
  ) {}

  /**
   * Assures indices are seeded with historical data from the storage backend.
   */
  public async ensureInitialized(): Promise<void> {
    if (this.initialized) return;
    this.initialized = true;
    try {
      const historicalEvents = await this.backend.read<T>(this.name);
      for (const ev of historicalEvents) {
        this.index.index(ev);
      }
    } catch (err) {
      console.error(`Aether failed initializing index for stream '${this.name}':`, err);
    }
  }

  /**
   * Appends an event, writes to the backend log, indexes it, and signals subscribers.
   */
  public async write(
    data: T,
    meta?: { source?: string; version?: number; causedBy?: string }
  ): Promise<FlowEvent<T>> {
    await this.ensureInitialized();

    const event = createFlowEvent<T>(this.name, data, meta);
    
    // Write persist
    await this.backend.write(this.name, event);

    // Seed index
    this.index.index(event);

    // Notify observers
    this.observable.emit(event);

    return event;
  }

  /**
   * Appends an event (Alias for write).
   */
  public async append(
    data: T,
    meta?: { source?: string; version?: number; causedBy?: string }
  ): Promise<FlowEvent<T>> {
    return this.write(data, meta);
  }

  /**
   * Creates a lazy query chain targeting this flow stream.
   */
  public query(): FlowQuery<T> {
    return new FlowQuery<T>(async () => {
      await this.ensureInitialized();
      return this.index.all();
    }, this.index);
  }

  // Chaining operator convenience shortcuts
  public where(predicate: (data: T, event: FlowEvent<T>) => boolean): FlowQuery<T> {
    return this.query().where(predicate);
  }

  public map<U>(mapper: (data: T, event: FlowEvent<T>) => U): FlowQuery<U> {
    return this.query().map(mapper);
  }

  public at(timestamp: string | Date): FlowQuery<T> {
    return this.query().at(timestamp);
  }

  public since(timestamp: string | Date): FlowQuery<T> {
    return this.query().since(timestamp);
  }

  public async latest(n: number): Promise<FlowEvent<T>[]> {
    return this.query().latest(n);
  }

  public async reduce<U>(
    reducer: (acc: U, data: T, event: FlowEvent<T>) => U,
    initialValue: U
  ): Promise<U> {
    return this.query().reduce(reducer, initialValue);
  }

  /**
   * Real-time stream subscription listener. Slower handlers are buffered sequentially.
   */
  public subscribe(
    callback: (event: FlowEvent<T>) => Promise<void> | void,
    onError?: (error: any) => void
  ): { unsubscribe: () => void } {
    return this.observable.subscribe(callback, onError);
  }

  /**
   * Generates a structural materialized state snapshot of all records.
   */
  public async snapshot(options?: {
    idResolver?: (data: T) => string;
    reducer?: (state: Map<string, T>, event: FlowEvent<T>) => void;
  }): Promise<FlowSnapshot<T>> {
    const events = await this.query().evaluate();
    return this.snapshotEngine.materialize(events, options);
  }

  /**
   * Detaches active observers and flushes buffers.
   */
  public teardown(): void {
    this.observable.clearAllSubscribers();
  }
}
