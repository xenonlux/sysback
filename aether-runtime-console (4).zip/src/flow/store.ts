/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Flow } from './flow';
import { StorageBackend } from '../storage/interface';
import { SnapshotEngine } from './snapshot';

export class FlowStore {
  private readonly flows = new Map<string, Flow<any>>();
  private readonly snapshotEngine = new SnapshotEngine();

  constructor(public readonly backend: StorageBackend) {}

  /**
   * Dynamic retrieval. Retrieves or creates an active flow manager by stream name.
   */
  public get<T>(name: string): Flow<T> {
    let flow = this.flows.get(name);
    if (!flow) {
      flow = new Flow<T>(name, this.backend, this.snapshotEngine);
      this.flows.set(name, flow);
    }
    return flow as Flow<T>;
  }

  /**
   * Scans and loads all existing flows initialized in the persistent backend.
   */
  public async getActiveFlows(): Promise<string[]> {
    try {
      const backendStreams = await this.backend.listStreams();
      for (const name of backendStreams) {
        this.get(name);
      }
    } catch {
      // ignore failures during direct scans
    }
    return Array.from(this.flows.keys());
  }

  /**
   * Teardown and clear of all active memory flows and backend logs.
   */
  public async reset(): Promise<void> {
    for (const flow of this.flows.values()) {
      flow.teardown();
    }
    this.flows.clear();
    await this.backend.clear();
  }
}
