/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  sha3_256Sync,
  sha3_512Sync,
  encryptAES256GCM,
  decryptAES256GCM,
  generateKyberKeyPair,
  kyberEncapsulate,
  kyberDecapsulate,
  generateDilithiumKeyPair,
  dilithiumSign,
  dilithiumVerify,
  generateAetherIdentity,
  signAetherToken,
  verifyAetherToken,
  PolicyEngine,
  ImmutableAuditLogger,
  ZeroTrustVerifier,
  AetherQuantumRuntimePlugin,
  QuantumStatement,
  TokenClaims
} from '../src/index';

export interface QuantumTestResult {
  name: string;
  category: string;
  status: 'passed' | 'failed';
  durationMs: number;
  errorMessage?: string;
}

/**
 * Runs the AETHER Quantum Guard post-quantum attack simulation and assertion suite.
 */
export async function runAetherQuantumTests(): Promise<QuantumTestResult[]> {
  const results: QuantumTestResult[] = [];

  const runTest = async (category: string, name: string, fn: () => Promise<void>) => {
    const start = Date.now();
    try {
      await fn();
      results.push({
        name,
        category,
        status: 'passed',
        durationMs: Date.now() - start,
      });
    } catch (err: any) {
      results.push({
        name,
        category,
        status: 'failed',
        durationMs: Date.now() - start,
        errorMessage: err.message || String(err),
      });
    }
  };

  // --- 1. SHA-3 HASH FUNCTIONS ---
  await runTest('SHA-3 Variants', 'SHA3-256 and SHA3-512 sponge checksum verification', async () => {
    const text = 'AETHER_SECURE_VAULT_2026';
    const hash256 = sha3_256Sync(text);
    const hash512 = sha3_512Sync(text);

    if (hash256.length !== 64) {
      throw new Error(`SHA3-256 output length mismatch, expected 64 hex characters, got ${hash256.length}`);
    }
    if (hash512.length !== 128) {
      throw new Error(`SHA3-512 output length mismatch, expected 128 hex characters, got ${hash512.length}`);
    }
    if (hash256 === hash512) {
      throw new Error('Collision / cross-variant structural failure');
    }
  });

  // --- 2. AES-256-GCM SYMMETRIC ENCRYPTION ---
  await runTest('AES-256-GCM', 'Symmetric cipher record encryption and decryption symmetry', async () => {
    const secretKey = 'Aether_Symmetric_Secret_Passphrase';
    const originalText = 'Quantum-secured confidential data payload';

    const encrypted = await encryptAES256GCM(originalText, secretKey);
    const decryptedBytes = await decryptAES256GCM(encrypted.ciphertext, encrypted.iv, secretKey);
    const decryptedText = new TextDecoder().decode(decryptedBytes);

    if (decryptedText !== originalText) {
      throw new Error(`Symmetric asymmetry. Expected "${originalText}", got "${decryptedText}"`);
    }
  });

  // --- 3. CRYSTALS-KYBER KEY ENCAPSULATION MECHANISM ---
  await runTest('CRYSTALS-Kyber', 'ML-KEM-768 lattice key generation, encapsulation, decapsulation loop', async () => {
    // Generate ML-KEM key pair
    const keyPair = await generateKyberKeyPair();

    if (keyPair.publicKey.length === 0 || keyPair.privateKey.length === 0) {
      throw new Error('Generated empty Kyber key records');
    }

    // Encapsulate shared secret using public key
    const encResult = await kyberEncapsulate(keyPair.publicKey);

    // Decapsulate shared secret using private key
    const decResultSecret = await kyberDecapsulate(encResult.ciphertext, keyPair.privateKey);

    // Check byte-by-byte symmetry
    if (encResult.sharedSecret.length !== 32 || decResultSecret.length !== 32) {
      throw new Error('Shared secret size is not 256 bits (32 bytes)');
    }

    for (let i = 0; i < 32; i++) {
      if (encResult.sharedSecret[i] !== decResultSecret[i]) {
        throw new Error(`Symmetry breach at byte idx ${i}: encapsulated=${encResult.sharedSecret[i]}, decapsulated=${decResultSecret[i]}`);
      }
    }
  });

  // --- 4. CRYSTALS-DILITHIUM DIGITAL SIGNATURES ---
  await runTest('CRYSTALS-Dilithium', 'ML-DSA-65 vector signature generation and integrity verification', async () => {
    const keyPair = await generateDilithiumKeyPair();
    const data = 'Authorize critical quantum ledger state alteration request';

    // Sign
    const signature = await dilithiumSign(data, keyPair.privateKey);

    // Verify
    const verified = await dilithiumVerify(data, signature, keyPair.publicKey);
    if (!verified) {
      throw new Error('Authorized signature failed verification');
    }

    // Attempt Verification with modified data
    const corruptedData = data + '!';
    const badVerify = await dilithiumVerify(corruptedData, signature, keyPair.publicKey);
    if (badVerify) {
      throw new Error('Verification passed over MITM tampered payload data!');
    }
  });

  // --- 5. COMPOSITE IDENTITY & DYNAMIC SECURITY TOKENS ---
  await runTest('Identity', 'Aether hybrid identity creation and multi-algorithm JWT validation', async () => {
    const identity = await generateAetherIdentity();
    const claims: TokenClaims = {
      iss: identity.did,
      sub: identity.did,
      aud: 'aether:microservice:payments',
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 3600,
      jti: 'session-id-token-9923',
      roles: ['ADMIN', 'CORE_SECURITY_OPERATOR']
    };

    // Issue Token
    const token = await signAetherToken(
      claims,
      identity.dilithium.privateKey,
      identity.classic.privateKey,
      identity.classic.privateKeyHex
    );

    // Verify Token
    const parsedClaims = await verifyAetherToken(
      token,
      identity.dilithium.publicKey,
      identity.classic.publicKey,
      identity.classic.publicKeyHex
    );

    if (parsedClaims.sub !== identity.did) {
      throw new Error('Claims principal mismatch on decoded post-quantum identity');
    }
    if (!parsedClaims.roles?.includes('ADMIN')) {
      throw new Error('Token claims payload roles dropped during transit parsing');
    }
  });

  // --- 6. SECURITY ATTACK SCENARIO: REPLAY ATTACK ---
  await runTest('Attack Scenarios', 'Replay Attack: verification rejection of expired credentials', async () => {
    const identity = await generateAetherIdentity();
    
    // Create an EXPIRED token (iat and exp set in the past)
    const expiredClaims: TokenClaims = {
      iss: identity.did,
      sub: identity.did,
      aud: 'aether:api:secrets',
      iat: Math.floor(Date.now() / 1000) - 3600,
      exp: Math.floor(Date.now() / 1000) - 100, // expired 100 seconds ago
      jti: 'replay-target-uuid-2231'
    };

    const expiredToken = await signAetherToken(
      expiredClaims,
      identity.dilithium.privateKey,
      identity.classic.privateKey,
      identity.classic.privateKeyHex
    );

    // Check directly with verifyAetherToken
    try {
      await verifyAetherToken(
        expiredToken,
        identity.dilithium.publicKey,
        identity.classic.publicKey,
        identity.classic.publicKeyHex
      );
      throw new Error('Expired replay token was accepted!');
    } catch (err: any) {
      if (!err.message.includes('expired')) {
        throw new Error(`Expected expiration error, got: ${err.message}`);
      }
    }
  });

  // --- 7. SECURITY ATTACK SCENARIO: MAN-IN-THE-MIDDLE (MITM) TAMPERING ---
  await runTest('Attack Scenarios', 'MITM Tampering: packet interpolation and signature verification collapse', async () => {
    const identity = await generateAetherIdentity();
    const claims: TokenClaims = {
      iss: identity.did,
      sub: identity.did,
      aud: 'aether:sys:vault',
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 1200,
      jti: 'mitm-target-9213',
      roles: ['USER'] // intruder wants to promote this to ADMIN!
    };

    const originalToken = await signAetherToken(
      claims,
      identity.dilithium.privateKey,
      identity.classic.privateKey,
      identity.classic.privateKeyHex
    );

    // Simulate MITM payload modification
    const parts = originalToken.split('.');
    const decodedClaims = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf8')) as TokenClaims;
    
    // Intruder injects higher security clearance roles
    decodedClaims.roles = ['ADMIN', 'SUPER_ROOT'];
    
    const tamperedPayloadB64 = Buffer.from(JSON.stringify(decodedClaims))
      .toString('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');

    const tamperedToken = `${parts[0]}.${tamperedPayloadB64}.${parts[2]}`;

    // Verify token MUST fail
    try {
      await verifyAetherToken(
        tamperedToken,
        identity.dilithium.publicKey,
        identity.classic.publicKey,
        identity.classic.publicKeyHex
      );
      throw new Error('MITM modified claims token bypassed signature validation!');
    } catch (err: any) {
      if (!err.message.includes('failed') && !err.message.includes('Signature')) {
        throw new Error(`Expected signature validation failure, got: ${err.message}`);
      }
    }
  });

  // --- 8. SECURITY ATTACK SCENARIO: PROTOCOL DOWNGRADE ATTACK ---
  await runTest('Attack Scenarios', 'Downgrade Attack: interception and enforcement of "quantum" modifiers', async () => {
    const plugin = new AetherQuantumRuntimePlugin({
      minimumKeyStrength: 'ML-KEM-768',
      signatureStandard: 'ML-DSA-65',
      enforceZeroTrust: true, // enforce policies strictly
      rejectDowngrades: true,  // reject legacy classical authentication tokens
      shaVariant: 'SHA3-256'
    });

    const targetNode: QuantumStatement = {
      type: 'EmitStatement',
      signal: 'ledger.funds.transfer',
      data: { type: 'Literal', value: { amount: 1000 } },
      modifiers: ['quantum'], // Quantum modifier annotation!
      quantumRequired: true
    };

    // Register active policy
    plugin.registerAccessPolicy({
      id: "policy-transfer-1",
      name: "Quantum Funds Policy",
      effect: "allow",
      resources: ["ledger.funds.transfer"],
      actions: ["invoke"],
      subjectRoles: ["ACCOUNT_OWNER"]
    });

    const regularIdentity = await generateAetherIdentity();
    plugin.registerTrustAnchor({
      did: regularIdentity.did,
      dilithiumPubKey: regularIdentity.dilithium.publicKey,
      classicPubKey: regularIdentity.classic.publicKey,
      fallbackClassicKeyHex: regularIdentity.classic.publicKeyHex
    });

    // Create message with standard claims
    const validClaims: TokenClaims = {
      iss: regularIdentity.did,
      sub: regularIdentity.did,
      aud: 'aether:runtime',
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 1000,
      jti: 'jti-101',
      roles: ["ACCOUNT_OWNER"]
    };

    const validToken = await signAetherToken(
      validClaims,
      regularIdentity.dilithium.privateKey,
      regularIdentity.classic.privateKey,
      regularIdentity.classic.privateKeyHex
    );

    const callMsg: any = {
      id: 'msg-1',
      type: 'call',
      target: 'ledger.funds.transfer',
      payload: { amount: 1000 },
      meta: {
        token: validToken,
        source: 'user-channel',
        traceId: 'trace-101'
      }
    };

    // Authenticated execution checks should succeed
    const successResult = await plugin.interceptExecution(targetNode, callMsg);
    if (!successResult.allowed) {
      throw new Error(`Legitimate quantum-signed call failed: ${successResult.error}`);
    }

    // Downgrade Attempt: attacker strips the post-quantum signature fields
    const parts = validToken.split('.');
    const decodedSignature = Buffer.from(parts[2].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
    const [dilithiumSigHex, ecdsaSigHex] = decodedSignature.split(':');

    // Strip dilithium signature (only post the classical ECDSA signature)
    const strippedSignatureB64 = Buffer.from(`:${ecdsaSigHex}`)
      .toString('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');

    const downgradedToken = `${parts[0]}.${parts[1]}.${strippedSignatureB64}`;

    const downgradeMsg: any = {
      id: 'msg-2',
      type: 'call',
      target: 'ledger.funds.transfer',
      payload: { amount: 1000 },
      meta: {
        token: downgradedToken,
        source: 'user-channel',
        traceId: 'trace-102'
      }
    };

    // System must reject the downgraded credentials
    const blockedResult = await plugin.interceptExecution(targetNode, downgradeMsg);
    if (blockedResult.allowed) {
      throw new Error('Security flaw: Protocol Downgrade Attack succeeded! Accepted token without Post-Quantum ML-DSA signature.');
    }
  });

  return results;
}
