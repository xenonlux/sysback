/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  createAetherMessage,
  validateAetherMessage,
  JSONCodec,
  MessagePackCodec,
  frame,
  LengthPrefixedUnframer,
  LocalTransport,
  LocalTransportServer,
  TcpTransport,
  TcpTransportServer,
  HttpTransport,
  HttpTransportServer,
  WebSocketTransport,
  WebSocketTransportServer,
  WebrtcTransport,
  WebrtcTransportServer,
  LoadBalancer,
  CircuitBreaker,
  retryWithBackoff,
  createAetherClientProxy,
  HandlerRegistry,
  MultiTransportServer,
  AetherMessage
} from '../src/index';

export interface TestResult {
  name: string;
  category: string;
  status: 'passed' | 'failed';
  durationMs: number;
  errorMessage?: string;
}

/**
 * Runs the complete AETHER Network Mesh compatibility test suite.
 */
export async function runAetherMeshTests(): Promise<TestResult[]> {
  const results: TestResult[] = [];

  const runTest = async (category: string, name: string, fn: () => Promise<void>) => {
    const start = Date.now();
    try {
      await fn();
      results.push({
        name,
        category,
        status: 'passed',
        durationMs: Date.now() - start,
      });
    } catch (err: any) {
      results.push({
        name,
        category,
        status: 'failed',
        durationMs: Date.now() - start,
        errorMessage: err.message || String(err),
      });
    }
  };

  // --- 1. CODE & PACKAGING SCHEMAS ---
  await runTest('Message Schema', 'AetherMessage factory and validation', async () => {
    const msg = createAetherMessage('call', 'users.fetch', { id: 101 }, { source: 'test-env' });
    const err = validateAetherMessage(msg);
    if (err) throw new Error(`Schema validate error: ${err}`);

    if (msg.type !== 'call') throw new Error('Type mismatch');
    if (msg.target !== 'users.fetch') throw new Error('Target mismatch');
    if ((msg.payload as any).id !== 101) throw new Error('Payload mismatch');
  });

  await runTest('Message Schema', 'Schema invalidation triggers', async () => {
    const invalidMsgObj = { id: '', type: 'bad', payload: null };
    const err = validateAetherMessage(invalidMsgObj);
    if (!err) throw new Error('Validator should have failed mock message object');
  });

  // --- 2. CODECS & PROTOCOLS ---
  await runTest('Codecs', 'JSON codec serialization symmetry', async () => {
    const codec = new JSONCodec();
    const mockData = { title: 'Cosmic Node', ports: [3000, 4000], active: true };
    const encoded = codec.encode(mockData);
    const decoded = codec.decode(encoded);

    if (decoded.title !== mockData.title) throw new Error('Title asymmetry');
    if (decoded.ports[1] !== 4000) throw new Error('Payload port index error');
    if (decoded.active !== true) throw new Error('Boolean state mismatch');
  });

  await runTest('Codecs', 'MessagePack codec serialization symmetry', async () => {
    const codec = new MessagePackCodec();
    const complexObj = {
      str: 'Aether Engine',
      num: 42,
      negNum: -15,
      largeNum: 99999,
      float: 3.14159,
      bool: false,
      nil: null,
      arr: [1, 'two', { inner: 'yes' }],
      nested: { x: 10, y: [true] },
    };

    const encoded = codec.encode(complexObj);
    const decoded = codec.decode(encoded);

    if (decoded.str !== complexObj.str) throw new Error('String asymmetry');
    if (decoded.num !== complexObj.num) throw new Error('Integer asymmetry');
    if (decoded.negNum !== complexObj.negNum) throw new Error('Negative int asymmetry');
    if (decoded.largeNum !== complexObj.largeNum) throw new Error('Large int asymmetry');
    if (Math.abs(decoded.float - complexObj.float) > 0.0001) throw new Error('Float asymmetry');
    if (decoded.bool !== complexObj.bool) throw new Error('Bool asymmetry');
    if (decoded.nil !== null) throw new Error('Nil asymmetry');
    if (decoded.arr[1] !== 'two') throw new Error('Array string index error');
    if (decoded.arr[2].inner !== 'yes') throw new Error('Highly nested array object mismatch');
    if (decoded.nested.y[0] !== true) throw new Error('Nested mapped boolean mismatch');
  });

  await runTest('Framing', 'Length prefix framing stream reconstruction', async () => {
    const rawBytes = new TextEncoder().encode('Test TCP Payload');
    const framed = frame(rawBytes);

    // Header size verification
    if (framed.length !== rawBytes.length + 4) throw new Error('Frame size header length error');

    // Verification of Big-Endian 32-bit value in first 4 bytes
    const view = new DataView(framed.buffer, framed.byteOffset, 4);
    if (view.getUint32(0, false) !== rawBytes.length) throw new Error('Frame length value header mismatch');

    // Unframing process
    let received: Uint8Array | null = null;
    const unframer = new LengthPrefixedUnframer((msg) => {
      received = msg;
    });

    // Feed unframer in partial sliding segments
    unframer.append(framed.subarray(0, 2));
    if (received !== null) throw new Error('Parsed incomplete header too early');

    unframer.append(framed.subarray(2, 8));
    if (received !== null) throw new Error('Parsed incomplete payload too early');

    unframer.append(framed.subarray(8));
    if (received === null) throw new Error('Failed to reconstruct framed payload');

    const decodedStr = new TextDecoder().decode(received);
    if (decodedStr !== 'Test TCP Payload') throw new Error('Payload corrupted after reassembly');
  });

  // --- 3. RESILIENCE SYSTEMS ---
  await runTest('Resilience', 'Exponential Backoff Retry pattern', async () => {
    let calls = 0;
    const fn = async () => {
      calls++;
      if (calls < 3) {
        throw new Error('Transient connection loss');
      }
      return 'success';
    };

    const res = await retryWithBackoff(fn, 3, 10, 1.5);
    if (res !== 'success') throw new Error('Retry did not succeed');
    if (calls !== 3) throw new Error(`Incorrect retry tally: ${calls}`);
  });

  await runTest('Resilience', 'Three-state Circuit Breaker trip cycle', async () => {
    const breaker = new CircuitBreaker({ failureThreshold: 2, cooldownPeriodMs: 40 });
    if (breaker.getState() !== 'CLOSED') throw new Error('Should start CLOSED');

    let counter = 0;
    const unstableTask = async () => {
      counter++;
      throw new Error('Database connection timeout error');
    };

    // Attempt 1: Closed -> Track 1 failure
    try {
      await breaker.execute(unstableTask);
    } catch {}
    if (breaker.getState() !== 'CLOSED') throw new Error('Should remain closed on single error');

    // Attempt 2: Closed -> Track 2 failures -> Over threshold, Trip OPEN
    try {
      await breaker.execute(unstableTask);
    } catch {}
    if (breaker.getState() !== 'OPEN') throw new Error('Should trip OPEN on second sequential failure');

    // Attempt 3: Open -> Block immediately without running the underlying task
    let ranTaskInOpen = false;
    try {
      await breaker.execute(async () => {
        ranTaskInOpen = true;
      });
    } catch (err: any) {
      if (!err.message.includes('OPEN state')) throw err;
    }
    if (ranTaskInOpen) throw new Error('Blocker failed, task was executed while OPEN');

    // Settle cooldown
    await new Promise((resolve) => setTimeout(resolve, 50));
    if (breaker.getState() !== 'HALF-OPEN') throw new Error('Cooldown expired, should enter HALF-OPEN');

    // Attempt 4: Half-Open success closes circuit
    const successfulTask = async () => 'green';
    const res = await breaker.execute(successfulTask);

    if (res !== 'green') throw new Error('Execution output error');
    if (breaker.getState() !== 'CLOSED') throw new Error('Successful probe should re-Close circuit');
  });

  // --- 4. TRAFFIC CONTROL ---
  await runTest('Load Balancer', 'Round-Robin load balancing policy', async () => {
    const pool = ['node-1:3000', 'node-2:3000', 'node-3:3000'];
    const balancer = new LoadBalancer(pool, 'round-robin');

    const s1 = balancer.select();
    const s2 = balancer.select();
    const s3 = balancer.select();
    const s4 = balancer.select();

    if (s1 !== 'node-1:3000') throw new Error('Incorrect round-robin s1 index');
    if (s2 !== 'node-2:3000') throw new Error('Incorrect round-robin s2 index');
    if (s3 !== 'node-3:3000') throw new Error('Incorrect round-robin s3 index');
    if (s4 !== 'node-1:3000') throw new Error('Incorrect round-robin s4 wrapping');
  });

  await runTest('Load Balancer', 'Least-Connections load balancing policy', async () => {
    const pool = ['host-A', 'host-B', 'host-C'];
    const balancer = new LoadBalancer(pool, 'least-connections');

    balancer.incrementConnection('host-A');
    balancer.incrementConnection('host-C');

    // Since host-B has 0 active connection markers, least-connections MUST select host-B
    const selected = balancer.select();
    if (selected !== 'host-B') throw new Error(`Should choose host-B (0 connection markers), got ${selected}`);

    balancer.incrementConnection('host-B');
    balancer.incrementConnection('host-B');

    // Now counts: host-A = 1, host-B = 2, host-C = 1. Target should fall back to host-A or host-C
    const nextSel = balancer.select();
    if (nextSel === 'host-B') throw new Error('Should avoid overloaded host-B node');
  });

  // --- 5. COMPATIBILITY TRANSPORTS ---
  await runTest('Transports', 'Local Transport loopback direct link', async () => {
    const registry = new HandlerRegistry();
    registry.register('ping', (payload) => {
      return { pong: payload.count + 1 };
    });

    const server = new LocalTransportServer();
    const client = new LocalTransport();

    // Attach local multi-server mock framework
    const multiServer = new MultiTransportServer(registry);
    multiServer.registerServer('local', server);

    await server.listen('local://test-endpoint');
    await client.connect('local://test-endpoint');

    let replyMsg: AetherMessage | null = null;
    client.onMessage((msg) => {
      replyMsg = msg;
    });

    const trigger = createAetherMessage('call', 'ping', { count: 3 });
    await client.send(trigger);

    if (!replyMsg) throw new Error('Fails to return response message');
    if ((replyMsg as AetherMessage).payload.pong !== 4) throw new Error('Incorrect execution tally');

    await client.close();
    await server.close();
  });

  await runTest('Transports', 'TCP transport loopback compatibility', async () => {
    const registry = new HandlerRegistry();
    registry.register('compute', (val) => val * 10);

    const server = new TcpTransportServer();
    const client = new TcpTransport();

    const mServer = new MultiTransportServer(registry);
    mServer.registerServer('tcp', server);

    await server.listen('127.0.0.1:9099');
    await client.connect('127.0.0.1:9099');

    let responsePayload: any = null;
    client.onMessage((msg) => {
      responsePayload = msg.payload;
    });

    const trigger = createAetherMessage('call', 'compute', 7);
    await client.send(trigger);

    // Wait short segment for virtual pipe processing
    await new Promise((resolve) => setTimeout(resolve, 10));

    if (responsePayload !== 70) throw new Error(`Incorrect TCP execution results: ${responsePayload}`);

    await client.close();
    await server.close();
  });

  await runTest('Transports', 'HTTP transport auto-route loopback', async () => {
    const registry = new HandlerRegistry();
    registry.register('greet', (name) => `Hello, ${name}!`);

    const server = new HttpTransportServer();
    const client = new HttpTransport();

    const mServer = new MultiTransportServer(registry);
    mServer.registerServer('http', server);

    await server.listen('http://127.0.0.1:8080');
    await client.connect('http://127.0.0.1:8080');

    let response: any = null;
    client.onMessage((msg) => {
      response = msg.payload;
    });

    const trigger = createAetherMessage('call', 'greet', 'Mesh Architect');
    await client.send(trigger);

    await new Promise((resolve) => setTimeout(resolve, 10));
    if (response !== 'Hello, Mesh Architect!') throw new Error(`HTTP payload issue, got: ${response}`);

    await client.close();
    await server.close();
  });

  await runTest('Transports', 'WebSocket transport full duplex pipeline', async () => {
    const registry = new HandlerRegistry();
    registry.register('echo', (payload) => payload);

    const server = new WebSocketTransportServer();
    const client = new WebSocketTransport();

    const mServer = new MultiTransportServer(registry);
    mServer.registerServer('websocket', server);

    await server.listen('ws://127.0.0.1:7771');
    await client.connect('ws://127.0.0.1:7771');

    let response: any = null;
    client.onMessage((msg) => {
      response = msg.payload;
    });

    const trigger = createAetherMessage('call', 'echo', { raw: 'socket-stream' });
    await client.send(trigger);

    await new Promise((resolve) => setTimeout(resolve, 10));
    if (response.raw !== 'socket-stream') throw new Error(`WS transaction mismatch ` + JSON.stringify(response));

    await client.close();
    await server.close();
  });

  await runTest('Transports', 'WebRTC DataChannel P2P negotiation loops', async () => {
    const registry = new HandlerRegistry();
    registry.register('p2p.message', (txt) => `WebRTC Verified: ${txt}`);

    const server = new WebrtcTransportServer();
    const client = new WebrtcTransport();

    const mServer = new MultiTransportServer(registry);
    mServer.registerServer('webrtc', server);

    await server.listen('webrtc://peer-node-a');
    await client.connect('webrtc://peer-node-a');

    let response: any = null;
    client.onMessage((msg) => {
      response = msg.payload;
    });

    const trigger = createAetherMessage('call', 'p2p.message', 'Direct Connection');
    await client.send(trigger);

    await new Promise((resolve) => setTimeout(resolve, 10));
    if (response !== 'WebRTC Verified: Direct Connection') throw new Error(`WebRTC P2P delivery mismatch: ${response}`);

    await client.close();
    await server.close();
  });

  // --- 6. HIGH-LEVEL CLIENT & SERVER ORCHESTRATION ---
  await runTest('Orchestration', 'ES6 dynamic RPC Client proxy pipelines', async () => {
    const registry = new HandlerRegistry();
    registry.register('user.profile.details', (id) => {
      return { id, email: 'user@aether.net', clearance: 'L3_CORE' };
    });

    const server = new LocalTransportServer();
    const client = new LocalTransport();

    const mServer = new MultiTransportServer(registry);
    mServer.registerServer('local', server);

    await server.listen('local://core-gateway');
    await client.connect('local://core-gateway');

    // Inject routing proxies
    const meshRouter = new RouterMeshExtension();
    meshRouter.registerCustomTransport('local', client);

    const proxy = createAetherClientProxy({
      router: meshRouter as any,
      timeoutMs: 100,
    });

    // Invoke clean ES6 fluent property chain!
    const profile = await proxy.user.profile.details(999);

    if (!profile || profile.clearance !== 'L3_CORE') {
      throw new Error('ES6 Proxy failed to resolve fluent target reply value');
    }
    if (profile.id !== 999) {
      throw new Error('Request payload didn’t arrive properly');
    }

    await client.close();
    await server.close();
  });

  await runTest('Orchestration', 'MultiTransportServer Logging and wildcards', async () => {
    const registry = new HandlerRegistry();
    registry.register('analytics.*', (payload, original) => {
      return { received: true, key: original.target };
    });

    const server = new LocalTransportServer();
    const client = new LocalTransport();

    const mServer = new MultiTransportServer(registry);
    mServer.registerServer('local', server);

    await server.listen('local://tracker');
    await client.connect('local://tracker');

    const trigger = createAetherMessage('call', 'analytics.metrics.clicks', { count: 12 });
    await client.send(trigger);

    await new Promise((resolve) => setTimeout(resolve, 5));

    const logs = mServer.getEventLogs();
    if (logs.length === 0) throw new Error('Telemetry log was not recorded on server dispatch');

    const lastLog = logs[0];
    if (lastLog.target !== 'analytics.metrics.clicks') throw new Error('Key mismatch');
    if (lastLog.status !== 'success') throw new Error('Status trace is incorrect');

    await client.close();
    await server.close();
  });

  return results;
}

/**
 * Stripped extensions to mock standard routing inside testing environments easily
 */
class RouterMeshExtension {
  private readonly maps = new Map<string, any>();

  public registerCustomTransport(name: string, transport: any) {
    this.maps.set(name, transport);
  }

  public selectTransport(address: string) {
    return this.maps.get('local');
  }

  public async connect(address: string) {
    return this.maps.get('local');
  }

  public async routeMessage(address: string, msg: any) {
    await this.maps.get('local').send(msg);
  }
}
