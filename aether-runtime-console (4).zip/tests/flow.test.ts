/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FlowStore } from '../src/flow/store';
import { MemoryStore } from '../src/storage/memory';
import { FileStore } from '../src/storage/file';
import { deepFreeze } from '../src/flow/event';

// Simple mockup for standard test frameworks (Jest/Vitest) compatibility
declare var describe: any;
declare var test: any;
declare var expect: any;
declare var beforeEach: any;
declare var afterEach: any;

// Fallback test block if run outside any mock runner context
const runningInRunner = typeof describe !== 'undefined';

if (runningInRunner) {
  describe('Aether Flow Data Engine - Full Test Suite', () => {
    let memoryStore: MemoryStore;
    let flowStore: FlowStore;

    beforeEach(async () => {
      memoryStore = new MemoryStore();
      flowStore = new FlowStore(memoryStore);
      await flowStore.reset();
    });

    test('Write & Read Round-Trip logic', async () => {
      const usersFlow = flowStore.get<{ id: string; name: string; email: string }>('flow.users');
      
      const event1 = await usersFlow.write({ id: 'usr_1', name: 'Alice', email: 'alice@aether.io' });
      const event2 = await usersFlow.write({ id: 'usr_2', name: 'Bob', email: 'bob@aether.io' });

      expect(event1.stream).toBe('flow.users');
      expect(event1.data.name).toBe('Alice');
      expect(event2.data.name).toBe('Bob');

      // Verify log contents
      const historical = await memoryStore.read('flow.users');
      expect(historical.length).toBe(2);
      expect(historical[0].id).toBe(event1.id);
      expect(historical[1].id).toBe(event2.id);

      // Verify immutability check: attempts to mutate event throws
      expect(() => {
        (event1.data as any).name = 'Alice Modified';
      }).toThrow();
    });

    test('Query operators: Where, Map, Reduce, At, Since', async () => {
      const metricsFlow = flowStore.get<{ key: string; val: number }>('flow.metrics');
      
      const t1 = new Date(Date.now() - 5000).toISOString();
      await metricsFlow.write({ key: 'cpu', val: 45 });
      const t2 = new Date().toISOString();
      await metricsFlow.write({ key: 'memory', val: 80 });
      await metricsFlow.write({ key: 'cpu', val: 90 });
      const t3 = new Date(Date.now() + 5000).toISOString();

      // 1. Where
      const cpuMetrics = await metricsFlow.where(m => m.key === 'cpu').evaluate();
      expect(cpuMetrics.length).toBe(2);
      expect(cpuMetrics[0].data.val).toBe(45);
      expect(cpuMetrics[1].data.val).toBe(90);

      // 2. Map (Transforms types)
      const cpuDoubles = await metricsFlow.where(m => m.key === 'cpu').map(m => m.val * 2).evaluate();
      expect(cpuDoubles.length).toBe(2);
      expect(cpuDoubles[0].data).toBe(90);
      expect(cpuDoubles[1].data).toBe(180);

      // 3. Reduce
      const sum = await metricsFlow.reduce((acc, m) => acc + m.val, 0);
      expect(sum).toBe(215);

      // 4. Since (Filter start bound)
      const sinceT2 = await metricsFlow.since(t2).evaluate();
      expect(sinceT2.length).toBe(2); // memory and cpu=90

      // 5. At (Filter upper threshold bound)
      const atT2 = await metricsFlow.at(t2).evaluate();
      expect(atT2.length).toBe(2); // cpu=45 and memory
    });

    test('Subscribe + Reactive updates with buffer backpressure', async () => {
      const alertsFlow = flowStore.get<{ message: string; severity: string }>('flow.alerts');
      const received: any[] = [];
      const delays: Promise<void>[] = [];

      // Slower hook delays each message by 30ms simulation
      const subscription = alertsFlow.subscribe(async (event) => {
        const promise = new Promise<void>(resolve => setTimeout(resolve, 30));
        delays.push(promise);
        await promise;
        received.push(event.data.message);
      });

      // Write 3 alerts quickly (asynchronously fast sequence)
      await alertsFlow.write({ message: 'Memory spike', severity: 'warning' });
      await alertsFlow.write({ message: 'Disk primary full', severity: 'critical' });
      await alertsFlow.write({ message: 'Node cluster joined', severity: 'info' });

      // Immediate check before subscriber queues finish: backpressure buffer should keep them
      expect(received.length).toBeLessThan(3);

      // Await all sequential async delays
      await Promise.all(delays);
      
      // Allow event turn to loop
      await new Promise(r => setTimeout(r, 120));

      expect(received.length).toBe(3);
      expect(received[0]).toBe('Memory spike');
      expect(received[1]).toBe('Disk primary full');
      expect(received[2]).toBe('Node cluster joined');

      subscription.unsubscribe();
    });

    test('Materialized Snapshot correctness', async () => {
      const dbFlow = flowStore.get<{ id: string; username: string; age: number; _deleted?: boolean }>('flow.db');

      await dbFlow.write({ id: 'u1', username: 'john', age: 30 });
      await dbFlow.write({ id: 'u2', username: 'maria', age: 25 });
      // Update maria's age
      await dbFlow.write({ id: 'u2', username: 'maria', age: 26 });
      // Delete john
      await dbFlow.write({ id: 'u1', username: 'john', age: 30, _deleted: true });

      const snap = await dbFlow.snapshot();
      expect(snap.size).toBe(1);
      expect(snap.get('u2')).toEqual({ id: 'u2', username: 'maria', age: 26 });
      expect(snap.get('u1')).toBeUndefined();
    });

    test('Time-travel snapshots consistency', async () => {
      const historyFlow = flowStore.get<{ id: string; status: string }>('flow.history');

      await historyFlow.write({ id: 'srv_1', status: 'INIT' });
      const stage1_time = new Date().toISOString();
      
      await new Promise(r => setTimeout(r, 10)); // assure timestamp increments
      await historyFlow.write({ id: 'srv_1', status: 'PROVISIONING' });
      const stage2_time = new Date().toISOString();
      
      await new Promise(r => setTimeout(r, 10));
      await historyFlow.write({ id: 'srv_1', status: 'READY' });

      // Query past snapshot at Stage 1
      const snap1_events = await historyFlow.at(stage1_time).evaluate();
      const snap1 = dbSnapshot(snap1_events);
      expect(snap1.get('srv_1')?.status).toBe('INIT');

      // Query past snapshot at Stage 2
      const snap2_events = await historyFlow.at(stage2_time).evaluate();
      const snap2 = dbSnapshot(snap2_events);
      expect(snap2.get('srv_1')?.status).toBe('PROVISIONING');

      // Query current snapshot
      const snapCurrent = await historyFlow.snapshot();
      expect(snapCurrent.get('srv_1')?.status).toBe('READY');
    });

    test('Large-volume scale performance (100k events)', async () => {
      const benchmarkFlow = flowStore.get<{ value: number }>('flow.benchmark');
      const startMark = performance.now();
      
      const payload = { value: 1 };
      
      // Push 100,000 events in batches to avoid CPU bounds
      const totalCount = 100000;
      const batchSize = 1000;

      for (let i = 0; i < totalCount; i += batchSize) {
        const promises = [];
        for (let j = 0; j < batchSize; j++) {
          promises.push(benchmarkFlow.write(payload));
        }
        await Promise.all(promises);
      }

      const writeDuration = performance.now() - startMark;
      console.log(`Large Volume: 100,000 events appended and B-Tree indexed in ${writeDuration.toFixed(2)}ms`);
      
      expect(writeDuration).toBeLessThan(10000); // Shorter than 10s is robust, highly-optimized

      const queryStart = performance.now();
      const allEvents = await benchmarkFlow.query().evaluate();
      const queryDuration = performance.now() - queryStart;

      expect(allEvents.length).toBe(100000);
      console.log(`Large Volume: Query evaluation of 100,000 items in ${queryDuration.toFixed(2)}ms`);
    });
  });
}

// Micro fallback implementation of snapshot materialize for manual testing helper
function dbSnapshot(events: any[]): { get: (k: string) => any } {
  const records = new Map<string, any>();
  for (const ev of events) {
    records.set(ev.data.id, ev.data);
  }
  return {
    get: (key: string) => records.get(key)
  };
}
