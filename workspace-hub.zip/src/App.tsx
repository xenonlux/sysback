import React, { useState, useEffect } from 'react';
import {
  Layers,
  Sparkles,
  Plus,
  Trash2,
  Code,
  CheckCircle,
  Circle,
  FileText,
  Check,
  ExternalLink,
  BookOpen,
  ArrowRight,
  RotateCcw,
  Edit,
  Save,
  FileCode,
  Layout,
  Sliders,
  Palette,
  Calculator,
  Compass,
  Flame,
  CheckSquare,
  HelpCircle,
  FileSpreadsheet
} from 'lucide-react';

// Types
interface Task {
  id: string;
  title: string;
  priority: 'low' | 'medium' | 'high';
  completed: boolean;
}

interface SpecConfig {
  appType: string;
  features: string[];
  persistence: string;
  styling: string;
}

export default function App() {
  // Task Planner State
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('workspace_tasks');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return [
      { id: '1', title: 'Plan core app structure and design theme', priority: 'high', completed: false },
      { id: '2', title: 'Define data models and state management schema', priority: 'medium', completed: false },
      { id: '3', title: 'Assemble UI elements and test responsiveness', priority: 'low', completed: false }
    ];
  });

  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');

  // Scratchpad State
  const [scratchpad, setScratchpad] = useState(() => {
    return localStorage.getItem('workspace_scratchpad') || 
      '// Draft your thoughts, custom scripts, or schema here...\n\nconst projectConfig = {\n  version: "1.0.0",\n  theme: "elegant-slate",\n  features: ["durable-persistence", "responsive-grid"]\n};';
  });
  const [scratchSaved, setScratchSaved] = useState(false);

  // Specification Generator State
  const [specConfig, setSpecConfig] = useState<SpecConfig>({
    appType: 'Todo Tracker',
    features: ['Local Storage Schema', 'Interactive Charts / Recharts'],
    persistence: 'Browser Storage (localStorage)',
    styling: 'Tailwind CSS Modern Light Theme'
  });
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  // Quick Sandbox Interactive Widgets
  // Numeric Converter Widget State
  const [calculatorInput, setCalculatorInput] = useState('100');
  const [conversionType, setConversionType] = useState<'usd_to_eur' | 'c_to_f' | 'kg_to_lbs'>('usd_to_eur');
  
  // Custom Interactive Palette state
  const [primaryColor, setPrimaryColor] = useState('#6366f1'); // Indigo

  // Active Tab state
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<'planner' | 'spec_builder' | 'sandbox' | 'docs'>('spec_builder');

  // Save Tasks in LocalStorage on change
  useEffect(() => {
    localStorage.setItem('workspace_tasks', JSON.stringify(tasks));
  }, [tasks]);

  // Save Scratchpad
  useEffect(() => {
    localStorage.setItem('workspace_scratchpad', scratchpad);
    setScratchSaved(true);
    const timer = setTimeout(() => setScratchSaved(false), 800);
    return () => clearTimeout(timer);
  }, [scratchpad]);

  // Generate Prompt Template
  useEffect(() => {
    const listFeatures = specConfig.features.map(f => `- **${f}**`).join('\n');
    const prompt = `Please build a highly polished, single-view **${specConfig.appType}** application with the following characteristics:

1. **Aesthetic Design**:
   - Styled using a **${specConfig.styling}**.
   - Balanced negative space, modern typography, crisp interactive elements, and micro-hover states.
   - Use beautiful **Lucide React** icons.

2. **Core Features**:
${listFeatures}

3. **Data & Storage**:
   - Uses **${specConfig.persistence}** to persist user changes.
   - Implements validation to catch faulty inputs.

4. **Code Quality**:
   - Write fully typed TypeScript.
   - Keep structural boundaries of simple single-view setups where applicable.`;

    setGeneratedPrompt(prompt);
  }, [specConfig]);

  // Add Project Task
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const newTask: Task = {
      id: Date.now().toString(),
      title: newTaskTitle.trim(),
      priority: newTaskPriority,
      completed: false
    };
    setTasks([...tasks, newTask]);
    setNewTaskTitle('');
  };

  // Toggle Task Completion
  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  // Delete Task
  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  // Reset Checklist
  const resetTasks = () => {
    setTasks([
      { id: '1', title: 'Plan core app structure and design theme', priority: 'high', completed: false },
      { id: '2', title: 'Define data models and state management schema', priority: 'medium', completed: false },
      { id: '3', title: 'Assemble UI elements and test responsiveness', priority: 'low', completed: false }
    ]);
  };

  // Copy Prompt to Clipboard
  const copyPromptToClipboard = () => {
    navigator.clipboard.writeText(generatedPrompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  // Calculate Conversions
  const calculateConversionResult = () => {
    const num = parseFloat(calculatorInput);
    if (isNaN(num)) return 'Invalid Input';
    
    switch (conversionType) {
      case 'usd_to_eur':
        return `€ ${(num * 0.92).toFixed(2)}`;
      case 'c_to_f':
        return `${((num * 9/5) + 32).toFixed(1)} °F`;
      case 'kg_to_lbs':
        return `${(num * 2.20462).toFixed(2)} lbs`;
      default:
        return '';
    }
  };

  // Predefined Suggestion Templates
  const appTemplates = [
    { name: 'Todo Tracker', icon: CheckSquare, defaultFeatures: ['Local Storage Schema', 'Dynamic Tag Filtering', 'Priority Color Indicators'] },
    { name: 'Recipe Assistant', icon: Compass, defaultFeatures: ['Ingredient Portion Scaler', 'Step-by-step Guides', 'Preparation Timer'] },
    { name: 'Finance Ledger', icon: FileSpreadsheet, defaultFeatures: ['Transaction History Dashboard', 'Interactive Recharts Panel', 'Monthly Budget Limits'] },
    { name: 'Aesthetic Calendar', icon: Layout, defaultFeatures: ['Visual Event Grid', 'Color-Coded Calendars', 'Reminders & Notifications'] }
  ];

  const toggleFeatureSelection = (feat: string) => {
    if (specConfig.features.includes(feat)) {
      setSpecConfig({
        ...specConfig,
        features: specConfig.features.filter(f => f !== feat)
      });
    } else {
      setSpecConfig({
        ...specConfig,
        features: [...specConfig.features, feat]
      });
    }
  };

  // Statistics
  const completedCount = tasks.filter(t => t.completed).length;
  const progressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 font-sans antialiased Selection:bg-indigo-100 selection:text-indigo-900" id="workspace-root">
      {/* Top Banner / Navigation */}
      <header className="border-b border-slate-200 bg-white sticky top-0 z-30" id="main-header">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="bg-indigo-600 text-white p-2 rounded-xl shadow-xs" id="header-logo-container">
              <Layers className="h-6 w-6" id="logo-icon" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900" id="app-title-header">Workspace Hub</h1>
              <p className="text-xs text-slate-500" id="app-subtitle-header">Plan, prototype, and build your next React application</p>
            </div>
          </div>
          
          {/* Quick Environment Badges */}
          <div className="flex items-center gap-3 text-xs" id="env-status-container">
            <div className="flex items-center space-x-2 bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-semibold">Vite Ready</span>
            </div>
            <div className="bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg font-mono border border-slate-200">
              Clojure-Ready Applet
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8" id="main-content-layout">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Sidebar Tabs */}
          <aside className="lg:col-span-3 flex flex-col gap-2" id="sidebar-navigation">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">Workspace Sections</h3>
            
            <button
              id="tab-spec-builder"
              onClick={() => setActiveWorkspaceTab('spec_builder')}
              className={`flex items-center space-x-3 px-3.5 py-3 rounded-xl text-sm font-medium transition-all ${
                activeWorkspaceTab === 'spec_builder'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold shadow-xs border-l-4 border-indigo-600'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Sparkles className="h-4 w-4 shrink-0 text-slate-500 group-hover:text-slate-700" />
              <span>Prompt & Spec Builder</span>
            </button>

            <button
              id="tab-planner"
              onClick={() => setActiveWorkspaceTab('planner')}
              className={`flex items-center space-x-3 px-3.5 py-3 rounded-xl text-sm font-medium transition-all ${
                activeWorkspaceTab === 'planner'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold shadow-xs border-l-4 border-indigo-600'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <CheckSquare className="h-4 w-4 shrink-0 text-slate-500" />
              <span>Roadmap Planner</span>
              {tasks.filter(t => !t.completed).length > 0 && (
                <span className="ml-auto bg-indigo-100 text-indigo-800 text-xs px-2 py-0.5 rounded-full font-bold">
                  {tasks.filter(t => !t.completed).length}
                </span>
              )}
            </button>

            <button
              id="tab-sandbox"
              onClick={() => setActiveWorkspaceTab('sandbox')}
              className={`flex items-center space-x-3 px-3.5 py-3 rounded-xl text-sm font-medium transition-all ${
                activeWorkspaceTab === 'sandbox'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold shadow-xs border-l-4 border-indigo-600'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Sliders className="h-4 w-4 shrink-0 text-slate-500" />
              <span>UI Sandboxing</span>
            </button>

            <button
              id="tab-docs"
              onClick={() => setActiveWorkspaceTab('docs')}
              className={`flex items-center space-x-3 px-3.5 py-3 rounded-xl text-sm font-medium transition-all ${
                activeWorkspaceTab === 'docs'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold shadow-xs border-l-4 border-indigo-600'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <BookOpen className="h-4 w-4 shrink-0 text-slate-500" />
              <span>Guidelines Quick Reference</span>
            </button>

            {/* Quick Interactive Scratchpad inside the sidebar */}
            <div className="mt-8 bg-white rounded-2xl p-4 border border-slate-200 shadow-xs" id="quick-scratchpad-panel">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                  <FileText className="h-3.5 w-3.5 text-indigo-600" /> Persistent Notepad
                </span>
                {scratchSaved && (
                  <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-1 animate-fade-in">
                    <Check className="h-3 w-3" /> Saved
                  </span>
                )}
              </div>
              <textarea
                id="workspace-scratchpad-area"
                value={scratchpad}
                onChange={(e) => setScratchpad(e.target.value)}
                placeholder="Jot down prompt snippets, temporary database schema, ideas..."
                className="w-full h-44 p-3 text-xs font-mono bg-slate-50 text-slate-700 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white resize-none"
              />
            </div>
          </aside>

          {/* Main workspace interactive container */}
          <div className="lg:col-span-9" id="active-panel-container">
            
            {/* TAB 1: Specification Builder */}
            {activeWorkspaceTab === 'spec_builder' && (
              <div className="space-y-6 animate-fade-in" id="spec-builder-main-view">
                
                {/* Visual Intro */}
                <div className="bg-gradient-to-r from-indigo-900 to-slate-900 text-white p-6 sm:p-8 rounded-3xl shadow-sm relative overflow-hidden" id="hero-banner-spec">
                  <div className="absolute right-0 top-0 opacity-10 transform translate-x-12 -translate-y-6">
                    <Sparkles className="h-64 w-64 text-white" />
                  </div>
                  <div className="relative z-10 max-w-xl">
                    <span className="text-xs font-bold tracking-widest text-indigo-300 uppercase bg-indigo-950/70 px-3 py-1 rounded-full border border-indigo-800">
                      AI Studio Builder Assistant
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-extrabold mt-3 tracking-tight">Ready to build your masterpiece?</h2>
                    <p className="text-sm mt-2 text-indigo-200 leading-relaxed">
                      Toggle specifications, choose an application preset, and copy the optimized blueprint to send directly to this agent block to build.
                    </p>
                  </div>
                </div>

                {/* Main Settings Builder Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="configuration-forms-grid">
                  
                  {/* Configuration Form */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5" id="spec-config-options">
                    <h3 className="font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3 text-base">
                      <Sliders className="h-5 w-5 text-indigo-600" />
                      Configure Blueprint
                    </h3>

                    {/* App Type selection */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Application Preset Type</label>
                      <div className="grid grid-cols-2 gap-2" id="preset-type-grid">
                        {appTemplates.map((tmpl) => {
                          const IconComp = tmpl.icon;
                          const isSelected = specConfig.appType === tmpl.name;
                          return (
                            <button
                              id={`preset-btn-${tmpl.name.toLowerCase().replace(/\s+/g, '-')}`}
                              key={tmpl.name}
                              type="button"
                              onClick={() => setSpecConfig({
                                ...specConfig,
                                appType: tmpl.name,
                                features: tmpl.defaultFeatures
                              })}
                              className={`flex items-center space-x-2.5 p-3 rounded-xl border text-left text-xs transition-all ${
                                isSelected 
                                  ? 'bg-indigo-50 border-indigo-600 text-indigo-900 font-semibold' 
                                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              <IconComp className={`h-4 w-4 shrink-0 ${isSelected ? 'text-indigo-600' : 'text-slate-400'}`} />
                              <span className="truncate">{tmpl.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Feature Lists toggling */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Major Technical Capabilities</label>
                      <div className="space-y-2" id="technical-capabilities-list">
                        {[
                          'Local Storage Schema',
                          'Interactive Charts / Recharts',
                          'Responsive Grid Layout',
                          'Animated Page Transitions (framer-motion-style)',
                          'Drag & Drop File Selection Handler',
                          'Data Sort, Filter & CSV Export'
                        ].map((feature) => {
                          const hasFeature = specConfig.features.includes(feature);
                          return (
                            <button
                              id={`feature-toggle-${feature.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                              key={feature}
                              type="button"
                              onClick={() => toggleFeatureSelection(feature)}
                              className={`flex items-center justify-between w-full p-2.5 rounded-xl border text-left text-xs transition-all ${
                                hasFeature
                                  ? 'bg-indigo-50/50 border-indigo-200 text-slate-800 font-semibold'
                                  : 'border-slate-100 text-slate-500 hover:bg-slate-50 hover:border-slate-200'
                              }`}
                            >
                              <span className="flex items-center space-x-2">
                                <span className={`w-2 h-2 rounded-full ${hasFeature ? 'bg-indigo-600' : 'bg-slate-300'}`}></span>
                                <span>{feature}</span>
                              </span>
                              <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold uppercase ${
                                hasFeature ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-100 text-slate-400'
                              }`}>
                                {hasFeature ? 'Selected' : 'Add'}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Styling Choice select */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Styling Paradigm</label>
                      <select
                        id="select-styling-paradigm"
                        value={specConfig.styling}
                        onChange={(e) => setSpecConfig({ ...specConfig, styling: e.target.value })}
                        className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl text-slate-700 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      >
                        <option>Tailwind CSS Modern Light Theme</option>
                        <option>Aesthetic Cyberpunk Dark Preset</option>
                        <option>Minimalist Warm Off-White UI Accent</option>
                        <option>Productive Slate-Gray Dashboard Layout</option>
                      </select>
                    </div>

                    {/* Persistence Target */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Data Persistence Strategy</label>
                      <select
                        id="select-persistence-strategy"
                        value={specConfig.persistence}
                        onChange={(e) => setSpecConfig({ ...specConfig, persistence: e.target.value })}
                        className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl text-slate-700 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      >
                        <option>Browser Storage (localStorage)</option>
                        <option>Server-side Memory Cache</option>
                        <option>Cloud-powered Firestore Database (Firebase Skill)</option>
                      </select>
                    </div>

                  </div>

                  {/* Generated Prompt Code block */}
                  <div className="bg-slate-900 rounded-2xl p-6 text-slate-100 flex flex-col justify-between shadow-lg relative border border-slate-800" id="generated-prompt-output-box">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                        <span className="text-xs font-semibold text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                          <Code className="h-4 w-4" /> Optimized AI Code Prompt
                        </span>
                        <div className="flex space-x-1">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                        </div>
                      </div>
                      
                      <div className="text-xs font-mono text-slate-300 whitespace-pre-line leading-relaxed max-h-96 overflow-y-auto pr-2 bg-slate-950 p-4 rounded-xl border border-slate-800/80" id="prompt-textbox-scroller">
                        {generatedPrompt}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-800 mt-4 flex items-center justify-between" id="prompt-action-bar">
                      <p className="text-[11px] text-slate-400 flex items-center gap-1">
                        <HelpCircle className="h-3.5 w-3.5" /> Ready to copy & paste
                      </p>
                      
                      <button
                        id="copy-blueprint-prompt-button"
                        onClick={copyPromptToClipboard}
                        className={`text-xs px-4 py-2.5 rounded-xl font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                          copiedPrompt
                            ? 'bg-emerald-600 text-white'
                            : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md hover:shadow-lg'
                        }`}
                      >
                        {copiedPrompt ? (
                          <>
                            <Check className="h-4 w-4" />
                            <span>Ready to Paste!</span>
                          </>
                        ) : (
                          <>
                            <FileCode className="h-4 w-4" />
                            <span>Copy Prompt Blueprint</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                </div>

                {/* Simple Prompt Builder Quick Start Info card */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4" id="next-steps-info-card">
                  <div className="flex items-start space-x-3.5">
                    <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                      <Flame className="h-5 w-5 text-indigo-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-900 text-sm">How to use this template:</h4>
                      <p className="text-xs text-slate-500 max-w-xl mt-0.5 leading-relaxed">
                        Copy the template above, tweak the text if needed, then simply paste it to me in the text prompt area. I will immediately transition this workspace into your custom requested app!
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* TAB 2: Roadmap Planner */}
            {activeWorkspaceTab === 'planner' && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 animate-fade-in" id="planner-main-view">
                
                {/* Visual Intro row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5" id="roadmap-heading-container">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900">Project Roadmap & Task Planner</h2>
                    <p className="text-xs text-slate-500 mt-1">Manage, sort, and complete key feature elements for your pending app.</p>
                  </div>

                  <div className="flex items-center space-x-3 text-xs" id="roadmap-stats-badges">
                    <span className="bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg border border-slate-200/80 font-medium">
                      {completedCount} of {tasks.length} Done ( {progressPercent}% )
                    </span>
                    <button
                      id="reset-project-roadmap-button"
                      onClick={resetTasks}
                      className="text-slate-500 hover:text-indigo-600 transition-colors py-1 px-2.5 rounded-md hover:bg-slate-50 text-xs flex items-center gap-1 cursor-pointer font-bold"
                    >
                      <RotateCcw className="h-3.5 w-3.5" /> Reset Starter Tasks
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden" id="planner-progressbar-track">
                  <div 
                    id="planner-progressbar-fill"
                    className="bg-indigo-600 h-full transition-all duration-500" 
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>

                {/* Insertion Form */}
                <form id="add-task-form" onSubmit={handleAddTask} className="flex flex-col sm:flex-row gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-150">
                  <div className="flex-1">
                    <input
                      id="input-task-title"
                      type="text"
                      placeholder="Add a custom roadmap milestone... e.g., Set up Firebase authentication"
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 text-slate-700"
                    />
                  </div>
                  
                  {/* Priority selector */}
                  <div className="flex items-center gap-3">
                    <select
                      id="select-task-priority"
                      value={newTaskPriority}
                      onChange={(e) => setNewTaskPriority(e.target.value as 'low' | 'medium' | 'high')}
                      className="text-xs p-3 bg-white border border-slate-200 rounded-xl text-slate-600 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="low">Low Priority</option>
                      <option value="medium">Medium Priority</option>
                      <option value="high">High Priority</option>
                    </select>

                    <button
                      id="submit-add-task-button"
                      type="submit"
                      className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs p-3 rounded-xl transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Add Task
                    </button>
                  </div>
                </form>

                {/* Tasks List */}
                <div className="space-y-2.5" id="roadmap-tasks-list">
                  {tasks.length === 0 ? (
                    <div className="text-center py-10 text-slate-400" id="empty-tasks-placeholder">
                      <CheckCircle className="h-10 w-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs">No active roadmap tasks! Add one using the form above.</p>
                    </div>
                  ) : (
                    tasks.map((task) => {
                      const badgeColors = {
                        low: 'bg-blue-50 text-blue-700 border-blue-100',
                        medium: 'bg-amber-50 text-amber-700 border-amber-100',
                        high: 'bg-rose-50 text-rose-700 border-rose-100'
                      };

                      return (
                        <div
                          id={`task-item-${task.id}`}
                          key={task.id}
                          className={`flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                            task.completed 
                              ? 'bg-slate-50/50 border-slate-100 opacity-65' 
                              : 'bg-white border-slate-200 hover:shadow-xs'
                          }`}
                        >
                          <div className="flex items-center space-x-3 flex-1 min-w-0">
                            <button
                              id={`toggle-task-${task.id}`}
                              type="button"
                              onClick={() => toggleTask(task.id)}
                              className="text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer shrink-0"
                            >
                              {task.completed ? (
                                <CheckCircle className="h-5 w-5 text-indigo-600" />
                              ) : (
                                <Circle className="h-5 w-5" />
                              )}
                            </button>
                            
                            <span className={`text-xs font-medium truncate ${task.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                              {task.title}
                            </span>
                          </div>

                          <div className="flex items-center space-x-3 ml-4 shrink-0">
                            <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold uppercase border ${badgeColors[task.priority]}`}>
                              {task.priority}
                            </span>

                            <button
                              id={`delete-task-${task.id}`}
                              type="button"
                              onClick={() => deleteTask(task.id)}
                              className="text-slate-300 hover:text-rose-600 p-1.5 rounded-md hover:bg-rose-50 transition-all cursor-pointer"
                              title="Delete task"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

              </div>
            )}

            {/* TAB 3: Sandbox Playground */}
            {activeWorkspaceTab === 'sandbox' && (
              <div className="space-y-6 animate-fade-in" id="sandbox-main-view">
                
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm" id="sandbox-features-card">
                  <div className="border-b border-slate-100 pb-4 mb-6">
                    <h2 className="text-xl font-bold text-slate-900">Aesthetic UI Sandboxing</h2>
                    <p className="text-xs text-slate-500 mt-1">
                      Check interactive states, layouts, and input parameters directly in your workspace.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="sandbox-components-grid">
                    
                    {/* Live Unit Converter Widget */}
                    <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col justify-between" id="sandbox-calculator-box">
                      <div>
                        <div className="flex items-center space-x-2 text-indigo-900 font-bold text-sm mb-4">
                          <Calculator className="h-4" /> <span>Micro Converter State Engine</span>
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Enter Numerical Value</label>
                            <input
                              id="converter-input-val"
                              type="number"
                              value={calculatorInput}
                              onChange={(e) => setCalculatorInput(e.target.value)}
                              className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl text-slate-700 font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Conversion Metric</label>
                            <div className="grid grid-cols-3 gap-1.5" id="conversion-modes-dock">
                              {[
                                { key: 'usd_to_eur', label: 'USD → EUR' },
                                { key: 'c_to_f', label: '°C → °F' },
                                { key: 'kg_to_lbs', label: 'kg → lbs' }
                              ].map((opt) => (
                                <button
                                  id={`metric-btn-${opt.key}`}
                                  key={opt.key}
                                  type="button"
                                  onClick={() => setConversionType(opt.key as any)}
                                  className={`p-2 text-[10px] font-bold rounded-lg transition-all ${
                                    conversionType === opt.key
                                      ? 'bg-indigo-600 text-white shadow-xs'
                                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                                  }`}
                                >
                                  {opt.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="mt-6 pt-4 border-t border-slate-200 flex items-center justify-between" id="converter-bottom-result">
                        <span className="text-xs text-slate-500 font-medium">Rendered Result:</span>
                        <span id="converter-result-span" className="text-lg font-black text-indigo-700 tracking-tight transition-all">
                          {calculateConversionResult()}
                        </span>
                      </div>
                    </div>

                    {/* Color Palette Playground */}
                    <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col justify-between" id="sandbox-palette-box">
                      <div>
                        <div className="flex items-center space-x-2 text-indigo-900 font-bold text-sm mb-4">
                          <Palette className="h-4" /> <span>Tailwind Color Palette Previewer</span>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Preset Accent Focus</label>
                            <div className="flex space-x-2" id="palette-choices-container">
                              {[
                                { hex: '#6366f1', name: 'Indigo' },
                                { hex: '#10b981', name: 'Emerald' },
                                { hex: '#3b82f6', name: 'Blue' },
                                { hex: '#f59e0b', name: 'Amber' },
                                { hex: '#ec4899', name: 'Pink' }
                              ].map((clr) => (
                                <button
                                  id={`clr-btn-${clr.name.toLowerCase()}`}
                                  key={clr.hex}
                                  type="button"
                                  onClick={() => setPrimaryColor(clr.hex)}
                                  className="w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 shadow-xs cursor-pointer focus:outline-hidden"
                                  style={{ 
                                    backgroundColor: clr.hex,
                                    borderColor: primaryColor === clr.hex ? '#000000' : 'transparent'
                                  }}
                                  title={clr.name}
                                />
                              ))}
                            </div>
                          </div>

                          {/* Dynamic box preview styled elements */}
                          <div className="p-3.5 rounded-xl border transition-all text-xs flex flex-col space-y-2" style={{ backgroundColor: `${primaryColor}0e`, borderColor: `${primaryColor}30` }}>
                            <div className="flex items-center space-x-2">
                              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: primaryColor }} />
                              <span className="font-extrabold" style={{ color: primaryColor }}>Custom Styled Element</span>
                            </div>
                            <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                              This context background changes dynamically matching your configuration theme setup rules.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 text-xs text-slate-400 font-mono flex items-center justify-between" id="palette-hex-code">
                        <span>HEX Code:</span>
                        <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-extrabold text-[11px]">
                          {primaryColor}
                        </span>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            )}

            {/* TAB 4: Guidelines reference */}
            {activeWorkspaceTab === 'docs' && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 animate-fade-in" id="guidelines-main-view">
                <div className="border-b border-slate-100 pb-4">
                  <h2 className="text-xl font-bold text-slate-900">Guidelines Quick Reference</h2>
                  <p className="text-xs text-slate-500 mt-1">Essential structural policies and code architecture standards for this build workspace.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="guidelines-cards-grid">
                  
                  {/* Styling Rule card */}
                  <div className="p-5 bg-slate-50 border border-slate-150 rounded-2xl space-y-2.5" id="guidelines-styling-rule">
                    <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-widest bg-indigo-100 px-2.5 py-0.5 rounded-full">
                      Styling Policy
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm">Tailwind CSS Utility Classes</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Standardized on full responsive utility patterns. No custom inline <code>style</code> blocks or separate CSS file creation. Focus on beautiful typography, margins, clean borders, and generous padding.
                    </p>
                  </div>

                  {/* Persistence Rule card */}
                  <div className="p-5 bg-slate-50 border border-slate-150 rounded-2xl space-y-2.5" id="guidelines-persistence-rule">
                    <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest bg-emerald-100 px-2.5 py-0.5 rounded-full">
                      Storage Policy
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm">Durable vs Transient Storage</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Single-user utilities stay clean, local, or use standard browser <code>localStorage</code> cache. Production state managers and durable requirements are synced smoothly using Cloud Firebase (Firestore).
                    </p>
                  </div>

                  {/* Boundaries Rule card */}
                  <div className="p-5 bg-slate-50 border border-slate-150 rounded-2xl space-y-2.5" id="guidelines-boundaries-rule">
                    <span className="text-[10px] font-bold text-rose-700 uppercase tracking-widest bg-rose-100 px-2.5 py-0.5 rounded-full">
                      Scope Boundary
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm">Minimalist Single-View Rule</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      For straightforward tasks (e.g. clock, list, calculator), keep the code in a single elegant screen. Avoid adding unsolicited complex secondary layouts, drawers, sidebars, or telemetry details.
                    </p>
                  </div>

                  {/* Code Quality Rule card */}
                  <div className="p-5 bg-slate-50 border border-slate-150 rounded-2xl space-y-2.5" id="guidelines-code-quality-rule">
                    <span className="text-[10px] font-bold text-slate-700 uppercase tracking-widest bg-slate-200 px-2.5 py-0.5 rounded-full">
                      TS Standards
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm">Strict Type Safety</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Write clean compile-safe TypeScript. Place all import statements at the top level, use named imports, and avoid type assertions unless required.
                    </p>
                  </div>

                </div>
              </div>
            )}

          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-16 text-center text-xs text-slate-500" id="main-footer">
        <p className="max-w-6xl mx-auto px-4">
          Workspace Hub © {new Date().getFullYear()} • Fully operational & ready. Let me know what to construct next!
        </p>
      </footer>
    </div>
  );
}
