/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DiscoveredPattern } from '../analyze/pattern-miner';

export interface PersistedEvolutionModel {
  epoch: number;
  lastUpdated: number;
  patterns: DiscoveredPattern[];
  appliedOptimizationsCount: number;
  avgConfidence: number;
}

export class ModelPersistenceStore {
  private storageKey = 'aether_learned_evolution_model';

  constructor() {}

  /**
   * Serializes and stores the current learned state
   */
  public saveModel(model: PersistedEvolutionModel): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(model));
    } catch (e) {
      console.error('Error persisting Aether learned models:', e);
    }
  }

  /**
   * Retrieves the current learned state
   */
  public loadModel(): PersistedEvolutionModel | null {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Error loading Aether learned models:', e);
    }
    return null;
  }

  /**
   * Erases all model definitions from persistence
   */
  public clear(): void {
    try {
      localStorage.removeItem(this.storageKey);
    } catch (e) {
      console.error('Error clearing persisted models:', e);
    }
  }
}
