/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from '../observe/collector';

export class SignalPersistenceStore {
  private storageKey = 'aether_evolution_execution_signals';

  constructor() {}

  /**
   * Saves a collection of signals to local persistence
   */
  public saveSignals(signals: ExecutionSignal[]): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(signals));
    } catch (e) {
      console.error('Error persisting Aether execution signals:', e);
    }
  }

  /**
   * Loads signals from local persistence
   */
  public loadSignals(): ExecutionSignal[] {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Error loading persisted Aether execution signals:', e);
    }
    return [];
  }

  /**
   * Clears the signals database
   */
  public clear(): void {
    try {
      localStorage.removeItem(this.storageKey);
    } catch (e) {
      console.error('Error clearing persisted signals:', e);
    }
  }
}
