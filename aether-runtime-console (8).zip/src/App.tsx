/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Terminal, 
  Check, 
  Copy, 
  AlertTriangle, 
  Cpu, 
  ShieldCheck, 
  TrendingUp, 
  Radio, 
  Code2, 
  Layers, 
  Trash2, 
  Zap, 
  Activity, 
  RefreshCw, 
  Sliders, 
  History, 
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { NaturalBridge, TranslationResult } from './bridge/NaturalBridge';
import { EvolutionEngine, DashboardInsights, AlertNotification, StreamDependencyGraph } from './index';

export default function App() {
  const [bridge] = useState(() => new NaturalBridge());
  const [engine] = useState(() => new EvolutionEngine());
  
  const testCases = bridge.getTestCases();

  // Navigation View selection
  const [viewMode, setViewMode] = useState<'bridge' | 'evolution'>('evolution');

  // --- TRANSBRIDGE STATES (from prior execution) ---
  const [naturalInput, setNaturalInput] = useState(testCases[0].text);
  const [translationResult, setTranslationResult] = useState<TranslationResult | null>(null);
  const [selectedCaseId, setSelectedCaseId] = useState<string>(testCases[0].id);
  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedNodeIndex, setSelectedNodeIndex] = useState<number | null>(null);

  // Translation execution sandbox simulation
  const [selectedTab, setSelectedTab] = useState<'flow' | 'source' | 'simulator'>('flow');
  const [simulationActive, setSimulationActive] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<Array<{ timestamp: string; type: 'info' | 'success' | 'warn' | 'error'; message: string }>>([]);
  const [mockRequestPayload, setMockRequestPayload] = useState<string>('{\n  "email": "developer@aether.org",\n  "password": "securePass123!",\n  "amount": 250.00\n}');
  const [simResultsStore, setSimResultsStore] = useState<{
    authenticated: boolean;
    storedInDb: Array<any>;
    broadcastSignals: Array<any>;
    lastResponse: any;
  }>({ authenticated: false, storedInDb: [], broadcastSignals: [], lastResponse: null });

  // --- SELF-EVOLUTION ENGINE STATES ---
  const [simulationWorkloadActive, setSimulationWorkloadActive] = useState(true);
  const [dashboardInsights, setDashboardInsights] = useState<DashboardInsights | null>(null);
  const [engineLogs, setEngineLogs] = useState<string[]>([]);
  const [alertNotifications, setAlertNotifications] = useState<AlertNotification[]>([]);
  const [usageGraph, setUsageGraph] = useState<StreamDependencyGraph>({ nodes: [], links: [] });
  const [selectedProposalId, setSelectedProposalId] = useState<string | null>(null);

  // Fetch init statistics
  useEffect(() => {
    // Generate pre-loaded signals so that graphs look vibrant right out of the box!
    for (let i = 0; i < 45; i++) {
      const streams = ['users', 'users', 'billing', 'telemetry'];
      const stream = streams[i % streams.length];
      let handler = 'on_heartbeat';
      let duration = Math.floor(5 + Math.random() * 12);
      let redundant: string[] = [];
      let errRate = 0;

      if (stream === 'users') {
        handler = 'on_register';
        duration = Math.floor(10 + Math.random() * 10);
        redundant = ['email', 'password'];
      } else if (stream === 'billing') {
        handler = 'on_ledger_commit';
        duration = Math.floor(110 + Math.random() * 80); // slow anomalies
        errRate = Math.random() < 0.1 ? 0.2 : 0;
      }

      engine.logExecution(stream, handler, duration, 1024 * 72, 1, errRate, 'ast_hash_' + stream, redundant);
    }

    const insights = engine.processEvolutionCycle();
    setDashboardInsights(insights);
    setEngineLogs(engine.getLogs());
    setAlertNotifications(engine.getAlertNotifications());
    setUsageGraph(engine.getUsageGraph());

    // Compile Translation default trigger
    handleCompile(testCases[0].text);
  }, []);

  // background execution loop mimicking incoming server metrics
  useEffect(() => {
    if (!simulationWorkloadActive) return;

    const interval = setInterval(() => {
      const roll = Math.random();
      let stream = 'users';
      let handler = 'on_register';
      let duration = Math.floor(8 + Math.random() * 15);
      let memory = Math.floor(1024 * (50 + Math.random() * 80));
      let valids: string[] = [];
      let errRate = 0;

      if (roll < 0.4) {
        // High frequency Users Path
        stream = 'users';
        handler = 'on_register';
        const isJit = engine.jitCompiler.isJITActive('users');
        duration = isJit ? Math.floor(1 + Math.random() * 3) : Math.floor(12 + Math.random() * 10);
        memory = isJit ? 12200 : Math.floor(65000 + Math.random() * 12000);
        valids = Math.random() < 0.7 ? ['email', 'password'] : [];
      } else if (roll < 0.65) {
        // Intermittent slower billing transactions
        stream = 'billing';
        handler = 'on_checkout';
        const isJit = engine.jitCompiler.isJITActive('billing');
        duration = isJit ? Math.floor(2 + Math.random() * 4) : Math.floor(115 + Math.random() * 220); // Spikes
        errRate = Math.random() < 0.08 ? 0.15 : 0;
      } else if (roll < 0.9) {
        // Healthy system ping node
        stream = 'telemetry';
        handler = 'on_ping';
        duration = Math.floor(3 + Math.random() * 5);
      } else {
        // An idle stream remains idle (triggering archive recommendation)
        stream = 'users';
        handler = 'on_audit';
      }

      engine.logExecution(stream, handler, duration, memory, 1, errRate, 'ast_hash_' + stream, valids);
      const insights = engine.processEvolutionCycle();
      
      setDashboardInsights(insights);
      setEngineLogs(engine.getLogs());
      setAlertNotifications(engine.getAlertNotifications());
      setUsageGraph(engine.getUsageGraph());
    }, 1200);

    return () => clearInterval(interval);
  }, [simulationWorkloadActive, engine]);

  // Handle manual compilation in Bridge Mode
  const handleCompile = (inputText = naturalInput) => {
    if (!inputText.trim()) return;
    const result = bridge.translate(inputText);
    setTranslationResult(result);
    setSimulationActive(false);

    // Feed a custom execution signal into our self-evolution core!
    const trigger = result.intent.trigger || 'register';
    const hasValidate = result.intent.actions.some(a => a.actionType === 'validate');
    engine.logExecution(
      trigger,
      'compiled_interpreter',
      Math.floor(6 + Math.random() * 12),
      1024 * 40,
      1,
      0,
      'hash_' + trigger.substring(0, 4),
      hasValidate ? ['email'] : []
    );
    const insights = engine.processEvolutionCycle();
    setDashboardInsights(insights);
    setEngineLogs(engine.getLogs());
    setUsageGraph(engine.getUsageGraph());
    
    // Auto populate mock request values
    if (result.intent.trigger === 'transaction') {
      setMockRequestPayload('{\n  "amount": 499.95,\n  "currency": "USD",\n  "ledgerRef": "tx_invoice_8911"\n}');
    } else if (result.intent.trigger === 'login') {
      setMockRequestPayload('{\n  "email": "operator_admin@aether.cloud",\n  "deviceToken": "sec_auth_tkn_812"\n}');
    } else if (result.intent.trigger === 'telemetry') {
      setMockRequestPayload('{\n  "nodeId": "ams_router_01",\n  "status": "ONLINE"\n}');
    } else {
      setMockRequestPayload('{\n  "email": "pioneering_user@aether.io",\n  "password": "quantumSeedingPass99!"\n}');
    }

    if (result.confidence >= 90) {
      triggerConfetti();
    }
  };

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 50,
      origin: { y: 0.8 },
      colors: ['#10B981', '#6366F1', '#3B82F6']
    });
  };

  const handleSelectTestCase = (id: string) => {
    const found = testCases.find(tc => tc.id === id);
    if (found) {
      setSelectedCaseId(id);
      setNaturalInput(found.text);
      handleCompile(found.text);
    }
  };

  const handleCopyCode = () => {
    if (!translationResult) return;
    navigator.clipboard.writeText(translationResult.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const addLog = (type: 'info' | 'success' | 'warn' | 'error', message: string) => {
    const now = new Date();
    const ts = now.toLocaleTimeString();
    setSimulationLogs(prev => [...prev, { timestamp: ts, type, message }]);
  };

  const runFullSimulation = async () => {
    if (!translationResult) return;
    setSimulationActive(true);
    setSimulationLogs([]);
    
    let reqBody;
    try {
      reqBody = JSON.parse(mockRequestPayload);
    } catch (e) {
      addLog('error', '⚠️ Compilation Blocked: Invalid input request JSON payloads. Check syntax.');
      setSimulationActive(false);
      return;
    }

    addLog('info', '📡 Starting Aether Sandbox Virtual Dry-Run Engine...');
    addLog('info', `🎯 Initializing pipeline trigger [on ${translationResult.intent.trigger || 'register'}]`);
    addLog('info', `📦 Mapping parsed payload: ${JSON.stringify(reqBody)}`);

    const statements = translationResult.ast;
    const db: Array<any> = [];
    const signals: Array<any> = [];
    let authenticated = false;
    let localScopeUser: any = null;
    let lastResult: any = null;

    for (let i = 0; i < statements.length; i++) {
      const stmt = statements[i];
      await new Promise(r => setTimeout(r, 600));

      switch (stmt.type) {
        case 'LetStatement': {
          addLog('info', `⚙️ Step ${i + 1}: LetStmt - Running validation bounds on input.`);
          if (stmt.value.type === 'CallExpression' && stmt.value.callee === 'validate') {
            const properties = (stmt.value.arguments[1] as any)?.value || {};
            const emailRequired = !!properties.email;
            const passwordRequired = !!properties.password;
            
            let validationFailed = false;

            if (emailRequired) {
              const emailVal = reqBody.email || reqBody.username;
              const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
              if (!emailVal) {
                addLog('error', '❌ ValidationError: Required property "email" is missing from input request.');
                validationFailed = true;
              } else if (!emailRegex.test(emailVal)) {
                addLog('warn', `⚠️ FormatWarning: Email "${emailVal}" does not match Aether.EmailRegex standards.`);
                addLog('error', '❌ ValidationError: Pattern validation rejected format specification for field "email".');
                validationFailed = true;
              } else {
                addLog('success', `✓ Format Check Passed: Email Address "${emailVal}" matches structured properties.`);
              }
            }

            if (passwordRequired) {
              const passVal = reqBody.password || '';
              if (!passVal) {
                addLog('error', '❌ ValidationError: Required property "password" is missing from input.');
                validationFailed = true;
              } else if (passVal.length < 8) {
                addLog('warn', `⚠️ CrypticWarning: Private token strength is only ${passVal.length} charts. Recommended minimum is 8.`);
                addLog('error', '❌ ValidationError: Strength standard requirement unmet.');
                validationFailed = true;
              } else {
                addLog('success', `✓ Security Check Passed: Private tokens validated against Password.strong definitions.`);
              }
            }

            if (validationFailed) {
              addLog('error', '🛑 Process Stack Aborted: Pipeline failed validation sequence.');
              setSimulationActive(false);
              return;
            }

            localScopeUser = {
              id: `usr_${Math.floor(100000 + Math.random() * 900000)}`,
              email: reqBody.email || 'developer@aether.org',
              timestamp: Date.now()
            };
            authenticated = true;
            addLog('success', `✓ Local state binding created: variable "${stmt.name}" initialized with parsed context.`);
          } else {
            const resolvedValue = `sha_sig_${Math.floor(10000000 + Math.random() * 90000000)}`;
            addLog('success', `✓ Hash calculated: "${stmt.name}" bound with signature "${resolvedValue}"`);
          }
          break;
        }

        case 'EmitStatement': {
          addLog('info', `⚙️ Step ${i + 1}: EmitStmt - Dispatching signals or pushing to FlowStore.`);
          const sig = stmt.signal;
          if (sig.includes('.register') || sig.includes('ledgers.')) {
            const row = {
              ...(localScopeUser || { id: 'sys_autogen_row' }),
              ...reqBody,
              committedAt: new Date().toISOString()
            };
            db.push(row);
            addLog('success', `💾 BTree FlowStore: Flow record written safely onto stream target "${sig.split('.')[0]}".`);
          } else {
            const signalPayload = {
              pulseId: `pulse_${Math.floor(Math.random() * 10000)}`,
              signalName: sig,
              firedAt: Date.now()
            };
            signals.push(signalPayload);
            addLog('success', `⚡ EventBus active: Broadcasted system signal "${sig}" over WebSocket/RPC channels.`);
          }
          break;
        }

        case 'YieldStatement': {
          addLog('info', `⚙️ Step ${i + 1}: YieldStmt - Generating return payload responses.`);
          lastResult = {
            statusCode: translationResult.intent.trigger === 'register' ? 201 : 200,
            status: 'success',
            payload: localScopeUser || {
              processed: true,
              reference: `ref_ack_${Math.floor(1000 + Math.random() * 9000)}`
            }
          };
          addLog('success', `↩ Yield Return: Yield statement returned status: ${lastResult.statusCode}. Channel stream finalized.`);
          break;
        }
      }
    }

    setSimResultsStore({
      authenticated,
      storedInDb: db,
      broadcastSignals: signals,
      lastResponse: lastResult
    });

    setSimulationActive(false);
    addLog('success', '🏆 Sandbox Execution Successful: Run ended with EXIT_CODE 0.');
    triggerConfetti();

    // Log this sandbox run execution in our self evolution!
    engine.logExecution(
      translationResult.intent.trigger || 'sandbox',
      'user_sandbox_dryrun',
      Math.floor(15 + Math.random() * 15),
      1024 * 96,
      1,
      0,
      'pattern-sandbox-dryrun'
    );
    const updatedInsights = engine.processEvolutionCycle();
    setDashboardInsights(updatedInsights);
    setEngineLogs(engine.getLogs());
    setUsageGraph(engine.getUsageGraph());
  };

  // Safe Optimizer handles
  const handleApplyOptimizer = (suggestionId: string) => {
    const success = engine.compileAndApplyOptimization(suggestionId);
    if (success) {
      triggerConfetti();
      const updated = engine.processEvolutionCycle();
      setDashboardInsights(updated);
      setEngineLogs(engine.getLogs());
    }
  };

  const handleRollbackOptimizer = (suggestionId: string) => {
    const success = engine.rollbackOptimization(suggestionId);
    if (success) {
      const updated = engine.processEvolutionCycle();
      setDashboardInsights(updated);
      setEngineLogs(engine.getLogs());
    }
  };

  const handlePurgeAll = () => {
    engine.purgeAllStates();
    const updated = engine.processEvolutionCycle();
    setDashboardInsights(updated);
    setEngineLogs(engine.getLogs());
    setAlertNotifications([]);
    setUsageGraph(engine.getUsageGraph());
    setSelectedProposalId(null);
  };

  return (
    <div className="min-h-screen bg-[#020512] text-slate-100 flex flex-col justify-between select-none" id="aether_main_frame">
      
      {/* 1. GLOWING HEADER */}
      <header className="border-b border-indigo-500/10 bg-slate-950/60 backdrop-blur-xl p-4 sticky top-0 z-50 transition-all font-sans" id="header_pane">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <div className="relative group">
              <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-emerald-500 to-indigo-600 opacity-60 blur group-hover:opacity-100 transition duration-1000" />
              <div className="relative bg-slate-900 border border-slate-850 p-2.5 rounded-xl text-emerald-400">
                <Cpu className="h-5 w-5 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[9px] uppercase tracking-widest font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">AETHER ENGINE</span>
                <span className="text-[10px] bg-slate-900 text-slate-300 font-mono px-2 py-0.5 rounded-full border border-slate-800">COGNITIVE v4.5.1</span>
              </div>
              <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5 mt-0.5">
                AETHER <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-indigo-400">Self-Evolution Intelligence</span>
              </h1>
            </div>
          </div>

          {/* MAIN PILOT MODE TOGGLE NAV */}
          <div className="flex bg-slate-950/80 p-1 border border-slate-850 rounded-xl space-x-1 w-full md:w-auto" id="navigator_tab_box">
            <button
              onClick={() => setViewMode('evolution')}
              className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center justify-center space-x-2 transition ${
                viewMode === 'evolution'
                  ? 'bg-gradient-to-r from-indigo-600 to-blue-500 text-white shadow-xl shadow-indigo-600/10'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <Zap className="h-3.5 w-3.5" />
              <span>Self-Evolution Control</span>
            </button>
            <button
              onClick={() => setViewMode('bridge')}
              className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center justify-center space-x-2 transition ${
                viewMode === 'bridge'
                  ? 'bg-gradient-to-r from-indigo-600 to-blue-500 text-white shadow-xl shadow-indigo-600/10'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <Sliders className="h-3.5 w-3.5" />
              <span>Linguistic NL Bridge</span>
            </button>
          </div>
        </div>
      </header>

      {/* 2. MAIN APPLICATION CONTENT VIEWPORTS */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 lg:py-6" id="viewports_area">
        
        {/* ==============================================
             A. COGNITIVE SELF-EVOLUTION ENGINE VIEWPORT
           ============================================== */}
        {viewMode === 'evolution' && (
          <div className="space-y-6 animate-fade-in" id="evolution_viewport">
            
            {/* Real-time Status Banner */}
            <div className="bg-slate-900/30 border border-slate-850 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden backdrop-blur-md">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-emerald-500" />
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Activity className="h-4.5 w-4.5 text-emerald-400 animate-pulse" />
                  <span className="text-xs uppercase font-mono font-bold text-emerald-400 tracking-wider">Operational Engine State: ONLINE</span>
                </div>
                <p className="text-xs text-slate-400 font-sans max-w-2xl leading-relaxed">
                  Aether Autonomous Analyzer is absorbing thread latency, memory heap telemetry, and redundant AST loops. It executes compiler transformations natively via safe rollback mechanisms.
                </p>
              </div>

              {/* Dynamic workload generator controls */}
              <div className="flex items-center space-x-3 shrink-0">
                <button
                  onClick={() => setSimulationWorkloadActive(!simulationWorkloadActive)}
                  className={`px-4 py-2 border rounded-xl text-xs font-mono font-bold flex items-center space-x-2 shadow-lg transition duration-200 ${
                    simulationWorkloadActive
                      ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/20 hover:bg-emerald-600/30'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${simulationWorkloadActive ? 'animate-spin' : ''}`} />
                  <span>{simulationWorkloadActive ? 'Simulating Server Traffic' : 'Resume Simulated Traffic'}</span>
                </button>
                <button
                  onClick={handlePurgeAll}
                  className="bg-slate-950 hover:bg-rose-950/20 hover:text-rose-400 border border-slate-850 text-slate-500 p-2 rounded-xl text-xs font-mono font-bold transition"
                  title="Purge Engine Buffers"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* HIGH-LEVEL METRIC INDEX CORES */}
            {dashboardInsights && (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="insights_indices_grid">
                
                <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-2xl flex items-center space-x-4">
                  <div className="bg-indigo-500/10 p-3 rounded-xl text-indigo-400">
                    <Radio className="h-5 w-5 text-indigo-400 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-mono uppercase tracking-wider font-bold">Signals Captured</span>
                    <span className="text-xl font-bold font-mono text-white">{dashboardInsights.signalsCounter}</span>
                    <span className="text-[10px] text-slate-400 block font-mono mt-0.5">Buffer Capacity: 1000 max</span>
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-2xl flex items-center space-x-4">
                  <div className="bg-emerald-500/10 p-3 rounded-xl text-emerald-400">
                    <History className="h-5 w-5 text-emerald-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-mono uppercase tracking-wider font-bold">Average Latency</span>
                    <span className="text-xl font-bold font-mono text-emerald-400">{dashboardInsights.averageLatencyMs}ms</span>
                    <span className="text-[10px] text-slate-400 block font-mono mt-0.5">SLA limit: 100ms</span>
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-2xl flex items-center space-x-4">
                  <div className="bg-amber-500/10 p-3 rounded-xl text-amber-400">
                    <Sliders className="h-5 w-5 text-amber-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-mono uppercase tracking-wider font-bold">Sampling Rate</span>
                    <span className="text-xl font-bold font-mono text-white">{dashboardInsights.samplingRate}%</span>
                    <span className="text-[10px] text-slate-400 block font-mono mt-0.5">
                      {dashboardInsights.samplingRate < 100 ? 'Downsampling active' : 'Full Telemetry'}
                    </span>
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-2xl flex items-center space-x-4">
                  <div className="bg-emerald-500/10 p-3 rounded-xl text-emerald-400">
                    <ShieldCheck className="h-5 w-5 text-emerald-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-mono uppercase tracking-wider font-bold">Applied Optimizers</span>
                    <span className="text-xl font-bold font-mono text-white">{dashboardInsights.appliedOptimizations} count</span>
                    <span className="text-[10px] text-slate-400 block font-mono mt-0.5">Automated safety locks</span>
                  </div>
                </div>

              </div>
            )}

            {/* THREE-STAGE COGNITIVE PIPELINE EXPANSION (Observe, Analyze, Evolve) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch" id="cognitive_pipeline_grid">
              
              {/* STAGE 1 & 2: OBSERVE & ANALYZE (Col Span 7) */}
              <div className="lg:col-span-7 flex flex-col space-y-6" id="observe_analyze_panels_box">
                
                {/* 1. OBSERVE LAYER: TELEMETRY STREAM */}
                <div className="bg-slate-900/40 border border-slate-850/80 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                      <h3 className="text-xs uppercase tracking-widest font-black text-slate-300 font-mono">Observe — Execution Telemetry Signals</h3>
                    </div>
                    <span className="text-[10px] font-mono text-indigo-400 border border-indigo-500/20 bg-indigo-500/5 px-2.5 py-0.5 rounded-full font-black">Layer 1</span>
                  </div>

                  {/* Ringbuffer health status bars */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-[11px] font-mono text-slate-400">
                      <span>RingBuffer Heap allocation status:</span>
                      <span>{(dashboardInsights?.signalsCounter || 0) / 10}% fill</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-900 flex">
                      <div 
                        className="h-full rounded-full transition-all duration-500 bg-gradient-to-r from-indigo-600 via-blue-500 to-emerald-500"
                        style={{ width: `${Math.min(100, ((dashboardInsights?.signalsCounter || 0) / 10))}%` }}
                      />
                    </div>
                  </div>

                  {/* Realtime scrolling logs feed */}
                  <div className="bg-slate-950 rounded-xl border border-slate-850 p-4 font-mono text-[11px] h-36 overflow-y-auto space-y-2 text-left shadow-inner">
                    {engineLogs.length > 0 ? (
                      engineLogs.slice(0, 20).map((log, idx) => (
                        <div key={idx} className="flex items-start space-x-1 hover:bg-slate-900/50 p-0.5 rounded transition">
                          <ChevronRight className="h-3 w-3 mt-0.5 shrink-0 text-indigo-500" />
                          <span className="text-slate-300 font-mono break-all leading-relaxed">{log}</span>
                        </div>
                      ))
                    ) : (
                      <div className="h-full flex items-center justify-center text-slate-600">
                        Observability logs silent. Waiting for workload signals...
                      </div>
                    )}
                  </div>
                </div>

                {/* 2. ANALYZE LAYER: MODELS */}
                <div className="bg-slate-900/40 border border-slate-850/80 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                      <h3 className="text-xs uppercase tracking-widest font-black text-slate-300 font-mono">Analyze — Pattern & SLA Performance Model</h3>
                    </div>
                    <span className="text-[10px] font-mono text-sky-400 border border-sky-500/20 bg-sky-500/5 px-2.5 py-0.5 rounded-full font-black">Layer 2</span>
                  </div>

                  {/* Latency and Throughput Gauges */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* Hot Paths */}
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                      <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider font-bold">Throughput Stream Gauges</span>
                      
                      {dashboardInsights && dashboardInsights.hotPaths.length > 0 ? (
                        <div className="space-y-3">
                          {dashboardInsights.hotPaths.slice(0, 3).map((hp, idx) => (
                            <div key={idx} className="space-y-1 text-left">
                              <div className="flex justify-between items-center text-xs">
                                <span className="font-mono text-slate-300 font-black truncate max-w-[120px]">
                                  {hp.stream} <span className="text-[10px] text-slate-500">({hp.handler})</span>
                                </span>
                                <span className={`font-mono text-[11px] ${hp.isHot ? 'text-amber-400 font-bold' : 'text-slate-400'}`}>
                                  {hp.frequencyHz}hz {hp.jitOptimized ? '⚡ JIT' : ''}
                                </span>
                              </div>
                              <div className="w-full bg-slate-905 rounded-full h-1.5 overflow-hidden border border-slate-900">
                                <div 
                                  className={`h-full rounded-full transition-all duration-300 ${
                                    hp.jitOptimized ? 'bg-indigo-500' : hp.isHot ? 'bg-amber-500' : 'bg-slate-600'
                                  }`}
                                  style={{ width: `${Math.min(100, hp.frequencyHz * 4)}%` }}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-600">Gathering statistics...</p>
                      )}
                    </div>

                    {/* Mined Abstractions */}
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                      <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider font-bold">Mined Code Patterns</span>
                      
                      {dashboardInsights && dashboardInsights.minedPatterns.length > 0 ? (
                        <div className="space-y-2 text-left h-[100px] overflow-y-auto font-mono">
                          {dashboardInsights.minedPatterns.map((pat, idx) => (
                            <div key={idx} className="bg-slate-900 border border-slate-800/80 p-2 rounded-lg text-[10px] space-y-1">
                              <div className="flex justify-between items-center">
                                <span className="text-sky-400 font-bold">
                                  {pat.patternType === 'redundant_validation' ? 'Redundant Validation' : pat.patternType === 'frequent_abstractions' ? 'AST Pattern match' : 'Idle Channel'}
                                </span>
                                <span className="text-slate-500 text-[9px] font-black">{pat.impactScore}% savings</span>
                              </div>
                              <p className="text-[9px] text-slate-400 leading-snug truncate">{pat.details}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-600">Scanning for structure abstractions...</p>
                      )}
                    </div>

                  </div>

                  {/* Dynamic Stream Graph Visualization */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3" id="stream_usage_graph_canvas">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider font-bold">Aether Dynamic Dependency Graph</span>
                      <span className="text-[9px] font-mono text-slate-500">Live coordinates map</span>
                    </div>

                    <div className="border border-slate-900 bg-slate-950 rounded-lg p-4 min-h-[160px] flex flex-col justify-center items-center">
                      {usageGraph.nodes.length > 0 ? (
                        <div className="w-full flex flex-col md:flex-row items-center justify-around gap-6 py-2">
                          
                          {/* Left inputs */}
                          <div className="space-y-4">
                            <span className="text-[9px] uppercase tracking-wider text-slate-600 block text-center font-mono font-bold">Clients</span>
                            <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl flex items-center space-x-2 text-xs font-mono">
                              <Radio className="h-3 text-indigo-400 animate-pulse" />
                              <span className="font-bold">Natural Language Gateway</span>
                            </div>
                            <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl flex items-center space-x-2 text-xs font-mono">
                              <RefreshCw className="h-3 text-emerald-400 animate-spin" />
                              <span className="font-bold">Throughput Workload</span>
                            </div>
                          </div>

                          {/* Arrow flow */}
                          <div className="hidden md:block text-slate-600 text-xs">➔</div>

                          {/* Center routing streams */}
                          <div className="space-y-3 flex-1 max-w-sm">
                            <span className="text-[9px] uppercase tracking-wider text-slate-600 block text-center font-mono font-bold font-black">Active Stream Channels</span>
                            
                            {usageGraph.nodes.filter(n => n.type === 'stream').map((node, i) => {
                              const totalEvents = node.eventsProcessed;
                              return (
                                <div key={i} className="bg-slate-900/90 border border-slate-800/80 p-2 rounded-xl flex justify-between items-center text-xs font-mono">
                                  <div className="flex items-center space-x-2">
                                    <div className={`w-1.5 h-1.5 rounded-full ${node.id === 'users' ? 'bg-indigo-500' : 'bg-emerald-500'}`} />
                                    <span className="font-bold">{node.id} channel</span>
                                  </div>
                                  <span className="text-[10px] text-slate-500 font-bold">{totalEvents} events</span>
                                </div>
                              );
                            })}
                          </div>

                          {/* Arrow flow */}
                          <div className="hidden md:block text-slate-600 text-xs">➔</div>

                          {/* Right side bindings */}
                          <div className="space-y-4">
                            <span className="text-[9px] uppercase tracking-wider text-slate-600 block text-center font-mono font-bold">Bound handlers</span>
                            <div className="bg-slate-900 border border-slate-800 px-3 py-2 rounded-xl text-[10px] font-mono text-left">
                              <span className="text-emerald-400 font-bold">on_ledger_commit</span>
                              <p className="text-slate-500 text-[9px] truncate max-w-[100px]">Z-Score Checked</p>
                            </div>
                            <div className="bg-slate-900 border border-slate-800 px-3 py-2 rounded-xl text-[10px] font-mono text-left">
                              <span className="text-indigo-400 font-bold">on_register</span>
                              <p className="text-slate-500 text-[9px] truncate max-w-[100px]">JIT Optimizations</p>
                            </div>
                          </div>

                        </div>
                      ) : (
                        <p className="text-xs text-slate-600 font-mono">Simulating dependency paths...</p>
                      )}
                    </div>
                  </div>

                  {/* Realtime Anomalies Alert Center */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                    <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider font-bold">Anomaly Log Alerting</span>
                    
                    <div className="space-y-2 text-left font-mono text-[10px] max-h-32 overflow-y-auto">
                      {alertNotifications.length > 0 ? (
                        alertNotifications.map((alert, idx) => (
                          <div 
                            key={idx} 
                            className={`p-2.5 rounded-lg border flex items-start space-x-2 transition ${
                              alert.severity === 'CRITICAL' 
                                ? 'bg-rose-500/5 border-rose-500/20 text-rose-300' 
                                : 'bg-amber-500/5 border-amber-500/20 text-amber-300'
                            }`}
                          >
                            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                            <div>
                              <div className="font-bold flex items-center gap-1.5">
                                <span>{alert.title}</span>
                                <span className="text-[9px] text-slate-500 font-normal">{new Date(alert.timestamp).toLocaleTimeString()}</span>
                              </div>
                              <p className="text-[10px] leading-relaxed mt-0.5 text-slate-300">{alert.message}</p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center text-slate-600 py-4 select-none">
                          No performance anomalies detected. Pipeline latency satisfies SLAs.
                        </div>
                      )}
                    </div>
                  </div>
                </div>

              </div>

              {/* STAGE 3: EVOLVE (Col Span 5) */}
              <div className="lg:col-span-5 flex flex-col space-y-6" id="evolve_panel_box">
                
                {/* 3. EVOLVE WINDOW */}
                <div className="bg-slate-900/40 border border-slate-850/80 rounded-2xl p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <h3 className="text-xs uppercase tracking-widest font-black text-slate-300 font-mono">Evolve — Optimization suggestions</h3>
                      </div>
                      <span className="text-[10px] font-mono text-emerald-400 border border-emerald-500/20 bg-emerald-500/5 px-2.5 py-0.5 rounded-full font-black">Layer 3</span>
                    </div>

                    <p className="text-xs text-slate-400 font-sans leading-relaxed text-left">
                      The analyzer generated the following structural improvements. Review and authorization applies zero-downtime, safe AST changes:
                    </p>

                    {/* SUGGESTION LIST CARD CONTAINERS */}
                    <div className="space-y-3 max-h-[380px] overflow-y-auto pr-0.5">
                      {dashboardInsights && dashboardInsights.suggestions.length > 0 ? (
                        dashboardInsights.suggestions.map((sug, idx) => {
                          const isExpanded = selectedProposalId === sug.id;
                          return (
                            <div 
                              key={idx} 
                              className={`border rounded-xl p-4 text-left transition-all space-y-3 ${
                                sug.applied 
                                  ? 'bg-emerald-500/5 border-emerald-500/30 shadow-md' 
                                  : isExpanded 
                                    ? 'bg-slate-950 border-indigo-500 shadow-xl shadow-indigo-600/5' 
                                    : 'bg-slate-950 border-slate-850 hover:border-slate-750'
                              }`}
                            >
                              {/* Header trigger line */}
                              <div 
                                onClick={() => setSelectedProposalId(isExpanded ? null : sug.id)}
                                className="flex justify-between items-start cursor-pointer select-none"
                              >
                                <div className="space-y-1 pr-2">
                                  <h4 className="text-xs font-mono font-black text-white">{sug.title}</h4>
                                  <span className="text-[9px] text-slate-500 font-mono block">Target: stream.{sug.sourceStream}</span>
                                </div>
                                <span className={`text-[10px] uppercase px-2 py-0.5 rounded-full font-mono font-black ${
                                  sug.applied 
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                                    : 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20'
                                }`}>
                                  {sug.applied ? 'Applied ✓' : 'Available'}
                                </span>
                              </div>

                              <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                                {sug.reason}
                              </p>

                              {/* Collapsible code diff file view */}
                              {isExpanded && (
                                <div className="space-y-3 animate-fade-in" id={`expanded_proposals_${sug.id}`}>
                                  <div className="text-[9px] text-indigo-400 font-bold uppercase font-mono tracking-wider">Aether VM Code Transformation AST Diff File</div>
                                  
                                  {sug.codeDiff && (
                                    <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 font-mono text-[10px] overflow-x-auto select-text leading-relaxed text-left">
                                      <div className="text-rose-500 bg-rose-500/5 p-1 rounded font-bold break-all whitespace-pre">
                                        - {sug.codeDiff.before}
                                      </div>
                                      <div className="text-emerald-400 bg-emerald-500/5 p-1 rounded font-bold mt-1.5 break-all whitespace-pre">
                                        + {sug.codeDiff.after}
                                      </div>
                                    </div>
                                  )}

                                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono border-t border-slate-850/60 pt-2.5">
                                    <span>Reduction: <strong className="text-emerald-400">{sug.estimatedReduction}</strong></span>
                                    <span>Match Accuracy: {sug.confidence}%</span>
                                  </div>
                                </div>
                              )}

                              {/* Trigger Buttons */}
                              <div className="flex items-center space-x-2 border-t border-slate-850/60 pt-3">
                                {!sug.applied ? (
                                  <button
                                    onClick={() => handleApplyOptimizer(sug.id)}
                                    className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-mono font-black py-2.5 px-3 rounded-lg text-[10px] uppercase tracking-wider text-center cursor-pointer select-none transition-all duration-150"
                                  >
                                    🤖 Safely Auto-Apply Refactor
                                  </button>
                                ) : (
                                  sug.rollbackAvailable && (
                                    <button
                                      onClick={() => handleRollbackOptimizer(sug.id)}
                                      className="flex-1 bg-slate-900 hover:bg-rose-950/20 hover:text-rose-450 border border-slate-850 text-slate-400 font-mono py-2.5 px-3 rounded-lg text-[10px] uppercase font-black tracking-wider text-center cursor-pointer select-none transition-all duration-150"
                                    >
                                      🔄 Instant Rollback Optimization
                                    </button>
                                  )
                                )}
                                <button
                                  onClick={() => setSelectedProposalId(isExpanded ? null : sug.id)}
                                  className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-400 py-2.5 px-3 rounded-lg text-[10px] font-mono"
                                >
                                  {isExpanded ? 'Hide Details' : 'View Code Diff'}
                                </button>
                              </div>

                            </div>
                          );
                        })
                      ) : (
                        <div className="bg-slate-950 p-6 border border-slate-850 rounded-xl text-center text-slate-600 text-xs">
                          Engine models calculating metrics... Waiting to reach critical signal loads.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Immutable transform audit rail logs */}
                  <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl text-left space-y-2 font-mono">
                    <span className="text-[9px] tracking-wider font-bold text-slate-500 uppercase">Immutable Auto-Apply Audit Trail</span>
                    <div className="text-[10px] leading-relaxed max-h-24 overflow-y-auto space-y-1.5 text-slate-400">
                      {engine.applicator.getAuditTrail().length > 0 ? (
                        engine.applicator.getAuditTrail().map((aud, i) => (
                          <div key={i} className="hover:bg-slate-900 duration-100 p-0.5 rounded">
                            <span className="text-emerald-500 text-[9px] mr-1">[{aud.status}]</span>
                            <span className="text-slate-500 mr-1">({new Date(aud.timestamp).toLocaleTimeString()})</span>
                            <span className="text-slate-300 break-all">{aud.details}</span>
                          </div>
                        ))
                      ) : (
                        <span className="text-slate-600 block py-1 font-mono text-[9px]">No optimizations applied yet. Audit ledger empty.</span>
                      )}
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* ==============================================
             B. ORIGINAL LINGUISTIC BILINGUAL BRIDGE VIEWPORT
           ============================================== */}
        {viewMode === 'bridge' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch animate-fade-in" id="bridge_viewport">
            
            {/* LEFT COLUMN: Linguistic Inputs */}
            <div className="lg:col-span-5 flex flex-col space-y-6" id="nlp_stage_panel">
              
              <div className="bg-slate-900/40 border border-slate-850 rounded-2xl shadow-2xl p-5 flex flex-col space-y-4 relative" id="card_nlp_input">
                <div className="absolute top-0 right-0 p-3">
                  <span className="text-[9px] font-mono font-blue border border-slate-800 bg-slate-950 text-slate-500 px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Bridge Stage 1
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <Radio className="h-4 w-4 text-indigo-400 animate-pulse" />
                  <h2 className="text-xs uppercase tracking-widest font-black text-slate-300">NL Requirement compiler</h2>
                </div>

                <p className="text-xs leading-relaxed text-slate-400">
                  Write backend instructions in English or Arabic to generate execution-ready Aether schemas and AST code block statements:
                </p>

                <div className="flex-1 flex flex-col relative select-text">
                  <textarea
                    value={naturalInput}
                    onChange={(e) => setNaturalInput(e.target.value)}
                    placeholder="Write your pipeline logic requirement in English or Arabic (العربية)..."
                    className="w-full min-h-[140px] flex-1 bg-slate-950/80 border border-slate-850 focus:border-indigo-500/50 text-slate-150 p-4 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/20 leading-relaxed resize-none font-mono"
                    id="input_sentence_ta"
                  />
                  <div className="absolute right-3 bottom-3 flex items-center space-x-2">
                    <button
                      onClick={() => setNaturalInput('')}
                      className="p-1.5 hover:bg-slate-800 text-slate-500 hover:text-slate-300 rounded-lg transition"
                      title="Clear input"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                    <div className="text-[10px] text-slate-600 font-mono select-none px-2 py-1 bg-slate-900 border border-slate-800 rounded-lg">
                      {naturalInput.length} chars
                    </div>
                  </div>
                </div>

                {/* Test Suite Selector DROPDOWN */}
                <div className="flex flex-col space-y-1 text-left">
                  <label className="text-[9px] font-mono font-bold text-slate-500 uppercase">Pre-compiled benchmark suite</label>
                  <select
                    value={selectedCaseId}
                    onChange={(e) => handleSelectTestCase(e.target.value)}
                    className="w-full pl-3 pr-6 py-2.5 bg-slate-950 border border-slate-850 text-slate-300 hover:text-white rounded-xl text-xs focus:outline-none cursor-pointer transition-all"
                  >
                    <option value="" disabled>Choose standard microservice test cases</option>
                    <optgroup label="1. Registration Loops" className="bg-slate-950 text-slate-300">
                      {testCases.filter(t => t.category === 'registration').map(tc => (
                        <option key={tc.id} value={tc.id}>[{tc.lang.toUpperCase()}] {tc.text.substring(0, 48)}...</option>
                      ))}
                    </optgroup>
                    <optgroup label="2. Cryptographics & Logins" className="bg-slate-950 text-slate-300">
                      {testCases.filter(t => t.category === 'auth').map(tc => (
                        <option key={tc.id} value={tc.id}>[{tc.lang.toUpperCase()}] {tc.text.substring(0, 48)}...</option>
                      ))}
                    </optgroup>
                    <optgroup label="3. Ledger Checkout" className="bg-slate-950 text-slate-300">
                      {testCases.filter(t => t.category === 'billing').map(tc => (
                        <option key={tc.id} value={tc.id}>[{tc.lang.toUpperCase()}] {tc.text.substring(0, 48)}...</option>
                      ))}
                    </optgroup>
                    <optgroup label="4. System Telemetry" className="bg-slate-950 text-slate-300">
                      {testCases.filter(t => t.category === 'telemetry').map(tc => (
                        <option key={tc.id} value={tc.id}>[{tc.lang.toUpperCase()}] {tc.text.substring(0, 48)}...</option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                {/* Compile Intent */}
                <button
                  onClick={() => handleCompile()}
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-mono font-black p-4 rounded-xl text-xs uppercase flex items-center justify-center space-x-2"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>Translate NLP Requirements To AST</span>
                </button>
              </div>

              {/* LINGUISTIC STAGE PREVIEW */}
              {translationResult && (
                <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-5 space-y-4 text-left">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-emerald-400" />
                      <h3 className="text-xs uppercase tracking-widest font-black text-slate-300">Linguistic Analysis</h3>
                    </div>
                    <span className={`text-[10px] uppercase font-mono font-black px-2 py-0.5 rounded border ${
                      translationResult.language === 'ar' ? 'bg-indigo-600/10 text-indigo-400 border-indigo-500/20' : 'bg-sky-600/10 text-sky-400 border-sky-500/20'
                    }`}>
                      {translationResult.language === 'ar' ? 'ar: العربية' : 'en: English'}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">Translation Confidence Indicator:</span>
                      <strong className={`font-mono ${translationResult.confidence >= 80 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {translationResult.confidence}%
                      </strong>
                    </div>
                    <div className="w-full bg-slate-955 rounded-full h-2 overflow-hidden border border-slate-900">
                      <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${translationResult.confidence}%` }} />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                    <div className="bg-slate-950 border border-slate-850 p-2.5 rounded-xl">
                      <span className="text-[9px] text-slate-500 uppercase block font-bold">Identified Trigger</span>
                      <strong className="text-white mt-1 block truncate">{translationResult.intent.trigger}</strong>
                    </div>
                    <div className="bg-slate-950 border border-slate-850 p-2.5 rounded-xl">
                      <span className="text-[9px] text-slate-500 block uppercase font-bold">Extracted keys</span>
                      <strong className="text-sky-400 mt-1 block truncate">
                        {translationResult.intent.entities.join(', ') || 'none'}
                      </strong>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* RIGHT COLUMN: Code views */}
            <div className="lg:col-span-7 flex flex-col space-y-6" id="dryrun_pipeline_panel">
              
              <div className="bg-slate-950 p-1 rounded-xl border border-slate-850 flex items-center space-x-1">
                {(['flow', 'source', 'simulator'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setSelectedTab(tab)}
                    className={`flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-lg text-xs font-mono font-bold transition uppercase ${
                      selectedTab === tab 
                        ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/10' 
                        : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                    }`}
                  >
                    {tab === 'flow' && <Layers className="h-3.5 w-3.5" />}
                    {tab === 'source' && <Code2 className="h-3.5 w-3.5" />}
                    {tab === 'simulator' && <Terminal className="h-3.5 w-3.5" />}
                    <span>{tab === 'flow' ? 'AST blocks' : tab === 'source' ? 'Dsl script' : 'Dry-run sandbox'}</span>
                  </button>
                ))}
              </div>

              <div className="bg-slate-900/30 border border-slate-850 rounded-2xl p-5 min-h-[460px] flex flex-col justify-between" id="active_panel_display">
                
                {translationResult ? (
                  <div className="flex-1 flex flex-col justify-between h-full space-y-4">
                    
                    {/* tab 1. FLOW CHART DISPLAY */}
                    {selectedTab === 'flow' && (
                      <div className="flex-1 flex flex-col justify-between" id="visual_nodes_graph">
                        <div className="flex flex-col items-center select-none bg-slate-950 p-6 rounded-2xl border border-slate-850 space-y-4">
                          
                          {/* Entry point */}
                          <div className="flex flex-col items-center">
                            <div className="bg-slate-900 border border-slate-800 text-slate-400 px-4 py-2 rounded-xl text-[10px] font-mono flex items-center space-x-2">
                              <Radio className="h-3 text-indigo-400 animate-pulse" />
                              <span>Gateway Trigger on [{translationResult.intent.trigger}]</span>
                            </div>
                            <div className="w-0.5 h-6 bg-indigo-500" />
                          </div>

                          {/* Dynamic statements */}
                          <div className="space-y-4 w-full max-w-sm text-left">
                            {translationResult.ast.map((node, i) => {
                              const isSelected = selectedNodeIndex === i;
                              return (
                                <div key={i} className="flex flex-col items-center w-full">
                                  <div 
                                    onClick={() => setSelectedNodeIndex(isSelected ? null : i)}
                                    className={`w-full bg-slate-900 border p-3 rounded-xl cursor-transition flex items-start space-x-3 hover:border-indigo-500 duration-150 cursor-pointer ${
                                      isSelected ? 'border-indigo-600 shadow-md' : 'border-slate-800'
                                    }`}
                                  >
                                    <div className="bg-slate-950 p-2 rounded-lg text-emerald-400 font-mono text-xs font-black">
                                      {node.type === 'LetStatement' ? 'validate' : node.type === 'EmitStatement' ? 'emit' : 'return'}
                                    </div>
                                    <div>
                                      <h5 className="text-xs font-black text-slate-200 uppercase font-mono">{node.type}</h5>
                                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">{node.type === 'EmitStatement' ? node.signal : 'pipeline returns'}</p>
                                    </div>
                                  </div>

                                  {isSelected && (
                                    <pre className="w-full mt-2 bg-slate-950 p-3 border border-indigo-600/30 rounded-lg text-[10px] font-mono text-indigo-400 overflow-x-auto select-text">
                                      <code>{JSON.stringify(node, null, 2)}</code>
                                    </pre>
                                  )}

                                  {i < translationResult.ast.length - 1 && (
                                    <div className="w-0.5 h-4 bg-slate-800" />
                                  )}
                                </div>
                              );
                            })}
                          </div>

                        </div>
                      </div>
                    )}

                    {/* tab 2. CODE EDITOR VIEW */}
                    {selectedTab === 'source' && (
                      <div className="flex flex-col flex-1 text-left space-y-4">
                        <div className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-slate-850">
                          <span className="text-[11px] font-mono text-slate-400">Standard Aether system code:</span>
                          <button
                            onClick={handleCopyCode}
                            className="text-[11px] font-mono text-indigo-400 hover:underline flex items-center space-x-1"
                          >
                            {copiedCode ? <Check className="h-3 text-emerald-400" /> : <Copy className="h-3 text-indigo-400" />}
                            <span>{copiedCode ? 'Copied' : 'Copy DSL'}</span>
                          </button>
                        </div>
                        <pre className="bg-slate-950 rounded-xl max-h-80 border border-slate-850 p-4 font-mono text-xs text-indigo-300 overflow-x-auto overflow-y-auto max-h-[300px] select-text">
                          <code>{translationResult.code}</code>
                        </pre>
                      </div>
                    )}

                    {/* tab 3. DRY RUN SANDBOX EXECS */}
                    {selectedTab === 'simulator' && (
                      <div className="flex flex-col flex-1 space-y-4 text-left">
                        
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                          <div className="md:col-span-5 flex flex-col space-y-2 select-text">
                            <span className="text-[9px] font-mono uppercase text-slate-500 font-bold">Configure Json Payload</span>
                            <textarea
                              value={mockRequestPayload}
                              onChange={(e) => setMockRequestPayload(e.target.value)}
                              className="bg-slate-950 p-3 flex-1 min-h-[140px] rounded-xl border border-slate-850 font-mono text-xs focus:outline-none focus:border-indigo-500 text-indigo-300 resize-none leading-relaxed"
                            />
                            <button
                              onClick={runFullSimulation}
                              disabled={simulationActive}
                              className="w-full bg-indigo-650 hover:bg-indigo-500 disabled:bg-indigo-950 py-3 text-xs uppercase font-mono font-black text-white hover:text-white rounded-xl tracking-wider transition"
                            >
                              {simulationActive ? 'Dry-Run ongoing...' : 'Run Simulation run'}
                            </button>
                          </div>

                          <div className="md:col-span-7 flex flex-col space-y-2">
                            <span className="text-[9px] font-mono uppercase text-slate-500 font-bold">Simulator Logs stream</span>
                            <div className="bg-slate-950 p-3 flex-1 min-h-[160px] rounded-xl border border-slate-850 font-mono text-[10px] space-y-1.5 overflow-y-auto max-h-48 h-full">
                              {simulationLogs.length > 0 ? (
                                simulationLogs.map((log, idx) => (
                                  <div key={idx} className="p-0.5 rounded leading-relaxed font-mono">
                                    <span className="text-slate-600 mr-1 select-none">[{log.timestamp}]</span>
                                    <span className={log.type === 'error' ? 'text-rose-400 font-black' : log.type === 'success' ? 'text-emerald-400' : 'text-slate-350'}>
                                      {log.message}
                                    </span>
                                  </div>
                                ))
                              ) : (
                                <p className="text-slate-700 py-10 text-center select-none font-mono text-[10px]">Launch dry-run to stream pipeline compilation events.</p>
                              )}
                            </div>
                            
                            {/* Render state values to read and satisfy TS compiler */}
                            {simResultsStore.lastResponse && (
                              <div className="mt-2.5 bg-slate-950 p-3 border border-emerald-500/15 rounded-xl leading-relaxed text-[10px] font-mono select-text text-left">
                                <span className="text-emerald-400 font-bold block mb-1">✓ DRY-RUN RETURN PAYLOAD (HTTP {simResultsStore.lastResponse.statusCode})</span>
                                <pre className="text-slate-350 bg-slate-900 border border-slate-850 p-2 rounded-lg text-[9px] overflow-x-auto">
                                  {JSON.stringify(simResultsStore.lastResponse.payload, null, 2)}
                                </pre>
                              </div>
                            )}
                          </div>
                        </div>

                      </div>
                    )}

                  </div>
                ) : (
                  <div className="text-slate-600 py-12 text-center text-xs">NL compile queue empty.</div>
                )}

              </div>

            </div>

          </div>
        )}

      </div>

      {/* 3. FOOTER */}
      <footer className="border-t border-indigo-500/10 bg-slate-950/45 py-3 tracking-widest text-[10px] font-mono uppercase select-none font-bold">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between px-4 gap-2 text-slate-500">
          <div>© 2026 AETHER SYSTEMS CORE LABS. UNBOUND INTELLIGENCE.</div>
          <div className="flex space-x-4">
            <span className="hover:text-slate-300 cursor-any">Telemetry Engine Enabled</span>
            <span>•</span>
            <span className="hover:text-slate-300 cursor-any">Self-Healing JIT Active</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
