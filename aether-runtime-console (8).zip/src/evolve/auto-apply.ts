/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OptimizationSuggestion } from './optimizer';

export interface AuditRecord {
  id: string;
  timestamp: number;
  suggestionId: string;
  type: string;
  action: 'APPLY' | 'ROLLBACK';
  status: 'SUCCESS' | 'FAILED';
  details: string;
}

export class SafeOptimizerApplicator {
  private auditLogs: AuditRecord[] = [];
  private appliedLogs: Map<string, OptimizationSuggestion> = new Map();

  constructor() {}

  /**
   * Safe auto-apply of behavioral-neutral pure optimizations
   */
  public apply(suggestion: OptimizationSuggestion): boolean {
    if (!suggestion.autoApplicable) {
      this.logAudit(suggestion.id, suggestion.type, 'APPLY', 'FAILED', 'Block: Optimization is structural and requires human key authorization.');
      return false;
    }

    if (suggestion.applied) {
      return true; // Already applied
    }

    // Transform logic safely (mock state change)
    suggestion.applied = true;
    this.appliedLogs.set(suggestion.id, { ...suggestion });

    this.logAudit(
      suggestion.id,
      suggestion.type,
      'APPLY',
      'SUCCESS',
      `Auto-applied structural transformation [${suggestion.title}] successfully onto stream ${suggestion.sourceStream}. System integrity satisfies all invariants.`
    );
    return true;
  }

  /**
   * Instantly roll back an optimization to restore the original AST status
   */
  public rollback(suggestion: OptimizationSuggestion): boolean {
    if (!suggestion.applied) {
      return false;
    }

    suggestion.applied = false;
    this.appliedLogs.delete(suggestion.id);

    this.logAudit(
      suggestion.id,
      suggestion.type,
      'ROLLBACK',
      'SUCCESS',
      `Rolled back transformation [${suggestion.title}] safely. Original system pipeline state re-established.`
    );
    return true;
  }

  /**
   * Registers an audit transaction log
   */
  private logAudit(suggestionId: string, type: string, action: 'APPLY' | 'ROLLBACK', status: 'SUCCESS' | 'FAILED', details: string): void {
    const record: AuditRecord = {
      id: `aud_${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: Date.now(),
      suggestionId,
      type,
      action,
      status,
      details
    };
    this.auditLogs.unshift(record); // newest logs first
  }

  /**
   * Returns complete immutable auditing records
   */
  public getAuditTrail(): AuditRecord[] {
    return this.auditLogs;
  }

  /**
   * Clears audit records
   */
  public clear(): void {
    this.auditLogs = [];
    this.appliedLogs.clear();
  }
}
