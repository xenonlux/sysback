/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HotPathInfo } from '../analyze/hot-path';
import { PerformanceAnomaly } from '../analyze/anomaly';
import { DiscoveredPattern } from '../analyze/pattern-miner';

export interface OptimizationSuggestion {
  id: string;
  type: 'JIT_COMPILATION' | 'CACHE_VALIDATION' | 'ASYNC_PARALLEL' | 'ARCHIVE_STREAM';
  title: string;
  sourceStream: string;
  reason: string;
  estimatedReduction: string;
  confidence: number;
  autoApplicable: boolean;
  codeDiff?: { before: string; after: string };
  applied: boolean;
  rollbackAvailable: boolean;
}

export class ServiceOptimizer {
  constructor() {}

  /**
   * Generates discrete, high-impact optimizations based on operational signals
   */
  public generateSuggestions(
    hotPaths: HotPathInfo[],
    anomalies: PerformanceAnomaly[],
    patterns: DiscoveredPattern[]
  ): OptimizationSuggestion[] {
    const suggestions: OptimizationSuggestion[] = [];

    // 1. Hot Paths -> JIT Compilation Hints
    hotPaths.filter(h => h.isHot && !h.jitOptimized).forEach((hp) => {
      suggestions.push({
        id: `opt_jit_${hp.stream}`,
        type: 'JIT_COMPILATION',
        title: `⚡ JIT Compiler Injection: ${hp.stream}`,
        sourceStream: hp.stream,
        reason: `Throughput is elevated (${hp.frequencyHz}hz, total events: ${hp.total_events}). Bundling AST statements into direct machine-instructions reduces runtime traversal latency.`,
        estimatedReduction: '85% to 92% latency reduction (p99 < 5ms)',
        confidence: 98,
        autoApplicable: true,
        codeDiff: {
          before: `// Standard Interpreted Traversal\nfor (const node of stream.ast) {\n  evaluate(node, scope);\n}`,
          after: `// JIT Compiled Node Module Machine Instructions Bound\nconst compiledHandler = Compiler.compile(stream.ast);\ncompiledHandler(scope);`
        },
        applied: false,
        rollbackAvailable: true
      });
    });

    // 2. Redundant validations -> Cache Validation results
    patterns.filter(p => p.patternType === 'redundant_validation').forEach((p) => {
      const field = p.id.split('_').pop() || 'id';
      suggestions.push({
        id: `opt_cache_${field}`,
        type: 'CACHE_VALIDATION',
        title: `💾 Schema Cache Binding: "${field}"`,
        sourceStream: 'users',
        reason: `Duplicate validations of structure type detected (${p.occurrences} instances). Injecting a memory caching table reduces CPU cycles.`,
        estimatedReduction: '45% computation overhead savings',
        confidence: 90,
        autoApplicable: true,
        codeDiff: {
          before: p.reusableDraft.split('\n')[0] + `\nvalidate(payload, { ${field}: Format }); // Repeated`,
          after: p.reusableDraft
        },
        applied: false,
        rollbackAvailable: true
      });
    });

    // 3. Slow anomalous nodes -> Async Parallelization suggestions
    anomalies.filter(a => a.metric === 'duration' && a.z_score > 3.0).forEach((anom) => {
      suggestions.push({
        id: `opt_async_${anom.id}`,
        type: 'ASYNC_PARALLEL',
        title: `🔀 Parallelize Handler Threads: ${anom.stream}`,
        sourceStream: anom.stream,
        reason: `Anomaly z-score threshold reached (${anom.z_score}). Thread Jitter is high because file IO and network emit stages execute on a single blocking connection.`,
        estimatedReduction: '30% overall execution speedup',
        confidence: 76,
        autoApplicable: false, // Humans must confirm multi-thread locks
        codeDiff: {
          before: `await database.save(user);\nawait websocket.broadcast(signal); // Sequential block`,
          after: `await Promise.all([\n  database.save(user),\n  websocket.broadcast(signal)\n]); // Multi-thread concurrency`
        },
        applied: false,
        rollbackAvailable: false
      });
    });

    // 4. Unused streams -> Suggested archiving
    patterns.filter(p => p.patternType === 'unreferenced_stream').forEach((p) => {
      const streamName = p.id.split('_').pop() || '';
      suggestions.push({
        id: `opt_archive_${streamName}`,
        type: 'ARCHIVE_STREAM',
        title: `🗄️ Archive Idle Channels: "${streamName}"`,
        sourceStream: streamName,
        reason: p.details,
        estimatedReduction: 'Reduces CPU idle footprint by 15%',
        confidence: 85,
        autoApplicable: true,
        codeDiff: {
          before: `StreamManager.register("${streamName}", { status: "ACTIVE" });`,
          after: `StreamManager.archive("${streamName}", { status: "DECOMMISSIONED" });`
        },
        applied: false,
        rollbackAvailable: true
      });
    });

    return suggestions;
  }
}
