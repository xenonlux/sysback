/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OptimizationSuggestion } from './optimizer';

export class HumanSuggester {
  constructor() {}

  /**
   * Generates a fully written human proposal explaining the performance benefits of an optimization
   */
  public generateProposal(suggestion: OptimizationSuggestion): string {
    const header = `🔹 PROPOSAL FOR STREAM [${suggestion.sourceStream.toUpperCase()}] — CONFIDENCE: ${suggestion.confidence}%\n`;
    const actionLine = `ACTION: ${suggestion.title}\n`;
    
    let description = '';
    switch (suggestion.type) {
      case 'JIT_COMPILATION':
        description = `Throughput spikes on stream channel detected. If you authorize JIT compilation under the hot-path JIT interface, the compiler will flatten internal AST structures directly into binary-compiled memory buffers. This will compress latency by roughly ~15x.`;
        break;
      case 'CACHE_VALIDATION':
        description = `Identified redundant structural JSON schema validations. Applying this optimization injects a high-performance LRU Cache middleware layer that intercepts repeated schema fields, checking hashes instead of deep-verifying tokens.`;
        break;
      case 'ASYNC_PARALLEL':
        description = `Parallelize blocking validation tasks. By turning serial pipeline callbacks into simultaneous multi-thread event loops, thread starvation is avoided and overall system latency satisfies global SLA parameters.`;
        break;
      case 'ARCHIVE_STREAM':
        description = `We detected that the stream "${suggestion.sourceStream}" is completely idle with zero packets logged. Suggesting safe automated decomissioning and archival procedures to prevent wasted heap allocation overhead.`;
        break;
    }

    const footer = `\nIMPACT: ${suggestion.estimatedReduction}\nAUTO-APPLY CAPABLE: ${suggestion.autoApplicable ? 'YES ✓' : 'NO (Manual Confirmation Required 🔑)'}`;

    return `${header}${actionLine}\n${description}${footer}`;
  }
}
