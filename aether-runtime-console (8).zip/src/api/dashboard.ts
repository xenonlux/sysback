/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from '../observe/collector';
import { HotPathInfo } from '../analyze/hot-path';
import { PerformanceAnomaly } from '../analyze/anomaly';
import { DiscoveredPattern } from '../analyze/pattern-miner';
import { OptimizationSuggestion } from '../evolve/optimizer';

export interface DashboardInsights {
  operationalStatus: string;
  uptimeSec: number;
  signalsCounter: number;
  samplingRate: number;
  averageLatencyMs: number;
  anomalyRate: number;
  appliedOptimizations: number;
  hotPaths: HotPathInfo[];
  anomalies: PerformanceAnomaly[];
  minedPatterns: DiscoveredPattern[];
  suggestions: OptimizationSuggestion[];
}

export class EvolutionDashboardAPI {
  private startTime: number = Date.now();

  constructor() {}

  /**
   * Mock endpoint that matches a REST GET `/api/evolution/insights`
   */
  public getInsightsEndpoint(
    allSignals: ExecutionSignal[],
    hotPaths: HotPathInfo[],
    anomalies: PerformanceAnomaly[],
    patterns: DiscoveredPattern[],
    suggestions: OptimizationSuggestion[],
    samplerRate: number
  ): DashboardInsights {
    const uptimeSec = Math.floor((Date.now() - this.startTime) / 1000);
    const signalsCounter = allSignals.length;

    // Calculate dynamic dashboard statistics
    const averageLatencyMs = signalsCounter > 0
      ? parseFloat((allSignals.reduce((s, x) => s + x.duration_ms, 0) / signalsCounter).toFixed(2))
      : 0;

    const anomalyRate = signalsCounter > 0
      ? parseFloat(((anomalies.length / signalsCounter) * 100).toFixed(2))
      : 0;

    const appliedOptimizations = suggestions.filter(s => s.applied).length;

    return {
      operationalStatus: 'HEALTHY - COGNITIVE EVOLUTION ENGINE ACTIVE',
      uptimeSec,
      signalsCounter,
      samplingRate: parseFloat((samplerRate * 100).toFixed(2)),
      averageLatencyMs,
      anomalyRate,
      appliedOptimizations,
      hotPaths,
      anomalies,
      minedPatterns: patterns,
      suggestions
    };
  }
}
