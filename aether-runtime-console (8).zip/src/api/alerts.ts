/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PerformanceAnomaly } from '../analyze/anomaly';

export interface AlertNotification {
  id: string;
  severity: 'CRITICAL' | 'WARNING' | 'NOTICE';
  timestamp: number;
  title: string;
  message: string;
  resolved: boolean;
}

export class EvolutionAlertSystem {
  private activeAlerts: AlertNotification[] = [];

  constructor() {}

  /**
   * Translates anomalies and critical conditions into user-facing alerts notifications
   */
  public evaluateAlerts(anomalies: PerformanceAnomaly[]): AlertNotification[] {
    const newAlerts: AlertNotification[] = [];

    anomalies.forEach((anom) => {
      // Avoid duplicate alert matching
      const exists = this.activeAlerts.some(a => a.message === anom.description);
      if (exists) return;

      const isCritical = anom.metric === 'error_rate' || anom.z_score > 4.0;
      const severity = isCritical ? 'CRITICAL' : 'WARNING';
      
      const alert: AlertNotification = {
        id: `alt_${Math.floor(1000 + Math.random() * 9000)}`,
        severity,
        timestamp: anom.timestamp,
        title: isCritical ? '🔥 Core SLA Violation Alert' : '⚠️ Late Jitter Trend warning',
        message: anom.description,
        resolved: false
      };

      this.activeAlerts.unshift(alert); // Newest on top
      newAlerts.push(alert);
    });

    return this.activeAlerts;
  }

  /**
   * Marks warning notification as resolved
   */
  public resolveAlert(alertId: string): void {
    const alert = this.activeAlerts.find(a => a.id === alertId);
    if (alert) {
      alert.resolved = true;
    }
  }

  /**
   * Returns current notification arrays
   */
  public getAlerts(): AlertNotification[] {
    return this.activeAlerts;
  }

  /**
   * Resets active alerts list of the notification queue
   */
  public clear(): void {
    this.activeAlerts = [];
  }
}
