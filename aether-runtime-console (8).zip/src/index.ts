/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SignalCollector, type ExecutionSignal } from './observe/collector';
import { RingBuffer } from './observe/buffer';
import { SignalSampler } from './observe/sampler';

import { HotPathAnalyzer } from './analyze/hot-path';
import { AnomalyDetector } from './analyze/anomaly';
import { PatternMiner, type DiscoveredPattern } from './analyze/pattern-miner';
import { UsageGraphBuilder, type StreamDependencyGraph } from './analyze/usage-graph';

import { ServiceOptimizer, type OptimizationSuggestion } from './evolve/optimizer';
import { JITCompilationInterface } from './evolve/jit-hints';
import { HumanSuggester } from './evolve/suggester';
import { SafeOptimizerApplicator } from './evolve/auto-apply';

import { SignalPersistenceStore } from './storage/signal-store';
import { ModelPersistenceStore } from './storage/model-store';

import { EvolutionDashboardAPI, DashboardInsights } from './api/dashboard';
import { EvolutionAlertSystem, AlertNotification } from './api/alerts';

export class EvolutionEngine {
  // Layer 1 — Observe
  public collector = new SignalCollector();
  public buffer = new RingBuffer(1000);
  public sampler = new SignalSampler();

  // Layer 2 — Analyze
  public hotPathAnalyzer = new HotPathAnalyzer(15); // throughput Hz limit
  public anomalyDetector = new AnomalyDetector(2.5); // zscore deviation limit
  public patternMiner = new PatternMiner();
  public graphBuilder = new UsageGraphBuilder();

  // Layer 3 — Evolve
  public optimizer = new ServiceOptimizer();
  public jitCompiler = new JITCompilationInterface();
  public suggester = new HumanSuggester();
  public applicator = new SafeOptimizerApplicator();

  // Storage
  public signalStore = new SignalPersistenceStore();
  public modelStore = new ModelPersistenceStore();

  // API Layers
  public dashboardApi = new EvolutionDashboardAPI();
  public alertSystem = new EvolutionAlertSystem();

  // State Management
  private activeSuggestions: OptimizationSuggestion[] = [];
  private engineLogs: string[] = [];

  constructor() {
    this.addLog('⚙️ Starting Autonomous AETHER Self-Evolution Engine...');
    
    // Wire Telemetry Collector -> Buffer & Sampler
    this.collector.subscribe((signal) => {
      // 1. Hook sampling checks
      if (this.sampler.shouldSample(signal)) {
        // 2. Load into ring memory buffers
        this.buffer.push(signal);
        
        // 3. Keep signals locally saved
        this.saveSignalsLocally();
      }
    });

    // Load any historical session markers on startup
    this.loadPersistenceStates();
    this.collector.hookIntoRuntime();
    this.addLog('✓ Initialization Completed. WebSockets, RingBuffer, and JIT Compiler nodes online.');
  }

  /**
   * Pushes raw telemetry data into the collection queues
   */
  public logExecution(
    stream: string,
    handler: string,
    durationMs: number,
    memoryBytes: number,
    eventCount: number,
    errorRate: number,
    astHash: string,
    redundantValidations?: string[]
  ): ExecutionSignal {
    const signal = this.collector.emit({
      stream,
      handler,
      duration_ms: durationMs,
      memory_bytes: memoryBytes,
      event_count: eventCount,
      error_rate: errorRate,
      pattern: astHash,
      redundant_validations: redundantValidations
    });

    return signal;
  }

  /**
   * Executes complete evolution iteration loop analysis and model storage updating
   */
  public processEvolutionCycle(): DashboardInsights {
    const signals = this.buffer.getSignals();
    
    // Evaluate Analytical Models
    const hotPaths = this.hotPathAnalyzer.analyze(signals);
    const anomalies = this.anomalyDetector.detect(signals, signals.slice(-5));
    const patterns = this.patternMiner.mine(signals);
    
    // Evaluate triggers & alerts
    this.alertSystem.evaluateAlerts(anomalies);

    // Apply suggestions updates
    const currentSuggestionsList = this.optimizer.generateSuggestions(hotPaths, anomalies, patterns);

    // Merge suggestions states gently with active applied/non-applied states
    this.activeSuggestions = currentSuggestionsList.map((newSug) => {
      const existing = this.activeSuggestions.find(as => as.id === newSug.id);
      if (existing) {
        return {
          ...newSug,
          applied: existing.applied,
          rollbackAvailable: existing.rollbackAvailable
        };
      }
      return newSug;
    });

    // Save model states to disk
    this.persistEvolutionModel(patterns);

    return this.getInsights();
  }

  /**
   * Safe automatic execution of optimization records
   */
  public compileAndApplyOptimization(suggestionId: string): boolean {
    const suggestion = this.activeSuggestions.find(s => s.id === suggestionId);
    if (!suggestion) return false;

    const success = this.applicator.apply(suggestion);
    if (success) {
      this.addLog(`🚀 AUTO-APPLY SUCCESS: Implemented ${suggestion.title}. Pipeline refactoring applied.`);
      
      // If it's a JIT compilation choice, notify our JIT Interface!
      if (suggestion.type === 'JIT_COMPILATION') {
        this.jitCompiler.compile(suggestion.sourceStream);
        this.hotPathAnalyzer.registerJIT(suggestion.sourceStream);
      }
    } else {
      this.addLog(`❌ AUTO-APPLY FAULT: Failed transformation application on [${suggestionId}]. Requires explicit user authorization keys.`);
    }

    this.processEvolutionCycle(); // trigger refresh
    return success;
  }

  /**
   * Full rollbacks of applied improvements
   */
  public rollbackOptimization(suggestionId: string): boolean {
    const suggestion = this.activeSuggestions.find(s => s.id === suggestionId);
    if (!suggestion) return false;

    const success = this.applicator.rollback(suggestion);
    if (success) {
      this.addLog(`🔄 ROLLBACK REVERTED: Retracted optimization [${suggestion.title}]. VM executing in safe interpreted fallback mode.`);
      
      // Decompile matching JIT keys if relevant
      if (suggestion.type === 'JIT_COMPILATION') {
        this.jitCompiler.decompile(suggestion.sourceStream);
        this.hotPathAnalyzer.clearJIT();
      }
    }
    this.processEvolutionCycle(); // trigger refresh
    return success;
  }

  /**
   * Retrieves full details graph structure
   */
  public getUsageGraph(): StreamDependencyGraph {
    return this.graphBuilder.build(this.buffer.getSignals());
  }

  /**
   * Pulls public dashboard metrics summaries matching REST specifications
   */
  public getInsights(): DashboardInsights {
    const signals = this.buffer.getSignals();
    const hotPaths = this.hotPathAnalyzer.analyze(signals);
    const anomalies = this.anomalyDetector.detect(signals, []);
    const patterns = this.patternMiner.mine(signals);

    return this.dashboardApi.getInsightsEndpoint(
      signals,
      hotPaths,
      anomalies,
      patterns,
      this.activeSuggestions,
      this.sampler.getSampleRate()
    );
  }

  /**
   * Fetches active notifications warnings list and alarms trigger sets
   */
  public getAlertNotifications(): AlertNotification[] {
    return this.alertSystem.getAlerts();
  }

  /**
   * Clears engine states completely (e.g. debugging reset)
   */
  public purgeAllStates(): void {
    this.buffer.clear();
    this.activeSuggestions = [];
    this.alertSystem.clear();
    this.jitCompiler.getActiveModels().forEach(m => this.jitCompiler.decompile(m.stream));
    this.hotPathAnalyzer.clearJIT();
    this.applicator.clear();
    this.signalStore.clear();
    this.modelStore.clear();
    this.addLog('🗑️ Purged all Evolution stores, memory rings, alarms, and JIT configurations.');
  }

  /**
   * Logs transaction states to visual log consoles
   */
  public addLog(msg: string): void {
    const time = new Date().toLocaleTimeString();
    this.engineLogs.unshift(`[${time}] ${msg}`);
  }

  public getLogs(): string[] {
    return this.engineLogs;
  }

  // --- PRIVATE PERSISTENCE UTILITIES ---
  private saveSignalsLocally(): void {
    const signals = this.buffer.getSignals();
    this.signalStore.saveSignals(signals);
  }

  private persistEvolutionModel(patterns: DiscoveredPattern[]): void {
    const appliedCount = this.activeSuggestions.filter(s => s.applied).length;
    this.modelStore.saveModel({
      epoch: Math.floor(Date.now() / 60000), // minute epoch
      lastUpdated: Date.now(),
      patterns,
      appliedOptimizationsCount: appliedCount,
      avgConfidence: 91.5
    });
  }

  private loadPersistenceStates(): void {
    const signals = this.signalStore.loadSignals();
    if (signals && signals.length > 0) {
      signals.forEach(s => this.buffer.push(s));
      this.addLog(`✓ Session Restored: Hydrated ${signals.length} execution signals from storage cache.`);
    }

    const model = this.modelStore.loadModel();
    if (model) {
      this.addLog(`✓ Brain Loaded: Recovered model states from Epoch ${model.epoch}. ${model.patterns.length} optimized features synchronized.`);
    }
  }
}
export type { ExecutionSignal, OptimizationSuggestion, DashboardInsights, AlertNotification, StreamDependencyGraph };
export default EvolutionEngine;
