/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from './collector';

export class RingBuffer {
  private buffer: Array<ExecutionSignal | null>;
  private capacity: number;
  private writePointer: number = 0;
  private totalEmittedCount: number = 0;

  constructor(capacity: number = 1000) {
    this.capacity = capacity;
    this.buffer = new Array(capacity).fill(null);
  }

  /**
   * Pushes a new execution telemetry signal into the ring buffer
   */
  public push(signal: ExecutionSignal): void {
    this.buffer[this.writePointer] = signal;
    this.writePointer = (this.writePointer + 1) % this.capacity;
    this.totalEmittedCount++;
  }

  /**
   * Retrieves all actual signals stored inside the buffer, sorted from oldest to newest
   */
  public getSignals(): ExecutionSignal[] {
    const result: ExecutionSignal[] = [];
    
    // Read sequentially starting from oldest elements
    for (let i = 0; i < this.capacity; i++) {
      const idx = (this.writePointer + i) % this.capacity;
      const sig = this.buffer[idx];
      if (sig !== null) {
        result.push(sig);
      }
    }
    return result;
  }

  /**
   * Clears the current buffer states
   */
  public clear(): void {
    this.buffer.fill(null);
    this.writePointer = 0;
    this.totalEmittedCount = 0;
  }

  /**
   * Returns current fill size
   */
  public size(): number {
    return this.buffer.filter(s => s !== null).length;
  }

  /**
   * Returns maximum configured capacity metrics
   */
  public getCapacity(): number {
    return this.capacity;
  }

  /**
   * Gets total count of historical telemetry processed
   */
  public getTotalCount(): number {
    return this.totalEmittedCount;
  }
}
