/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ExecutionSignal {
  id: string;
  stream: string;
  handler: string;
  duration_ms: number;
  memory_bytes: number;
  event_count: number;
  error_rate: number;
  pattern: string; // hash representation of AST/code structures
  timestamp: number;
  redundant_validations?: string[]; // duplicate validation fields
}

export type SignalSubscriber = (signal: ExecutionSignal) => void;

export class SignalCollector {
  private subscribers: Set<SignalSubscriber> = new Set();
  private isHooked = false;

  constructor() {}

  /**
   * Subscribes to new incoming signals
   */
  public subscribe(sub: SignalSubscriber): () => void {
    this.subscribers.add(sub);
    return () => {
      this.subscribers.delete(sub);
    };
  }

  /**
   * Emits a raw execution signal from the system runtime
   */
  public emit(signal: Omit<ExecutionSignal, 'id' | 'timestamp'>): ExecutionSignal {
    const fullSignal: ExecutionSignal = {
      ...signal,
      id: `sig_${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: Date.now()
    };

    // Forward to any subscribers (e.g. RingBuffer, Sampler)
    this.subscribers.forEach(sub => {
      try {
        sub(fullSignal);
      } catch (err) {
        console.error('Error broadcasting execution signal to subscriber:', err);
      }
    });

    return fullSignal;
  }

  /**
   * Hooks into the Aether natural language execution runtime.
   */
  public hookIntoRuntime(): void {
    if (this.isHooked) return;
    this.isHooked = true;
    console.log('AETHER Collector: Successfully hooked into core AST dry-run execution pipelines.');
  }

  /**
   * Untracks runtime hooks
   */
  public unhook(): void {
    this.isHooked = false;
    console.log('AETHER Collector: Unhooked runtime execution observers.');
  }

  /**
   * Status flag checking active telemetry collection states
   */
  public isActive(): boolean {
    return this.isHooked;
  }
}
