/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from './collector';

export class SignalSampler {
  private sampleRate: number = 1.0; // 1.0 means 100% telemetry captured
  private frequencyThreshold: number = 200; // if requests/sec gets above this, downsample
  private streamCounters: Map<string, { count: number; lastReset: number }> = new Map();

  constructor(targetSampleRate: number = 1.0) {
    this.sampleRate = targetSampleRate;
  }

  /**
   * Sets custom constant sampling rate
   */
  public setConstantRate(rate: number): void {
    this.sampleRate = Math.max(0.01, Math.min(1.0, rate));
  }

  /**
   * Decides if an incoming signal should be statistically sampled
   */
  public shouldSample(signal: ExecutionSignal): boolean {
    const stream = signal.stream;
    const now = Date.now();
    
    // Dynamic sampling rates based on frequency
    if (!this.streamCounters.has(stream)) {
      this.streamCounters.set(stream, { count: 0, lastReset: now });
    }
    
    const stats = this.streamCounters.get(stream)!;
    stats.count++;

    // Calculate moving interval rate (e.g. per second)
    const timeDelta = now - stats.lastReset;
    if (timeDelta > 1000) {
      const frequency = (stats.count / timeDelta) * 1000;
      
      if (frequency > this.frequencyThreshold) {
        // Automatically drop sampling rates to avoid telemetry bloat
        this.sampleRate = 0.1; // capture only 10%
      } else if (frequency > this.frequencyThreshold / 2) {
        this.sampleRate = 0.5; // capture 50%
      } else {
        this.sampleRate = 1.0; // 100%
      }
      
      // Reset window counter
      stats.count = 0;
      stats.lastReset = now;
    }

    // Standard probability-based check
    return Math.random() <= this.sampleRate;
  }

  /**
   * Returns current evaluation sampling rate
   */
  public getSampleRate(): number {
    return this.sampleRate;
  }
}
