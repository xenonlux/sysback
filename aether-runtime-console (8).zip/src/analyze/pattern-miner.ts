/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from '../observe/collector';

export interface DiscoveredPattern {
  id: string;
  patternType: 'redundant_validation' | 'frequent_abstractions' | 'unreferenced_stream';
  occurrences: number;
  impactScore: number; // 0-100 estimate of optimization benefits
  details: string;
  reusableDraft: string;
}

export class PatternMiner {
  constructor() {}

  /**
   * Scans signals for recurring code schemas & validation redundancies
   */
  public mine(signals: ExecutionSignal[]): DiscoveredPattern[] {
    const patterns: DiscoveredPattern[] = [];

    // 1. Redundant validations mining
    const validationCounts: Record<string, number> = {};
    signals.forEach(sig => {
      if (sig.redundant_validations) {
        sig.redundant_validations.forEach(field => {
          validationCounts[field] = (validationCounts[field] || 0) + 1;
        });
      }
    });

    Object.entries(validationCounts).forEach(([field, count]) => {
      if (count > 2) {
        patterns.push({
          id: `pat_val_${field}`,
          patternType: 'redundant_validation',
          occurrences: count,
          impactScore: Math.min(95, count * 15),
          details: `Field "${field}" is evaluated multiple times across the stream pipeline in back-to-back LetStatements without intermediate updates.`,
          reusableDraft: `// Shared validation caching middleware\nlet cached_${field} = cache.get(payload.${field});\nif (!cached_${field}) {\n  validate(payload, { ${field}: Format });\n  cache.set(payload.${field}, true);\n}`
        });
      }
    });

    // 2. Unreferenced streams (0 events in a specific time or buffer)
    const activeStreams = new Set(signals.map(s => s.stream));
    const allExpectedStreams = ['users', 'billing', 'telemetry', 'heartbeat', 'deprecated_stream_v1'];
    
    allExpectedStreams.forEach(expected => {
      if (!activeStreams.has(expected)) {
        patterns.push({
          id: `pat_unused_${expected}`,
          patternType: 'unreferenced_stream',
          occurrences: 0,
          impactScore: 30,
          details: `Stream channels named "${expected}" have processed 0 messages for consecutive epochs. Core memory allocations are unutilized.`,
          reusableDraft: `// Suggest clean-up\narchive stream: "${expected}"`
        });
      }
    });

    // 3. Frequent abstractions (reusable structures)
    const actionSequences: Record<string, number> = {};
    signals.forEach(sig => {
      const key = sig.pattern; // typical AST signature
      if (key) {
        actionSequences[key] = (actionSequences[key] || 0) + 1;
      }
    });

    Object.entries(actionSequences).forEach(([astHash, counts]) => {
      if (counts > 3) {
        patterns.push({
          id: `pat_abs_${astHash.substring(0, 8)}`,
          patternType: 'frequent_abstractions',
          occurrences: counts,
          impactScore: 80,
          details: `Identified identical sequential actions under signature pattern [${astHash.substring(0, 12)}]. Can compose into reusable middleware blocks.`,
          reusableDraft: `define macro compiled_abstr_${astHash.substring(0, 4)}() {\n  // Collapses let validation, emit, and yield instructions\n}`
        });
      }
    });

    return patterns;
  }
}
