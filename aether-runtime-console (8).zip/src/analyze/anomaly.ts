/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from '../observe/collector';

export interface PerformanceAnomaly {
  id: string;
  stream: string;
  handler: string;
  metric: 'duration' | 'memory' | 'error_rate';
  actual_value: number;
  expected_mean: number;
  z_score: number;
  timestamp: number;
  description: string;
}

export class AnomalyDetector {
  private zThreshold: number = 2.5; // Z-score above 2.5 defines anomalous conditions

  constructor(zThreshold: number = 2.5) {
    this.zThreshold = zThreshold;
  }

  /**
   * Evaluates any anomalous metrics on newly arrived signals against historical buffers
   */
  public detect(allSignals: ExecutionSignal[], currentSignals: ExecutionSignal[]): PerformanceAnomaly[] {
    if (allSignals.length < 5) return []; // Require minimum base to construct stable averages

    // Compute standard population averages
    const durations = allSignals.map(s => s.duration_ms);
    const meanDuration = durations.reduce((s, x) => s + x, 0) / durations.length;
    
    // Variance & Standard Deviation
    const sqDiffs = durations.map(x => Math.pow(x - meanDuration, 2));
    const avgSqDiff = sqDiffs.reduce((s, x) => s + x, 0) / sqDiffs.length;
    const stdDevDuration = Math.sqrt(avgSqDiff) || 1; // avoid divide by zero

    const anomalies: PerformanceAnomaly[] = [];

    currentSignals.forEach(sig => {
      // Check latency anomaly
      const dZ = (sig.duration_ms - meanDuration) / stdDevDuration;
      
      if (dZ > this.zThreshold && sig.duration_ms > 80) { // minimum threshold filter to ignore minor latency fluctuations
        anomalies.push({
          id: `anm_${Math.floor(1000 + Math.random() * 9000)}`,
          stream: sig.stream,
          handler: sig.handler,
          metric: 'duration',
          actual_value: sig.duration_ms,
          expected_mean: parseFloat(meanDuration.toFixed(2)),
          z_score: parseFloat(dZ.toFixed(2)),
          timestamp: sig.timestamp,
          description: `⚠️ Late Spike: Latency spiked to ${sig.duration_ms}ms (p99 mean avg: ${meanDuration.toFixed(2)}ms, Z-Score: ${dZ.toFixed(1)}).`
        });
      }

      // Check high error rates triggers
      if (sig.error_rate > 0.05) {
        anomalies.push({
          id: `anm_${Math.floor(1000 + Math.random() * 9000)}`,
          stream: sig.stream,
          handler: sig.handler,
          metric: 'error_rate',
          actual_value: sig.error_rate,
          expected_mean: 0,
          z_score: 9.9,
          timestamp: sig.timestamp,
          description: `❌ Critical Fault Error rate spike on stream ${sig.stream} (${(sig.error_rate * 100).toFixed(1)}% failures).`
        });
      }
    });

    return anomalies;
  }
}
