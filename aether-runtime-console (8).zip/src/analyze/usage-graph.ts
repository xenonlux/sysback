/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from '../observe/collector';

export interface UsageLink {
  source: string;
  target: string;
  value: number; // weight / throughput
}

export interface UsageNode {
  id: string;
  type: 'stream' | 'handler' | 'external_signal';
  eventsProcessed: number;
}

export interface StreamDependencyGraph {
  nodes: UsageNode[];
  links: UsageLink[];
}

export class UsageGraphBuilder {
  constructor() {}

  /**
   * Generates graph structures from current operational signals list
   */
  public build(signals: ExecutionSignal[]): StreamDependencyGraph {
    const nodesMap: Map<string, UsageNode> = new Map();
    const linksMap: Map<string, UsageLink> = new Map();

    // Establish static default system boundaries for graph stability when buffer is brief
    nodesMap.set('users', { id: 'users', type: 'stream', eventsProcessed: 0 });
    nodesMap.set('billing', { id: 'billing', type: 'stream', eventsProcessed: 0 });
    nodesMap.set('telemetry', { id: 'telemetry', type: 'stream', eventsProcessed: 0 });

    signals.forEach(sig => {
      // Stream Node
      if (!nodesMap.has(sig.stream)) {
        nodesMap.set(sig.stream, { id: sig.stream, type: 'stream', eventsProcessed: 0 });
      }
      nodesMap.get(sig.stream)!.eventsProcessed += sig.event_count;

      // Handler Node
      const handlerId = `${sig.stream}.${sig.handler}`;
      if (!nodesMap.has(handlerId)) {
        nodesMap.set(handlerId, { id: handlerId, type: 'handler', eventsProcessed: 0 });
      }
      nodesMap.get(handlerId)!.eventsProcessed += sig.event_count;

      // Link: Stream -> Handler
      const linkKey = `${sig.stream}->${handlerId}`;
      if (!linksMap.has(linkKey)) {
        linksMap.set(linkKey, { source: sig.stream, target: handlerId, value: 0 });
      }
      linksMap.get(linkKey)!.value += sig.event_count;

      // Check external side affects (like signals emitted inside AST handler)
      if (sig.stream === 'users') {
        const extId = 'signal.welcome';
        if (!nodesMap.has(extId)) {
          nodesMap.set(extId, { id: extId, type: 'external_signal', eventsProcessed: 0 });
        }
        nodesMap.get(extId)!.eventsProcessed += sig.event_count;

        const extLinkKey = `${handlerId}->${extId}`;
        if (!linksMap.has(extLinkKey)) {
          linksMap.set(extLinkKey, { source: handlerId, target: extId, value: 0 });
        }
        linksMap.get(extLinkKey)!.value += sig.event_count;
      }
    });

    return {
      nodes: Array.from(nodesMap.values()),
      links: Array.from(linksMap.values())
    };
  }
}
