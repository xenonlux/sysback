/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExecutionSignal } from '../observe/collector';

export interface HotPathInfo {
  stream: string;
  handler: string;
  frequencyHz: number; // calculated operations per second equivalent
  avg_duration_ms: number;
  total_events: number;
  isHot: boolean;
  jitOptimized: boolean;
  recommendation: string;
}

export class HotPathAnalyzer {
  private hotThresholdHz: number = 20; // Simulated scale down for prototype demonstration
  private JITOptimizedStreams: Set<string> = new Set();

  constructor(thresholdHz: number = 20) {
    this.hotThresholdHz = thresholdHz;
  }

  /**
   * Scans previous signals to evaluate hot paths
   */
  public analyze(signals: ExecutionSignal[]): HotPathInfo[] {
    const groupings: Record<string, ExecutionSignal[]> = {};
    
    // Group signals by stream:handler
    signals.forEach(sig => {
      const key = `${sig.stream}:${sig.handler}`;
      if (!groupings[key]) {
        groupings[key] = [];
      }
      groupings[key].push(sig);
    });

    const results: HotPathInfo[] = [];

    Object.entries(groupings).forEach(([key, sList]) => {
      const [stream, handler] = key.split(':');
      const total_events = sList.reduce((sum, s) => sum + s.event_count, 0);
      const avg_duration = sList.reduce((sum, s) => sum + s.duration_ms, 0) / sList.length;
      
      // Calculate active throughput frequency (count/interval span)
      let frequencyHz = sList.length;
      if (sList.length > 1) {
        const earliest = Math.min(...sList.map(s => s.timestamp));
        const latest = Math.max(...sList.map(s => s.timestamp));
        const deltaSec = (latest - earliest) / 1000;
        if (deltaSec > 0.1) {
          frequencyHz = sList.length / deltaSec;
        }
      }

      const isHot = frequencyHz > this.hotThresholdHz || total_events > 500;
      const jitOptimized = this.JITOptimizedStreams.has(stream);

      let recommendation = 'Performance satisfies SLAs.';
      if (isHot && !jitOptimized) {
        recommendation = '🚨 Critical Path: Enable target JIT pre-compilation instructions on AST registers to reduce thread locking.';
      } else if (isHot && jitOptimized) {
        recommendation = '🚀 Under Optimal JIT Execution: Speedups active.';
      }

      results.push({
        stream,
        handler,
        frequencyHz: parseFloat(frequencyHz.toFixed(2)),
        avg_duration_ms: parseFloat(avg_duration.toFixed(2)),
        total_events,
        isHot,
        jitOptimized,
        recommendation
      });
    });

    return results;
  }

  /**
   * Registers a stream as JIT optimized
   */
  public registerJIT(stream: string): void {
    this.JITOptimizedStreams.add(stream);
  }

  /**
   * Resets JIT flags
   */
  public clearJIT(): void {
    this.JITOptimizedStreams.clear();
  }
}
