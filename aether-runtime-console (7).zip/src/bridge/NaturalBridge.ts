/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement } from '../runtime/types';
import { extractIntent, ExtractedIntent } from '../detect/intent';
import { buildASTFromIntent } from '../build/ast-builder';
import { calculateConfidence } from '../feedback/confidence';
import { generateSuggestions } from '../feedback/suggestion';
import { NL_TEST_CASES, BridgeTestCase } from './test-cases';

export interface TranslationResult {
  ast: Statement[];
  confidence: number;
  suggestions: string[];
  code: string;
  language: 'en' | 'ar';
  intent: ExtractedIntent;
}

export class NaturalBridge {
  /**
   * Translates plain human text (English or Arabic) into valid AETHER AST, code, and metadata.
   */
  public translate(text: string): TranslationResult {
    const intent = extractIntent(text);
    const { ast, code } = buildASTFromIntent(intent);
    const confidence = calculateConfidence(intent, text);
    const suggestions = confidence < 80 ? generateSuggestions(intent) : [];

    return {
      ast,
      confidence,
      suggestions,
      code,
      language: intent.language,
      intent
    };
  }

  /**
   * Service diagnostic to fetch pre-bundled test suite cases (50+ available)
   */
  public getTestCases(): BridgeTestCase[] {
    return NL_TEST_CASES;
  }
}
