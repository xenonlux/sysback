/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BridgeTestCase {
  id: string;
  text: string;
  lang: 'en' | 'ar';
  category: 'registration' | 'auth' | 'billing' | 'telemetry' | 'general';
}

export const NL_TEST_CASES: BridgeTestCase[] = [
  // --- 1. User Registration & Onboarding (10 Cases) ---
  {
    id: 'reg_en_1',
    text: 'When a user registers, validate their email and password, save them to the users stream, and send a welcome signal',
    lang: 'en',
    category: 'registration'
  },
  {
    id: 'reg_ar_1',
    text: 'عند تسجيل مستخدم جديد، تحقق من البريد والكلمة السرية، احفظه في تدفق المستخدمين، وأرسل إشارة ترحيب',
    lang: 'ar',
    category: 'registration'
  },
  {
    id: 'reg_en_2',
    text: 'If signup occurs, validate username and strength, flow record to users table, and response created status',
    lang: 'en',
    category: 'registration'
  },
  {
    id: 'reg_ar_2',
    text: 'إذا تم إنشاء حساب جديد، دقق في الإيميل والرمز السري، ثم خزن البيانات في جدول المستخدمين وأرجع استجابة ناجحة',
    lang: 'ar',
    category: 'registration'
  },
  {
    id: 'reg_en_3',
    text: 'When customer enrolls, check credentials, write to users, and send welcome greet',
    lang: 'en',
    category: 'registration'
  },
  {
    id: 'reg_ar_3',
    text: 'عندما يسجل العميل، تأكد من بريده الإلكتروني، اكتب البيانات في تدفق مستخدمين، وأطلق إشارة ترحيب',
    lang: 'ar',
    category: 'registration'
  },
  {
    id: 'reg_en_4',
    text: 'On registration, validate email format and password strength, write user flow, and return Response.created',
    lang: 'en',
    category: 'registration'
  },
  {
    id: 'reg_ar_4',
    text: 'عند التسجيل، تحقق من البريد والرمز، سجل المستخدم في مستودع البيانات، وأرجع Response.created',
    lang: 'ar',
    category: 'registration'
  },
  {
    id: 'reg_en_5',
    text: 'If a guest registers, validate req details and save user info',
    lang: 'en',
    category: 'registration'
  },
  {
    id: 'reg_ar_5',
    text: 'إذا سجل زائر، تحقق من البيانات المطلوبة واحفظ معلومات المستخدم',
    lang: 'ar',
    category: 'registration'
  },

  // --- 2. Secure Authentication & Session Login (10 Cases) ---
  {
    id: 'auth_en_1',
    text: 'When user logins, validate credentials, hash session keys, and emit security.handshake',
    lang: 'en',
    category: 'auth'
  },
  {
    id: 'auth_ar_1',
    text: 'عند تسجيل الدخول، تحقق من الهوية، خزن الجلسة، وأصدر إشارة ترحيبية للمستخدم بقرص الحماية',
    lang: 'ar',
    category: 'auth'
  },
  {
    id: 'auth_en_2',
    text: 'If client signs in, check email coordinates and compute secure symmetric hash key',
    lang: 'en',
    category: 'auth'
  },
  {
    id: 'auth_ar_2',
    text: 'إذا قام العميل بتسجيل الولوج، دقق البريد الإلكتروني الخاص به، وأصدر رمز مرور مشفر',
    lang: 'ar',
    category: 'auth'
  },
  {
    id: 'auth_en_3',
    text: 'On admin authenticates, check security claims, write session state, and dispatch login signal',
    lang: 'en',
    category: 'auth'
  },
  {
    id: 'auth_ar_3',
    text: 'عند تحقق المشرف للمرة الأولى، دقق في الهوية، خزن مستوى الدخول، وأطلق تنبيه حماية',
    lang: 'ar',
    category: 'auth'
  },
  {
    id: 'auth_en_4',
    text: 'When a controller logins, authorize their session credentials and return success status',
    lang: 'en',
    category: 'auth'
  },
  {
    id: 'auth_ar_4',
    text: 'عندما يسجل لوحة التحكم دخوله، تحقق من صلاحياته وأعد استجابة ترحيبية وتذكرة اتصال',
    lang: 'ar',
    category: 'auth'
  },
  {
    id: 'auth_en_5',
    text: 'If authentication claims pass, sign transaction token and return session key',
    lang: 'en',
    category: 'auth'
  },
  {
    id: 'auth_ar_5',
    text: 'إذا تطابقت شروط التحقق الأمنية، وقع رمز التذكرة الرقمية وأرجع مفتاح الجلسة',
    lang: 'ar',
    category: 'auth'
  },

  // --- 3. Checkout Payments & Ledgers (10 Cases) ---
  {
    id: 'pay_en_1',
    text: 'On transaction occurs, validate payment positive amount, save to ledger, and emit billing.receipt',
    lang: 'en',
    category: 'billing'
  },
  {
    id: 'pay_ar_1',
    text: 'عند حدوث دفعة، تحقق من صحة المبلغ، احفظه في تدفق الحسابات، وبث إشارة الفاتورة',
    lang: 'ar',
    category: 'billing'
  },
  {
    id: 'pay_en_2',
    text: 'When checkout payment request arrives, validate cost parameters, write logs, and return status',
    lang: 'en',
    category: 'billing'
  },
  {
    id: 'pay_ar_2',
    text: 'عند وصول طلب الشراء والدفع، تأكد من التفاصيل المالية، خزن الفاتورة، وأرجع استجابة ناجحة',
    lang: 'ar',
    category: 'billing'
  },
  {
    id: 'pay_en_3',
    text: 'If user purchases catalog item, check transaction cost structure and emit receipt signals',
    lang: 'en',
    category: 'billing'
  },
  {
    id: 'pay_ar_3',
    text: 'إذا اشترى المشترك عنصراً، تحقق من السعر المدفوع، خزن السجل التاريخي، وفعل إشارة الدفع',
    lang: 'ar',
    category: 'billing'
  },
  {
    id: 'pay_en_4',
    text: 'When premium order initiates, validate details schema and flow transaction to billing store',
    lang: 'en',
    category: 'billing'
  },
  {
    id: 'pay_ar_4',
    text: 'عند تفعيل اشتراك مميز، دقق في معطيات الدفع، خزن العملية في تدفق المبيعات وأرجع الفاتورة',
    lang: 'ar',
    category: 'billing'
  },
  {
    id: 'pay_en_5',
    text: 'On transaction checkout, write to ledger stream and yield status success',
    lang: 'en',
    category: 'billing'
  },
  {
    id: 'pay_ar_5',
    text: 'عند تأكيد البيع النهائي، اكتب السجلات المالية في الدفتر الحسابي وأرجع Response.success',
    lang: 'ar',
    category: 'billing'
  },

  // --- 4. Telemetry Logging, Status & Pulse Heartbeats (10 Cases) ---
  {
    id: 'tel_en_1',
    text: 'When pulse received, fetch uuid, emit telemetry.pulse online status, and yield heartbeat',
    lang: 'en',
    category: 'telemetry'
  },
  {
    id: 'tel_ar_1',
    text: 'عند استقبال نبض من النظام، ولد تذكرة تعريف، أطلق إشارة قياس نشطة، وأرجع حالة الاتصال الحالية',
    lang: 'ar',
    category: 'telemetry'
  },
  {
    id: 'tel_en_2',
    text: 'If ping arrives, record current epoch now, write details to flow logs, and yield pulseToken',
    lang: 'en',
    category: 'telemetry'
  },
  {
    id: 'tel_ar_2',
    text: 'إذا ورد طلب فحص، خزن التوقيت الحالي حالا، احفظ بيانات الاتصال في تدفق المراقبة، وأرجع رمز النبض',
    lang: 'ar',
    category: 'telemetry'
  },
  {
    id: 'tel_en_3',
    text: 'On telemetry pulse received, broadcast metrics reports and write to telemetry database',
    lang: 'en',
    category: 'telemetry'
  },
  {
    id: 'tel_ar_3',
    text: 'عند استقبال تقرير خادم قياسي، بث إشارة إحصائية شاملة وخفض زمن الاستجابة في تدفق المراقبة',
    lang: 'ar',
    category: 'telemetry'
  },
  {
    id: 'tel_en_4',
    text: 'When server fails, record error code variables and send critical alarm signal to controller',
    lang: 'en',
    category: 'telemetry'
  },
  {
    id: 'tel_ar_4',
    text: 'عند فشل الاتصال بالخادم، خزن رمز الخطأ في المتغيرات، وأطلق تحذيراً أمنياً عاجلاً للمشرف',
    lang: 'ar',
    category: 'telemetry'
  },
  {
    id: 'tel_en_5',
    text: 'If system diagnostics trigger, emit hardware pulse status state and respond with status code',
    lang: 'en',
    category: 'telemetry'
  },
  {
    id: 'tel_ar_5',
    text: 'إذا تم استدعاء الفحص الذاتي، أطلق إشارة بحالة الذاكرة الحالية وأرجع رمز تأكيد سليم',
    lang: 'ar',
    category: 'telemetry'
  },

  // --- 5. General Verification, Conditionals & Errors (10 Cases) ---
  {
    id: 'gen_en_1',
    text: 'If priority is above fifty, send priority alert to admin stream',
    lang: 'en',
    category: 'general'
  },
  {
    id: 'gen_ar_1',
    text: 'إذا كانت الأولوية مرتفعة، أصدر إشعار تنبيه كيرفرن في تدفق الإدارة الأمني وعجل الرد',
    lang: 'ar',
    category: 'general'
  },
  {
    id: 'gen_en_2',
    text: 'When input matches validation, yield true to confirm credentials state',
    lang: 'en',
    category: 'general'
  },
  {
    id: 'gen_ar_2',
    text: 'عند تطابق البيانات المدخلة مع محدد الفحص، أعد القيمة الصحيحة لتأكيد حالة الهوية',
    lang: 'ar',
    category: 'general'
  },
  {
    id: 'gen_en_3',
    text: 'If token validation schema is strong, authorize users flow write block',
    lang: 'en',
    category: 'general'
  },
  {
    id: 'gen_ar_3',
    text: 'إذا كان البريد وكلمة المرور متطابقين، اسمح بكتابة السجل في تدفق مستخدمين وأعلم المشرف',
    lang: 'ar',
    category: 'general'
  },
  {
    id: 'gen_en_4',
    text: 'On database error alert, check connection coordinates, send safety signal, and yield response fault',
    lang: 'en',
    category: 'general'
  },
  {
    id: 'gen_ar_4',
    text: 'عند حدوث عطل في مخزن البيانات، تحقق من مصفق الشبكة، وأطلق تحذيراً فورياً مع تراجع البيانات',
    lang: 'ar',
    category: 'general'
  },
  {
    id: 'gen_en_5',
    text: 'When user credentials update, validate requirements, save to flow users, and yield Success',
    lang: 'en',
    category: 'general'
  },
  {
    id: 'gen_ar_5',
    text: 'عند تحديث بيانات الهوية، دقق تفاصيل الطلب، خزن السجل الجديد في تدفق الملفات، وأعد استجابة نجاح',
    lang: 'ar',
    category: 'general'
  }
];
