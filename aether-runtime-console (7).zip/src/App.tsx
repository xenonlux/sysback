/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Terminal, 
  Play, 
  Check, 
  Copy, 
  AlertTriangle, 
  Database, 
  Cpu, 
  ShieldCheck, 
  TrendingUp, 
  BookOpen, 
  Radio, 
  Code2, 
  Layers, 
  HelpCircle,
  FileCheck2,
  Trash2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { NaturalBridge, TranslationResult } from './bridge/NaturalBridge';

export default function App() {
  const [bridge] = useState(() => new NaturalBridge());
  const testCases = bridge.getTestCases();

  // Natural Language state
  const [naturalInput, setNaturalInput] = useState(testCases[0].text);
  const [translationResult, setTranslationResult] = useState<TranslationResult | null>(null);
  
  // Custom states
  const [selectedCaseId, setSelectedCaseId] = useState<string>(testCases[0].id);
  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedNodeIndex, setSelectedNodeIndex] = useState<number | null>(null);

  // Simulation states
  const [selectedTab, setSelectedTab] = useState<'flow' | 'source' | 'simulator'>('flow');
  const [simulationActive, setSimulationActive] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<Array<{ timestamp: string; type: 'info' | 'success' | 'warn' | 'error'; message: string }>>([]);
  const [mockRequestPayload, setMockRequestPayload] = useState<string>('{\n  "email": "developer@aether.org",\n  "password": "securePass123!",\n  "amount": 250.00\n}');
  const [simResultsStore, setSimResultsStore] = useState<{
    authenticated: boolean;
    storedInDb: Array<any>;
    broadcastSignals: Array<any>;
    lastResponse: any;
  }>({ authenticated: false, storedInDb: [], broadcastSignals: [], lastResponse: null });

  // Translation trigger
  const handleCompile = (inputText = naturalInput) => {
    if (!inputText.trim()) return;
    const result = bridge.translate(inputText);
    setTranslationResult(result);
    setSimulationActive(false);
    
    // Auto populate mock values depending on content
    if (result.intent.trigger === 'transaction') {
      setMockRequestPayload('{\n  "amount": 499.95,\n  "currency": "USD",\n  "ledgerRef": "tx_invoice_8911"\n}');
    } else if (result.intent.trigger === 'login') {
      setMockRequestPayload('{\n  "email": "operator_admin@aether.cloud",\n  "deviceToken": "sec_auth_tkn_812"\n}');
    } else if (result.intent.trigger === 'telemetry') {
      setMockRequestPayload('{\n  "nodeId": "ams_router_01",\n  "status": "ONLINE"\n}');
    } else {
      setMockRequestPayload('{\n  "email": "pioneering_user@aether.io",\n  "password": "quantumSeedingPass99!"\n}');
    }

    if (result.confidence >= 90) {
      triggerConfetti();
    }
  };

  // Run on startup
  useEffect(() => {
    handleCompile(testCases[0].text);
  }, []);

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 50,
      origin: { y: 0.8 },
      colors: ['#10B981', '#6366F1', '#3B82F6']
    });
  };

  const handleSelectTestCase = (id: string) => {
    const found = testCases.find(tc => tc.id === id);
    if (found) {
      setSelectedCaseId(id);
      setNaturalInput(found.text);
      handleCompile(found.text);
    }
  };

  const handleCopyCode = () => {
    if (!translationResult) return;
    navigator.clipboard.writeText(translationResult.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const addLog = (type: 'info' | 'success' | 'warn' | 'error', message: string) => {
    const now = new Date();
    const ts = now.toLocaleTimeString();
    setSimulationLogs(prev => [...prev, { timestamp: ts, type, message }]);
  };

  // Safe JSON Parsing helper
  const parsePayload = () => {
    try {
      return JSON.parse(mockRequestPayload);
    } catch (e) {
      return null;
    }
  };

  // Simulated Dry-Run Interpreter
  const runFullSimulation = async () => {
    if (!translationResult) return;
    setSimulationActive(true);
    setSimulationLogs([]);
    
    const reqBody = parsePayload();
    if (!reqBody) {
      addLog('error', '⚠️ Compilation Blocked: Invalid input request JSON payloads. Check syntax.');
      setSimulationActive(false);
      return;
    }

    addLog('info', '📡 Starting Aether Sandbox Virtual Dry-Run Engine...');
    addLog('info', `🎯 Initializing pipeline trigger [on ${translationResult.intent.trigger || 'register'}]`);
    addLog('info', `📦 Mapping parsed payload: ${JSON.stringify(reqBody)}`);

    const statements = translationResult.ast;
    const db: Array<any> = [];
    const signals: Array<any> = [];
    let authenticated = false;
    let localScopeUser: any = null;
    let lastResult: any = null;

    for (let i = 0; i < statements.length; i++) {
      const stmt = statements[i];
      await new Promise(r => setTimeout(r, 900));

      switch (stmt.type) {
        case 'LetStatement': {
          addLog('info', `⚙️ Step ${i + 1}: LetStmt - Running validation bounds on input.`);
          if (stmt.value.type === 'CallExpression' && stmt.value.callee === 'validate') {
            const properties = (stmt.value.arguments[1] as any)?.value || {};
            const emailRequired = !!properties.email;
            const passwordRequired = !!properties.password;
            
            let validationFailed = false;

            if (emailRequired) {
              const emailVal = reqBody.email || reqBody.username;
              const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
              if (!emailVal) {
                addLog('error', '❌ ValidationError: Required property "email" is missing from input request.');
                validationFailed = true;
              } else if (!emailRegex.test(emailVal)) {
                addLog('warn', `⚠️ FormatWarning: Email "${emailVal}" does not match Aether.EmailRegex standards.`);
                addLog('error', '❌ ValidationError: Pattern validation rejected format specification for field "email".');
                validationFailed = true;
              } else {
                addLog('success', `✓ Format Check Passed: Email Address "${emailVal}" matches structured properties.`);
              }
            }

            if (passwordRequired) {
              const passVal = reqBody.password || '';
              if (!passVal) {
                addLog('error', '❌ ValidationError: Required property "password" is missing from input.');
                validationFailed = true;
              } else if (passVal.length < 8) {
                addLog('warn', `⚠️ CrypticWarning: Private token strength is only ${passVal.length} charts. Recommended minimum is 8.`);
                addLog('error', '❌ ValidationError: Strength standard requirement unmet.');
                validationFailed = true;
              } else {
                addLog('success', `✓ Security Check Passed: Private tokens validated against Password.strong definitions.`);
              }
            }

            if (validationFailed) {
              addLog('error', '🛑 Process Stack Aborted: Pipeline failed validation sequence.');
              setSimulationActive(false);
              return;
            }

            localScopeUser = {
              id: `usr_${Math.floor(100000 + Math.random() * 900000)}`,
              email: reqBody.email || 'developer@aether.org',
              timestamp: Date.now()
            };
            authenticated = true;
            addLog('success', `✓ Local state binding created: variable "${stmt.name}" initialized with parsed context.`);
          } else {
            // General let statement (e.g. hash calculation)
            const resolvedValue = `sha_sig_${Math.floor(10000000 + Math.random() * 90000000)}`;
            addLog('success', `✓ Hash calculated: "${stmt.name}" bound with signature "${resolvedValue}"`);
          }
          break;
        }

        case 'EmitStatement': {
          addLog('info', `⚙️ Step ${i + 1}: EmitStmt - Dispatching signals or pushing to FlowStore.`);
          const sig = stmt.signal;
          if (sig.includes('.register') || sig.includes('ledgers.')) {
            const row = {
              ...(localScopeUser || { id: 'sys_autogen_row' }),
              ...reqBody,
              committedAt: new Date().toISOString()
            };
            db.push(row);
            addLog('success', `💾 BTree FlowStore: Flow record written safely onto stream target "${sig.split('.')[0]}".`);
            addLog('success', `   Row payload committed: { id: "${row.id}", index_key: "${row.email || row.amount || 'system_ref'}" }`);
          } else {
            const signalPayload = {
              pulseId: `pulse_${Math.floor(Math.random() * 10000)}`,
              signalName: sig,
              firedAt: Date.now()
            };
            signals.push(signalPayload);
            addLog('success', `⚡ EventBus active: Broadcasted system signal "${sig}" over WebSocket/RPC channels.`);
          }
          break;
        }

        case 'YieldStatement': {
          addLog('info', `⚙️ Step ${i + 1}: YieldStmt - Generating return payload responses.`);
          lastResult = {
            statusCode: translationResult.intent.trigger === 'register' ? 201 : 200,
            status: 'success',
            payload: localScopeUser || {
              processed: true,
              reference: `ref_ack_${Math.floor(1000 + Math.random() * 9000)}`
            }
          };
          addLog('success', `↩ Yield Return: Yield statement returned status: ${lastResult.statusCode}. Channel stream finalized.`);
          break;
        }
      }
    }

    setSimResultsStore({
      authenticated,
      storedInDb: db,
      broadcastSignals: signals,
      lastResponse: lastResult
    });

    setSimulationActive(false);
    addLog('success', '🏆 Sandbox Execution Successful: Run ended with EXIT_CODE 0.');
    triggerConfetti();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#020512] via-[#040922] to-[#020512] text-slate-100 flex flex-col justify-between" id="aether_main_frame">
      
      {/* GLOWING HEADER */}
      <header className="border-b border-indigo-500/10 bg-slate-950/60 backdrop-blur-xl p-4 sticky top-0 z-50 transition-all" id="header_pane">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <div className="relative group">
              <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-emerald-500 to-indigo-600 opacity-60 blur group-hover:opacity-100 transition duration-1000 animate-pulse-glow" />
              <button className="relative bg-slate-900 border border-slate-800 p-2.5 rounded-xl text-emerald-400 group-hover:text-white transition duration-200">
                <Cpu className="h-5 w-5" />
              </button>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs uppercase tracking-widest font-black text-rose-500 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded-full">Autonomous Core</span>
                <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded-full border border-slate-700">v4.2.1-stable</span>
              </div>
              <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5 mt-0.5">
                AETHER <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-indigo-400">Natural Language Bridge</span>
              </h1>
            </div>
          </div>

          {/* Test cases loader dropdown */}
          <div className="flex items-center space-x-3 w-full md:w-auto">
            <div className="text-right hidden xl:block">
              <span className="text-[10px] text-slate-400 block uppercase font-mono tracking-wider font-bold">Linguistic Benchmarks</span>
              <span className="text-xs text-slate-500">50 Bilingual Tests Loaded</span>
            </div>
            <div className="relative flex-1 md:flex-none">
              <BookOpen className="absolute left-3 top-3.5 h-3.5 w-3.5 text-slate-500" />
              <select
                value={selectedCaseId}
                onChange={(e) => handleSelectTestCase(e.target.value)}
                className="w-full md:w-80 pl-9 pr-6 py-2.5 bg-slate-900/90 border border-slate-800 text-slate-200 hover:text-white rounded-xl text-xs accent-indigo-500 focus:outline-none focus:border-indigo-500 cursor-pointer transition-all"
                id="test_case_selectbox"
              >
                <option value="" disabled>Choose standard bilingual microservice test case</option>
                
                <optgroup label="1. Registration & Onboarding Loops" className="bg-slate-950 text-slate-300">
                  {testCases.filter(t => t.category === 'registration').map(tc => (
                    <option key={tc.id} value={tc.id}>
                      [{tc.lang.toUpperCase()}] {tc.text.substring(0, 52)}...
                    </option>
                  ))}
                </optgroup>

                <optgroup label="2. Cryptographic Security & Logins" className="bg-slate-950 text-slate-300">
                  {testCases.filter(t => t.category === 'auth').map(tc => (
                    <option key={tc.id} value={tc.id}>
                      [{tc.lang.toUpperCase()}] {tc.text.substring(0, 52)}...
                    </option>
                  ))}
                </optgroup>

                <optgroup label="3. Ledger Checkout & Payments" className="bg-slate-950 text-slate-300">
                  {testCases.filter(t => t.category === 'billing').map(tc => (
                    <option key={tc.id} value={tc.id}>
                      [{tc.lang.toUpperCase()}] {tc.text.substring(0, 52)}...
                    </option>
                  ))}
                </optgroup>

                <optgroup label="4. System Telemetry & Heartbeats" className="bg-slate-950 text-slate-300">
                  {testCases.filter(t => t.category === 'telemetry').map(tc => (
                    <option key={tc.id} value={tc.id}>
                      [{tc.lang.toUpperCase()}] {tc.text.substring(0, 52)}...
                    </option>
                  ))}
                </optgroup>

                <optgroup label="5. Conditionals & General Handlers" className="bg-slate-950 text-slate-300">
                  {testCases.filter(t => t.category === 'general').map(tc => (
                    <option key={tc.id} value={tc.id}>
                      [{tc.lang.toUpperCase()}] {tc.text.substring(0, 52)}...
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>
          </div>
        </div>
      </header>

      {/* WORKSPACE AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:py-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch" id="main_content_arena">
        
        {/* LEFT COLUMN: Linguistic Parsing Engine Inputs (Col Span 5) */}
        <section className="lg:col-span-5 flex flex-col space-y-6" id="left_workspace">
          
          {/* INPUT CARD */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl shadow-2xl p-5 flex flex-col space-y-4 glow-box-indigo relative overflow-hidden" id="card_nlp_input">
            <div className="absolute top-0 right-0 p-3">
              <span className="text-[9px] font-mono font-black border border-slate-700 bg-slate-950 text-slate-500 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Parser Stage 1
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <Radio className="h-4 w-4 text-indigo-400 animate-pulse" />
              <h2 className="text-xs uppercase tracking-widest font-black text-slate-300">NLP Input Console</h2>
            </div>

            <p className="text-xs leading-relaxed text-slate-400">
              Type or customize bilingual backend requirements instructions to compute into Aether stream AST objects:
            </p>

            <div className="flex-1 flex flex-col relative">
              <textarea
                value={naturalInput}
                onChange={(e) => setNaturalInput(e.target.value)}
                placeholder="Write your pipeline logic requirement in English or Arabic (العربية)..."
                className="w-full min-h-[140px] flex-1 bg-slate-950/80 border border-slate-800 focus:border-indigo-500/50 text-slate-100 p-4 rounded-xl text-xs sm:text-sm placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500/20 leading-relaxed resize-none transition-all font-mono"
                id="input_sentence_ta"
              />
              <div className="absolute right-3 bottom-3 flex items-center space-x-2">
                <button
                  onClick={() => setNaturalInput('')}
                  className="p-1.5 hover:bg-slate-800 text-slate-500 hover:text-slate-300 rounded-lg transition"
                  title="Clear input"
                  id="button_clear_ta"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
                <div className="text-[10px] text-slate-600 font-mono select-none px-2 py-1 bg-slate-900 border border-slate-800 rounded-lg">
                  {naturalInput.length} chars
                </div>
              </div>
            </div>

            {/* COMPILE BUTTON */}
            <button
              onClick={() => handleCompile()}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-mono font-black p-4 rounded-xl text-xs uppercase flex items-center justify-center space-x-2 shadow-xl shadow-emerald-500/5 hover:-translate-y-0.5 cursor-pointer select-none transition-all active:translate-y-0"
              id="compile_action_btn"
            >
              <Sparkles className="h-4.5 w-4.5 text-slate-950" />
              <span>Compile Intent To AST</span>
            </button>
          </div>

          {/* META & ANALYSIS CARD */}
          {translationResult && (
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 relative" id="card_analysis_pane">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-4 w-4 text-emerald-400" />
                  <h3 className="text-xs uppercase tracking-widest font-black text-slate-300">Linguistic Analysis</h3>
                </div>
                <span className={`text-[10px] uppercase font-mono font-black px-2 py-0.5 rounded border ${
                  translationResult.language === 'ar' ? 'bg-indigo-600/10 text-indigo-400 border-indigo-500/20' : 'bg-sky-600/10 text-sky-400 border-sky-500/20'
                }`}>
                  {translationResult.language === 'ar' ? 'ar: العربية' : 'en: English'}
                </span>
              </div>

              {/* CONFIDENCE BAR CONTAINER */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Translation Confidence Trust:</span>
                  <span className={`font-mono font-black ${
                    translationResult.confidence >= 80 ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {translationResult.confidence}%
                  </span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-900">
                  <div 
                    className={`h-full rounded-full transition-all duration-700 ${
                      translationResult.confidence >= 80 
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-400' 
                        : 'bg-gradient-to-r from-amber-600 to-yellow-400'
                    }`} 
                    style={{ width: `${translationResult.confidence}%` }}
                  />
                </div>
              </div>

              {/* ENTITY & INTENT DICTIONARY GRID */}
              <div className="grid grid-cols-2 gap-3" id="analysis_details_grid">
                <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider font-bold">Identified Trigger</span>
                  <span className="text-sm font-bold text-white font-mono break-all flex items-center space-x-1.5 leading-none">
                    <span className="w-2 h-2 rounded-full bg-indigo-500 inline-block" />
                    <span>{translationResult.intent.trigger || 'telemetry'}</span>
                  </span>
                </div>
                <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider font-bold">Data Domains Found</span>
                  <span className="text-xs font-bold text-sky-400 font-mono truncate block" title={translationResult.intent.entities.join(', ') || 'none'}>
                    {translationResult.intent.entities.length > 0 ? translationResult.intent.entities.join(', ') : 'none'}
                  </span>
                </div>
              </div>

              {/* SEQUENTIAL pipeline preview */}
              <div className="space-y-1.5">
                <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider font-bold block">Execution Sequence Pipeline</span>
                <div className="flex flex-wrap items-center gap-1.5" id="extraction_path">
                  {translationResult.intent.actions.map((act, index) => (
                    <React.Fragment key={index}>
                      {index > 0 && <span className="text-slate-600 text-xs">➔</span>}
                      <div className="bg-slate-900 border border-slate-800/80 px-2.5 py-1 rounded-lg flex items-center space-x-1 hover:border-slate-700 transition">
                        <span className="text-[11px] font-mono font-bold text-slate-300">{act.actionType.toUpperCase()}</span>
                        <span className="text-[10px] text-slate-500 font-mono">({act.actionOriginal})</span>
                      </div>
                    </React.Fragment>
                  ))}
                </div>
              </div>

              {/* LOW CONFIDENCE SUGGESTIONS */}
              {translationResult.confidence < 80 && translationResult.suggestions.length > 0 && (
                <div className="bg-amber-500/5 p-4 border border-amber-500/10 rounded-xl space-y-2">
                  <div className="flex items-center space-x-1.5 text-amber-500">
                    <AlertTriangle className="h-4 w-4 shrink-0" />
                    <span className="text-[10px] font-mono font-black uppercase tracking-wider">Linguistic Suggestions</span>
                  </div>
                  <ul className="space-y-1.5">
                    {translationResult.suggestions.map((sug, idx) => (
                      <li key={idx}>
                        <button
                          onClick={() => {
                            setNaturalInput(sug);
                            handleCompile(sug);
                          }}
                          className="w-full text-left bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-slate-200 p-2 rounded-lg text-xs leading-relaxed transition flex items-start space-x-1.5 group select-none"
                        >
                          <span className="text-indigo-400 mt-1 shrink-0 text-[10px]">👉</span>
                          <span className="group-hover:underline">{sug}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </section>

        {/* RIGHT COLUMN: Code Viewers, Node Graph & Real-Time Simulator Sandbox (Col Span 7) */}
        <section className="lg:col-span-7 flex flex-col space-y-6" id="right_workspace">
          
          {/* TAB HEADERS */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-850 flex items-center space-x-1">
            <button
              onClick={() => setSelectedTab('flow')}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-lg text-xs font-mono font-bold select-none cursor-pointer transition ${
                selectedTab === 'flow' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
              id="tab_btn_flow"
            >
              <Layers className="h-3.5 w-3.5" />
              <span>Btree flow graph</span>
            </button>
            <button
              onClick={() => setSelectedTab('source')}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-lg text-xs font-mono font-bold select-none cursor-pointer transition ${
                selectedTab === 'source' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
              id="tab_btn_source"
            >
              <Code2 className="h-3.5 w-3.5" />
              <span>Aether system DSL</span>
            </button>
            <button
              onClick={() => setSelectedTab('simulator')}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-lg text-xs font-mono font-bold select-none cursor-pointer transition ${
                selectedTab === 'simulator' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
              id="tab_btn_simulator"
            >
              <Terminal className="h-3.5 w-3.5" />
              <span>Dry-Run simulator</span>
            </button>
          </div>

          {/* ACTIVE TAB DISPLAY CONTAINER */}
          <div className="flex-1 bg-slate-900/30 border border-slate-800/80 rounded-2xl p-5 min-h-[460px] flex flex-col justify-between" id="active_panel_display">
            {translationResult ? (
              <div className="flex-1 flex flex-col justify-between h-full space-y-4">
                
                {/* 1. LAYER GRAPH CANVAS VIEW */}
                {selectedTab === 'flow' && (
                  <div className="flex-1 flex flex-col justify-between" id="flow_graph_workbench">
                    <div className="space-y-1">
                      <h4 className="text-xs uppercase tracking-widest font-black text-slate-300">Aether Node Graph Canvas</h4>
                      <p className="text-[11px] text-slate-500">Represents compiled AST statements as responsive visual data flow blocks:</p>
                    </div>

                    {/* FLOW CONTAINER */}
                    <div className="my-4 flex-1 bg-slate-950 p-5 rounded-2xl border border-slate-850 flex flex-col justify-center items-center space-y-6 min-h-[280px]">
                      
                      {/* START NODE */}
                      <div className="flex flex-col items-center">
                        <div className="bg-slate-900 border border-slate-800 text-slate-400 px-4 py-2 rounded-xl text-[10px] font-mono flex items-center space-x-2 shadow-lg" id="node_start">
                          <Radio className="h-3.5 w-3.5 text-indigo-400 animate-pulse" />
                          <span>Stream Entry point [on register]</span>
                        </div>
                        <div className="w-0.5 h-6 bg-gradient-to-b from-indigo-500 to-emerald-500" />
                      </div>

                      {/* CONSTRUCTED AST BLOCK NODES */}
                      <div className="flex flex-col items-center space-y-5 w-full max-w-md">
                        {translationResult.ast.map((node, idx) => {
                          const isSelected = selectedNodeIndex === idx;
                          let nodeIcon = <Cpu className="h-4 w-4 text-sky-400" />;
                          let title = 'General Expression';
                          let description = 'Computed Let Statement state calculation.';

                          if (node.type === 'LetStatement') {
                            nodeIcon = <ShieldCheck className="h-4 w-4 text-emerald-400" />;
                            title = `Let scope : ${node.name}`;
                            description = `validate req fields : ${JSON.stringify((node.value as any)?.arguments?.[1]?.value || 'any')}`;
                          } else if (node.type === 'EmitStatement') {
                            nodeIcon = <Database className="h-4 w-4 text-indigo-400" />;
                            title = `Emit flow : ${node.signal}`;
                            description = `broadcasting message payloads on database channel`;
                          } else if (node.type === 'YieldStatement') {
                            nodeIcon = <FileCheck2 className="h-4 w-4 text-emerald-400 animate-pulse" />;
                            title = `Yield returns`;
                            description = `Stream finalizes returning response structures.`;
                          }

                          return (
                            <div key={idx} className="flex flex-col items-center w-full">
                              <div
                                onClick={() => setSelectedNodeIndex(idx === selectedNodeIndex ? null : idx)}
                                className={`w-full bg-slate-900/90 border rounded-2xl p-3.5 flex items-start space-x-3.5 cursor-pointer hover:border-indigo-500/50 hover:bg-slate-900 transition-all ${
                                  isSelected 
                                    ? 'border-indigo-500 shadow-xl shadow-indigo-600/5 bg-slate-900' 
                                    : 'border-slate-800'
                                }`}
                                title="Click to view detailed compiled AST node variables"
                              >
                                <div className="bg-slate-950 border border-slate-800 p-2.5 rounded-xl">
                                  {nodeIcon}
                                </div>
                                <div className="flex-1 text-left">
                                  <div className="flex items-center justify-between">
                                    <h5 className="text-xs font-mono font-black text-slate-200">{title}</h5>
                                    <span className="text-[9px] font-mono text-slate-500 uppercase font-black">Node {idx + 1}</span>
                                  </div>
                                  <p className="text-[10px] text-slate-400 mt-1 font-mono leading-relaxed truncate max-w-sm">{description}</p>
                                </div>
                              </div>

                              {/* Nested detail expanded view */}
                              {isSelected && (
                                <div className="w-full mt-2 bg-slate-950/90 p-4 border border-indigo-500/30 rounded-xl text-left space-y-2 animate-fade-in text-[11px] font-mono" id={`node_expanded_${idx}`}>
                                  <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider mb-2">Compiled AST Statement JSON Definition</div>
                                  <pre className="text-emerald-400 whitespace-pre overflow-x-auto max-h-[140px] pr-2">
                                    <code>{JSON.stringify(node, null, 2)}</code>
                                  </pre>
                                </div>
                              )}

                              {idx < translationResult.ast.length - 1 && (
                                <div className="w-0.5 h-5 bg-gradient-to-b from-slate-800 to-indigo-500" />
                              )}
                            </div>
                          );
                        })}
                      </div>

                    </div>
                  </div>
                )}

                {/* 2. SOURCE CODE DSL EDITOR VIEW */}
                {selectedTab === 'source' && (
                  <div className="flex-1 flex flex-col justify-between" id="source_code_editor_pane">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-xs uppercase tracking-widest font-black text-slate-300">Aether DSL Generated Code</h4>
                          <p className="text-[11px] text-slate-500">View human-readable script code translated block-by-block:</p>
                        </div>
                        <button
                          onClick={handleCopyCode}
                          className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 font-mono text-[10px] px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition select-none"
                          id="btn_copy_source"
                        >
                          {copiedCode ? (
                            <>
                              <Check className="h-3.5 w-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-3.5 w-3.5" />
                              <span>Copy Code</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="my-4 flex-1 bg-slate-950 rounded-2xl border border-slate-850 p-4 font-mono text-xs text-emerald-400 overflow-x-auto overflow-y-auto max-h-[340px] text-left leading-relaxed shadow-inner">
                      <pre><code>{translationResult.code}</code></pre>
                    </div>

                    <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-850 flex items-center space-x-2 text-[11px] text-slate-400">
                      <HelpCircle className="h-4 w-4 text-slate-500 shrink-0" />
                      <span>This DSL integrates native zero-trust verification rules, hashing functions, and B-Tree schema engines at the system layer.</span>
                    </div>
                  </div>
                )}

                {/* 3. FULL-STACK INTERPRETED SANDBOX SIMULATOR */}
                {selectedTab === 'simulator' && (
                  <div className="flex-1 flex flex-col justify-between" id="simulator_pane">
                    
                    {/* Sandbox Grid Controls */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 flex-1">
                      
                      {/* Left Block Payload Inputs */}
                      <div className="md:col-span-5 flex flex-col space-y-2">
                        <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider font-bold">Input Body JSON payload</span>
                        <textarea
                          value={mockRequestPayload}
                          onChange={(e) => setMockRequestPayload(e.target.value)}
                          className="w-full flex-1 min-h-[160px] md:min-h-[220px] bg-slate-950 p-3 rounded-xl border border-slate-850 font-mono text-xs text-indigo-300 focus:outline-none focus:border-indigo-500/50 leading-relaxed resize-none transition-all shadow-inner"
                          id="simulator_json_payload"
                        />
                        <button
                          onClick={runFullSimulation}
                          disabled={simulationActive}
                          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-950 font-mono font-black text-white p-3 rounded-xl text-xs uppercase flex items-center justify-center space-x-1.5 tracking-wider transition-all shadow-lg hover:shadow-indigo-600/10 active:translate-y-0.5 select-none"
                          id="btn_sandbox_run"
                        >
                          <Play className="h-3.5 w-3.5" />
                          <span>{simulationActive ? 'Running simulation...' : 'Run Dry-Run simulation'}</span>
                        </button>
                      </div>

                      {/* Right Block Live streaming logs */}
                      <div className="md:col-span-7 flex flex-col space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider font-bold">Execution logs Console</span>
                          {simulationLogs.length > 0 && (
                            <button
                              onClick={() => setSimulationLogs([])}
                              className="text-[10px] text-rose-500 hover:underline font-mono"
                            >
                              Clear Logs
                            </button>
                          )}
                        </div>

                        <div className="flex-1 bg-slate-950 rounded-xl border border-slate-850 p-3 font-mono text-[11px] overflow-y-auto max-h-[220px] md:max-h-[260px] text-left space-y-1.5 shadow-inner" id="sim_logs_dashboard">
                          {simulationLogs.length > 0 ? (
                            simulationLogs.map((log, index) => {
                              let logColor = 'text-slate-400';
                              if (log.type === 'success') logColor = 'text-emerald-400 font-bold';
                              else if (log.type === 'warn') logColor = 'text-amber-400';
                              else if (log.type === 'error') logColor = 'text-rose-400 font-black';

                              return (
                                <div key={index} className="leading-relaxed hover:bg-slate-900/50 p-0.5 rounded transition">
                                  <span className="text-slate-600 mr-1.5 select-none">[{log.timestamp}]</span>
                                  <span className={logColor}>{log.message}</span>
                                </div>
                              );
                            })
                          ) : (
                            <div className="h-full flex flex-col items-center justify-center text-slate-600 text-center space-y-1.5 py-12 select-none">
                              <Terminal className="h-7 w-7 text-slate-800" />
                              <span>Console logs streaming idle</span>
                              <span className="text-[10px] text-slate-700 max-w-[180px]">Adjust values in the request payload, then click Run Simulation.</span>
                            </div>
                          )}
                        </div>
                      </div>

                    </div>

                    {/* Simulation Engine State Visualizer */}
                    {simResultsStore.lastResponse && (
                      <div className="mt-4 p-4 bg-slate-950/80 rounded-xl border border-slate-850 space-y-3 font-mono text-left animate-slide-up" id="sim_results_visualizer">
                        <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Interpreter State Results</div>
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg space-y-0.5">
                            <span className="text-[9px] text-slate-500 block">HTTP Code</span>
                            <span className="text-emerald-400 font-bold font-mono">{simResultsStore.lastResponse.statusCode}</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg space-y-0.5">
                            <span className="text-[9px] text-slate-500 block">Scope Auth</span>
                            <span className="text-emerald-400 font-bold font-mono">
                              {simResultsStore.authenticated ? 'AUTHORIZED ✓' : 'UNAUTHORIZED 🔒'}
                            </span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg space-y-0.5">
                            <span className="text-[9px] text-slate-500 block">FlowStore Inserts</span>
                            <span className="font-bold text-white pr-1 truncate block">
                              {simResultsStore.storedInDb.length} records
                            </span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg space-y-0.5">
                            <span className="text-[9px] text-slate-500 block">Signals Transmitted</span>
                            <span className="text-sky-400 font-bold font-mono">
                              {simResultsStore.broadcastSignals.length} counts
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                )}

              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-500 text-center space-y-2 py-12" id="workbench_fallback">
                <Sparkles className="h-8 w-8 text-slate-700 animate-pulse" />
                <p className="text-xs">Translation Workbench Idle</p>
                <p className="text-[10px] text-slate-600 max-w-xs leading-relaxed">
                  Type custom English or Arabic logic sentence, then click compile to analyze compiler structures.
                </p>
              </div>
            )}
          </div>

        </section>

      </main>

      {/* FOOTER */}
      <footer className="border-t border-indigo-500/10 bg-slate-950/40 py-3 text-center text-slate-600 text-[10px] font-mono tracking-widest max-w-7xl mx-auto w-full flex flex-col md:flex-row items-center justify-between px-4 gap-2 text-slate-500 select-none">
        <div>© 2026 AETHER SYSTEMS CORP. ALL RIGHTS RESERVED.</div>
        <div className="flex space-x-3.5">
          <span className="hover:text-slate-300 cursor-pointer">PRIVACY PROTOCOL</span>
          <span>•</span>
          <span className="hover:text-slate-300 cursor-pointer">SECURE NODE CORE</span>
        </div>
      </footer>

    </div>
  );
}
