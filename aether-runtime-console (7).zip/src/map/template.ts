/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement } from '../runtime/types';

export interface ASTTemplate {
  name: string;
  trigger: string;
  codeSnippet: string;
  ast: Statement[];
}

export const TEMPLATES: Record<string, ASTTemplate> = {
  register: {
    name: 'Secure Registration',
    trigger: 'register',
    codeSnippet: `// 1. Validate the registration request parameters
let user = validate(req, {
  email: "Email.format",
  password: "Password.strong"
});

// 2. Save records safely to Flow users stream databases
emit users.register(user);

// 3. Dispatch a secure welcome notification trigger
emit signal.welcome({ userId: user.id });

// 4. Return Response created status payload
yield Response.created(user);`,
    ast: [
      {
        type: 'LetStatement',
        name: 'user',
        value: {
          type: 'CallExpression',
          callee: 'validate',
          arguments: [
            { type: 'Identifier', name: 'req' },
            {
              type: 'Literal',
              value: {
                email: 'Email.format',
                password: 'Password.strong'
              }
            }
          ]
        }
      },
      {
        type: 'EmitStatement',
        signal: 'users.register',
        data: { type: 'Identifier', name: 'user' }
      },
      {
        type: 'EmitStatement',
        signal: 'signal.welcome',
        data: {
          type: 'Literal',
          value: { userId: 'usr_uuid_new_user' }
        }
      },
      {
        type: 'YieldStatement',
        value: {
          type: 'CallExpression',
          callee: 'AetherResponse.created',
          arguments: [
            { type: 'Identifier', name: 'user' }
          ]
        }
      }
    ]
  },

  login: {
    name: 'Identity Authentication',
    trigger: 'login',
    codeSnippet: `// 1. Parse incoming authentication claims credentials
let loginClaims = validate(req, {
  email: "Email.format"
});

// 2. Compute cryptographically secure hash verification
let sessionKey = hash(loginClaims.email);

// 3. Save session reference and broadcast security handshake
emit security.handshake({ key: sessionKey });

// 4. Yield session signature
yield sessionKey;`,
    ast: [
      {
        type: 'LetStatement',
        name: 'loginClaims',
        value: {
          type: 'CallExpression',
          callee: 'validate',
          arguments: [
            { type: 'Identifier', name: 'req' },
            {
              type: 'Literal',
              value: {
                email: 'Email.format'
              }
            }
          ]
        }
      },
      {
        type: 'LetStatement',
        name: 'sessionKey',
        value: {
          type: 'CallExpression',
          callee: 'hash',
          arguments: [
            { type: 'Identifier', name: 'loginClaims' }
          ]
        }
      },
      {
        type: 'EmitStatement',
        signal: 'security.handshake',
        data: {
          type: 'Literal',
          value: { key: 'sessionKey_placeholder' }
        }
      },
      {
        type: 'YieldStatement',
        value: { type: 'Identifier', name: 'sessionKey' }
      }
    ]
  },

  transaction: {
    name: 'Transactional Checkout',
    trigger: 'transaction',
    codeSnippet: `// 1. Verify payment parameters schema
let payment = validate(req, {
  amount: "Number.positive"
});

// 2. Commit transaction flow to ledger store
emit ledgers.payment(payment);

// 3. Emit billing receipt signal pulse
emit billing.receipt({ amount: payment.amount });

// 4. Response success status
yield Response.success(payment);`,
    ast: [
      {
        type: 'LetStatement',
        name: 'payment',
        value: {
          type: 'CallExpression',
          callee: 'validate',
          arguments: [
            { type: 'Identifier', name: 'req' },
            {
              type: 'Literal',
              value: {
                amount: 'Number.positive'
              }
            }
          ]
        }
      },
      {
        type: 'EmitStatement',
        signal: 'ledgers.payment',
        data: { type: 'Identifier', name: 'payment' }
      },
      {
        type: 'EmitStatement',
        signal: 'billing.receipt',
        data: {
          type: 'Literal',
          value: { amount: 'payment.amount_val' }
        }
      },
      {
        type: 'YieldStatement',
        value: {
          type: 'CallExpression',
          callee: 'AetherResponse.success',
          arguments: [
            { type: 'Identifier', name: 'payment' }
          ]
        }
      }
    ]
  },

  telemetry: {
    name: 'System Telemetry Report',
    trigger: 'telemetry',
    codeSnippet: `// 1. Fetch system timestamps and tokens
let pulseToken = uuid();
let reportTime = now();

// 2. Broadcast diagnostic heartbeat pulses
emit telemetry.pulse({ node: pulseToken, time: reportTime, status: "ONLINE" });

// 3. Return confirmation id
yield pulseToken;`,
    ast: [
      {
        type: 'LetStatement',
        name: 'pulseToken',
        value: {
          type: 'CallExpression',
          callee: 'uuid',
          arguments: []
        }
      },
      {
        type: 'LetStatement',
        name: 'reportTime',
        value: {
          type: 'CallExpression',
          callee: 'now',
          arguments: []
        }
      },
      {
        type: 'EmitStatement',
        signal: 'telemetry.pulse',
        data: {
          type: 'Literal',
          value: { status: 'ONLINE' }
        }
      },
      {
        type: 'YieldStatement',
        value: { type: 'Identifier', name: 'pulseToken' }
      }
    ]
  }
};

/**
 * Retrieves the matching AST template if found for trigger keyword
 */
export function getTemplateForTrigger(trigger: string): ASTTemplate | null {
  const norm = trigger.toLowerCase().trim();
  if (TEMPLATES[norm]) {
    return TEMPLATES[norm];
  }
  return null;
}
