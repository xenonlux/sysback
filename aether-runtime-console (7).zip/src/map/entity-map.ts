/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface EntityTypeInfo {
  aetherType: string;
  defaultValue: any;
  validationSchema?: any;
}

export const ENTITY_MAP: Record<string, EntityTypeInfo> = {
  email: {
    aetherType: 'Email.format',
    defaultValue: 'Email.format',
    validationSchema: { type: 'string', required: true, format: 'email' }
  },
  password: {
    aetherType: 'Password.strong',
    defaultValue: 'Password.strong',
    validationSchema: { type: 'string', required: true, minLength: 8 }
  },
  users: {
    aetherType: 'FlowStore<User>',
    defaultValue: 'flow.users',
    validationSchema: { type: 'object' }
  },
  'signal.welcome': {
    aetherType: 'Signal',
    defaultValue: 'signal.welcome',
  }
};

/**
 * Resolves raw natural language words or entities to standard internal systems definitions
 */
export function resolveEntityInfo(entity: string): EntityTypeInfo {
  const norm = entity.toLowerCase().trim();
  if (ENTITY_MAP[norm]) {
    return ENTITY_MAP[norm];
  }
  
  return {
    aetherType: 'string',
    defaultValue: `{{${entity}}}`
  };
}
