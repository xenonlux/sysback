/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ActionASTMap {
  astType: 'LetStatement' | 'EmitStatement' | 'YieldStatement' | 'IfStatement' | 'FlowStatement';
  description: string;
  defaultCallee?: string;
}

export const ACTION_TO_AST_MAP: Record<string, ActionASTMap> = {
  validate: {
    astType: 'LetStatement',
    description: 'Schema verification check using validate()',
    defaultCallee: 'validate'
  },
  flow: {
    astType: 'EmitStatement',
    description: 'Writes record payload into Flow DB BTree container store',
    defaultCallee: 'flow'
  },
  emit: {
    astType: 'EmitStatement',
    description: 'Dispatches active event pulse to EventBus subscribers',
  },
  yield: {
    astType: 'YieldStatement',
    description: 'Final execution return output',
  }
};

/**
 * Resolves action type category into target statement type
 */
export function getStatementTypeForAction(actionType: string): string {
  const mapInfo = ACTION_TO_AST_MAP[actionType];
  return mapInfo ? mapInfo.astType : 'LetStatement';
}
