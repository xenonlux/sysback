/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExtractedIntent } from '../detect/intent';

/**
 * Returns a list of friendly suggestions when confidence levels drop below 85%
 */
export function generateSuggestions(intent: ExtractedIntent): string[] {
  const suggestions: string[] = [];
  const language = intent.language;

  if (language === 'ar') {
    if (!intent.trigger || intent.trigger === 'telemetry') {
      suggestions.push(
        'عند تسجيل مستخدم جديد، تحقق من البريد والرمز السري، احفظه في تدفق المستخدمين، وأرسل إشارة ترحيب',
        'عند تسجيل الدخول، تحقق من الهوية، خزن الجلسة، وأصدر إشارة ترحيبية'
      );
    } else if (intent.trigger === 'register') {
      suggestions.push(
        'إذا سجل زائر، تحقق من البيانات المطلوبة واحفظ معلومات المستخدم وأرجع استجابة ناجحة',
        'عند التسجيل، تحقق من البريد والرمز السري وسجل المستخدم في مستودع البيانات'
      );
    } else {
      suggestions.push(
        'عند حدوث دفعه، تحقق من صحة المبلغ، احفظه في تدفق الحسابات، وبث إشارة الفاتورة',
        'عند استقبال نبض من النظام، ولد تذكرة تعريف، أطلق إشارة قياس نشطة'
      );
    }
  } else {
    if (!intent.trigger || intent.trigger === 'telemetry') {
      suggestions.push(
        'When a user registers, validate their email and password, save them to the users stream, and send a welcome signal',
        'On login, validate email and password, and return session token'
      );
    } else if (intent.trigger === 'register') {
      suggestions.push(
        'On registration, validate email format and password strength, write user flow, and return Response.created',
        'If guest registers, validate req details and save user info'
      );
    } else if (intent.trigger === 'login') {
      suggestions.push(
        'When user logins, validate credentials, hash session keys, and emit security.handshake',
        'On admin authenticates, check security claims, write session state, and dispatch login signal'
      );
    } else {
      suggestions.push(
        'On transaction occurs, validate payment positive amount, save to ledger, and emit billing.receipt',
        'When pulse received, fetch uuid, emit telemetry.pulse online status, and yield heartbeat'
      );
    }
  }

  return Array.from(new Set(suggestions));
}
