/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExtractedIntent } from '../detect/intent';

/**
 * Computes a translation confidence score (10% to 98%) for the mapped intents
 */
export function calculateConfidence(intent: ExtractedIntent, originalText: string): number {
  if (!originalText || originalText.trim().length < 5) {
    return 10;
  }

  let score = 20;

  if (intent.trigger) {
    score += 25;
  }

  const actionCount = intent.actions.length;
  if (actionCount > 0) {
    score += Math.min(actionCount * 15, 30);
  }

  const entityCount = intent.entities.length;
  if (entityCount > 0) {
    score += Math.min(entityCount * 10, 20);
  }

  const markers = ['when', 'if', 'on', 'registers', 'عند', 'إذا', 'تحقق', 'احفظ', 'تسجيل'];
  let markerMatches = 0;
  markers.forEach(m => {
    if (originalText.toLowerCase().includes(m)) {
      markerMatches++;
    }
  });

  if (markerMatches > 0) {
    score += Math.min(markerMatches * 5, 15);
  }

  const finalScore = Math.max(10, Math.min(98, score));
  return Math.round(finalScore);
}
