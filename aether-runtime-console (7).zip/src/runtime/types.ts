/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LiteralExpression {
  type: 'Literal';
  value: any;
}

export interface IdentifierExpression {
  type: 'Identifier';
  name: string;
}

export interface CallExpression {
  type: 'CallExpression';
  callee: string;
  arguments: Expression[];
}

export type Expression = LiteralExpression | IdentifierExpression | CallExpression;

export interface LetStatement {
  type: 'LetStatement';
  name: string;
  value: Expression;
}

export interface EmitStatement {
  type: 'EmitStatement';
  signal: string;
  data: Expression;
}

export interface YieldStatement {
  type: 'YieldStatement';
  value: Expression;
}

export interface IfStatement {
  type: 'IfStatement';
  condition: Expression;
  consequent: Statement[];
}

export type Statement = LetStatement | EmitStatement | YieldStatement | IfStatement;
