/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface NLPattern {
  id: string;
  lang: 'en' | 'ar';
  category: 'trigger' | 'action' | 'entity';
  keywords: string[]; // Root roots or stems
  phrases?: string[];  // Multi-word phrase matches
  mappedValue: string;
}

export const PATTERN_LIBRARY: NLPattern[] = [
  // Triggers
  {
    id: 'trig_register',
    lang: 'en',
    category: 'trigger',
    keywords: ['register', 'registration', 'signup', 'create', 'enroll'],
    phrases: ['user registers', 'registers', 'creates account', 'when a user registers', 'customer enrolls', 'signup occurs'],
    mappedValue: 'register'
  },
  {
    id: 'trig_register_ar',
    lang: 'ar',
    category: 'trigger',
    keywords: ['تسجيل', 'مستخدم', 'تسجل', 'جديد', 'حساب', 'انشاء'],
    phrases: ['تسجيل مستخدم', 'انشاء حساب', 'عند تسجيل', 'تسجيل جديد', 'إنشاء حساب', 'يسجل العميل', 'سجل زائر'],
    mappedValue: 'register'
  },
  {
    id: 'trig_login',
    lang: 'en',
    category: 'trigger',
    keywords: ['login', 'signin', 'authenticate', 'verify', 'claims'],
    phrases: ['user login', 'logins', 'signs in', 'authenticates', 'client signs in', 'admin authenticates'],
    mappedValue: 'login'
  },
  {
    id: 'trig_login_ar',
    lang: 'ar',
    category: 'trigger',
    keywords: ['دخول', 'ولوج', 'تحقق', 'هويه', 'مشرف'],
    phrases: ['تسجيل دخول', 'تحقق هويه', 'عند الدخول', 'تسجيل الولوج', 'تحقق المشرف'],
    mappedValue: 'login'
  },
  {
    id: 'trig_transaction',
    lang: 'en',
    category: 'trigger',
    keywords: ['transaction', 'payment', 'checkout', 'pay', 'purchase'],
    phrases: ['user pays', 'transaction occurs', 'checkout request', 'payment request', 'checkout payment', 'user purchases', 'final checkout'],
    mappedValue: 'transaction'
  },
  {
    id: 'trig_transaction_ar',
    lang: 'ar',
    category: 'trigger',
    keywords: ['دفع', 'عمليه', 'شراء', 'مبلغ'],
    phrases: ['عمليه دفع', 'عند الشراء', 'طلب شراء', 'حدوث دفعه', 'تأكيد البيع'],
    mappedValue: 'transaction'
  },
  {
    id: 'trig_telemetry',
    lang: 'en',
    category: 'trigger',
    keywords: ['telemetry', 'ping', 'pulse', 'report', 'fail', 'error'],
    phrases: ['telemetry occurs', 'ping received', 'pulse received', 'ping arrives', 'server fails', 'critical alarm'],
    mappedValue: 'telemetry'
  },
  {
    id: 'trig_telemetry_ar',
    lang: 'ar',
    category: 'trigger',
    keywords: ['نبض', 'قياس', 'اتصال', 'فحص', 'فشل'],
    phrases: ['ارسال نبض', 'تقرير قياس', 'قياس عن بعد', 'استقبال نبض', 'ورد طلب فحص', 'فشل الاتصال'],
    mappedValue: 'telemetry'
  },

  // Actions
  {
    id: 'act_validate',
    lang: 'en',
    category: 'action',
    keywords: ['validate', 'validation', 'verify', 'check', 'ensure', 'authorize'],
    phrases: ['validate email and password', 'validate fields', 'validate their', 'check credentials', 'validate email format', 'validate req details'],
    mappedValue: 'validate'
  },
  {
    id: 'act_validate_ar',
    lang: 'ar',
    category: 'action',
    keywords: ['تحقق', 'تاكد', 'دقق', 'فحص', 'تأكد'],
    phrases: ['التحقق من', 'تاكد من', 'تحقق من البريد', 'دقق في', 'تأكد من بريد', 'فحص ذاتي'],
    mappedValue: 'validate'
  },
  {
    id: 'act_save',
    lang: 'en',
    category: 'action',
    keywords: ['save', 'store', 'insert', 'write', 'flow', 'record'],
    phrases: ['save them', 'save user', 'store in stream', 'flow to', 'save user info', 'write user flow', 'save to ledger', 'flow record to'],
    mappedValue: 'flow'
  },
  {
    id: 'act_save_ar',
    lang: 'ar',
    category: 'action',
    keywords: ['احفظ', 'خزن', 'سجل', 'اكتب', 'تدفق', 'كب'],
    phrases: ['احفظه في', 'سجل في', 'كتابه في', 'خزن في', 'اكتب البيانات', 'سجل المستخدم', 'خزن معلومات'],
    mappedValue: 'flow'
  },
  {
    id: 'act_emit',
    lang: 'en',
    category: 'action',
    keywords: ['emit', 'send', 'broadcast', 'dispatch', 'signal', 'alert'],
    phrases: ['emit signal', 'send welcome', 'broadcast welcome', 'dispatch login', 'emit billing', 'send priority', 'broadcast metrics'],
    mappedValue: 'emit'
  },
  {
    id: 'act_emit_ar',
    lang: 'ar',
    category: 'action',
    keywords: ['ارسل', 'أرسل', 'اصدر', 'أطلق', 'بث', 'اشاره', 'اشارة'],
    phrases: ['ارسال اشاره', 'بث نبض', 'اصدار اشاره', 'أرسل إشارة', 'أطلق إشارة', 'أرسل ترحيب', 'بث إشارة', 'أطلق تحذيراً'],
    mappedValue: 'emit'
  },
  {
    id: 'act_yield',
    lang: 'en',
    category: 'action',
    keywords: ['yield', 'return', 'respond', 'give'],
    phrases: ['yield response', 'return success', 'yield created', 'return status', 'respond with'],
    mappedValue: 'yield'
  },
  {
    id: 'act_yield_ar',
    lang: 'ar',
    category: 'action',
    keywords: ['ارجع', 'أرجع', 'اعد', 'أعد', 'اعط', 'استجابه', 'سلم'],
    phrases: ['اعد استجابه', 'ارجاع استجابه', 'تسليم ناتج', 'أرجع الاستجابة', 'أرجع Response'],
    mappedValue: 'yield'
  },

  // Entities
  {
    id: 'ent_users_stream',
    lang: 'en',
    category: 'entity',
    keywords: ['users', 'user', 'stream', 'table'],
    phrases: ['users stream', 'user flow', 'user stream', 'users collection', 'users table'],
    mappedValue: 'users'
  },
  {
    id: 'ent_users_stream_ar',
    lang: 'ar',
    category: 'entity',
    keywords: ['مستخدم', 'تدفق', 'مستودع', 'جدول'],
    phrases: ['تدفق المستخدمين', 'مخزن مستخدمين', 'جدول المستخدمين', 'تدفق مستخدمين'],
    mappedValue: 'users'
  },
  {
    id: 'ent_email',
    lang: 'en',
    category: 'entity',
    keywords: ['email', 'email.format', 'username'],
    phrases: ['email format', 'valid email', 'user email', 'username and password'],
    mappedValue: 'email'
  },
  {
    id: 'ent_email_ar',
    lang: 'ar',
    category: 'entity',
    keywords: ['بريد', 'الكتروني', 'عنوان', 'ايميل'],
    phrases: ['البريد الالكتروني', 'عنوان بريد', 'البريد والكلمه', 'الإيميل والرمز', 'البريد الإلكتروني'],
    mappedValue: 'email'
  },
  {
    id: 'ent_password',
    lang: 'en',
    category: 'entity',
    keywords: ['password', 'password.strong', 'strength'],
    phrases: ['strong password', 'password strength'],
    mappedValue: 'password'
  },
  {
    id: 'ent_password_ar',
    lang: 'ar',
    category: 'entity',
    keywords: ['كلمه', 'سر', 'مرور', 'رمز'],
    phrases: ['الكلمه السريه', 'كلمه المرور', 'كلمه السر', 'الرمز السري'],
    mappedValue: 'password'
  },
  {
    id: 'ent_welcome_signal',
    lang: 'en',
    category: 'entity',
    keywords: ['welcome', 'signal.welcome', 'greet', 'receipt', 'billing.receipt', 'pulseToken', 'sessionKey'],
    phrases: ['welcome signal', 'greeting signal', 'onboarding greet', 'billing receipt', 'security handshake'],
    mappedValue: 'signal.welcome'
  },
  {
    id: 'ent_welcome_signal_ar',
    lang: 'ar',
    category: 'entity',
    keywords: ['ترحيب', 'اشاره', 'ترحيبيه', 'فاتورة', 'فاتوره', 'رمز'],
    phrases: ['اشاره ترحيب', 'رساله ترحيب', 'نبضه الترحيب', 'إشارة الفاتورة', 'إشارة ترحيبية'],
    mappedValue: 'signal.welcome'
  }
];

export const TRIGGER_MARKERS = {
  en: ['when', 'if', 'on', 'whenever'],
  ar: ['عند', 'اذا', 'إذا', 'في حال', 'عندما']
};
