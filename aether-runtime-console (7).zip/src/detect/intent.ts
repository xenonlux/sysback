/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { tokenizeText } from './tokenizer';
import { PATTERN_LIBRARY, TRIGGER_MARKERS } from './patterns';

export interface ExtractedAction {
  actionType: string;       // e.g. 'validate', 'flow', 'emit', 'yield'
  actionOriginal: string;   // Original word as typed
  entities: string[];       // Entities associated with this action
}

export interface ExtractedIntent {
  trigger: string | null;         // Action trigger name, e.g. 'register'
  triggerPhrase: string | null;   // Matched phrase
  actions: ExtractedAction[];
  entities: string[];             // Global list of entities found
  language: 'en' | 'ar';
}

/**
 * Stage 1: Detects and extracts trigger, actions and entities from bilingual text
 */
export function extractIntent(text: string): ExtractedIntent {
  if (!text) {
    return { trigger: null, triggerPhrase: null, actions: [], entities: [], language: 'en' };
  }
  const tokens = tokenizeText(text);
  const normalizedText = text.toLowerCase();

  // 1. Determine dominant language
  let arCount = 0;
  let enCount = 0;
  tokens.forEach(tok => {
    if (tok.lang === 'ar') arCount++;
    else if (tok.lang === 'en' && !tok.isPunctuation) enCount++;
  });
  const language: 'en' | 'ar' = arCount > enCount ? 'ar' : 'en';

  // 2. Identify the Trigger
  let trigger: string | null = null;
  let triggerPhrase: string | null = null;

  const triggerPatterns = PATTERN_LIBRARY.filter(p => p.category === 'trigger');
  
  // Sort phrases by length descending to match longest first
  const sortedPatterns = [...triggerPatterns].sort((a, b) => {
    const aLen = a.phrases?.reduce((max, s) => Math.max(max, s.length), 0) || 0;
    const bLen = b.phrases?.reduce((max, s) => Math.max(max, s.length), 0) || 0;
    return bLen - aLen;
  });

  // Phrase matching
  for (const pattern of sortedPatterns) {
    if (pattern.phrases) {
      for (const phrase of pattern.phrases) {
        if (normalizedText.includes(phrase.toLowerCase())) {
          trigger = pattern.mappedValue;
          triggerPhrase = phrase;
          break;
        }
      }
    }
    if (trigger) break;
  }

  // Keyword stem fallback
  if (!trigger) {
    for (const pattern of triggerPatterns) {
      const hasWord = tokens.some(tok => pattern.keywords.includes(tok.stem) || pattern.keywords.includes(tok.normalized));
      if (hasWord) {
        trigger = pattern.mappedValue;
        triggerPhrase = pattern.keywords[0];
        break;
      }
    }
  }

  // Final fallback based on conditional starter words
  if (!trigger) {
    const hasTriggerMarker = tokens.some(tok => 
      TRIGGER_MARKERS.en.includes(tok.normalized) || TRIGGER_MARKERS.ar.includes(tok.normalized)
    );
    if (hasTriggerMarker) {
      trigger = 'register';
      triggerPhrase = language === 'en' ? 'when' : 'عند';
    }
  }

  // 3. Find Global Entities
  const matchedEntities: { value: string; index: number; original: string }[] = [];
  const entityPatterns = PATTERN_LIBRARY.filter(p => p.category === 'entity');

  entityPatterns.forEach(pattern => {
    let foundPhrase = false;
    if (pattern.phrases) {
      for (const phrase of pattern.phrases) {
        const idx = normalizedText.indexOf(phrase.toLowerCase());
        if (idx !== -1) {
          matchedEntities.push({
            value: pattern.mappedValue,
            index: idx,
            original: phrase
          });
          foundPhrase = true;
          break;
        }
      }
    }

    if (!foundPhrase) {
      tokens.forEach((tok, tokIdx) => {
        if (pattern.keywords.includes(tok.stem) || pattern.keywords.includes(tok.normalized)) {
          const wordIndex = text.toLowerCase().indexOf(tok.original.toLowerCase());
          matchedEntities.push({
            value: pattern.mappedValue,
            index: wordIndex !== -1 ? wordIndex : tokIdx * 5,
            original: tok.original
          });
        }
      });
    }
  });

  const uniqueEntities = Array.from(new Set(matchedEntities.map(e => e.value)));

  // 4. Extract Actions chronologically
  const actionPatterns = PATTERN_LIBRARY.filter(p => p.category === 'action');
  const actionPositions: { actionType: string; index: number; length: number; original: string }[] = [];

  actionPatterns.forEach(pattern => {
    let matchedInText = false;
    if (pattern.phrases) {
      for (const phrase of pattern.phrases) {
        let pos = normalizedText.indexOf(phrase.toLowerCase());
        while (pos !== -1) {
          actionPositions.push({
            actionType: pattern.mappedValue,
            index: pos,
            length: phrase.length,
            original: phrase
          });
          matchedInText = true;
          pos = normalizedText.indexOf(phrase.toLowerCase(), pos + 1);
        }
      }
    }

    if (!matchedInText) {
      tokens.forEach(tok => {
        if (pattern.keywords.includes(tok.stem) || pattern.keywords.includes(tok.normalized)) {
          const pos = text.toLowerCase().indexOf(tok.original.toLowerCase());
          if (pos !== -1) {
            actionPositions.push({
              actionType: pattern.mappedValue,
              index: pos,
              length: tok.original.length,
              original: tok.original
            });
          }
        }
      });
    }
  });

  // Sort and deduplicate action positions
  const sortedActions = actionPositions
    .sort((a, b) => a.index - b.index)
    .filter((v, i, self) => self.findIndex(t => t.actionType === v.actionType && Math.abs(t.index - v.index) < 5) === i);

  const actions: ExtractedAction[] = [];
  
  sortedActions.forEach((act, actIdx) => {
    const nextActPos = sortedActions[actIdx + 1] ? sortedActions[actIdx + 1].index : Infinity;
    
    // Entity grouping
    const segmentEntities = matchedEntities
      .filter(ent => ent.index >= act.index && ent.index < nextActPos)
      .map(ent => ent.value);

    // Context enrichments
    if (segmentEntities.length === 0) {
      if (act.actionType === 'validate') {
        if (uniqueEntities.includes('email')) segmentEntities.push('email');
        if (uniqueEntities.includes('password')) segmentEntities.push('password');
      } else if (act.actionType === 'flow') {
        if (uniqueEntities.includes('users')) segmentEntities.push('users');
      } else if (act.actionType === 'emit') {
        if (uniqueEntities.includes('signal.welcome')) segmentEntities.push('signal.welcome');
      }
    }

    const uniqueSegmentEntities = Array.from(new Set(segmentEntities));

    actions.push({
      actionType: act.actionType,
      actionOriginal: act.original,
      entities: uniqueSegmentEntities
    });
  });

  // Default Action Sequence Pipeline fallback
  if (actions.length === 0) {
    if (trigger === 'register') {
      actions.push(
        { actionType: 'validate', actionOriginal: language === 'en' ? 'validate' : 'تحقق', entities: ['email', 'password'] },
        { actionType: 'flow', actionOriginal: language === 'en' ? 'save' : 'احفظ', entities: ['users'] },
        { actionType: 'emit', actionOriginal: language === 'en' ? 'send welcome' : 'أرسل ترحيب', entities: ['signal.welcome'] },
        { actionType: 'yield', actionOriginal: language === 'en' ? 'yield' : 'ارجع', entities: [] }
      );
    } else if (trigger === 'login') {
      actions.push(
        { actionType: 'validate', actionOriginal: language === 'en' ? 'validate' : 'تحقق', entities: ['email'] },
        { actionType: 'emit', actionOriginal: language === 'en' ? 'sessionKey' : 'مفتاح الجلسة', entities: ['signal.welcome'] },
        { actionType: 'yield', actionOriginal: language === 'en' ? 'yield' : 'ارجع', entities: [] }
      );
    } else if (trigger === 'transaction') {
      actions.push(
        { actionType: 'validate', actionOriginal: language === 'en' ? 'validate' : 'تحقق', entities: [] },
        { actionType: 'flow', actionOriginal: language === 'en' ? 'save' : 'احفظ', entities: [] },
        { actionType: 'emit', actionOriginal: language === 'en' ? 'emit billing' : 'بث فاتورة', entities: [] },
        { actionType: 'yield', actionOriginal: language === 'en' ? 'yield' : 'تحويل', entities: [] }
      );
    } else {
      actions.push(
        { actionType: 'validate', actionOriginal: language === 'en' ? 'ping' : 'نبض', entities: [] },
        { actionType: 'yield', actionOriginal: language === 'en' ? 'return' : 'تحصيل', entities: [] }
      );
    }
  }

  return {
    trigger: trigger || 'telemetry',
    triggerPhrase,
    actions,
    entities: uniqueEntities,
    language
  };
}
