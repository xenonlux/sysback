/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface WordToken {
  original: string;
  normalized: string;
  stem: string;
  lang: 'en' | 'ar';
  isPunctuation: boolean;
}

/**
 * Normalizes Arabic characters to simplify matching across spelling variations
 */
export function normalizeArabic(text: string): string {
  return text
    // Replace Alef variations with bare Alef
    .replace(/[أإآٱ]/g, 'ا')
    // Normalise Teh Marbuta to Heh
    .replace(/ة/g, 'ه')
    // Normalise Yeo / Alif Maksura to Yeh
    .replace(/ى/g, 'ي')
    // Remove Arabic diacritics (harakat/tasgkeel)
    .replace(/[\u064B-\u065F]/g, '');
}

/**
 * Strips common Arabic morphological prefixes and suffixes
 */
export function stemArabicWord(word: string): string {
  let normalized = normalizeArabic(word);

  const prefixes = [
    'وبال', 'وفال', 'وب', 'وف', 'وال', 'ال', 'لل', 'ب', 'ف', 'و', 'l'
  ];

  for (const prefix of prefixes) {
    if (normalized.startsWith(prefix) && normalized.length > prefix.length + 2) {
      const stripped = normalized.substring(prefix.length);
      if (stripped.length >= 3) {
        normalized = stripped;
        break;
      }
    }
  }

  const suffixes = ['هم', 'نا', 'كم', 'ه'];
  for (const suffix of suffixes) {
    if (normalized.endsWith(suffix) && normalized.length > suffix.length + 2) {
      const stripped = normalized.substring(0, normalized.length - suffix.length);
      if (stripped.length >= 3) {
        normalized = stripped;
        break;
      }
    }
  }

  return normalized;
}

/**
 * Lightweight English suffix stemmer
 */
export function stemEnglishWord(word: string): string {
  let w = word.toLowerCase().trim();
  if (w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us')) {
    w = w.slice(0, -1);
  }
  if (w.endsWith('ing')) {
    w = w.slice(0, -3);
  }
  if (w.endsWith('ed')) {
    w = w.slice(0, -2);
  }
  return w;
}

/**
 * Tokenizes plain text inputs into bilingual word objects
 */
export function tokenizeText(text: string): WordToken[] {
  if (!text) return [];

  const words = text.match(/[\u0600-\u06FF\w\-\.]+|\S+/g) || [];

  return words.map(rawWord => {
    const isPunct = /^[^\u0600-\u06FF\w]+$/.test(rawWord);
    const isArabic = /[\u0600-\u06FF]/.test(rawWord);
    const lang: 'en' | 'ar' = isArabic ? 'ar' : 'en';

    let normalized = rawWord;
    let stem = rawWord;

    if (!isPunct) {
      if (lang === 'ar') {
        normalized = normalizeArabic(rawWord);
        stem = stemArabicWord(rawWord);
      } else {
        normalized = rawWord.toLowerCase();
        stem = stemEnglishWord(rawWord);
      }
    }

    return {
      original: rawWord,
      normalized,
      stem,
      lang,
      isPunctuation: isPunct
    };
  });
}
