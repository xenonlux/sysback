#!/usr/bin/env node
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Command } from 'commander';
import {
  runCommand,
  buildCommand,
  checkCommand,
  replCommand,
  newCommand,
  listStreamsCommand,
  killStreamCommand,
  inspectFlowCommand
} from './commands';

const program = new Command();

program
  .name('aether')
  .description('AETHER Command Line Interface - Autonomous compile & stream engine CLI')
  .version('1.0.0');

// 1. aether run <file.ae>
program
  .command('run')
  .description('Execute an Aether language file in the virtual browser/node sandbox runtime')
  .argument('<file>', 'Paths to the custom .ae file')
  .action((file) => {
    runCommand(file);
  });

// 2. aether build <file.ae>
program
  .command('build')
  .description('Compile and compile .ae source code into optimized standard.js')
  .argument('<file>', 'Paths to Aether source file')
  .action((file) => {
    buildCommand(file);
  });

// 3. aether check <file.ae>
program
  .command('check')
  .description('Performs static semantic parsing and type validations')
  .argument('<file>', 'Paths to .ae source file')
  .action((file) => {
    checkCommand(file);
  });

// 4. aether repl
program
  .command('repl')
  .description('Boots up a responsive prompt interaction terminal (REPL)')
  .action(() => {
    replCommand();
  });

// 5. aether new <name>
program
  .command('new')
  .description('Scaffolds and sets up a clean new Aether microservice project skeleton')
  .argument('<name>', 'Directory folder name')
  .action((name) => {
    newCommand(name);
  });

// 6. Subcommand structure: aether stream [ls / kill]
const streamGroup = program
  .command('stream')
  .description('Inspect, monitor, or manage active reactive signals registries');

streamGroup
  .command('ls')
  .description('Lists running/active streams on the EventBus network')
  .action(() => {
    listStreamsCommand();
  });

streamGroup
  .command('kill')
  .description('Gracefully tears down or stops an active signal handler thread')
  .argument('<name>', 'Signal signal identity or process ID (PID)')
  .action((name) => {
    killStreamCommand(name);
  });

// 7. Subcommand structure: aether flow inspect <store>
const flowGroup = program
  .command('flow')
  .description('Inspect persistent B-Tree ledger data structures');

flowGroup
  .command('inspect')
  .description('Dump active snapshots inside a specific collection or B-tree key store')
  .argument('<store>', 'Store namespace identification to dump (e.g. telemetry, ledger)')
  .action((store) => {
    inspectFlowCommand(store);
  });

program.parse(process.argv);
