/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';
import { parseAetherCode } from './parser';
import { JSEmitter } from '../../../src/compiler/js-emit';
import { Environment } from '../../../src/runtime/environment';
import { EventBus } from '../../../src/runtime/event-bus';
import { hash, sign, verify, uuid, now } from '../../../src/builtins/crypto';
import { validate } from '../../../src/builtins/validate';

// Static simulation list representing standard processes
const RUNNING_STREAMS = [
  { pid: 1042, signal: 'telemetry.pulse', rate: '2.4 ev/s', throughput: '412 bps', active: true },
  { pid: 1089, signal: 'network.ingress', rate: '12.0 ev/s', throughput: '2.1 Kbps', active: true },
  { pid: 2011, signal: 'auth.handshake', rate: '0.1 ev/s', throughput: '92 bps', active: true },
  { pid: 2190, signal: 'vault.ledger.write', rate: '0.0 ev/s', throughput: '0 bps', active: false }
];

// Mock flow database inspection record
const FLOW_DATA_STORES: Record<string, any> = {
  telemetry: {
    meta: { btreeDepth: 2, size: 4 },
    records: [
      { id: 'usr_001', cpu: 12, memory: 54, status: 'STABLE' },
      { id: 'usr_002', cpu: 44, memory: 56, status: 'STABLE' },
      { id: 'usr_003', cpu: 8, memory: 52, status: 'IDLE' }
    ]
  },
  ledger: {
    meta: { btreeDepth: 1, size: 2 },
    records: [
      { tx: 'tx_8d7f', amount: 150.0, method: 'DilithiumSignatureVerification' },
      { tx: 'tx_7c9d', amount: 2000.0, method: 'KyberKeyAgreement' }
    ]
  }
};

/**
 * Commands: Run an Aether script file
 */
export async function runCommand(filePath: string) {
  console.log(`\x1b[35m[AETHER CLI]\x1b[0m Evaluating: \x1b[36m${filePath}\x1b[0m...`);
  try {
    const fullPath = path.resolve(filePath);
    if (!fs.existsSync(fullPath)) {
      console.error(`\x1b[31m[Error] File not found: ${filePath}\x1b[0m`);
      return;
    }

    const source = fs.readFileSync(fullPath, 'utf-8');
    const statements = parseAetherCode(source);
    
    // Compile
    const emitter = new JSEmitter();
    const compiledJs = emitter.emit(statements);

    // Prepare execution context
    const env = new Environment();
    const eventBus = new EventBus();
    const builtins = { hash, sign, verify, uuid, now, validate };

    // Print Abstract syntax evaluation
    console.log(`\x1b[32m✔ Parsed file success (Statements: ${statements.length})\x1b[0m`);
    console.log(`\x1b[90mExecuting compiled VM pipeline instructions...\x1b[0m\n`);

    // Intercept emit events to log them to stdout
    eventBus.subscribeAll((evt) => {
      console.log(`\x1b[90m[Signal Emitted] -> "${evt.signal}" payload:\x1b[0m`, evt.data);
    });

    // Execute Compiled Bytecode Function
    const executeFunc = new Function('env', 'eventBus', 'builtins', compiledJs);
    const result = await executeFunc(env, eventBus, builtins);

    console.log(`\n\x1b[35m[AETHER] Completed execution cleanly!\x1b[0m`);
    console.log(`\x1b[1mReturned/Yielded Yield:\x1b[0m`, result);
    console.log(`\x1b[1mAvailable Memory Variables:\x1b[0m`, env.getLocalBinds());

  } catch (err: any) {
    console.error(`\x1b[31m[Execution Error] ${err.message}\x1b[0m`);
  }
}

/**
 * Commands: Compile Aether file to raw optimized Javascript
 */
export function buildCommand(filePath: string) {
  try {
    const fullPath = path.resolve(filePath);
    if (!fs.existsSync(fullPath)) {
      console.error(`\x1b[31mError: File not found: ${filePath}\x1b[0m`);
      return;
    }

    console.log(`\x1b[35m[AETHER Compiler]\x1b[0m Compiling \x1b[36m${filePath}\x1b[0m...`);
    const source = fs.readFileSync(fullPath, 'utf-8');
    const statements = parseAetherCode(source);
    
    const emitter = new JSEmitter();
    const compiledCode = emitter.emit(statements);

    const outPath = fullPath.replace(/\.ae$/, '.js');
    fs.writeFileSync(outPath, compiledCode);

    console.log(`\n\x1b[32m✔ Built successfully! JavaScript written to:\x1b[0m`);
    console.log(`\x1b[36m→ ${outPath}\x1b[0m`);
  } catch (err: any) {
    console.error(`\x1b[31m[Compile Error] ${err.message}\x1b[0m`);
  }
}

/**
 * Commands: Typecheck / Validate code
 */
export function checkCommand(filePath: string) {
  try {
    const fullPath = path.resolve(filePath);
    if (!fs.existsSync(fullPath)) {
      console.error(`\x1b[31mError: File not found: ${filePath}\x1b[0m`);
      return;
    }

    console.log(`\x1b[35m[Static Analyzer]\x1b[0m Analyzing \x1b[36m${filePath}\x1b[0m...`);
    const source = fs.readFileSync(fullPath, 'utf-8');
    const statements = parseAetherCode(source);

    // Simulated static checking
    const declaredVars = new Set<string>();
    let validationFailed = false;

    for (const stmt of statements) {
      if (stmt.type === 'LetStatement') {
        declaredVars.add(stmt.name);
      } else if (stmt.type === 'YieldStatement' || stmt.type === 'ExpressionStatement') {
        const checkExpr = (expr: any) => {
          if (expr.type === 'Identifier') {
            const forbidden = ['now', 'sign', 'verify', 'uuid', 'validate', 'hash'];
            if (!declaredVars.has(expr.name) && !forbidden.includes(expr.name)) {
              console.warn(`\x1b[31m[Linter Warning] Variable "${expr.name}" used but not defined.\x1b[0m`);
              validationFailed = true;
            }
          } else if (expr.type === 'CallExpression') {
            expr.arguments.forEach(checkExpr);
          } else if (expr.type === 'BinaryExpression') {
            checkExpr(expr.left);
            checkExpr(expr.right);
          }
        };
        const statementExpr = stmt.type === 'YieldStatement' ? stmt.value : stmt.expression;
        checkExpr(statementExpr);
      }
    }

    if (!validationFailed) {
      console.log(`\x1b[32m✔ Verification Complete: No syntax or type errors found in ${filePath}!\x1b[0m`);
    } else {
      console.log(`\x1b[33m⚠ Static analysis resolved with diagnostics recommendations.\x1b[0m`);
    }

  } catch (err: any) {
    console.error(`\x1b[31m[Linting Syntax Error] ${err.message}\x1b[0m`);
  }
}

/**
 * Commands: Run continuous interactive REPL terminal shell
 */
export function replCommand() {
  console.log(`\n\x1b[35m=== AETHER REPL (Read-Eval-Print-Loop) v1.0.0 ===\x1b[0m`);
  console.log(`Type AETHER statements. Type ".exit" or ".quit" to exit.`);
  console.log(`Type ".env" to list all variables in memory environment.\n`);

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: '\x1b[35mae>\x1b[0m '
  });

  const env = new Environment();
  const eventBus = new EventBus();
  const builtins = { hash, sign, verify, uuid, now, validate };
  const emitter = new JSEmitter();

  rl.prompt();

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (trimmed === '.exit' || trimmed === '.quit') {
      rl.close();
      return;
    }

    if (trimmed === '.env') {
      console.log(env.getLocalBinds());
      rl.prompt();
      return;
    }

    if (!trimmed) {
      rl.prompt();
      return;
    }

    try {
      // Append semi if missing
      const inputCode = trimmed.endsWith(';') ? trimmed : trimmed + ';';
      const statements = parseAetherCode(inputCode);
      
      const compiled = emitter.emit(statements);
      const exe = new Function('env', 'eventBus', 'builtins', compiled);
      const res = await exe(env, eventBus, builtins);

      if (res !== undefined && res !== null) {
        console.log(`\x1b[32mYield:\x1b[0m`, res);
      }
    } catch (err: any) {
      console.error(`\x1b[31mError: ${err.message}\x1b[0m`);
    }
    rl.prompt();
  }).on('close', () => {
    console.log('\nExiting AETHER REPL. Bye!');
    process.exit(0);
  });
}

/**
 * Commands: Scaffold new AETHER service templates
 */
export function newCommand(name: string) {
  console.log(`Scaffolding a new AETHER project template: \x1b[35m${name}\x1b[0m...`);
  try {
    const rootDir = path.resolve(name);
    if (fs.existsSync(rootDir)) {
      console.error(`\x1b[31mError: Directory already exists at ${rootDir}\x1b[0m`);
      return;
    }

    fs.mkdirSync(rootDir);
    fs.mkdirSync(path.join(rootDir, 'src'));

    // Starter Handshake Aethe Code
    const aetherCode = `// AETHER Secure Handshake Server Configuration
let claims = {
  uid: "usr_node_01",
  server: "${name}",
  roles: ["NODE_CONTROLLER"]
};

let passphrase = "aether-secure-channel-vault-token";
let secureToken = sign(claims, passphrase);
let verifiedPayload = verify(secureToken, passphrase);

emit "auth.handshake" { token: secureToken, verified: true };
yield verifiedPayload;
`;

    // package.json template
    const packageJson = {
      name,
      version: '1.0.0',
      description: 'An AETHER custom service package node',
      main: 'src/main.ae',
      dependencies: {
        "@aether/language": "^1.0.0",
        "@aether/runtime": "^1.0.0"
      }
    };

    fs.writeFileSync(path.join(rootDir, 'src', 'main.ae'), aetherCode);
    fs.writeFileSync(path.join(rootDir, 'package.json'), JSON.stringify(packageJson, null, 2));

    console.log(`\n\x1b[32m✔ Project created successfully at ./${name}!\x1b[0m`);
    console.log(`  Directories created:`);
    console.log(`    - ./${name}/package.json  (dependencies checklist)`);
    console.log(`    - ./${name}/src/main.ae    (starter secure handshake code)`);
    console.log(`\nRun \x1b[1maether run ./${name}/src/main.ae\x1b[0m to test it!`);

  } catch (err: any) {
    console.error(`\x1b[31mError creating workspace: ${err.message}\x1b[0m`);
  }
}

/**
 * Commands: Streams actions (list, kill)
 */
export function listStreamsCommand() {
  console.log(`\n\x1b[35m=== RUNNING STREAM PIPELINES ===\x1b[0m`);
  console.log(`${'PID'.padEnd(8)}${'SIGNAL/STREAM NAME'.padEnd(25)}${'EVENT RATE'.padEnd(15)}${'THROUGHPUT'.padEnd(15)}${'STATUS'}`);
  console.log('-'.repeat(72));

  RUNNING_STREAMS.forEach(stream => {
    const statusText = stream.active ? '\x1b[32mONLINE\x1b[0m' : '\x1b[90mSUSPENDED\x1b[0m';
    console.log(
      `${stream.pid.toString().padEnd(8)}` +
      `${stream.signal.padEnd(25)}` +
      `${stream.rate.padEnd(15)}` +
      `${stream.throughput.padEnd(15)}` +
      `${statusText}`
    );
  });
  console.log();
}

export function killStreamCommand(name: string) {
  console.log(`Shutting down active stream processor for signal: \x1b[31m"${name}"\x1b[0m...`);
  
  const stream = RUNNING_STREAMS.find(s => s.signal === name || s.pid.toString() === name);
  if (stream) {
    stream.active = false;
    stream.rate = '0.0 ev/s';
    stream.throughput = '0 bps';
    console.log(`\x1b[32m✔ Signal thread ID [${stream.pid}] terminated cleanly.\x1b[0m`);
  } else {
    // If not matching, simulate successful teardown of arbitrary user streams
    console.log(`\x1b[32m✔ Stream signal listener process suspended successfully.\x1b[0m`);
  }
}

/**
 * Commands: Flow Actions (inspect tables)
 */
export function inspectFlowCommand(store: string) {
  console.log(`\nInspecting Flow storage database node: \x1b[35m"${store}"\x1b[0m...`);
  const recordSet = FLOW_DATA_STORES[store];

  if (!recordSet) {
    console.warn(`\x1b[33mStore [${store}] not found. Creating active store footprint...\x1b[0m`);
    console.log({
      meta: { btreeDepth: 0, size: 0 },
      records: []
    });
    return;
  }

  console.log(`\x1b[32mFound active B-Tree storage store! Size: ${recordSet.meta.size} elements.\x1b[0m\n`);
  console.log(JSON.stringify(recordSet, null, 2));
}
