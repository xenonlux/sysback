/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement, Expression } from '../../../src/runtime/types';

export interface Token {
  type: 'KEYWORD' | 'IDENTIFIER' | 'LITERAL_STRING' | 'LITERAL_NUMBER' | 'LITERAL_BOOL' | 'OPERATOR' | 'PUNCTUATION';
  value: string;
}

export class AetherLexer {
  private src: string;
  private cursor = 0;

  constructor(src: string) {
    this.src = src;
  }

  public tokenize(): Token[] {
    const tokens: Token[] = [];
    const keywords = ['let', 'emit', 'yield', 'if', 'else', 'await', 'and', 'or', 'true', 'false', 'null'];

    while (this.cursor < this.src.length) {
      const char = this.src[this.cursor];

      // White spaces
      if (/\s/.test(char)) {
        this.cursor++;
        continue;
      }

      // Single-line comments
      if (char === '/' && this.src[this.cursor + 1] === '/') {
        this.cursor += 2;
        while (this.cursor < this.src.length && this.src[this.cursor] !== '\n') {
          this.cursor++;
        }
        continue;
      }

      // Strings (double quotes)
      if (char === '"' || char === "'") {
        const quote = char;
        this.cursor++;
        let val = '';
        while (this.cursor < this.src.length && this.src[this.cursor] !== quote) {
          if (this.src[this.cursor] === '\\') {
            this.cursor++;
          }
          val += this.src[this.cursor];
          this.cursor++;
        }
        this.cursor++; // Skip closing quote
        tokens.push({ type: 'LITERAL_STRING', value: val });
        continue;
      }

      // Punctuation (braces, brackets, parentheses, colons, semi, comma)
      if (['{', '}', '(', ')', '[', ']', ';', ',', ':'].includes(char)) {
        tokens.push({ type: 'PUNCTUATION', value: char });
        this.cursor++;
        continue;
      }

      // Operators
      if (['+', '-', '*', '/'].includes(char)) {
        tokens.push({ type: 'OPERATOR', value: char });
        this.cursor++;
        continue;
      }

      // Assignment / Equals / Comparison operators
      if (char === '=' || char === '!' || char === '>' || char === '<') {
        let op = char;
        if (this.src[this.cursor + 1] === '=') {
          op += '=';
          this.cursor++;
        }
        tokens.push({ type: 'OPERATOR', value: op });
        this.cursor++;
        continue;
      }

      // Numbers
      if (/\d/.test(char)) {
        let num = '';
        while (this.cursor < this.src.length && (/\d/.test(this.src[this.cursor]) || this.src[this.cursor] === '.')) {
          num += this.src[this.cursor];
          this.cursor++;
        }
        tokens.push({ type: 'LITERAL_NUMBER', value: num });
        continue;
      }

      // Identifiers / Keywords
      if (/[a-zA-Z_]/.test(char)) {
        let identifierVal = '';
        while (this.cursor < this.src.length && /[a-zA-Z0-9_\.]/.test(this.src[this.cursor])) {
          identifierVal += this.src[this.cursor];
          this.cursor++;
        }

        if (keywords.includes(identifierVal)) {
          if (identifierVal === 'true' || identifierVal === 'false') {
            tokens.push({ type: 'LITERAL_BOOL', value: identifierVal });
          } else {
            tokens.push({ type: 'KEYWORD', value: identifierVal });
          }
        } else {
          tokens.push({ type: 'IDENTIFIER', value: identifierVal });
        }
        continue;
      }

      // Fallback: Skip unknown character to avoid infinite loops, but log/warn if needed
      this.cursor++;
    }

    return tokens;
  }
}

export class AetherParser {
  private tokens: Token[];
  private currentIdx = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens;
  }

  private peek(): Token | undefined {
    return this.tokens[this.currentIdx];
  }

  private advance(): Token {
    return this.tokens[this.currentIdx++];
  }

  private match(type: string, value?: string): boolean {
    const token = this.peek();
    if (!token) return false;
    if (token.type !== type) return false;
    if (value && token.value !== value) return false;
    return true;
  }

  private consume(type: string, value?: string, errMsg?: string): Token {
    if (this.match(type, value)) {
      return this.advance();
    }
    throw new Error(errMsg || `Expected token ${type} ${value ? '"' + value + '"' : ''}, got ${this.peek()?.value}`);
  }

  public parse(): Statement[] {
    const statements: Statement[] = [];
    while (this.currentIdx < this.tokens.length) {
      statements.push(this.parseStatement());
    }
    return statements;
  }

  private parseStatement(): Statement {
    if (this.match('KEYWORD', 'let')) {
      return this.parseLetStatement();
    } else if (this.match('KEYWORD', 'emit')) {
      return this.parseEmitStatement();
    } else if (this.match('KEYWORD', 'yield')) {
      return this.parseYieldStatement();
    } else if (this.match('KEYWORD', 'if')) {
      return this.parseIfStatement();
    } else {
      return this.parseExpressionStatement();
    }
  }

  private parseLetStatement(): Statement {
    this.consume('KEYWORD', 'let');
    const nameToken = this.consume('IDENTIFIER');
    this.consume('OPERATOR', '=', 'Expected "=" after variable identifier');
    const valueExpr = this.parseExpression();
    this.consume('PUNCTUATION', ';', 'Expected ";" after assignment statement');
    return {
      type: 'LetStatement',
      name: nameToken.value,
      value: valueExpr
    };
  }

  private parseEmitStatement(): Statement {
    this.consume('KEYWORD', 'emit');
    let signal = '';
    
    // Support either emit "signal.name" or emit signal.name
    if (this.match('LITERAL_STRING')) {
      signal = this.advance().value;
    } else {
      const idToken = this.consume('IDENTIFIER', undefined, 'Expected signal identifier or string for emit');
      signal = idToken.value;
    }

    const dataExpr = this.parseExpression();
    this.consume('PUNCTUATION', ';', 'Expected ";" after emit statement');
    
    return {
      type: 'EmitStatement',
      signal,
      data: dataExpr
    };
  }

  private parseYieldStatement(): Statement {
    this.consume('KEYWORD', 'yield');
    const valueExpr = this.parseExpression();
    this.consume('PUNCTUATION', ';', 'Expected ";" after yield statement');
    return {
      type: 'YieldStatement',
      value: valueExpr
    };
  }

  private parseIfStatement(): Statement {
    this.consume('KEYWORD', 'if');
    this.consume('PUNCTUATION', '(', 'Expected "(" after "if"');
    const condition = this.parseExpression();
    this.consume('PUNCTUATION', ')', 'Expected ")" after if condition');
    
    this.consume('PUNCTUATION', '{', 'Expected "{" before if body');
    const consequent: Statement[] = [];
    while (!this.match('PUNCTUATION', '}')) {
      consequent.push(this.parseStatement());
    }
    this.consume('PUNCTUATION', '}', 'Expected "}" to close if body');

    let alternate: Statement[] | undefined = undefined;
    if (this.match('KEYWORD', 'else')) {
      this.consume('KEYWORD', 'else');
      this.consume('PUNCTUATION', '{', 'Expected "{" before else body');
      alternate = [];
      while (!this.match('PUNCTUATION', '}')) {
        alternate.push(this.parseStatement());
      }
      this.consume('PUNCTUATION', '}', 'Expected "}" to close else body');
    }

    return {
      type: 'IfStatement',
      condition,
      consequent,
      alternate
    };
  }

  private parseExpressionStatement(): Statement {
    const expr = this.parseExpression();
    if (this.match('PUNCTUATION', ';')) {
      this.advance(); // consume trailing semi if present
    }
    return {
      type: 'ExpressionStatement',
      expression: expr
    };
  }

  private parseExpression(): Expression {
    return this.parseBinaryExpression();
  }

  private parseBinaryExpression(): Expression {
    let left = this.parsePrimary();

    while (this.match('OPERATOR') || this.match('KEYWORD', 'and') || this.match('KEYWORD', 'or')) {
      const opToken = this.advance();
      const operator = opToken.value as any;
      const right = this.parsePrimary();
      left = {
        type: 'BinaryExpression',
        operator,
        left,
        right
      };
    }

    return left;
  }

  private parsePrimary(): Expression {
    if (this.match('KEYWORD', 'await')) {
      this.advance();
      const value = this.parsePrimary();
      return {
        type: 'AwaitExpression',
        value
      };
    }

    if (this.match('PUNCTUATION', '(')) {
      this.advance();
      const expr = this.parseExpression();
      this.consume('PUNCTUATION', ')', 'Expected ")" to close grouping');
      return expr;
    }

    if (this.match('LITERAL_STRING')) {
      return { type: 'Literal', value: this.advance().value };
    }

    if (this.match('LITERAL_NUMBER')) {
      return { type: 'Literal', value: Number(this.advance().value) };
    }

    if (this.match('LITERAL_BOOL')) {
      return { type: 'Literal', value: this.advance().value === 'true' };
    }

    if (this.match('KEYWORD', 'null')) {
      this.advance();
      return { type: 'Literal', value: null };
    }

    // Inline object parser like { field1: "val", field2: 2 }
    if (this.match('PUNCTUATION', '{')) {
      return this.parseObjectExpression();
    }

    if (this.match('IDENTIFIER')) {
      const idToken = this.advance();
      // Check if it's a call expression e.g. fn(...)
      if (this.match('PUNCTUATION', '(')) {
        this.advance(); // consume '('
        const args: Expression[] = [];
        if (!this.match('PUNCTUATION', ')')) {
          args.push(this.parseExpression());
          while (this.match('PUNCTUATION', ',')) {
            this.advance(); // consume ','
            args.push(this.parseExpression());
          }
        }
        this.consume('PUNCTUATION', ')', 'Expected ")" in call expression arguments');
        return {
          type: 'CallExpression',
          callee: idToken.value,
          arguments: args
        };
      }
      return {
        type: 'Identifier',
        name: idToken.value
      };
    }

    throw new Error(`Unexpected token inside expression: ${this.peek()?.value || 'EOF'}`);
  }

  private parseObjectExpression(): Expression {
    this.consume('PUNCTUATION', '{');
    const obj: Record<string, any> = {};
    
    if (!this.match('PUNCTUATION', '}')) {
      do {
        // field key can be identifiers or literal strings
        let key = '';
        if (this.match('IDENTIFIER')) {
          key = this.advance().value;
        } else if (this.match('LITERAL_STRING')) {
          key = this.advance().value;
        } else {
          throw new Error(`Expected object key identifier, got ${this.peek()?.value}`);
        }

        this.consume('PUNCTUATION', ':', 'Expected ":" after object key field name');
        
        // parse the property value expression
        const valExpr = this.parseExpression();
        
        // In Aether Runtime, Literal objects are evaluated on AST creation
        if (valExpr.type === 'Literal') {
          obj[key] = valExpr.value;
        } else if (valExpr.type === 'Identifier') {
          // Fallback simple mock resolution for identifiers or leave as is
          obj[key] = `{{${valExpr.name}}}`;
        } else {
          obj[key] = `<expression>`;
        }
      } while (this.match('PUNCTUATION', ',') && this.advance());
    }

    this.consume('PUNCTUATION', '}', 'Expected "}" after inline object fields');
    return {
      type: 'Literal',
      value: obj
    };
  }
}

/**
 * Convenience helper to parse raw file contents into fully structured AST Statements
 */
export function parseAetherCode(source: string): Statement[] {
  const lexer = new AetherLexer(source);
  const parser = new AetherParser(lexer.tokenize());
  return parser.parse();
}
