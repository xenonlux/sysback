/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const AETHER_THEME = {
  colors: {
    bgMain: 'bg-slate-950',
    bgCard: 'bg-slate-900',
    border: 'border-slate-800',
    primary: 'indigo-500',
    primaryHover: 'indigo-600',
    accentText: 'text-indigo-400',
    accentBg: 'bg-indigo-950/20'
  },
  typography: {
    heading: 'font-sans font-bold text-slate-100',
    mono: 'font-mono text-xs text-slate-400'
  }
};
