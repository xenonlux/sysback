/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { parseAetherCode } from '../../../cli/src/parser';
import { JSEmitter } from '../../../../src/compiler/js-emit';
import { Environment } from '../../../../src/runtime/environment';
import { EventBus } from '../../../../src/runtime/event-bus';
import { hash, sign, verify, uuid, now } from '../../../../src/builtins/crypto';
import { validate } from '../../../../src/builtins/validate';

export interface RunResults {
  success: boolean;
  yieldedValue: any;
  variables: Record<string, any>;
  logs: { timestamp: string; type: 'info' | 'success' | 'warn' | 'error'; message: string }[];
}

/**
 * Executes a raw Aether source script within the sandbox, harvesting output details
 */
export async function executeAetherSandbox(source: string, eventBus: EventBus): Promise<RunResults> {
  const resultLogs: RunResults['logs'] = [];
  const logInfo = (msg: string) => resultLogs.push({ timestamp: new Date().toLocaleTimeString(), type: 'info', message: msg });
  const logSuccess = (msg: string) => resultLogs.push({ timestamp: new Date().toLocaleTimeString(), type: 'success', message: msg });
  const logError = (msg: string) => resultLogs.push({ timestamp: new Date().toLocaleTimeString(), type: 'error', message: msg });

  try {
    logInfo('Starting VM execution process...');
    
    // Parse
    const statements = parseAetherCode(source);
    logSuccess(`Syntax parsing completed. Compiled into ${statements.length} logic nodes.`);

    // Compile to optimized ES pipeline
    const emitter = new JSEmitter();
    const jsBytecode = emitter.emit(statements);
    logInfo('Optimized JavaScript bytecode signature emitted.');

    // Prepare sandbox containers
    const env = new Environment();
    const builtins = {
      hash,
      sign,
      verify,
      uuid,
      now,
      validate,
      log: (msg: string) => logInfo(`[SDK SDK] ${msg}`)
    };

    // Listeners for dynamic inline emits
    const unsubscribe = eventBus.subscribeAll((evt) => {
      logSuccess(`[Signal Emitted] -> "${evt.signal}" data pack compiled.`);
    });

    // Run custom executable function context
    const executorFn = new Function('env', 'eventBus', 'builtins', jsBytecode);
    const yielded = await executorFn(env, eventBus, builtins);
    
    // Cleanup subscriptions
    unsubscribe();

    logSuccess('Autonomous execution sequence completed cleanly.');

    return {
      success: true,
      yieldedValue: yielded,
      variables: env.getLocalBinds(),
      logs: resultLogs
    };

  } catch (err: any) {
    logError(`Execution aborted: ${err.message}`);
    return {
      success: false,
      yieldedValue: null,
      variables: {},
      logs: resultLogs
    };
  }
}
