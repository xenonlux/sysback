/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Metadata definition specifying AETHER language syntax schemas for editor components
 */
export const AETHER_LANGUAGE_SPEC = {
  id: 'aether',
  keywords: [
    'let',
    'emit',
    'yield',
    'if',
    'else',
    'await',
    'and',
    'or',
    'true',
    'false',
    'null'
  ],
  builtins: [
    'sign',
    'verify',
    'validate',
    'hash',
    'uuid',
    'now',
    'emit',
    'yield'
  ],
  typeInferenceHints: {
    sign: '(claims: Object, secret: String) -> TokenString',
    verify: '(token: String, secret: String) -> ClaimsObject',
    validate: '(record: Object, schema: Object) -> CoercedRecord',
    hash: '(data: String) -> HexHash64',
    uuid: '() -> UUID',
    now: '() -> EpochTimestamp'
  },
  autocomplete: [
    {
      label: 'let',
      kind: 'keyword',
      detail: 'Declare a scoped reactive memory slot variable',
      insertText: 'let ${1:variableName} = ${2:value};'
    },
    {
      label: 'emit',
      kind: 'keyword',
      detail: 'Emits a reactive event signal block onto the EventBus',
      insertText: 'emit "${1:stream.identifier}" ${2:payload};'
    },
    {
      label: 'yield',
      kind: 'keyword',
      detail: 'Return final computed telemetry result from execution context',
      insertText: 'yield ${1:expression};'
    },
    {
      label: 'if',
      kind: 'keyword',
      detail: 'Branch conditional control block',
      insertText: 'if (${1:condition}) {\n  $2\n}'
    },
    {
      label: 'sign',
      kind: 'function',
      detail: 'Cryptographically signs claims payload with a seed secret',
      insertText: 'sign(${1:claims}, ${2:secret})'
    },
    {
      label: 'verify',
      kind: 'function',
      detail: 'Verifies and unpacks a signed token payload signature',
      insertText: 'verify(${1:tokenToken}, ${2:secret})'
    },
    {
      label: 'validate',
      kind: 'function',
      detail: 'Checks object structure against properties criteria rules',
      insertText: 'validate(${1:object}, ${2:schema})'
    }
  ]
};
