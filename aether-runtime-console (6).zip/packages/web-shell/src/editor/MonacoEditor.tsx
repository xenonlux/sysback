/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, HelpCircle, Code2, AlertTriangle, Lightbulb } from 'lucide-react';
import { AETHER_LANGUAGE_SPEC } from './aether-lang';
import { parseAetherCode } from '../../../cli/src/parser';
import AetherVisualEditor from '../../../../src/AetherVisualEditor';

interface MonacoEditorProps {
  filename: string;
  code: string;
  mode: 'code' | 'visual' | 'natural';
  onChangeCode: (newCode: string) => void;
  onChangeMode: (newMode: 'code' | 'visual' | 'natural') => void;
}

export default function MonacoEditor({
  filename,
  code,
  mode,
  onChangeCode,
  onChangeMode
}: MonacoEditorProps) {
  const [syntaxError, setSyntaxError] = useState<string | null>(null);
  const [inferredTypeHint, setInferredTypeHint] = useState<string | null>(null);

  // Parse check on keystroke to evaluate syntax validation
  useEffect(() => {
    if (mode !== 'code') return;
    try {
      parseAetherCode(code);
      setSyntaxError(null);
    } catch (err: any) {
      setSyntaxError(err.message);
    }

    // Type inference hints trigger when specific calling statements reside in the lines
    const matches = code.match(/(sign|verify|validate|hash)\(/);
    if (matches && matches[1]) {
      const fnName = matches[1];
      const hint = (AETHER_LANGUAGE_SPEC.typeInferenceHints as Record<string, string>)[fnName];
      setInferredTypeHint(`Inferred: ${fnName}${hint}`);
    } else {
      setInferredTypeHint(null);
    }
  }, [code, mode]);

  const handleAutocompleteClick = (insertText: string) => {
    // Append or inject snippet cleanly
    const snippet = insertText.replace(/\$\{\d:([^}]+)\}/g, '$1');
    onChangeCode(code + '\n' + snippet);
  };

  return (
    <div className="bg-slate-950 border border-slate-900 rounded-2xl flex flex-col h-full min-h-[400px]">
      {/* Editor Header Tab Switchers */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-900 font-mono text-xs">
        <div className="flex items-center space-x-2">
          <Code2 className="h-4 w-4 text-indigo-400" />
          <span className="text-slate-300 font-semibold">{filename}</span>
        </div>

        {/* Mode toggle icons */}
        <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-850">
          {(['code', 'visual', 'natural'] as const).map((m) => (
            <button
              key={m}
              onClick={() => onChangeMode(m)}
              className={`px-3 py-1 text-[10px] uppercase font-bold tracking-wider rounded transition-all cursor-pointer ${
                mode === m
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row min-h-0 relative">
        {/* Main interactive logic panel */}
        {mode === 'code' ? (
          <div className="flex-1 flex relative">
            {/* Simulated Monaco line gutters */}
            <div className="w-12 bg-slate-950 text-slate-700 select-none text-right pr-3 pt-4 font-mono text-[11px] border-r border-slate-900 leading-6">
              {Array.from({ length: Math.max(12, code.split('\n').length) }).map((_, idx) => (
                <div key={idx}>{idx + 1}</div>
              ))}
            </div>

            {/* Standard code typing layer */}
            <textarea
              className="flex-1 bg-transparent text-slate-100 font-mono text-[12px] p-4 focus:outline-none resize-none leading-6 w-full h-[300px]"
              value={code}
              onChange={(e) => onChangeCode(e.target.value)}
              placeholder="// Write AETHER Language microservice AST instructions here..."
              spellCheck={false}
            />
          </div>
        ) : mode === 'visual' ? (
          <div className="flex-1 overflow-hidden p-2 flex flex-col">
            <AetherVisualEditor initialCode={code} onChange={onChangeCode} />
          </div>
        ) : (
          <div className="flex-1 bg-slate-950/45 p-6 flex flex-col justify-center items-center text-center">
            <Sparkles className="h-10 w-10 text-emerald-400/50 mb-3 animate-pulse" />
            <h4 className="text-sm font-bold text-slate-300">Natural NLP AETHER Generator</h4>
            <p className="text-xs text-slate-500 max-w-sm mt-1">
              Translate plain-english logic triggers using deep LLM reasoning.
            </p>
            <div className="mt-4 w-full max-w-xs block relative">
              <input
                type="text"
                placeholder="Secure user transactions with Dilithium..."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 text-center focus:outline-none"
                disabled
              />
              <span className="absolute right-2.5 top-3 text-[9px] text-emerald-400 font-semibold uppercase">LLM</span>
            </div>
          </div>
        )}

        {/* Side-floating snippets Autocompletion tray */}
        <div className="w-full md:w-56 bg-slate-950/95 border-t md:border-t-0 md:border-l border-slate-900 p-3.5 flex flex-col text-xs text-slate-400 font-mono">
          <div className="flex items-center space-x-1.5 font-bold text-[10px] uppercase text-indigo-400 mb-3">
            <Lightbulb className="h-3.5 w-3.5" />
            <span>Autocomplete built-ins</span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[150px] md:max-h-none">
            {AETHER_LANGUAGE_SPEC.autocomplete.map((s) => (
              <div
                key={s.label}
                onClick={() => handleAutocompleteClick(s.insertText)}
                className="p-1.5 bg-slate-900 hover:bg-slate-850 hover:text-slate-100 rounded border border-slate-850 hover:border-slate-800 cursor-pointer transition text-[10px] flex items-center justify-between"
                title={s.detail}
              >
                <span>{s.label}()</span>
                <span className="text-[8px] bg-slate-950 px-1 py-0.2 rounded text-indigo-400 uppercase font-bold">
                  {s.kind}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Editor Status bar (diagnostic errors count or typehints) */}
      <div className="px-4 py-2 bg-slate-950 border-t border-slate-900 flex items-center justify-between text-[10px] font-mono text-slate-500">
        <div>
          {syntaxError ? (
            <div className="flex items-center space-x-1.5 text-red-400">
              <AlertTriangle className="h-3.5 w-3.5" />
              <span className="truncate max-w-[280px] md:max-w-[400px]" title={syntaxError}>{syntaxError}</span>
            </div>
          ) : inferredTypeHint ? (
            <div className="flex items-center space-x-1 text-emerald-400">
              <Lightbulb className="h-3.5 w-3.5" />
              <span>{inferredTypeHint}</span>
            </div>
          ) : (
            <span className="text-emerald-500">✔ Syntax: Perfect AETHER syntax</span>
          )}
        </div>
        <span className="shrink-0 uppercase font-semibold">aether-ae: UTF-8</span>
      </div>
    </div>
  );
}
