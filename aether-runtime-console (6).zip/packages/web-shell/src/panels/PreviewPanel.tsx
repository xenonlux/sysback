/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Radio, RefreshCw, Database, Activity, Server, Zap, Globe } from 'lucide-react';

interface PreviewPanelProps {
  traceLogs: { timestamp: string; type: string; message: string }[];
  activeStreams: { signal: string; count: number }[];
  onClearLogs: () => void;
}

export default function PreviewPanel({
  traceLogs,
  activeStreams,
  onClearLogs
}: PreviewPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'streams' | 'ledger' | 'trace'>('streams');

  // Simulated active B-tree stores
  const storeDB = {
    'vault.secrets': [
      { key: 'admin_usr', method: 'ML-KEM-768 SHA3-GCM', encryptedDigest: '0x992cfc...98ad' },
      { key: 'session_token_key', method: 'LatticeDilithiumSignature', encryptedDigest: '0x334ff0...bb11' }
    ],
    'flow.telemetry': [
      { stream: 'telemetry.pulse', rate: '2.4 ev/s', network: 'Active Loop' },
      { stream: 'network.ingress', rate: '12.0 ev/s', network: 'Router Root' }
    ]
  };

  return (
    <div className="bg-slate-950 border border-slate-900 rounded-2xl p-4 flex flex-col h-full h-[400px]">
      
      {/* Visual Navigation switcher inside Preview */}
      <div className="flex items-center justify-between border-b border-slate-900 pb-3 mb-3">
        <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-850 text-[10px]">
          <button
            onClick={() => setActiveSubTab('streams')}
            className={`px-2.5 py-1 font-bold rounded cursor-pointer ${
              activeSubTab === 'streams' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Streams Monitor
          </button>
          <button
            onClick={() => setActiveSubTab('ledger')}
            className={`px-2.5 py-1 font-bold rounded cursor-pointer ${
              activeSubTab === 'ledger' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Flow B-Tree DB
          </button>
          <button
            onClick={() => setActiveSubTab('trace')}
            className={`px-2.5 py-1 font-bold rounded cursor-pointer ${
              activeSubTab === 'trace' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Event Log ({traceLogs.length})
          </button>
        </div>

        {activeSubTab === 'trace' && (
          <button
            onClick={onClearLogs}
            className="text-[9px] font-mono font-bold text-slate-500 hover:text-slate-300 uppercase transition cursor-pointer"
          >
            flush
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto pr-1">
        {activeSubTab === 'streams' ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-850">
                <p className="text-[9px] text-slate-500 font-bold uppercase">Event Channels</p>
                <p className="text-sm font-black text-white mt-1 font-mono">
                  {activeStreams.length + 3} Live
                </p>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-850">
                <p className="text-[9px] text-slate-500 font-bold uppercase">Throughput Rate</p>
                <p className="text-sm font-black text-indigo-400 mt-1 font-mono">
                  14.5 ev/s
                </p>
              </div>
            </div>

            {/* Simulated Table of Live Active Streams */}
            <div className="space-y-2">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">Signal Pipeline Streams</span>
              
              <div className="space-y-1.5 font-mono text-[9px]">
                <div className="flex justify-between p-2 rounded bg-slate-900 border border-slate-850/60">
                  <span className="text-slate-300 flex items-center space-x-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                    <span>telemetry.pulse</span>
                  </span>
                  <span className="text-indigo-400 font-bold">2.4 ev/s</span>
                </div>

                <div className="flex justify-between p-2 rounded bg-slate-900 border border-slate-850/60">
                  <span className="text-slate-300 flex items-center space-x-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                    <span>network.ingress</span>
                  </span>
                  <span className="text-indigo-400 font-bold">12.0 ev/s</span>
                </div>

                {activeStreams.map((s, idx) => (
                  <div key={idx} className="flex justify-between p-2 rounded bg-indigo-950/10 border border-indigo-900/30">
                    <span className="text-indigo-300 flex items-center space-x-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping shrink-0" />
                      <span>{s.signal}</span>
                    </span>
                    <span className="text-indigo-400 font-bold">Triggered ({s.count})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : activeSubTab === 'ledger' ? (
          <div className="space-y-3 font-mono text-[10px]">
            <div className="flex items-center space-x-2 text-indigo-400 block mb-1">
              <Database className="h-3.5 w-3.5" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Global Memory Store Nodes</span>
            </div>

            {Object.entries(storeDB).map(([storeName, rows]) => (
              <div key={storeName} className="p-3 bg-slate-900 border border-slate-850 rounded-xl space-y-2">
                <span className="text-[10px] font-bold text-slate-300">{storeName}</span>
                <div className="space-y-1.5 text-[9px] text-slate-400">
                  {rows.map((row: any, i) => (
                    <div key={i} className="flex flex-col border-b border-slate-850 pb-1.5 last:border-0 last:pb-0">
                      <div className="flex justify-between font-bold text-slate-300">
                        <span>{row.key || row.stream}</span>
                        <span className="text-indigo-400">{row.rate || row.method}</span>
                      </div>
                      <div className="text-[8px] text-slate-600 truncate">{row.encryptedDigest || row.network}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2 max-h-[300px] overflow-y-auto font-mono text-[10px]">
            {traceLogs.length > 0 ? (
              [...traceLogs].reverse().map((log, i) => (
                <div
                  key={i}
                  className={`p-2 rounded border leading-5 ${
                    log.type === 'error'
                      ? 'bg-rose-950/10 border-rose-900/40 text-rose-300'
                      : log.type === 'info'
                      ? 'bg-indigo-950/10 border-indigo-900/40 text-indigo-300'
                      : 'bg-slate-900 border-slate-850/60 text-emerald-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[8px] text-slate-500 mb-1">
                    <span>{log.timestamp}</span>
                    <span className="uppercase font-bold tracking-wider">{log.type}</span>
                  </div>
                  <p className="text-[10px]">{log.message}</p>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-slate-500">
                <Activity className="h-6 w-6 text-slate-700 mx-auto animate-pulse mb-2" />
                <p className="text-[9px] uppercase font-bold tracking-widest">No transaction events</p>
                <p className="text-[9px] text-slate-600 mt-1">Hit Run on the Editor above to emit signal streams!</p>
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  );
}
