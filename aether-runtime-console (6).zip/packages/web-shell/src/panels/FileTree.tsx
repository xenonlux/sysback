/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FileCode, Plus, Trash2, FolderOpen } from 'lucide-react';

export interface VirtualFile {
  name: string;
  content: string;
}

interface FileTreeProps {
  files: VirtualFile[];
  selectedFile: VirtualFile;
  onSelectFile: (file: VirtualFile) => void;
  onCreateFile: () => void;
  onDeleteFile: (filename: string) => void;
}

export default function FileTree({
  files,
  selectedFile,
  onSelectFile,
  onCreateFile,
  onDeleteFile
}: FileTreeProps) {
  return (
    <div className="bg-slate-950 border border-slate-900 rounded-2xl p-4 flex flex-col h-full h-[400px]">
      <div className="flex items-center justify-between pb-3 border-b border-slate-900 mb-2">
        <div className="flex items-center space-x-2">
          <FolderOpen className="h-4 w-4 text-indigo-400" />
          <h3 className="text-xs font-bold text-slate-200 tracking-wider uppercase">Active Files</h3>
        </div>
        <button
          onClick={onCreateFile}
          className="p-1 hover:bg-slate-900 border border-transparent hover:border-slate-800 text-indigo-400 rounded transition cursor-pointer"
          title="Create custom .ae file"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
        {files.map((file) => {
          const isSelected = selectedFile.name === file.name;
          return (
            <div
              key={file.name}
              className={`group flex items-center justify-between p-2 rounded-lg text-xs transition border cursor-pointer ${
                isSelected
                  ? 'bg-indigo-950/20 border-indigo-500/35 text-indigo-200 font-medium'
                  : 'bg-transparent border-transparent text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
              onClick={() => onSelectFile(file)}
            >
              <div className="flex items-center space-x-2 min-w-0">
                <FileCode className={`h-4 w-4 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                <span className="truncate font-mono">{file.name}</span>
              </div>
              
              {files.length > 1 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteFile(file.name);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-slate-850 hover:text-rose-400 rounded text-slate-500 transition cursor-pointer"
                  title="Delete file"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
