/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, ArrowRight } from 'lucide-react';

interface TerminalREPLProps {
  onExecuteCommand: (commandStr: string) => string[];
}

export default function TerminalREPL({ onExecuteCommand }: TerminalREPLProps) {
  const [inputStr, setInputStr] = useState('');
  const [logs, setLogs] = useState<string[]>([
    '========================================',
    '=== AETHER CLI UNIVERSAL SANDBOX Terminal ===',
    '========================================',
    'Type "help" to list available command pipelines.',
    'Or type rich Aether code let allocations directly.',
    ''
  ]);

  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputStr.trim();
    if (!trimmed) return;

    // Prompt log
    const updatedLines = [...logs, `ae> ${trimmed}`];
    
    // Evaluate via parent callback
    const outputs = onExecuteCommand(trimmed);
    
    setLogs([...updatedLines, ...outputs, '']);
    setInputStr('');
  };

  return (
    <div className="bg-slate-950 border border-slate-900 rounded-2xl p-4 flex flex-col h-[280px]">
      <div className="flex items-center space-x-2 border-b border-slate-900 pb-2 mb-2 font-mono text-xs">
        <Terminal className="h-4 w-4 text-indigo-400 shrink-0" />
        <span className="text-slate-300 font-semibold uppercase">Interactive Node Prompt VM</span>
      </div>

      {/* Terminal log window */}
      <div className="flex-1 overflow-y-auto font-mono text-[11px] text-slate-300 p-2 space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800 pr-1">
        {logs.map((line, idx) => (
          <div
            key={idx}
            className={`whitespace-pre-wrap ${
              line.startsWith('ae>')
                ? 'text-indigo-400 font-bold'
                : line.startsWith('Error:') || line.includes('REJECTED')
                ? 'text-rose-400'
                : line.startsWith('[Success]') || line.includes('✔')
                ? 'text-emerald-400 font-semibold'
                : 'text-slate-300'
            }`}
          >
            {line}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex items-center space-x-2 border-t border-slate-900 pt-2.5 mt-1.5">
        <span className="text-indigo-400 font-mono text-xs font-bold shrink-0">ae&gt;</span>
        <input
          type="text"
          className="flex-1 bg-transparent border-none text-slate-100 font-mono text-xs focus:outline-none placeholder-slate-700 w-full"
          value={inputStr}
          onChange={(e) => setInputStr(e.target.value)}
          placeholder='Try "help", "aether stream ls", or "let counter = 100;"'
          spellCheck={false}
        />
        <button
          type="submit"
          className="p-1 hover:bg-slate-900 text-indigo-400 hover:text-indigo-300 border border-transparent hover:border-slate-850 rounded transition shrink-0 cursor-pointer"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
