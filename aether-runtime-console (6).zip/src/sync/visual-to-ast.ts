/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VisualNode, VisualEdge } from '../nodes/types';

/**
 * Traverses visual nodegraph elements and compiles them back to AETHER syntax.
 */
export function visualToCode(nodes: VisualNode[], edges: VisualEdge[]): string {
  let codeLines: string[] = [];

  // 1. Compile variable assignments first (LetStatement)
  const letNodes = nodes.filter((n) => n.type === 'let');
  if (letNodes.length > 0) {
    codeLines.push('// Variable Declarations');
    letNodes.forEach((n) => {
      let valExpr = n.data?.expression || '""';
      // Ensure syntax is balanced
      if (valExpr.startsWith('{') && !valExpr.endsWith('}')) {
        valExpr += ' }';
      }
      codeLines.push(`let ${n.name} = ${valExpr};`);
    });
    codeLines.push('');
  }

  // 2. Compile schema validators definitions (ValidateStatement)
  const validatorNodes = nodes.filter((n) => n.type === 'validate');
  if (validatorNodes.length > 0) {
    codeLines.push('// Custom validation rules checking');
    validatorNodes.forEach((n) => {
      const constraints = n.data?.constraints || {};
      const fields = Object.entries(constraints)
        .map(([key, info]) => `    ${key}: { type: "${info.type}", required: ${info.required || 'true'} }`)
        .join(',\n');

      codeLines.push(`let ${n.name}Schema = {`);
      codeLines.push('  type: "object",');
      codeLines.push('  properties: {');
      codeLines.push(fields);
      codeLines.push('  }');
      codeLines.push('};');
      codeLines.push('');
    });
  }

  // 3. Compile signal emissions (EmitStatement)
  const emitNodes = nodes.filter((n) => n.type === 'emit');
  if (emitNodes.length > 0) {
    codeLines.push('// Outgoing telemetry broadcasts');
    emitNodes.forEach((n) => {
      const signalName = n.name || 'network.pulse';
      const payloadExpr = n.data?.expression || '{}';
      codeLines.push(`emit ${signalName} ${payloadExpr};`);
    });
    codeLines.push('');
  }

  // 4. Compile Logical Branches (IfStatement)
  const branchNodes = nodes.filter((n) => n.type === 'branch');
  branchNodes.forEach((n) => {
    const condition = n.name || 'true';
    codeLines.push(`if (${condition}) {`);
    
    // Find consequence nodes (connected to then port)
    const thenEdges = edges.filter((e) => e.sourceId === n.id && e.sourcePortId === 'then');
    if (thenEdges.length > 0) {
      const targetId = thenEdges[0].targetId;
      const targetNode = nodes.find((tn) => tn.id === targetId);
      if (targetNode) {
        if (targetNode.type === 'emit') {
          codeLines.push(`  emit ${targetNode.name} ${targetNode.data?.expression || '{}'};`);
        } else if (targetNode.type === 'yield') {
          codeLines.push(`  yield ${targetNode.name};`);
        } else if (targetNode.type === 'flow') {
          codeLines.push(`  // write B-Tree Store flow: ${targetNode.name}`);
        }
      }
    } else {
      codeLines.push('  // empty consequent branch');
    }
    
    codeLines.push('}');

    // Find alternate branch details if present
    const elseEdges = edges.filter((e) => e.sourceId === n.id && e.sourcePortId === 'else');
    if (elseEdges.length > 0) {
      codeLines.push('else {');
      const targetId = elseEdges[0].targetId;
      const targetNode = nodes.find((tn) => tn.id === targetId);
      if (targetNode) {
        if (targetNode.type === 'emit') {
          codeLines.push(`  emit ${targetNode.name} ${targetNode.data?.expression || '{}'};`);
        } else if (targetNode.type === 'yield') {
          codeLines.push(`  yield ${targetNode.name};`);
        }
      }
      codeLines.push('}');
    }

    codeLines.push('');
  });

  // 5. Compile yields / returns (YieldStatement)
  const yieldNodes = nodes.filter((n) => n.type === 'yield');
  if (yieldNodes.length > 0) {
    codeLines.push('// Output execution returns');
    yieldNodes.forEach((n) => {
      const val = n.name || 'null';
      codeLines.push(`yield ${val};`);
    });
  }

  // Fallback statement index safety
  if (codeLines.length === 0) {
    return '// Empty Aether design workspace\nyield uuid();';
  }

  return codeLines.join('\n');
}
