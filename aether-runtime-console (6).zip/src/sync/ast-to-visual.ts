/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Statement, Expression } from '../runtime/types';
import { VisualNode, VisualEdge, PortDef } from '../nodes/types';

/**
 * Serialize Expression back to its string Representation for node display
 */
export function expressionToString(expr: Expression): string {
  if (!expr) return '';
  switch (expr.type) {
    case 'Literal': {
      if (expr.value === null) return 'null';
      if (typeof expr.value === 'object') {
        const fields = Object.entries(expr.value)
          .map(([k, v]) => {
            const vStr = typeof v === 'object' ? JSON.stringify(v) : String(v);
            return `${k}: ${vStr}`;
          })
          .join(', ');
        return `{ ${fields} }`;
      }
      return String(expr.value);
    }
    case 'Identifier':
      return expr.name;
    case 'BinaryExpression':
      return `${expressionToString(expr.left)} ${expr.operator} ${expressionToString(expr.right)}`;
    case 'CallExpression': {
      const args = expr.arguments.map(expressionToString).join(', ');
      return `${expr.callee}(${args})`;
    }
    case 'AwaitExpression':
      return `await ${expressionToString(expr.value)}`;
    default:
      return '';
  }
}

/**
 * Parses statement structures and generates Node / Edge coordinates mapping
 */
export function astToVisual(statements: Statement[]): { nodes: VisualNode[]; edges: VisualEdge[] } {
  const nodes: VisualNode[] = [];
  const edges: VisualEdge[] = [];

  let currentY = 80;
  const colX = 260;

  // Track statement execution sequencing to draw control flow edges
  let lastControlNodeId: string | null = null;
  let lastControlPortId: string | null = null;

  statements.forEach((stmt, idx) => {
    const nodeId = `node_${stmt.type.toLowerCase()}_${idx}_${Math.random().toString(36).substring(4, 7)}`;

    switch (stmt.type) {
      case 'LetStatement': {
        const exprStr = expressionToString(stmt.value);
        // Identify validate or function calls nested in Let statement
        let isValidation = exprStr.includes('validate(');

        const node: VisualNode = {
          id: nodeId,
          type: isValidation ? 'validate' : 'let',
          name: stmt.name,
          x: 100,
          y: currentY,
          width: 220,
          height: 140,
          data: {
            expression: exprStr,
            value: exprStr,
            // If it is a validate statement, populate mockup fields for the diamond rules
            constraints: isValidation ? {
              title: { type: 'string', required: true },
              priority: { type: 'number', required: true },
              completed: { type: 'boolean', required: true }
            } : undefined
          },
          inputs: [
            { id: 'in', name: 'in', direction: 'in', type: 'control' }
          ],
          outputs: [
            { id: 'out', name: 'val', direction: 'out', type: isValidation ? 'boolean' : 'object' }
          ]
        };

        nodes.push(node);

        if (lastControlNodeId && lastControlPortId) {
          edges.push({
            id: `edge_flow_${lastControlNodeId}_to_${nodeId}`,
            sourceId: lastControlNodeId,
            sourcePortId: lastControlPortId,
            targetId: nodeId,
            targetPortId: 'in'
          });
        }
        lastControlNodeId = nodeId;
        lastControlPortId = 'out';
        currentY += 180;
        break;
      }

      case 'EmitStatement': {
        // Find stream container name from signal (e.g. security.handshake => security)
        const parts = stmt.signal.split('.');
        const streamContainerName = parts[0] || 'global_stream';

        // Check if stream container already present, if not create one
        let streamNode = nodes.find(n => n.type === 'stream' && n.name === streamContainerName);
        if (!streamNode) {
          const streamId = `stream_${streamContainerName}`;
          streamNode = {
            id: streamId,
            type: 'stream',
            name: streamContainerName,
            x: colX + 160,
            y: currentY - 40,
            width: 250,
            height: 155,
            inputs: [{ id: 'in', name: 'stream', direction: 'in', type: 'signal' }],
            outputs: [{ id: 'out', name: 'events', direction: 'out', type: 'signal' }]
          };
          nodes.push(streamNode);
        }

        // Create emitter node inside or linked
        const exprStr = expressionToString(stmt.data);
        const node: VisualNode = {
          id: nodeId,
          type: 'emit',
          name: stmt.signal,
          x: colX,
          y: currentY,
          width: 210,
          height: 130,
          parentId: streamNode.id,
          data: {
            signal: stmt.signal,
            expression: exprStr
          },
          inputs: [
            { id: 'in', name: 'in', direction: 'in', type: 'control' },
            { id: 'data', name: 'feed', direction: 'in', type: 'object' }
          ],
          outputs: [
            { id: 'out', name: 'emit', direction: 'out', type: 'signal' }
          ]
        };

        nodes.push(node);

        // Draw connections
        if (lastControlNodeId && lastControlPortId) {
          edges.push({
            id: `edge_flow_${lastControlNodeId}_to_${nodeId}`,
            sourceId: lastControlNodeId,
            sourcePortId: lastControlPortId,
            targetId: nodeId,
            targetPortId: 'in'
          });
        }

        // Link Emitter output straight into custom Stream listener ports
        edges.push({
          id: `edge_stream_bind_${nodeId}_to_${streamNode.id}`,
          sourceId: nodeId,
          sourcePortId: 'out',
          targetId: streamNode.id,
          targetPortId: 'in'
        });

        lastControlNodeId = nodeId;
        lastControlPortId = 'out';
        currentY += 180;
        break;
      }

      case 'YieldStatement': {
        const exprStr = expressionToString(stmt.value);
        const node: VisualNode = {
          id: nodeId,
          type: 'yield',
          name: exprStr,
          x: colX * 2,
          y: currentY,
          width: 210,
          height: 130,
          data: {
            expression: exprStr
          },
          inputs: [
            { id: 'in', name: 'in', direction: 'in', type: 'any' }
          ],
          outputs: []
        };

        nodes.push(node);

        if (lastControlNodeId && lastControlPortId) {
          edges.push({
            id: `edge_flow_${lastControlNodeId}_to_${nodeId}`,
            sourceId: lastControlNodeId,
            sourcePortId: lastControlPortId,
            targetId: nodeId,
            targetPortId: 'in'
          });
        }
        lastControlNodeId = null; // terminal node
        lastControlPortId = null;
        currentY += 170;
        break;
      }

      case 'IfStatement': {
        const condStr = expressionToString(stmt.condition);
        const node: VisualNode = {
          id: nodeId,
          type: 'branch',
          name: condStr,
          x: colX,
          y: currentY,
          width: 210,
          height: 140,
          data: {
            condition: condStr
          },
          inputs: [
            { id: 'in', name: 'in', direction: 'in', type: 'control' }
          ],
          outputs: [
            { id: 'then', name: 'then', direction: 'out', type: 'control' },
            { id: 'else', name: 'else', direction: 'out', type: 'control' }
          ]
        };

        nodes.push(node);

        if (lastControlNodeId && lastControlPortId) {
          edges.push({
            id: `edge_flow_${lastControlNodeId}_to_${nodeId}`,
            sourceId: lastControlNodeId,
            sourcePortId: lastControlPortId,
            targetId: nodeId,
            targetPortId: 'in'
          });
        }

        // Drill down branch blocks if present
        if (stmt.consequent && stmt.consequent.length > 0) {
          const subResult = astToVisual(stmt.consequent);
          // Offset sub branch nodes layout
          subResult.nodes.forEach((sn, sidx) => {
            sn.x += colX + 40;
            sn.y += currentY;
            nodes.push(sn);
          });
          subResult.edges.forEach(se => edges.push(se));

          // Port link from true path
          if (subResult.nodes.length > 0) {
            edges.push({
              id: `edge_branch_then_${nodeId}`,
              sourceId: nodeId,
              sourcePortId: 'then',
              targetId: subResult.nodes[0].id,
              targetPortId: subResult.nodes[0].inputs[0].id
            });
          }
        }

        if (stmt.alternate && stmt.alternate.length > 0) {
          const subResult = astToVisual(stmt.alternate);
          subResult.nodes.forEach((sn, sidx) => {
            sn.x += colX + 40;
            sn.y += currentY + 180;
            nodes.push(sn);
          });
          subResult.edges.forEach(se => edges.push(se));

          // Port link from false path
          if (subResult.nodes.length > 0) {
            edges.push({
              id: `edge_branch_else_${nodeId}`,
              sourceId: nodeId,
              sourcePortId: 'else',
              targetId: subResult.nodes[0].id,
              targetPortId: subResult.nodes[0].inputs[0].id
            });
          }
        }

        lastControlNodeId = nodeId;
        lastControlPortId = 'then';
        currentY += 320;
        break;
      }

      default: {
        // Fallback or ExpressionStatement
        break;
      }
    }
  });

  // If there are standard data links we want to auto-predict (e.g. variable output to emitting field)
  // we scan identifier names matching variables
  nodes.forEach(n => {
    if (n.type === 'let') {
      const varName = n.name;
      // Search for any other node whose data expression uses this variable
      nodes.forEach(trg => {
        if (trg.id !== n.id && trg.type !== 'let') {
          const expr = trg.data?.expression || trg.name || '';
          if (expr.includes(varName)) {
            // Find object/any input port
            const inPort = trg.inputs.find(p => p.type === 'object' || p.type === 'any');
            if (inPort) {
              edges.push({
                id: `edge_data_${n.id}_to_${trg.id}`,
                sourceId: n.id,
                sourcePortId: 'out',
                targetId: trg.id,
                targetPortId: inPort.id,
                label: varName
              });
            }
          }
        }
      });
    }
  });

  return { nodes, edges };
}
