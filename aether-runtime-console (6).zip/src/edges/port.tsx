/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PortDef } from '../nodes/types';

interface PortProps {
  key?: string;
  nodeId: string;
  port: PortDef;
  onPointerDown: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUp: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerMove?: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
}

export function getTypeColor(type: string): string {
  switch (type) {
    case 'object':
      return 'bg-purple-500 border-purple-400';
    case 'string':
      return 'bg-emerald-500 border-emerald-400';
    case 'number':
      return 'bg-amber-500 border-amber-400';
    case 'boolean':
      return 'bg-rose-500 border-rose-400';
    case 'signal':
    case 'control':
      return 'bg-sky-500 border-sky-400';
    default:
      return 'bg-slate-400 border-slate-300';
  }
}

export default function Port({
  nodeId,
  port,
  onPointerDown,
  onPointerUp,
}: PortProps) {
  const isInput = port.direction === 'in';
  const colorClass = getTypeColor(port.type);

  return (
    <div
      className={`flex items-center space-x-1.5 py-1 ${isInput ? 'flex-row' : 'flex-row-reverse space-x-reverse'}`}
      title={`${port.name} (${port.type})`}
    >
      {/* Port dot */}
      <div
        id={`port-${nodeId}-${port.id}`}
        onPointerDown={(e) => {
          e.stopPropagation();
          onPointerDown(e, nodeId, port.id);
        }}
        onPointerUp={(e) => {
          e.stopPropagation();
          onPointerUp(e, nodeId, port.id);
        }}
        className={`w-3.5 h-3.5 rounded-full border-2 cursor-crosshair hover:scale-130 transition-transform shadow-md ${colorClass} select-none`}
        data-node-id={nodeId}
        data-port-id={port.id}
        data-direction={port.direction}
        data-port-type={port.type}
      />
      {/* Port Text */}
      <span className="text-[10px] uppercase font-mono font-bold tracking-tight text-slate-450">
        {port.name}
      </span>
    </div>
  );
}
