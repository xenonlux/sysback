/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface EdgeLabelProps {
  x: number;
  y: number;
  text: string;
  isError?: boolean;
}

export default function EdgeLabel({ x, y, text, isError = false }: EdgeLabelProps) {
  return (
    <g transform={`translate(${x}, ${y})`} className="select-none pointer-events-none">
      <rect
        x={-text.length * 3.5 - 6}
        y={-9}
        width={text.length * 7 + 12}
        height={18}
        rx={6}
        fill="#020617"
        stroke={isError ? '#ef4444' : '#334155'}
        strokeWidth={1}
      />
      <text
        textAnchor="middle"
        y={3}
        className={`font-mono text-[9px] font-bold fill-current ${isError ? 'text-red-400' : 'text-slate-400'}`}
      >
        {text}
      </text>
    </g>
  );
}
