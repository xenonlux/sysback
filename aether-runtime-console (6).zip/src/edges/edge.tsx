/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface EdgeProps {
  key?: string;
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  label?: string;
  isSelected?: boolean;
  isCompatible?: boolean; // Live validation check
  onDelete?: () => void;
}

export default function Edge({
  id,
  x1,
  y1,
  x2,
  y2,
  label,
  isSelected = false,
  isCompatible = true,
  onDelete
}: EdgeProps) {
  // Compute bezier control points
  const dx = Math.abs(x2 - x1) * 0.5;
  const cx1 = x1 + dx;
  const cy1 = y1;
  const cx2 = x2 - dx;
  const cy2 = y2;

  const pathD = `M ${x1} ${y1} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${x2} ${y2}`;

  // Middle point for label positioning
  const midX = x1 + (x2 - x1) * 0.5;
  const midY = y1 + (y2 - y1) * 0.5;

  return (
    <g className="group select-none" id={`edge-group-${id}`}>
      {/* Thick invisible interaction path for easier clicking */}
      <path
        d={pathD}
        fill="none"
        stroke="transparent"
        strokeWidth={15}
        className="cursor-pointer"
        onClick={(e) => {
          e.stopPropagation();
        }}
      />

      {/* Outer shadow glow path */}
      <path
        d={pathD}
        fill="none"
        stroke={!isCompatible ? '#f87171' : isSelected ? '#6366f1' : '#312e81'}
        strokeWidth={isSelected || !isCompatible ? 5 : 3}
        className="transition-all opacity-40 blur-[1px]"
      />

      {/* Main rendering path */}
      <path
        d={pathD}
        fill="none"
        stroke={!isCompatible ? '#ef4444' : isSelected ? '#818cf8' : '#475569'}
        strokeWidth={2}
        strokeDasharray={!isCompatible ? "4,4" : undefined}
        className={`transition-all ${!isCompatible ? 'animate-[dash_1s_linear_infinite]' : 'group-hover:stroke-slate-400'}`}
      />

      {/* Label and delete trigger */}
      {label && (
        <g transform={`translate(${midX}, ${midY})`}>
          <rect
            x={-label.length * 3 - 6}
            y={-10}
            width={label.length * 6 + 12}
            height={18}
            rx={5}
            fill="#090d16"
            stroke={isSelected ? '#6366f1' : '#1e293b'}
            strokeWidth={1}
          />
          <text
            textAnchor="middle"
            y={2}
            className="font-mono text-[9px] font-bold text-slate-400 select-none fill-current"
          >
            {label}
          </text>
        </g>
      )}

      {/* Delete cross button when selected */}
      {isSelected && onDelete && (
        <g
          transform={`translate(${midX}, ${midY + (label ? 16 : 0)})`}
          className="cursor-pointer"
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
        >
          <circle r={8} fill="#ef4444" className="hover:fill-red-500 transition-all" />
          <path d="M -3.5 -3.5 L 3.5 3.5 M -3.5 3.5 L 3.5 -3.5" stroke="white" strokeWidth={1.5} />
        </g>
      )}
    </g>
  );
}
