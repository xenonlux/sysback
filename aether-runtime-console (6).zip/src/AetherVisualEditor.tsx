/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Canvas from './canvas/canvas';
import NodePalette from './toolbar/node-palette';
import ActionBar from './toolbar/action-bar';
import { VisualNode, VisualEdge, VisualNodeType } from './nodes/types';
import { astToVisual } from './sync/ast-to-visual';
import { visualToCode } from './sync/visual-to-ast';
import { autoLayoutNodes } from './canvas/auto-layout';
import { parseAetherCode } from '../packages/cli/src/parser';

interface AetherVisualEditorProps {
  initialCode?: string;
  initialAst?: any[];
  onChange?: (code: string, ast?: any[]) => void;
}

export default function AetherVisualEditor({
  initialCode = '',
  initialAst,
  onChange,
}: AetherVisualEditorProps) {
  const [nodes, setNodes] = useState<VisualNode[]>([]);
  const [edges, setEdges] = useState<VisualEdge[]>([]);

  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);

  // Undo / Redo History stack states
  const [history, setHistory] = useState<{ nodes: VisualNode[]; edges: VisualEdge[] }[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // 1. Initial hydration from parsed AST code input
  useEffect(() => {
    let sourceStatements: any[] = [];
    if (initialAst && initialAst.length > 0) {
      sourceStatements = initialAst;
    } else if (initialCode) {
      try {
        sourceStatements = parseAetherCode(initialCode);
      } catch (err) {
        // Fallback mockup boilerplate if parsing fails on stub or user edit
        sourceStatements = [
          {
            type: 'LetStatement',
            name: 'claims',
            value: { type: 'Literal', value: { user: 'admin@aether.net' } },
          },
          {
            type: 'EmitStatement',
            signal: 'security.authenticate',
            data: { type: 'Identifier', name: 'claims' },
          },
          {
            type: 'YieldStatement',
            value: { type: 'Literal', value: true },
          },
        ];
      }
    }

    const graph = astToVisual(sourceStatements);

    // If empty graph, populate a default starting set
    if (graph.nodes.length === 0) {
      graph.nodes = [
        {
          id: 'node_let_start',
          type: 'let',
          name: 'claims',
          x: 80,
          y: 40,
          width: 210,
          height: 130,
          data: { expression: '{ user: "controller@aether.io" }' },
          inputs: [{ id: 'in', name: 'in', direction: 'in', type: 'control' }],
          outputs: [{ id: 'out', name: 'val', direction: 'out', type: 'object' }],
        },
        {
          id: 'node_emit_start',
          type: 'emit',
          name: 'security.authorize',
          x: 380,
          y: 40,
          width: 210,
          height: 130,
          data: { expression: 'claims' },
          inputs: [
            { id: 'in', name: 'in', direction: 'in', type: 'control' },
            { id: 'data', name: 'feed', direction: 'in', type: 'object' },
          ],
          outputs: [{ id: 'out', name: 'emit', direction: 'out', type: 'signal' }],
        },
      ];
      graph.edges = [
        {
          id: 'edge_start_1',
          sourceId: 'node_let_start',
          sourcePortId: 'out',
          targetId: 'node_emit_start',
          targetPortId: 'data',
        },
      ];
    }

    setNodes(graph.nodes);
    setEdges(graph.edges);

    // Bootstrap history state
    setHistory([{ nodes: graph.nodes, edges: graph.edges }]);
    setHistoryIndex(0);
  }, []);

  // Save changes to history (undo-redo manager)
  const pushHistory = (newNodes: VisualNode[], newEdges: VisualEdge[]) => {
    const nextHistory = history.slice(0, historyIndex + 1);
    const updatedHistory = [...nextHistory, { nodes: newNodes, edges: newEdges }];

    // Limit steps history to max 20 steps
    if (updatedHistory.length > 20) {
      updatedHistory.shift();
    }

    setHistory(updatedHistory);
    setHistoryIndex(updatedHistory.length - 1);
  };

  const handleUpdateNodes = (updated: VisualNode[]) => {
    setNodes(updated);
    pushHistory(updated, edges);
    syncChangesToParent(updated, edges);
  };

  // 2. Click palette action to spawn fresh nodes
  const handleAddNode = (type: VisualNodeType) => {
    // Generate ports based on node spec
    const inputs: any[] = [];
    const outputs: any[] = [];

    let name = '';
    let nodeW = 210;
    let nodeH = 135;
    let data: any = {};

    switch (type) {
      case 'stream':
        name = 'network.ingress';
        inputs.push({ id: 'in', name: 'stream', direction: 'in', type: 'signal' });
        outputs.push({ id: 'out', name: 'events', direction: 'out', type: 'signal' });
        nodeW = 240;
        nodeH = 180;
        break;
      case 'handler':
        name = 'on_message';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'control' });
        outputs.push({ id: 'out', name: 'data', direction: 'out', type: 'object' });
        break;
      case 'validate':
        name = 'userRecord';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'control' });
        outputs.push({ id: 'out', name: 'valid', direction: 'out', type: 'boolean' });
        data = { constraints: {} };
        nodeH = 220;
        break;
      case 'flow':
        name = 'metrics';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'control' });
        outputs.push({ id: 'out', name: 'saved', direction: 'out', type: 'control' });
        break;
      case 'emit':
        name = 'telemetry.alert';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'control' });
        inputs.push({ id: 'data', name: 'feed', direction: 'in', type: 'object' });
        outputs.push({ id: 'out', name: 'emit', direction: 'out', type: 'signal' });
        break;
      case 'yield':
        name = 'claims';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'any' });
        break;
      case 'branch':
        name = 'priority > 50';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'control' });
        outputs.push({ id: 'then', name: 'then', direction: 'out', type: 'control' });
        outputs.push({ id: 'else', name: 'else', direction: 'out', type: 'control' });
        break;
      case 'let':
        name = 'threshold';
        inputs.push({ id: 'in', name: 'in', direction: 'in', type: 'control' });
        outputs.push({ id: 'out', name: 'val', direction: 'out', type: 'number' });
        data = { expression: '100' };
        break;
    }

    // Place spawned node at center viewport offset
    const newNode: VisualNode = {
      id: `node_${type}_${Date.now()}`,
      type,
      name,
      x: 160 + Math.random() * 80,
      y: 120 + Math.random() * 80,
      width: nodeW,
      height: nodeH,
      inputs,
      outputs,
      data,
    };

    const nextNodes = [...nodes, newNode];
    setNodes(nextNodes);
    pushHistory(nextNodes, edges);
    syncChangesToParent(nextNodes, edges);
  };

  // Port Connections management
  const handleAddEdge = (edge: VisualEdge) => {
    // Avoid double connections to the exact target port
    const filteredEdges = edges.filter(
      (e) => !(e.targetId === edge.targetId && e.targetPortId === edge.targetPortId)
    );
    const nextEdges = [...filteredEdges, edge];
    setEdges(nextEdges);
    pushHistory(nodes, nextEdges);
    syncChangesToParent(nodes, nextEdges);
  };

  const handleDeleteEdge = (edgeId: string) => {
    const nextEdges = edges.filter((e) => e.id !== edgeId);
    setEdges(nextEdges);
    pushHistory(nodes, nextEdges);
    syncChangesToParent(nodes, nextEdges);
  };

  // 3. Layout arranger trigger
  const handleAutoLayout = () => {
    const alignedNodes = autoLayoutNodes(nodes, edges);
    setNodes(alignedNodes);
    pushHistory(alignedNodes, edges);
    syncChangesToParent(alignedNodes, edges);
  };

  // Undo / Redo controls
  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      const state = history[prevIdx];
      setNodes(state.nodes);
      setEdges(state.edges);
      setHistoryIndex(prevIdx);
      syncChangesToParent(state.nodes, state.edges);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIdx = historyIndex + 1;
      const state = history[nextIdx];
      setNodes(state.nodes);
      setEdges(state.edges);
      setHistoryIndex(nextIdx);
      syncChangesToParent(state.nodes, state.edges);
    }
  };

  // Push changes upward to editor shell
  const syncChangesToParent = (currentNodes: VisualNode[], currentEdges: VisualEdge[]) => {
    if (onChange) {
      const compiledCode = visualToCode(currentNodes, currentEdges);
      let parsedAst: any[] = [];
      try {
        parsedAst = parseAetherCode(compiledCode);
      } catch (err) {
        // quiet fail on intermediate broken syntax
      }
      onChange(compiledCode, parsedAst);
    }
  };

  const handleExport = () => {
    const compiledCode = visualToCode(nodes, edges);
    if (onChange) {
      onChange(compiledCode);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4 select-none animate-fade-in" id="aether-visual-editor">
      {/* Top action header bar */}
      <ActionBar
        onRun={handleExport}
        onAutoLayout={handleAutoLayout}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onExport={handleExport}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
      />

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-stretch">
        {/* Left Side Catalog palette */}
        <div className="xl:col-span-3">
          <NodePalette onAddNode={handleAddNode} />
        </div>

        {/* Central interactive zoomable canvas */}
        <div className="xl:col-span-9 flex flex-col">
          <Canvas
            nodes={nodes}
            edges={edges}
            selectedNodeId={selectedNodeId}
            selectedEdgeId={selectedEdgeId}
            onSelectNode={setSelectedNodeId}
            onSelectEdge={setSelectedEdgeId}
            onUpdateNodes={handleUpdateNodes}
            onAddEdge={handleAddEdge}
            onDeleteEdge={handleDeleteEdge}
          />
        </div>
      </div>
    </div>
  );
}
