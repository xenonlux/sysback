/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VisualNode, VisualEdge } from '../nodes/types';

/**
 * Custom layered tree layout arrangement
 * Ranks nodes sequentially and separates them horizontally & vertically
 */
export function autoLayoutNodes(nodes: VisualNode[], edges: VisualEdge[]): VisualNode[] {
  if (nodes.length === 0) return nodes;

  const nodeMap = new Map<string, VisualNode>();
  nodes.forEach(n => nodeMap.set(n.id, { ...n }));

  // Find incoming edge counts for each node to detect root statements
  const inDegree = new Map<string, number>();
  nodes.forEach(n => inDegree.set(n.id, 0));

  edges.forEach(e => {
    const current = inDegree.get(e.targetId) || 0;
    inDegree.set(e.targetId, current + 1);
  });

  // Basic topological/layered ranking
  const ranks: Record<string, number> = {};
  const visited = new Set<string>();

  // Assign layers based on graph traversal
  function assignRanks(nodeId: string, currentRank: number) {
    if (visited.has(nodeId)) {
      ranks[nodeId] = Math.max(ranks[nodeId] || 0, currentRank);
      return;
    }
    visited.add(nodeId);
    ranks[nodeId] = currentRank;

    // Outgoing links
    const outEdges = edges.filter(e => e.sourceId === nodeId);
    outEdges.forEach(e => {
      assignRanks(e.targetId, currentRank + 1);
    });
  }

  // Start ranking from root nodes (those with 0 incoming links)
  const roots = nodes.filter(n => (inDegree.get(n.id) || 0) === 0);
  if (roots.length === 0 && nodes.length > 0) {
    // If cyclic/empty, treat first node as root
    assignRanks(nodes[0].id, 0);
  } else {
    roots.forEach(r => assignRanks(r.id, 0));
  }

  // Collect unvisited nodes as Rank 0
  nodes.forEach(n => {
    if (ranks[n.id] === undefined) {
      ranks[n.id] = 0;
    }
  });

  // Group nodes by Rank column
  const rankGroups: Record<number, string[]> = {};
  Object.entries(ranks).forEach(([nodeId, rankVal]) => {
    if (!rankGroups[rankVal]) {
      rankGroups[rankVal] = [];
    }
    rankGroups[rankVal].push(nodeId);
  });

  const layoutXGap = 290;
  const layoutYGap = 180;
  const startX = 60;
  const startY = 80;

  // Re-position nodes on grid columns based on layered rank groups
  Object.entries(rankGroups).forEach(([rankStr, nodesInRank]) => {
    const rank = Number(rankStr);
    const colX = startX + rank * layoutXGap;

    nodesInRank.forEach((nodeId, index) => {
      const node = nodeMap.get(nodeId);
      if (node) {
        node.x = colX;
        node.y = startY + index * layoutYGap;

        // Visual adjustment for STREAM containers which are typically wider/taller
        if (node.type === 'stream') {
          node.x += 20;
          node.y -= 10;
        }
      }
    });
  });

  return Array.from(nodeMap.values());
}
