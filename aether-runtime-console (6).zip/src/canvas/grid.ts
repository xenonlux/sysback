/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const GRID_SIZE = 20;

/**
 * Snap a coordinate to the nearest grid step
 */
export function snapToGrid(coord: number): number {
  return Math.round(coord / GRID_SIZE) * GRID_SIZE;
}

/**
 * Snap x and y
 */
export function snapPosition(x: number, y: number): { x: number; y: number } {
  return {
    x: snapToGrid(x),
    y: snapToGrid(y),
  };
}

/**
 * Alignment guidelines helpers
 * Finds list of nodes that share close to same x or y coordinates
 */
export interface AlignmentGuide {
  type: 'x' | 'y';
  value: number;
}

export function findAlignmentGuides(
  draggedNode: { x: number; y: number; width: number; height: number },
  allNodes: { id: string; x: number; y: number; width?: number; height?: number }[],
  draggedId: string,
  threshold = 8
): { guides: AlignmentGuide[]; snappedX: number; snappedY: number } {
  const guides: AlignmentGuide[] = [];
  let snappedX = draggedNode.x;
  let snappedY = draggedNode.y;

  const dragCenterX = draggedNode.x + draggedNode.width / 2;
  const dragCenterY = draggedNode.y + draggedNode.height / 2;

  for (const node of allNodes) {
    if (node.id === draggedId) continue;
    const nodeW = node.width || 180;
    const nodeH = node.height || 100;
    const nodeCenterX = node.x + nodeW / 2;
    const nodeCenterY = node.y + nodeH / 2;

    // Check X alignments (left, center, right)
    if (Math.abs(draggedNode.x - node.x) < threshold) {
      snappedX = node.x;
      guides.push({ type: 'x', value: node.x });
    } else if (Math.abs((draggedNode.x + draggedNode.width) - (node.x + nodeW)) < threshold) {
      snappedX = node.x + nodeW - draggedNode.width;
      guides.push({ type: 'x', value: node.x + nodeW });
    } else if (Math.abs(dragCenterX - nodeCenterX) < threshold) {
      snappedX = nodeCenterX - draggedNode.width / 2;
      guides.push({ type: 'x', value: nodeCenterX });
    }

    // Check Y alignments (top, center, bottom)
    if (Math.abs(draggedNode.y - node.y) < threshold) {
      snappedY = node.y;
      guides.push({ type: 'y', value: node.y });
    } else if (Math.abs((draggedNode.y + draggedNode.height) - (node.y + nodeH)) < threshold) {
      snappedY = node.y + nodeH - draggedNode.height;
      guides.push({ type: 'y', value: node.y + nodeH });
    } else if (Math.abs(dragCenterY - nodeCenterY) < threshold) {
      snappedY = nodeCenterY - draggedNode.height / 2;
      guides.push({ type: 'y', value: nodeCenterY });
    }
  }

  return { guides, snappedX, snappedY };
}
