/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { VisualNode, VisualEdge } from '../nodes/types';
import { PanZoomState, handleZoom } from './pan-zoom';
import { snapPosition, findAlignmentGuides, AlignmentGuide } from './grid';
import Edge from '../edges/edge';

// Node specific components
import StreamNode from '../nodes/stream-node';
import HandlerNode from '../nodes/handler-node';
import ValidateNode from '../nodes/validate-node';
import FlowNode from '../nodes/flow-node';
import EmitNode from '../nodes/emit-node';
import YieldNode from '../nodes/yield-node';
import BranchNode from '../nodes/branch-node';
import LetNode from '../nodes/let-node';

interface CanvasProps {
  nodes: VisualNode[];
  edges: VisualEdge[];
  selectedNodeId: string | null;
  selectedEdgeId: string | null;
  onSelectNode: (id: string | null) => void;
  onSelectEdge: (id: string | null) => void;
  onUpdateNodes: (updated: VisualNode[]) => void;
  onAddEdge: (edge: VisualEdge) => void;
  onDeleteEdge: (id: string) => void;
}

export default function Canvas({
  nodes,
  edges,
  selectedNodeId,
  selectedEdgeId,
  onSelectNode,
  onSelectEdge,
  onUpdateNodes,
  onAddEdge,
  onDeleteEdge,
}: CanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Pan Zoom States
  const [transform, setTransform] = useState<PanZoomState>({ x: 0, y: 0, zoom: 0.9 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  // Node Drag States
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [guides, setGuides] = useState<AlignmentGuide[]>([]);

  // Connection Dragging States
  const [activeConnection, setActiveConnection] = useState<{
    sourceNodeId: string;
    sourcePortId: string;
    cursorX: number;
    cursorY: number;
    sourceType: string;
  } | null>(null);

  // Convert client cursor coords into local canvas coordinates
  const getLocalCoords = (clientX: number, clientY: number) => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    return {
      x: (clientX - rect.left - transform.x) / transform.zoom,
      y: (clientY - rect.top - transform.y) / transform.zoom,
    };
  };

  // 1. Mouse wheel zoom handlers
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const nextTransform = handleZoom(e, transform, rect);
    setTransform(nextTransform);
  };

  // 2. Pointer down on blank space (pan start) or node dragging start
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    // Left mouse click only
    if (e.button !== 0) return;

    // Deselect everything when clicking blank spaces
    onSelectNode(null);
    onSelectEdge(null);

    setIsPanning(true);
    setPanStart({ x: e.clientX - transform.x, y: e.clientY - transform.y });
    containerRef.current?.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isPanning) {
      setTransform((prev) => ({
        ...prev,
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      }));
      return;
    }

    if (draggedNodeId) {
      const coords = getLocalCoords(e.clientX, e.clientY);
      const targetNode = nodes.find((n) => n.id === draggedNodeId);
      if (targetNode) {
        const rawX = coords.x - dragOffset.x;
        const rawY = coords.y - dragOffset.y;

        // Visual snapped positions via grids snapping
        const snapped = snapPosition(rawX, rawY);

        // Calculate alignment guidelines
        const nodeW = targetNode.width || 210;
        const nodeH = targetNode.height || 140;
        const alignResult = findAlignmentGuides(
          { x: snapped.x, y: snapped.y, width: nodeW, height: nodeH },
          nodes,
          draggedNodeId
        );

        setGuides(alignResult.guides);

        onUpdateNodes(
          nodes.map((n) =>
            n.id === draggedNodeId
              ? { ...n, x: alignResult.snappedX, y: alignResult.snappedY }
              : n
          )
        );
      }
      return;
    }

    if (activeConnection) {
      const coords = getLocalCoords(e.clientX, e.clientY);
      setActiveConnection((prev) =>
        prev
          ? {
              ...prev,
              cursorX: coords.x,
              cursorY: coords.y,
            }
          : null
      );
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isPanning) {
      setIsPanning(false);
      containerRef.current?.releasePointerCapture(e.pointerId);
    }

    if (draggedNodeId) {
      setDraggedNodeId(null);
      setGuides([]);
    }

    if (activeConnection) {
      // Check if dropped on compatible port
      const target = e.target as HTMLElement;
      const targetPortEl = target.closest('[data-port-id]');
      if (targetPortEl) {
        const targetNodeId = targetPortEl.getAttribute('data-node-id');
        const targetPortId = targetPortEl.getAttribute('data-port-id');
        const targetDirection = targetPortEl.getAttribute('data-direction');
        const targetPortType = targetPortEl.getAttribute('data-port-type');

        if (
          targetNodeId &&
          targetPortId &&
          targetNodeId !== activeConnection.sourceNodeId &&
          targetDirection === 'in'
        ) {
          // Double verify type compatibility (e.g. control is strictly matching, others matching data types)
          const isCompatible =
            activeConnection.sourceType === targetPortType ||
            activeConnection.sourceType === 'any' ||
            targetPortType === 'any' ||
            (activeConnection.sourceType === 'object' && targetPortType === 'control');

          if (isCompatible) {
            onAddEdge({
              id: `edge_${Date.now()}`,
              sourceId: activeConnection.sourceNodeId,
              sourcePortId: activeConnection.sourcePortId,
              targetId: targetNodeId,
              targetPortId: targetPortId,
            });
          }
        }
      }
      setActiveConnection(null);
    }
  };

  // Node Drag Handlers
  const handleNodeDragStart = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation();
    onSelectNode(nodeId);
    onSelectEdge(null);

    const coords = getLocalCoords(e.clientX, e.clientY);
    const targetNode = nodes.find((n) => n.id === nodeId);
    if (targetNode) {
      setDraggedNodeId(nodeId);
      setDragOffset({
        x: coords.x - targetNode.x,
        y: coords.y - targetNode.y,
      });
    }
  };

  // Ports Connections handlers
  const handlePointerDownPort = (
    e: React.PointerEvent<HTMLDivElement>,
    nodeId: string,
    portId: string
  ) => {
    e.preventDefault();
    e.stopPropagation();
    const node = nodes.find((n) => n.id === nodeId);
    const port = [...(node?.inputs || []), ...(node?.outputs || [])].find(
      (p) => p.id === portId
    );

    if (node && port && port.direction === 'out') {
      const portX = node.x + (node.width || 210);
      const portY = node.y + 60; // offset inside the foreignObject card
      setActiveConnection({
        sourceNodeId: nodeId,
        sourcePortId: portId,
        cursorX: portX,
        cursorY: portY,
        sourceType: port.type,
      });
    }
  };

  const handlePointerUpPort = (
    e: React.PointerEvent<HTMLDivElement>,
    nodeId: string,
    portId: string
  ) => {
    e.preventDefault();
    e.stopPropagation();
  };

  // Port coordination lookups
  const getPortCoordinate = (nodeId: string, portId: string) => {
    const node = nodes.find((n) => n.id === nodeId);
    if (!node) return { x: 0, y: 0 };

    const nodeW = node.width || 210;
    const isInput =
      node.inputs.find((p) => p.id === portId) !== undefined;

    // Estimate relative position of port dot on Card
    const portIndex = isInput
      ? node.inputs.findIndex((p) => p.id === portId)
      : node.outputs.findIndex((p) => p.id === portId);

    const portYOffset = 110 + portIndex * 24;

    return {
      x: isInput ? node.x : node.x + nodeW,
      y: node.y + portYOffset,
    };
  };

  // Renderer matching for specific styles
  const renderNodeContent = (n: VisualNode) => {
    switch (n.type) {
      case 'stream':
        return (
          <StreamNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'handler':
        return (
          <HandlerNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'validate':
        return (
          <ValidateNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'flow':
        return (
          <FlowNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'emit':
        return (
          <EmitNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'yield':
        return (
          <YieldNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'branch':
        return (
          <BranchNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      case 'let':
        return (
          <LetNode
            node={n}
            isSelected={selectedNodeId === n.id}
            onPointerDownPort={handlePointerDownPort}
            onPointerUpPort={handlePointerUpPort}
            onNodeChange={(updated) =>
              onUpdateNodes(nodes.map((orig) => (orig.id === n.id ? updated : orig)))
            }
          />
        );
      default:
        return null;
    }
  };

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      onPointerDown={handlePointerDown}
      onPointerMouseMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      className="flex-1 bg-slate-950 rounded-3xl border border-slate-900 overflow-hidden relative select-none h-[520px] cursor-grab active:cursor-grabbing shadow-inner"
      id="aether-flow-canvas"
    >
      {/* Background GRID Dots representation */}
      <div
        className="absolute inset-0 pointer-events-none opacity-40 transition-all bg-[radial-gradient(#1e293b_1.5px,transparent_1.5px)] [background-size:20px_20px]"
        style={{
          backgroundPosition: `${transform.x}px ${transform.y}px`,
        }}
      />

      {/* Actual nodes container transformed via pan zoom */}
      <div
        className="absolute inset-0 origin-top-left pointer-events-none"
        style={{
          transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.zoom})`,
        }}
      >
        <svg className="absolute overflow-visible w-full h-full pointer-events-auto">
          {/* Alignment guides render */}
          {guides.map((g, i) => (
            <line
              key={i}
              x1={g.type === 'x' ? g.value : -2000}
              y1={g.type === 'y' ? g.value : -2000}
              x2={g.type === 'x' ? g.value : 5000}
              y2={g.type === 'y' ? g.value : 5000}
              stroke="#ef4444"
              strokeWidth={1}
              strokeDasharray="4,4"
              className="opacity-70"
            />
          ))}

          {/* Render Connections Cards links */}
          {edges.map((e) => {
            const p1 = getPortCoordinate(e.sourceId, e.sourcePortId);
            const p2 = getPortCoordinate(e.targetId, e.targetPortId);

            return (
              <Edge
                key={e.id}
                id={e.id}
                x1={p1.x}
                y1={p1.y}
                x2={p2.x}
                y2={p2.y}
                label={e.label}
                isSelected={selectedEdgeId === e.id}
                onDelete={() => onDeleteEdge(e.id)}
              />
            );
          })}

          {/* Draft curve connection during pointer drag */}
          {activeConnection && (() => {
            const node = nodes.find((n) => n.id === activeConnection.sourceNodeId);
            if (!node) return null;
            const p1 = getPortCoordinate(
              activeConnection.sourceNodeId,
              activeConnection.sourcePortId
            );
            return (
              <path
                d={`M ${p1.x} ${p1.y} C ${p1.x + Math.abs(activeConnection.cursorX - p1.x) * 0.5} ${p1.y}, ${activeConnection.cursorX - Math.abs(activeConnection.cursorX - p1.x) * 0.5} ${activeConnection.cursorY}, ${activeConnection.cursorX} ${activeConnection.cursorY}`}
                fill="none"
                stroke="#6366f1"
                strokeWidth={2}
                strokeDasharray="4,4"
                className="opacity-80"
              />
            );
          })()}
        </svg>

        {/* ForeignObject container holding HTML cards */}
        <div className="absolute top-0 left-0 pointer-events-auto">
          {nodes.map((n) => {
            const width = n.width || 215;
            const height = n.height || 140;

            return (
              <div
                key={n.id}
                style={{
                  position: 'absolute',
                  left: n.x,
                  top: n.y,
                  width: width,
                  height: height,
                  zIndex: selectedNodeId === n.id ? 50 : 10,
                }}
                onMouseDown={(e) => handleNodeDragStart(e, n.id)}
                className="cursor-pointer"
                id={`visnode-${n.id}`}
              >
                {renderNodeContent(n)}
              </div>
            );
          })}
        </div>
      </div>

      {/* Floating Canvas Meta metrics label */}
      <div className="absolute top-4 left-4 bg-slate-900/90 border border-slate-800 p-3 rounded-2xl text-[10px] font-mono text-slate-400 backdrop-blur space-y-1 select-none shadow-md">
        <div className="flex items-center space-x-1.5 font-bold text-indigo-400">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Infinite Mesh Canvas</span>
        </div>
        <div>Zoom scale: {(transform.zoom * 100).toFixed(0)}%</div>
        <div>Pan: {transform.x.toFixed(0)}, {transform.y.toFixed(0)}</div>
      </div>

      {/* Floating MiniMap Corner */}
      <div className="absolute bottom-4 right-4 w-32 h-24 bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl backdrop-blur select-none shadow-xl flex flex-col justify-between">
        <span className="text-[8px] font-black uppercase text-slate-500 block tracking-wider">MiniMap</span>
        <div className="flex-1 bg-slate-950 rounded-lg overflow-hidden relative border border-slate-950/80">
          {/* Render scaled representation of nodes on minimap */}
          {nodes.map((n) => {
            const scale = 0.05;
            const mx = 64 + (n.x - 200) * scale;
            const my = 40 + (n.y - 100) * scale;
            const nodeColor =
              n.type === 'stream'
                ? '#0ea5e9'
                : n.type === 'handler'
                ? '#8b5cf6'
                : n.type === 'validate'
                ? '#10b981'
                : n.type === 'emit'
                ? '#f97316'
                : '#6366f1';

            return (
              <div
                key={n.id}
                className="absolute rounded"
                style={{
                  left: mx,
                  top: my,
                  width: 12,
                  height: 8,
                  backgroundColor: nodeColor,
                  opacity: 0.7,
                }}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
