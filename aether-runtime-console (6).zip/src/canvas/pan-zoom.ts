/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export interface PanZoomState {
  x: number;
  y: number;
  zoom: number;
}

export function handleZoom(
  e: React.WheelEvent<HTMLDivElement>,
  current: PanZoomState,
  rect: DOMRect
): PanZoomState {
  const zoomIntensity = 0.1;
  const minZoom = 0.2;
  const maxZoom = 2.5;

  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;

  // Wheel delta
  const wheel = e.deltaY < 0 ? 1 : -1;
  const zoomFactor = Math.exp(wheel * zoomIntensity);

  const nextZoom = Math.min(Math.max(current.zoom * zoomFactor, minZoom), maxZoom);

  // Center zoom on mouse position
  const dx = mouseX - current.x;
  const dy = mouseY - current.y;

  return {
    x: mouseX - dx * (nextZoom / current.zoom),
    y: mouseY - dy * (nextZoom / current.zoom),
    zoom: nextZoom,
  };
}
