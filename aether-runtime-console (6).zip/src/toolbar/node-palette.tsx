/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Bell, ShieldCheck, Database, Zap, ArrowRight, GitBranch, Variable, Plus } from 'lucide-react';
import { VisualNodeType } from '../nodes/types';

interface PaletteItem {
  type: VisualNodeType;
  label: string;
  description: string;
  icon: React.ReactNode;
  colorClass: string;
}

const PALETTE_ITEMS: PaletteItem[] = [
  {
    type: 'stream',
    label: 'Aether Stream',
    description: 'Binds a streaming port or category (blue container box)',
    icon: <Shield className="h-4 w-4" />,
    colorClass: 'bg-sky-500/10 text-sky-400 border-sky-500/30'
  },
  {
    type: 'handler',
    label: 'Event Handler',
    description: 'Listen to signals on a stream channel',
    icon: <Bell className="h-4 w-4" />,
    colorClass: 'bg-violet-500/10 text-violet-400 border-violet-500/30'
  },
  {
    type: 'validate',
    label: 'Validator check',
    description: 'Diamond shape schema fields validation',
    icon: <ShieldCheck className="h-4 w-4" />,
    colorClass: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
  },
  {
    type: 'flow',
    label: 'B-Tree Storage',
    description: 'Cylinder storage node, write data queries',
    icon: <Database className="h-4 w-4" />,
    colorClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30'
  },
  {
    type: 'emit',
    label: 'Signal Emit',
    description: 'Lightning bolt, broadcast events to Bus listeners',
    icon: <Zap className="h-4 w-4" />,
    colorClass: 'bg-orange-500/10 text-orange-400 border-orange-500/30'
  },
  {
    type: 'yield',
    label: 'Pipeline Yield',
    description: 'Response output arrow return statement',
    icon: <ArrowRight className="h-4 w-4" />,
    colorClass: 'bg-sky-500/10 text-sky-350 border-sky-400/30'
  },
  {
    type: 'branch',
    label: 'If / Else Branch',
    description: 'Logic split pipeline for true/false rules',
    icon: <GitBranch className="h-4 w-4" />,
    colorClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30'
  },
  {
    type: 'let',
    label: 'Variable Assign',
    description: 'Declare an expression or object parameters in memory',
    icon: <Variable className="h-4 w-4" />,
    colorClass: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30'
  }
];

interface NodePaletteProps {
  onAddNode: (type: VisualNodeType) => void;
}

export default function NodePalette({ onAddNode }: NodePaletteProps) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 flex flex-col h-full" id="node-palette">
      <div className="border-b border-slate-850 pb-2">
        <h3 className="text-xs font-black text-slate-200 uppercase tracking-wider">Aether Palette</h3>
        <p className="text-[10px] text-slate-500 mt-1">Click to drop premium visual nodes onto your compiler canvas:</p>
      </div>

      <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[460px] pr-1">
        {PALETTE_ITEMS.map((item) => (
          <div
            key={item.type}
            onClick={() => onAddNode(item.type)}
            className="group flex items-start space-x-3 p-3/5 bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 rounded-2xl cursor-pointer transition-all active:scale-[0.98]"
            title={`Spawn ${item.label}`}
          >
            <div className={`p-2 rounded-xl border ${item.colorClass} shrink-0`}>
              {item.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="text-[11px] font-bold text-slate-200 group-hover:text-white transition">
                  {item.label}
                </h4>
                <Plus className="h-3.5 w-3.5 text-slate-600 group-hover:text-slate-400 transition" />
              </div>
              <p className="text-[9.5px] text-slate-500 leading-normal mt-0.5 group-hover:text-slate-400 transition truncate">
                {item.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
