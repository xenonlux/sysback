/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, AlignCenter, RotateCcw, RotateCw, Download, Layers, Sparkles, Copy, CalendarRange } from 'lucide-react';

interface ActionBarProps {
  onRun: () => void;
  onAutoLayout: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onExport: () => void;
  canUndo: boolean;
  canRedo: boolean;
}

export default function ActionBar({
  onRun,
  onAutoLayout,
  onUndo,
  onRedo,
  onExport,
  canUndo,
  canRedo,
}: ActionBarProps) {
  return (
    <div
      className="bg-slate-900 border border-slate-800 p-2.5 rounded-2xl flex items-center justify-between gap-4 flex-wrap"
      id="aether-action-bar"
    >
      <div className="flex items-center space-x-2">
        {/* Undo / Redo */}
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className={`p-2 rounded-xl border transition cursor-pointer flex items-center justify-center ${
            canUndo
              ? 'bg-slate-950 border-slate-850 text-slate-300 hover:bg-slate-850 hover:text-white'
              : 'border-transparent text-slate-650 cursor-not-allowed'
          }`}
          title="Undo Action"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
        <button
          onClick={onRedo}
          disabled={!canRedo}
          className={`p-2 rounded-xl border transition cursor-pointer flex items-center justify-center ${
            canRedo
              ? 'bg-slate-950 border-slate-850 text-slate-300 hover:bg-slate-850 hover:text-white'
              : 'border-transparent text-slate-650 cursor-not-allowed'
          }`}
          title="Redo Action"
        >
          <RotateCw className="h-4 w-4" />
        </button>

        <div className="w-px h-6 bg-slate-800" />

        {/* Auto Layout */}
        <button
          onClick={onAutoLayout}
          className="p-2 bg-slate-950 border border-slate-850 hover:bg-slate-850 text-indigo-400 hover:text-indigo-300 rounded-xl transition cursor-pointer flex items-center space-x-1.5 text-xs font-bold"
          title="Auto-Arrange Layout (Hierarchical Tree)"
        >
          <Layers className="h-4 w-4" />
          <span>Auto Layout</span>
        </button>
      </div>

      <div className="flex items-center space-x-2">
        {/* Export compiler script */}
        <button
          onClick={onExport}
          className="p-2 bg-slate-950 border border-slate-850 hover:bg-slate-850 text-slate-300 hover:text-white rounded-xl transition cursor-pointer flex items-center space-x-1.5 text-xs font-bold"
          title="Export AETHER Visual Graph to Code Mode"
        >
          <Download className="h-4 w-4" />
          <span>Sync Code</span>
        </button>

        {/* Run VM Script */}
        <button
          onClick={onRun}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-550 text-white font-bold rounded-xl transition active:scale-95 text-xs flex items-center space-x-2 cursor-pointer shadow-md shadow-indigo-600/10"
          title="Compile and execution in VM sandbox"
        >
          <Play className="h-3.5 w-3.5 fill-white" />
          <span>Run Flow</span>
        </button>
      </div>
    </div>
  );
}
