/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Play } from 'lucide-react';
import { VisualNode } from './types';
import Port from '../edges/port';

interface NodeProps {
  node: VisualNode;
  isSelected?: boolean;
  onPointerDownPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUpPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onNodeChange?: (updated: VisualNode) => void;
}

export default function StreamNode({
  node,
  isSelected = false,
  onPointerDownPort,
  onPointerUpPort,
  onNodeChange
}: NodeProps) {
  const width = node.width || 240;
  const height = node.height || 180;

  return (
    <div
      className={`h-full w-full rounded-2xl flex flex-col bg-sky-950/20 border-2 transition-all p-3.5 select-none relative group ${
        isSelected ? 'border-sky-500 shadow-[0_0_15px_rgba(14,165,233,0.35)]' : 'border-sky-800'
      }`}
    >
      {/* Stream container Name Header */}
      <div className="flex items-center justify-between pb-2 border-b border-sky-900/60 mb-2">
        <div className="flex items-center space-x-2 text-sky-400">
          <Shield className="h-4 w-4" />
          <span className="text-xs font-black uppercase tracking-wider">AETHER STREAM</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-1.5">
          <label className="text-[10px] text-slate-500 uppercase font-mono font-bold">Stream Channel / URI</label>
          <input
            type="text"
            className="w-full bg-slate-950/85 border border-sky-950 text-sky-200 text-xs px-2 py-1 rounded-md font-mono focus:outline-none focus:border-sky-500"
            value={node.name}
            onChange={(e) => {
              if (onNodeChange) {
                onNodeChange({ ...node, name: e.target.value });
              }
            }}
          />
        </div>

        {/* Input & Output Ports listing */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-2 border-t border-sky-900/40">
          <div className="space-y-1">
            {node.inputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
          <div className="space-y-1 flex flex-col items-end">
            {node.outputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
