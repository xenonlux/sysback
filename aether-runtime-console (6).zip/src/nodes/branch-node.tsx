/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GitBranch } from 'lucide-react';
import { VisualNode } from './types';
import Port from '../edges/port';

interface NodeProps {
  node: VisualNode;
  isSelected?: boolean;
  onPointerDownPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUpPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onNodeChange?: (updated: VisualNode) => void;
}

export default function BranchNode({
  node,
  isSelected = false,
  onPointerDownPort,
  onPointerUpPort,
  onNodeChange
}: NodeProps) {
  return (
    <div
      className={`h-full w-full rounded-2xl flex flex-col bg-rose-950/20 border-2 transition-all p-4 select-none relative group ${
        isSelected ? 'border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.35)]' : 'border-rose-900'
      }`}
    >
      {/* Visual Diamond / Branch symbol */}
      <div className="flex items-center justify-between pb-2 border-b border-rose-900/60 mb-2">
        <div className="flex items-center space-x-2 text-rose-450">
          <div className="w-5 h-5 bg-rose-500/15 border border-rose-500/30 rotate-45 flex items-center justify-center shrink-0">
            <GitBranch className="h-3 w-3 -rotate-45" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-wider">LOGICAL BRANCH</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-1">
          <label className="text-[9px] text-slate-500 uppercase font-mono font-bold">If Condition</label>
          <input
            type="text"
            className="w-full bg-slate-950/80 border border-rose-950 text-rose-200 text-xs px-2 py-1 rounded-md font-mono focus:outline-none focus:border-rose-500"
            value={node.name}
            onChange={(e) => {
              if (onNodeChange) {
                onNodeChange({ ...node, name: e.target.value });
              }
            }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-rose-900/40">
          <div className="space-y-1 font-mono text-[9px]">
            {node.inputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
          <div className="space-y-1 flex flex-col items-end font-mono text-[9px]">
            {node.outputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
