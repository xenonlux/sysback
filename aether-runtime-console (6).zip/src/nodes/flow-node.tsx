/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Database } from 'lucide-react';
import { VisualNode } from './types';
import Port from '../edges/port';

interface NodeProps {
  node: VisualNode;
  isSelected?: boolean;
  onPointerDownPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUpPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onNodeChange?: (updated: VisualNode) => void;
}

export default function FlowNode({
  node,
  isSelected = false,
  onPointerDownPort,
  onPointerUpPort,
  onNodeChange
}: NodeProps) {
  return (
    <div
      className={`h-full w-full rounded-2xl flex flex-col bg-amber-950/20 border-2 transition-all p-4 select-none relative group ${
        isSelected ? 'border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.35)]' : 'border-amber-805'
      }`}
    >
      {/* Visual Cylinder Shape header */}
      <div className="flex items-center justify-between pb-2 border-b border-amber-900/60 mb-2">
        <div className="flex items-center space-x-2 text-amber-400">
          {/* Cylinder SVG path representation */}
          <div className="w-5 h-5 flex flex-col items-center justify-center shrink-0">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-4 h-4">
              <path d="M12 2C6.48 2 2 3.79 2 6v12c0 2.21 4.48 4 10 4s10-1.79 10-4V6c0-2.21-4.48-4-10-4z" />
              <path d="M23 12c0 2.21-4.48 4-10 4S2 14.21 2 12" className="opacity-70" />
              <path d="M23 6c0 2.21-4.48 4-10 4S2 8.21 2 6" className="opacity-90" />
            </svg>
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest">AETHER B-TREE STORE</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-1">
          <label className="text-[9px] text-slate-500 uppercase font-mono font-bold">Store Node Name</label>
          <input
            type="text"
            className="w-full bg-slate-950/80 border border-amber-950 text-amber-200 text-xs px-2 py-1 rounded-md font-mono focus:outline-none focus:border-amber-500"
            value={node.name}
            onChange={(e) => {
              if (onNodeChange) {
                onNodeChange({ ...node, name: e.target.value });
              }
            }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-amber-900/30">
          <div className="space-y-1">
            {node.inputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
          <div className="space-y-1 flex flex-col items-end">
            {node.outputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
