/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShieldCheck, Plus, Trash2 } from 'lucide-react';
import { VisualNode } from './types';
import Port from '../edges/port';

interface NodeProps {
  node: VisualNode;
  isSelected?: boolean;
  onPointerDownPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUpPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onNodeChange?: (updated: VisualNode) => void;
}

export default function ValidateNode({
  node,
  isSelected = false,
  onPointerDownPort,
  onPointerUpPort,
  onNodeChange
}: NodeProps) {
  const [newKey, setNewKey] = useState('');
  const [newType, setNewType] = useState<any>('string');

  const constraints = node.data?.constraints || {};

  const handleAddConstraint = () => {
    if (!newKey.trim()) return;
    const updatedConstraints = {
      ...constraints,
      [newKey.trim()]: { type: newType, required: true }
    };
    if (onNodeChange) {
      onNodeChange({
        ...node,
        data: {
          ...node.data,
          constraints: updatedConstraints
        }
      });
    }
    setNewKey('');
  };

  const handleRemoveConstraint = (keyToDelete: string) => {
    const updatedConstraints = { ...constraints };
    delete updatedConstraints[keyToDelete];
    if (onNodeChange) {
      onNodeChange({
        ...node,
        data: {
          ...node.data,
          constraints: updatedConstraints
        }
      });
    }
  };

  return (
    <div
      className={`h-full w-full rounded-2xl flex flex-col bg-emerald-950/20 border-2 transition-all p-3.5 select-none relative group ${
        isSelected ? 'border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.35)]' : 'border-emerald-800'
      }`}
    >
      {/* Visual Diamond Header Badge */}
      <div className="flex items-center justify-between pb-1.5 border-b border-emerald-900/60 mb-2">
        <div className="flex items-center space-x-2 text-emerald-400">
          <div className="w-5 h-5 bg-emerald-500/10 border border-emerald-500/30 rotate-45 flex items-center justify-center shrink-0">
            <ShieldCheck className="h-3 w-3 -rotate-45" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-wider">AETHER VALIDATE</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-1">
          <label className="text-[9px] text-slate-500 uppercase font-mono font-bold">Schema Name</label>
          <input
            type="text"
            className="w-full bg-slate-950/80 border border-emerald-950 text-emerald-250 text-xs px-2 py-0.5 rounded font-mono focus:outline-none focus:border-emerald-500 mb-2"
            value={node.name}
            onChange={(e) => {
              if (onNodeChange) {
                onNodeChange({ ...node, name: e.target.value });
              }
            }}
          />

          {/* Existing Rules constraints list */}
          <div className="space-y-1 max-h-[140px] overflow-y-auto pr-0.5 mt-1 bg-slate-950/40 p-1.5 rounded border border-emerald-950/50">
            {Object.keys(constraints).length === 0 ? (
              <span className="text-[9px] text-slate-500 italic font-mono block text-center py-1">No properties constraints definition.</span>
            ) : (
              Object.entries(constraints).map(([key, val]) => (
                <div key={key} className="flex items-center justify-between bg-slate-950/60 p-1 rounded border border-emerald-950 text-[10px] font-mono">
                  <span className="text-slate-350 font-bold truncate max-w-[80px]" title={key}>{key}</span>
                  <div className="flex items-center space-x-1">
                    <span className="text-emerald-400 text-[8px] bg-emerald-950/30 px-1 border border-emerald-900/40 rounded">
                      {val.type}
                    </span>
                    <button
                      onClick={() => handleRemoveConstraint(key)}
                      className="text-red-400 hover:text-red-300 transition cursor-pointer p-0.5 rounded"
                      title="Delete Field"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Rule Creator */}
          <div className="flex space-x-1.5 mt-2 bg-slate-950/30 p-1 rounded border border-emerald-950/40">
            <input
              type="text"
              placeholder="attr..."
              className="w-20 bg-slate-950 border border-emerald-950 text-slate-300 text-[10px] px-1 py-0.5 rounded focus:outline-none focus:border-emerald-550"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleAddConstraint(); }}
            />
            <select
              className="bg-slate-950 border border-emerald-950 text-slate-300 text-[10px] px-1 py-0.5 rounded focus:outline-none cursor-pointer"
              value={newType}
              onChange={(e) => setNewType(e.target.value)}
            >
              <option value="string">str</option>
              <option value="number">num</option>
              <option value="boolean">bool</option>
              <option value="object">obj</option>
            </select>
            <button
              onClick={handleAddConstraint}
              className="p-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded cursor-pointer active:scale-90 transition-all shrink-0"
              title="Add field constraint"
            >
              <Plus className="h-3 w-3" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-1.5 border-t border-emerald-900/30">
          <div className="space-y-1">
            {node.inputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
          <div className="space-y-1 flex flex-col items-end">
            {node.outputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
