/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type VisualNodeType =
  | 'stream'
  | 'handler'
  | 'validate'
  | 'flow'
  | 'emit'
  | 'yield'
  | 'branch'
  | 'let';

export interface PortDef {
  id: string; // unique ID
  name: string; // display name inside the port label
  direction: 'in' | 'out';
  type: 'object' | 'string' | 'number' | 'boolean' | 'any' | 'signal' | 'control';
}

export interface VisualNode {
  id: string;
  type: VisualNodeType;
  name: string; // label or primary field
  x: number;
  y: number;
  width?: number;
  height?: number;
  parentId?: string; // used for STREAM nesting containers
  data?: {
    // Custom data depending on type
    constraints?: Record<string, { type: string; required?: boolean }>;
    storeName?: string;
    signal?: string;
    responseType?: string;
    condition?: string;
    expression?: string;
    value?: any;
  };
  inputs: PortDef[];
  outputs: PortDef[];
}

export interface VisualEdge {
  id: string;
  sourceId: string;
  sourcePortId: string;
  targetId: string;
  targetPortId: string;
  label?: string; // type constraint or filter name
}
