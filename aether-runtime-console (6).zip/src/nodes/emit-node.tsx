/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Zap } from 'lucide-react';
import { VisualNode } from './types';
import Port from '../edges/port';

interface NodeProps {
  node: VisualNode;
  isSelected?: boolean;
  onPointerDownPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUpPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onNodeChange?: (updated: VisualNode) => void;
}

export default function EmitNode({
  node,
  isSelected = false,
  onPointerDownPort,
  onPointerUpPort,
  onNodeChange
}: NodeProps) {
  return (
    <div
      className={`h-full w-full rounded-2xl flex flex-col bg-orange-950/20 border-2 transition-all p-4 select-none relative group ${
        isSelected ? 'border-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.35)]' : 'border-orange-850'
      }`}
    >
      <div className="flex items-center justify-between pb-2 border-b border-orange-900/60 mb-2">
        <div className="flex items-center space-x-2 text-orange-450">
          <Zap className="h-4 w-4 fill-orange-500 text-orange-500 animate-[bounce_1.5s_infinite]" />
          <span className="text-[10px] font-black uppercase tracking-wider">SIGNAL EMIT</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-1">
          <label className="text-[9px] text-slate-500 uppercase font-mono font-bold">Signal Target Event</label>
          <input
            type="text"
            className="w-full bg-slate-950/80 border border-orange-950 text-orange-200 text-xs px-2 py-1 rounded-md font-mono focus:outline-none focus:border-orange-500"
            value={node.name}
            onChange={(e) => {
              if (onNodeChange) {
                onNodeChange({ ...node, name: e.target.value });
              }
            }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-orange-900/30">
          <div className="space-y-1">
            {node.inputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
          <div className="space-y-1 flex flex-col items-end">
            {node.outputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
