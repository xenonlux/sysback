/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bell, Activity } from 'lucide-react';
import { VisualNode } from './types';
import Port from '../edges/port';

interface NodeProps {
  node: VisualNode;
  isSelected?: boolean;
  onPointerDownPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onPointerUpPort: (e: React.PointerEvent<HTMLDivElement>, nodeId: string, portId: string) => void;
  onNodeChange?: (updated: VisualNode) => void;
}

export default function HandlerNode({
  node,
  isSelected = false,
  onPointerDownPort,
  onPointerUpPort,
  onNodeChange
}: NodeProps) {
  return (
    <div
      className={`h-full w-full rounded-3xl flex flex-col bg-violet-950/20 border-2 transition-all p-4 select-none relative group ${
        isSelected ? 'border-violet-500 shadow-[0_0_15px_rgba(139,92,246,0.35)]' : 'border-violet-800'
      }`}
    >
      <div className="flex items-center justify-between pb-2 border-b border-violet-900/60 mb-2">
        <div className="flex items-center space-x-1.5 text-violet-400">
          <Bell className="h-4 w-4" />
          <span className="text-[10px] font-black uppercase tracking-wider">EVENT HANDLER</span>
        </div>
        <Activity className="h-3 w-3 text-violet-500 animate-pulse" />
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-1">
          <label className="text-[9px] text-slate-500 uppercase font-mono font-bold">Signal Filter Key</label>
          <input
            type="text"
            className="w-full bg-slate-950/80 border border-violet-950 text-violet-200 text-xs px-2 py-1 rounded-md font-mono focus:outline-none focus:border-violet-500"
            value={node.name}
            onChange={(e) => {
              if (onNodeChange) {
                onNodeChange({ ...node, name: e.target.value });
              }
            }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-violet-900/30">
          <div className="space-y-1">
            {node.inputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
          <div className="space-y-1 flex flex-col items-end">
            {node.outputs.map((p) => (
              <Port
                key={p.id}
                nodeId={node.id}
                port={p}
                onPointerDown={onPointerDownPort}
                onPointerUp={onPointerUpPort}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
