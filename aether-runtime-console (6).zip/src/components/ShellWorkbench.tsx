/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Terminal as TermIcon,
  Play,
  RotateCcw,
  CheckCircle2,
  FolderOpen,
  Monitor,
  ExternalLink,
  Laptop,
  Cpu,
  RefreshCw,
  Bell,
  Trash2,
  Sliders,
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  LogOut,
  AppWindow,
  Lock,
  ArrowUpRight,
  Settings
} from 'lucide-react';

// Sub-components from our web-shell package
import FileTree, { VirtualFile } from '../../packages/web-shell/src/panels/FileTree';
import MonacoEditor from '../../packages/web-shell/src/editor/MonacoEditor';
import PreviewPanel from '../../packages/web-shell/src/panels/PreviewPanel';
import TerminalREPL from '../../packages/web-shell/src/panels/TerminalREPL';
import { executeAetherSandbox } from '../../packages/web-shell/src/runtime/bridge';
import { EventBus } from '../runtime/event-bus';

// Initial preloaded .ae script file templates
const STARTER_FILES: VirtualFile[] = [
  {
    name: 'main.ae',
    content: `// AETHER Secure Handshake & Key Sign Session
let claims = {
  user: "asdfghjkl000qq00@gmail.com",
  access: "full",
  role: "CONTROLLER_ADMIN"
};

let passphrase = "my-secure-quantum-passphrase-seed";
let compactToken = sign(claims, passphrase);

emit security.handshake { token: compactToken, method: "SHA3_Lattice" };

yield verify(compactToken, passphrase);
`
  },
  {
    name: 'validation.ae',
    content: `// Validation properties validator check
let clientRecord = {
  title: "Deploy Node AWS-2",
  priority: 85,
  completed: false
};

let simpleSchema = {
  type: "object",
  properties: {
    title: { type: "string", required: true },
    priority: { type: "number", required: true },
    completed: { type: "boolean", required: true }
  }
};

yield validate(clientRecord, simpleSchema);
`
  },
  {
    name: 'ping.ae',
    content: `// Continuous telemetry metrics report
let nodeToken = uuid();
let epochTime = now();

emit telemetry.pulse { node: nodeToken, uptimeMs: 259000, latency: 12 };

yield nodeToken;
`
  }
];

export default function ShellWorkbench() {
  // Environments switcher
  const [activeEnv, setActiveEnv] = useState<'browser' | 'desktop' | 'cli'>('browser');

  // EventBus instance
  const [eventBus] = useState(() => new EventBus());

  // Browser IDE States
  const [files, setFiles] = useState<VirtualFile[]>(STARTER_FILES);
  const [selectedFile, setSelectedFile] = useState<VirtualFile>(STARTER_FILES[0]);
  const [editorMode, setEditorMode] = useState<'code' | 'visual' | 'natural'>('code');
  const [traceLogs, setTraceLogs] = useState<{ timestamp: string; type: string; message: string }[]>([]);
  const [activeStreams, setActiveStreams] = useState<{ signal: string; count: number }[]>([]);

  // Desktop Tauri Simulator States
  const [desktopLogs, setDesktopLogs] = useState<string[]>(['[Tauri OS] Native channel initialized.']);
  const [systemStats, setSystemStats] = useState({ cpu: 12, mem: 5.4, streams: 3 });
  const [tauriNotifier, setTauriNotifier] = useState<{ title: string; body: string } | null>(null);

  // Sync editor typed changes back to selected file state
  const handleUpdateCode = (newCode: string) => {
    setFiles(prev => prev.map(f => f.name === selectedFile.name ? { ...f, content: newCode } : f));
    setSelectedFile(prev => ({ ...prev, content: newCode }));
  };

  const handleSelectFile = (file: VirtualFile) => {
    setSelectedFile(file);
  };

  const handleCreateFile = () => {
    const defaultName = `service_${Math.random().toString(36).substring(7)}.ae`;
    const defaultContent = `// New Aether script file\nlet key = uuid();\nyield key;\n`;
    const newFile = { name: defaultName, content: defaultContent };
    setFiles(prev => [...prev, newFile]);
    setSelectedFile(newFile);
    logToBrowserEnv('info', `Created new microservice configuration ${defaultName}`);
  };

  const handleDeleteFile = (filename: string) => {
    const filtered = files.filter(f => f.name !== filename);
    setFiles(filtered);
    if (selectedFile.name === filename) {
      setSelectedFile(filtered[0] || STARTER_FILES[0]);
    }
    logToBrowserEnv('warn', `Removed file index: ${filename}`);
  };

  // Helper log functions
  const logToBrowserEnv = (type: 'info' | 'success' | 'warn' | 'error', message: string) => {
    setTraceLogs(prev => [...prev, { timestamp: new Date().toLocaleTimeString(), type, message }]);
  };

  const handleClearBrowserLogs = () => {
    setTraceLogs([]);
  };

  // Compile and run Aether script
  const handleRunScript = async () => {
    logToBrowserEnv('info', `Boots compiling & running: "${selectedFile.name}"`);
    
    const results = await executeAetherSandbox(selectedFile.content, eventBus);
    
    // Inject logs
    results.logs.forEach(l => {
      logToBrowserEnv(l.type, l.message);
    });

    if (results.success) {
      logToBrowserEnv('success', `✔ Completed elegantly! Returned data yielded: ${JSON.stringify(results.yieldedValue)}`);
      
      // Update running streams count on trigger
      const matches = selectedFile.content.match(/emit\s+["']?([a-zA-Z0-9_\.]+)["']?/);
      if (matches && matches[1]) {
        const sig = matches[1];
        setActiveStreams(prev => {
          const match = prev.find(s => s.signal === sig);
          if (match) {
            return prev.map(s => s.signal === sig ? { ...s, count: s.count + 1 } : s);
          } else {
            return [...prev, { signal: sig, count: 1 }];
          }
        });
      }
    } else {
      logToBrowserEnv('error', '💀 Runtime crashed running code.');
    }
  };

  // CLI execution logic
  const handleExecuteCli = (commandLine: string): string[] => {
    const args = commandLine.trim().split(/\s+/);
    if (!args[0]) return [];

    const baseCmd = args[0];

    if (baseCmd === 'help') {
      return [
        'Available AETHER subcommands:',
        '  aether run <file.ae>         - Run and evaluate an instance file',
        '  aether build <file.ae>       - Compile current statements code into optimized JavaScript',
        '  aether check <file.ae>       - Run static semantic validation tests on syntax',
        '  aether repl                  - Open prompt loop compiler instance',
        '  aether new <name>            - Scaffold a fresh workspace directory template',
        '  aether stream ls             - View long-running active signal threads',
        '  aether stream kill <name>    - Terminate listener stream thread',
        '  aether flow inspect <store>  - Dump snapshot stores values'
      ];
    }

    if (baseCmd === 'aether') {
      const sub = args[1];
      if (!sub) return ['Error: Specify a subcommand. Run "help" for templates.'];

      switch (sub) {
        case 'run': {
          const file = args[2] || selectedFile.name;
          const target = files.find(f => f.name === file || file.includes(f.name));
          if (!target) return [`Error: File code index "${file}" not found in local workspace.`];
          return [
            `[AETHER CLI] Evaluating: ${target.name}...`,
            '✔ Parsed file success (Statements: 3)',
            'Executing compiled VM pipeline instructions...',
            `[AETHER] Completed execution cleanly!`,
            `Returned/Yielded Yield: "${target.name} compilation secure"`
          ];
        }
        case 'build': {
          const file = args[2] || selectedFile.name;
          const target = files.find(f => f.name === file || file.includes(f.name));
          if (!target) return [`Error: File "${file}" not found.`];
          return [
            `[AETHER Compiler] Compiling ${target.name}...`,
            '✔ Built successfully! JavaScript written to:',
            `→ dist/${target.name.replace(/\.ae$/, '.js')}`
          ];
        }
        case 'check': {
          const file = args[2] || selectedFile.name;
          const target = files.find(f => f.name === file || file.includes(f.name));
          if (!target) return [`Error: File "${file}" not found.`];
          return [
            `[Static Analyzer] Analyzing ${target.name}...`,
            `✔ Verification Complete: No syntax or type errors found in ${target.name}!`
          ];
        }
        case 'repl': {
          return [
            '=== AETHER REPL v1.0.0 ===',
            'Type statements. Type ".exit" or ".quit" to exit REPL module.',
            'Type ".env" to list all variables in memory environment.'
          ];
        }
        case 'new': {
          const prjName = args[2] || 'new_node_app';
          return [
            `Scaffolding new AETHER project template: ${prjName}...`,
            `✔ Project created successfully at ./${prjName}!`,
            `  Directories created:`,
            `    - ./${prjName}/package.json  (dependencies checklist)`,
            `    - ./${prjName}/src/main.ae    (starter secure handshake code)`
          ];
        }
        case 'stream': {
          const action = args[2];
          if (action === 'ls') {
            return [
              'PID     SIGNAL/STREAM NAME       EVENT RATE     THROUGHPUT     STATUS',
              '---------------------------------------------------------------------',
              '1042    telemetry.pulse          2.4 ev/s       412 bps        ONLINE',
              '1089    network.ingress          12.0 ev/s      2.1 Kbps       ONLINE',
              '2011    auth.handshake           0.1 ev/s       92 bps         ONLINE',
              '2190    vault.ledger.write       0.0 ev/s       0 bps          SUSPENDED'
            ];
          } else if (action === 'kill') {
            const sigId = args[3] || 'telemetry.pulse';
            return [
              `Shutting down active stream processor for signal: "${sigId}"...`,
              `✔ Signal thread ID [1042] terminated cleanly.`
            ];
          }
          return ['Error: Invalid stream action. Use "ls" or "kill <name>".'];
        }
        case 'flow': {
          if (args[2] === 'inspect') {
            const target = args[3] || 'telemetry';
            if (target === 'telemetry') {
              return [
                'Inspecting Flow storage database node: "telemetry"...',
                '✔ Found active B-Tree storage store! Size: 3 elements.',
                JSON.stringify({
                  meta: { btreeDepth: 2, size: 3 },
                  records: [
                    { id: 'usr_001', cpu: 12, memory: 54, status: 'STABLE' },
                    { id: 'usr_002', cpu: 44, memory: 56, status: 'STABLE' },
                    { id: 'usr_003', cpu: 8, memory: 52, status: 'IDLE' }
                  ]
                }, null, 2)
              ];
            }
            return [
              `Inspecting Flow storage database node: "${target}"...`,
              '✔ Found active B-Tree storage store! Size: 2 elements.',
              JSON.stringify({
                meta: { btreeDepth: 1, size: 2 },
                records: [
                  { tx: 'tx_8d7f', amount: 150.0, method: 'DilithiumSignatureVerification' },
                  { tx: 'tx_7c9d', amount: 2000.0, method: 'KyberKeyAgreement' }
                ]
              }, null, 2)
            ];
          }
          return ['Error: Use "flow inspect <store>".'];
        }
        default:
          return [`Error: Unknown command identifier "${sub}". Type "help" to list.`];
      }
    }

    // Try parsing as simple inline raw variable assignment let statement
    if (commandLine.startsWith('let ') || commandLine.startsWith('yield ') || commandLine.startsWith('emit ')) {
      try {
        logToBrowserEnv('info', `Evaluating REPL console input: ${commandLine}`);
        return ['[REPL Success] Evaluated cleanly.', `Yield: ${commandLine.replace(/let\s+[a-zA-Z0-9_]+\s*=\s*/, '')}`];
      } catch (e: any) {
        return [`Error statement parsing: ${e.message}`];
      }
    }

    return [`Error: Command "${baseCmd}" not recognized. Run "help" for manuals.`];
  };

  // Simulated tauri triggers
  const triggerTauriFSRead = () => {
    setDesktopLogs(prev => [...prev, `[Tauri FileSystem] Calling open_aether_project("${selectedFile.name}")...`]);
    setTimeout(() => {
      setDesktopLogs(prev => [
        ...prev,
        `✔ File read successfully! filename: "${selectedFile.name}", byte size: ${selectedFile.content.len ?? selectedFile.content.length} bytes.`
      ]);
    }, 400);
  };

  const triggerTauriFSSave = () => {
    setDesktopLogs(prev => [...prev, `[Tauri FileSystem] Saving file changes to native workspace...`]);
    setTimeout(() => {
      setDesktopLogs(prev => [...prev, `✔ Successfully wrote Aether code payload. Saved state: true`]);
      triggerTauriNotify('Aether Studio Save', 'Code base synced with native operating system folder tree');
    }, 400);
  };

  const triggerTauriNotify = (title: string, body: string) => {
    setDesktopLogs(prev => [...prev, `[Tauri] Dispatching OS notification banner.`]);
    setTauriNotifier({ title, body });
    setTimeout(() => setTauriNotifier(null), 3500);
  };

  const triggerTauriUpdateCheck = () => {
    setDesktopLogs(prev => [...prev, '[Tauri Updater] Checking release tags on secure quantum channels...']);
    setTimeout(() => {
      setDesktopLogs(prev => [
        ...prev,
        '✔ Response payload: AETHER-V1.0.1-LATEST-STABLE verified with lattice signature ML-DSA-65.'
      ]);
      triggerTauriNotify('Update Available', 'AETHER Post-Quantum V1.0.1 hotfix ready to install.');
    }, 600);
  };

  const triggerTauriStatsSync = () => {
    setDesktopLogs(prev => [...prev, '[Tauri API] Fetching physical machine CPU, memory, and active threads...']);
    setTimeout(() => {
      setSystemStats({ cpu: 18, mem: 6.2, streams: activeStreams.length + 3 });
      setDesktopLogs(prev => [...prev, '✔ System performance parameters synchronized.']);
    }, 400);
  };

  return (
    <div className="space-y-8 animate-fade-in" id="universal-shell-workbench">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-indigo-950 p-6 rounded-3xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="absolute top-0 right-0 h-40 w-40 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center space-x-4">
          <div className="p-3.5 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/30">
            <AppWindow className="h-7 w-7 animate-pulse text-indigo-400" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400 bg-indigo-950/50 px-2 py-0.5 border border-indigo-900/50 rounded-md">
              Universal Shell
            </span>
            <h1 className="text-xl font-bold text-slate-100 mt-1">AETHER Autonomous Studio</h1>
            <p className="text-xs text-slate-400 mt-1">
              Write, compile, run, and execute Aether language in Browser IDE, native Tauri desktop wrapper, or local Commander CLI.
            </p>
          </div>
        </div>

        {/* Big Run Script Button */}
        <button
          onClick={handleRunScript}
          className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl border border-indigo-500/20 active:scale-95 transition text-xs flex items-center space-x-2.5 cursor-pointer shadow-lg shadow-indigo-600/15"
          title="Run selected Aether file in Virtual VM Sandbox"
        >
          <Play className="h-4 w-4" />
          <span>Execute Script</span>
        </button>
      </div>

      {/* Primary Environments Mode switcher */}
      <div className="flex bg-slate-900 border border-slate-800 p-2 rounded-2xl items-center justify-between gap-4 flex-col sm:flex-row">
        <div className="space-y-0.5 pl-2">
          <h3 className="text-xs font-black text-slate-200">Platform Environments Sandbox</h3>
          <p className="text-[9px] text-slate-500">Compare how Aether behaves across web workspace, native desktop, or prompt terminals.</p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-850 self-stretch sm:self-auto text-xs">
          <button
            onClick={() => setActiveEnv('browser')}
            className={`flex-1 sm:flex-none py-2 px-4 rounded-lg font-bold transition flex items-center justify-center space-x-2 cursor-pointer ${
              activeEnv === 'browser'
                ? 'bg-indigo-650 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Laptop className="h-4 w-4" />
            <span>Browser Shell (IDE)</span>
          </button>
          <button
            onClick={() => {
              setActiveEnv('desktop');
              triggerTauriStatsSync();
            }}
            className={`flex-1 sm:flex-none py-2 px-4 rounded-lg font-bold transition flex items-center justify-center space-x-2 cursor-pointer ${
              activeEnv === 'desktop'
                ? 'bg-indigo-650 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="h-4 w-4" />
            <span>Desktop Tauri Rust</span>
          </button>
          <button
            onClick={() => setActiveEnv('cli')}
            className={`flex-1 sm:flex-none py-2 px-4 rounded-lg font-bold transition flex items-center justify-center space-x-2 cursor-pointer ${
              activeEnv === 'cli'
                ? 'bg-indigo-650 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <TermIcon className="h-4 w-4" />
            <span>CLI Executable (`aether`)</span>
          </button>
        </div>
      </div>

      {/* Main Sandbox Interactive Block depending on active env selected */}
      {activeEnv === 'browser' && (
        <div className="space-y-6 animate-fade-in" id="browser-shell-ide">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Left panel */}
            <div className="lg:col-span-3">
              <FileTree
                files={files}
                selectedFile={selectedFile}
                onSelectFile={handleSelectFile}
                onCreateFile={handleCreateFile}
                onDeleteFile={handleDeleteFile}
              />
            </div>

            {/* Editor center panel */}
            <div className="lg:col-span-5 h-full">
              <MonacoEditor
                filename={selectedFile.name}
                code={selectedFile.content}
                mode={editorMode}
                onChangeCode={handleUpdateCode}
                onChangeMode={setEditorMode}
              />
            </div>

            {/* Right preview monitoring panel */}
            <div className="lg:col-span-4 select-none">
              <PreviewPanel
                traceLogs={traceLogs}
                activeStreams={activeStreams}
                onClearLogs={handleClearBrowserLogs}
              />
            </div>
          </div>

          {/* Bottom row terminal REPL */}
          <TerminalREPL onExecuteCommand={handleExecuteCli} />
        </div>
      )}

      {activeEnv === 'desktop' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in" id="desktop-tauri-wrapper">
          {/* Controls column */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center space-x-2 text-indigo-400">
                  <Laptop className="h-4 w-4" />
                  <span className="text-xs font-bold uppercase tracking-wider">Tauri Window Bridge</span>
                </div>
                <span className="text-[9px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 rounded-md">
                  Active Connection
                </span>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                AetherShell is packaged natively inside Rust. Trigger core OS capabilities right inside our sandboxed simulation:
              </p>

              {/* Tauri APIs */}
              <div className="space-y-2 text-xs">
                <button
                  onClick={triggerTauriFSRead}
                  className="w-full justify-between p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 transition flex items-center cursor-pointer"
                >
                  <span className="font-mono text-[10px] text-slate-300">open_aether_project()</span>
                  <span className="text-[10px] text-indigo-400 bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-900/30 font-bold">FS Read</span>
                </button>

                <button
                  onClick={triggerTauriFSSave}
                  className="w-full justify-between p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 transition flex items-center cursor-pointer"
                >
                  <span className="font-mono text-[10px] text-slate-300">save_aether_project()</span>
                  <span className="text-[10px] text-indigo-400 bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-900/30 font-bold">FS Write</span>
                </button>

                <button
                  onClick={() => triggerTauriNotify('Aether Studio System Alert', 'Native system core telemetry is running with PQC parameters.')}
                  className="w-full justify-between p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 transition flex items-center cursor-pointer"
                >
                  <span className="font-mono text-[10px] text-slate-300">trigger_native_notification()</span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900/30 font-bold">Native Toast</span>
                </button>

                <button
                  onClick={triggerTauriUpdateCheck}
                  className="w-full justify-between p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 transition flex items-center cursor-pointer"
                >
                  <span className="font-mono text-[10px] text-slate-300">check_for_system_updates()</span>
                  <span className="text-[10px] text-indigo-400 bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-900/30 font-bold">Auto Update</span>
                </button>

                <button
                  onClick={triggerTauriStatsSync}
                  className="w-full justify-between p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 transition flex items-center cursor-pointer"
                >
                  <span className="font-mono text-[10px] text-slate-300">get_native_system_stats()</span>
                  <span className="text-[10px] text-indigo-400 bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-900/30 font-bold">Sys Info</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics display */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3 font-mono text-[10px]">
              <span className="text-[9px] font-bold uppercase text-slate-500 tracking-wider">Tauri Local Diagnostics</span>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2 bg-slate-950 border border-slate-850 rounded-xl">
                  <span className="text-slate-500 text-[8px] uppercase block">Host CPU</span>
                  <span className="text-slate-300 font-bold text-xs mt-1 block">{systemStats.cpu}%</span>
                </div>
                <div className="p-2 bg-slate-950 border border-slate-850 rounded-xl">
                  <span className="text-slate-500 text-[8px] uppercase block">Host RAM</span>
                  <span className="text-slate-300 font-bold text-xs mt-1 block">{systemStats.mem} GB</span>
                </div>
                <div className="p-2 bg-slate-950 border border-slate-850 rounded-xl">
                  <span className="text-slate-500 text-[8px] uppercase block">Active Streams</span>
                  <span className="text-slate-300 font-bold text-xs mt-1 block">{systemStats.streams} Thread</span>
                </div>
              </div>
            </div>
          </div>

          {/* Console logger + Rust source code explorer */}
          <div className="lg:col-span-8 space-y-6">
            {/* Action tracker */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col h-[200px]">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-slate-300 font-mono">Tauri Native Event Ingress Messages</span>
                <span className="text-[9px] uppercase font-bold text-slate-600">IPC Channels</span>
              </div>
              <div className="flex-1 bg-slate-950 p-4 rounded-2xl overflow-y-auto pr-1 font-mono text-[10.5px] text-indigo-400 space-y-2 mt-1">
                {desktopLogs.map((logLine, i) => (
                  <div key={i} className="flex items-start space-x-2">
                    <span className="text-slate-600">[{new Date().toLocaleTimeString()}]</span>
                    <span className={logLine.includes('Error') ? 'text-red-400' : logLine.includes('✔') ? 'text-emerald-400' : 'text-slate-300'}>
                      {logLine}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tauri Native Rust main.rs code display block */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col">
              <span className="text-xs font-bold text-slate-300 font-mono flex items-center space-x-1.5 pb-2 border-b border-slate-800 mb-3 uppercase">
                <span className="w-1.5 h-1.5 bg-orange-500 rounded-full shrink-0" />
                <span>packages / desktop-shell / src-tauri / src / main.rs</span>
              </span>

              <pre className="bg-slate-950 p-4 rounded-2xl text-[9.5px] leading-5 font-mono text-slate-400 overflow-x-auto max-h-[220px]">
{`// Tauri rust-based cross platform wrapper main.rs
use tauri::{CustomMenuItem, SystemTray, SystemTrayMenu, SystemTrayMenuItem, SystemTrayEvent};
use serde::{Serialize, Deserialize};

#[tauri::command]
fn open_aether_project(filepath: String) -> Result<ProjectData, String> {
    match fs::read_to_string(&filepath) {
        Ok(content) => Ok(ProjectData { filepath, filename, content, byte_size: content.len() }),
        Err(e) => Err(format!("File read failed: {}", e))
    }
}

#[tauri::command]
fn save_aether_project(filepath: String, code: String) -> Result<bool, String> {
    fs::write(&filepath, code).map(|_| true).map_err(|e| format!("Save failed: {}", e))
}

fn main() {
    tauri::Builder::default()
        .system_tray(SystemTray::new())
        .invoke_handler(tauri::generate_handler![
            open_aether_project,
            save_aether_project,
            trigger_native_notification,
            get_native_system_stats,
            check_for_system_updates
        ])
        .run(tauri::generate_context!())
        .expect("Tauri launch failed");
}`}
              </pre>
            </div>
          </div>
        </div>
      )}

      {activeEnv === 'cli' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in" id="cli-shell-wrapper">
          {/* Interactive prompts checklist */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
              <div className="pb-2 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 font-mono">
                  Commander Sub-commands
                </span>
                <p className="text-[10px] text-slate-500 mt-1">Double click to copy Command instructions:</p>
              </div>

              <div className="space-y-4 text-[11px] font-mono text-slate-400 leading- relaxed">
                <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 uppercase text-[9px] font-bold">1. Execute Script</span>
                    <span className="text-emerald-400 text-[8px] font-bold">Ready</span>
                  </div>
                  <code className="text-indigo-400 text-[10px] block font-bold">aether run main.ae</code>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 uppercase text-[9px] font-bold">2. Compile File</span>
                    <span className="text-indigo-400 text-[8px] font-bold">JSEmitter</span>
                  </div>
                  <code className="text-indigo-400 text-[10px] block font-bold">aether build main.ae</code>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 uppercase text-[9px] font-bold">3. Inspect Flows</span>
                    <span className="text-indigo-400 text-[8px] font-bold">B-Tree</span>
                  </div>
                  <code className="text-indigo-400 text-[10px] block font-bold">aether flow inspect telemetry</code>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 uppercase text-[9px] font-bold">4. Listen Signals</span>
                    <span className="text-indigo-400 text-[8px] font-bold">EventBus</span>
                  </div>
                  <code className="text-indigo-400 text-[10px] block font-bold">aether stream ls</code>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Shell terminal and Commands list reader */}
          <div className="lg:col-span-8 space-y-6">
            <TerminalREPL onExecuteCommand={handleExecuteCli} />

            {/* Read CLI source structure */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col">
              <span className="text-xs font-bold text-slate-300 font-mono flex items-center space-x-1.5 pb-2 border-b border-slate-800 mb-3 uppercase">
                <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full shrink-0" />
                <span>packages / cli / src / index.ts</span>
              </span>

              <pre className="bg-slate-950 p-4 rounded-2xl text-[9.5px] leading-5 font-mono text-slate-400 overflow-x-auto max-h-[160px]">
{`import { Command } from 'commander';
const program = new Command();

program
  .name('aether')
  .description('AETHER Command Line Interface')
  .version('1.0.0');

program
  .command('run')
  .argument('<file>', 'Paths to the .ae file')
  .action((file) => { runCommand(file); });

program
  .command('build')
  .argument('<file>', 'Aether source file')
  .action((file) => { buildCommand(file); });

program.parse(process.argv);`}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Tauri Notification simulation overlay toast alert */}
      {tauriNotifier && (
        <div className="fixed bottom-6 right-6 p-4 bg-slate-900 border border-indigo-500/50 rounded-2xl shadow-xl w-72 flex items-start space-x-3 text-xs animate-bounce z-50">
          <div className="p-1.5 bg-indigo-500/15 text-indigo-400 rounded-lg">
            <Bell className="h-4 w-4 shrink-0" />
          </div>
          <div className="space-y-1">
            <h5 className="font-black text-slate-200">{tauriNotifier.title}</h5>
            <p className="text-slate-400 text-[10px]">{tauriNotifier.body}</p>
          </div>
        </div>
      )}

    </div>
  );
}
