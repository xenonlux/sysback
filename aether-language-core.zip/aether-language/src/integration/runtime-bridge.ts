/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description Runtime integration bridge.
 *
 * Converts a parsed AETHER Program AST into the runtime-compatible
 * format expected by the existing @aether/runtime Executor.
 * This is the critical missing link between Language Core and Runtime.
 *
 * Usage (in your runtime):
 *   import { parseToRuntime } from '@aether/language/integration';
 *   const rtDefs = parseToRuntime(aetherSourceCode);
 *   for (const def of rtDefs) runtime.register(def);
 */

import { parse }    from '../index';
import { regenerate } from '../codegen/regenerate';
import type {
  Program, StreamDeclaration, HandlerDeclaration,
  Statement, Expression, SchemaField,
} from '../ast';

// ─── Runtime-compatible types ─────────────────────────────────────────────────
// These match the shape expected by the existing runtime/types.ts Executor.

export interface RTStreamDef {
  name:      string;
  modifiers: string[];
  handlers:  RTHandlerDef[];
}

export interface RTHandlerDef {
  event:     string;
  params:    string[];
  modifiers: string[];
  fn:        (...args: unknown[]) => Promise<unknown>;
  rawAST:    HandlerDeclaration;   // kept for debugging / evolution
}

export interface ParseToRuntimeResult {
  streams:  RTStreamDef[];
  errors:   string[];
  warnings: string[];
  source:   string;      // formatted AETHER source (round-tripped)
}

// ─── Integration ─────────────────────────────────────────────────────────────

/**
 * Parse AETHER source and produce runtime-ready stream definitions.
 *
 * @param source   Raw AETHER source code string
 * @param builtins Object containing runtime built-in functions
 *                 (hash, sign, verify, validate, emit, flow)
 */
export function parseToRuntime(
  source:   string,
  builtins: Record<string, unknown> = {},
): ParseToRuntimeResult {
  const errors:   string[] = [];
  const warnings: string[] = [];
  let   program:  Program;

  try {
    program = parse(source);
  } catch (e: unknown) {
    return {
      streams:  [],
      errors:   [(e as Error).message],
      warnings: [],
      source,
    };
  }

  const streams: RTStreamDef[] = [];

  for (const decl of program.body) {
    if (decl.kind === 'TypeDeclaration') {
      warnings.push(`Type declaration '${decl.name}' noted (runtime type registry TBD)`);
      continue;
    }

    const streamDef: RTStreamDef = {
      name:      decl.name,
      modifiers: decl.modifiers,
      handlers:  [],
    };

    for (const handler of decl.handlers) {
      const fn = buildHandlerFn(handler, builtins, warnings);
      streamDef.handlers.push({
        event:     handler.event,
        params:    handler.params,
        modifiers: handler.modifiers,
        fn,
        rawAST:    handler,
      });
    }

    streams.push(streamDef);
  }

  return {
    streams,
    errors,
    warnings,
    source: regenerate(program),
  };
}

// ─── Handler function builder ─────────────────────────────────────────────────

type BuiltinFn = (...args: unknown[]) => unknown;

function buildHandlerFn(
  handler:  HandlerDeclaration,
  builtins: Record<string, unknown>,
  warnings: string[],
): (...args: unknown[]) => Promise<unknown> {
  return async (...paramValues: unknown[]) => {
    // Build initial scope from params
    const scope: Record<string, unknown> = {};
    handler.params.forEach((p, i) => { scope[p] = paramValues[i]; });

    // Add builtins to scope
    Object.assign(scope, builtins);

    let lastValue: unknown = null;

    for (const stmt of handler.body) {
      const result = await executeStatement(stmt, scope, builtins, warnings);
      if (result !== undefined) lastValue = result;

      // If a statement yields/returns, stop execution
      if (stmt.kind === 'YieldStatement') break;
    }

    return lastValue;
  };
}

// ─── Statement executor ───────────────────────────────────────────────────────

async function executeStatement(
  stmt:     Statement,
  scope:    Record<string, unknown>,
  builtins: Record<string, unknown>,
  warnings: string[],
): Promise<unknown> {
  switch (stmt.kind) {
    case 'LetStatement': {
      const val     = await evalExpr(stmt.value, scope, builtins);
      scope[stmt.name] = val;
      return undefined;
    }

    case 'ValidateStatement': {
      const validateFn = builtins['validate'] as BuiltinFn | undefined;
      if (!validateFn) {
        warnings.push('validate() builtin not provided to runtime bridge');
        return undefined;
      }
      const schema  = buildSchemaObj(stmt.schema);
      const source  = scope[stmt.target];
      const result  = await validateFn(source, schema);
      scope[stmt.target] = result;
      return undefined;
    }

    case 'FlowWriteStatement': {
      const flowObj = builtins['flow'] as Record<string, BuiltinFn> | undefined;
      if (!flowObj?.write) {
        warnings.push(`flow.write() not provided — skipping flow.${stmt.store} <-`);
        return undefined;
      }
      const data = await evalExpr(stmt.data, scope, builtins);
      await flowObj.write(stmt.store, data);
      return undefined;
    }

    case 'AssignStatement': {
      const value = await evalExpr(stmt.value, scope, builtins);
      // Set nested property: ['user', 'password'] → scope.user.password = value
      if (stmt.target.length === 1) {
        scope[stmt.target[0]] = value;
      } else {
        let obj = scope[stmt.target[0]] as Record<string, unknown>;
        for (let i = 1; i < stmt.target.length - 1; i++) {
          obj = obj[stmt.target[i]] as Record<string, unknown>;
        }
        obj[stmt.target[stmt.target.length - 1]] = value;
      }
      return undefined;
    }

    case 'EmitStatement': {
      const emitFn = builtins['emit'] as BuiltinFn | undefined;
      if (!emitFn) {
        warnings.push('emit() builtin not provided to runtime bridge');
        return undefined;
      }
      const payload = stmt.payload
        ? await evalExpr(stmt.payload, scope, builtins)
        : undefined;
      emitFn(`${stmt.namespace}.${stmt.signal}`, payload);
      return undefined;
    }

    case 'YieldStatement': {
      return await evalExpr(stmt.value, scope, builtins);
    }

    case 'IfStatement': {
      const cond = await evalExpr(stmt.condition, scope, builtins);
      const branch = cond ? stmt.consequent : (stmt.alternate ?? []);
      let last: unknown;
      for (const s of branch) {
        const r = await executeStatement(s, scope, builtins, warnings);
        if (r !== undefined) last = r;
      }
      return last;
    }

    case 'ExpressionStatement': {
      return await evalExpr(stmt.expression, scope, builtins);
    }
  }
}

// ─── Expression evaluator ─────────────────────────────────────────────────────

async function evalExpr(
  expr:     Expression,
  scope:    Record<string, unknown>,
  builtins: Record<string, unknown>,
): Promise<unknown> {
  switch (expr.kind) {
    case 'Literal': return expr.value;

    case 'Identifier': {
      if (expr.name in scope)    return scope[expr.name];
      if (expr.name in builtins) return builtins[expr.name];
      return undefined;
    }

    case 'MemberExpr': {
      let obj: unknown = scope[expr.object[0]] ?? builtins[expr.object[0]];
      for (let i = 1; i < expr.object.length; i++) {
        if (obj == null) return undefined;
        obj = (obj as Record<string, unknown>)[expr.object[i]];
      }
      return obj;
    }

    case 'CallExpr': {
      const args = await Promise.all(expr.args.map(a => evalExpr(a.value, scope, builtins)));

      // Resolve callee function
      let fn: unknown;
      if (expr.callee.length === 1) {
        fn = scope[expr.callee[0]] ?? builtins[expr.callee[0]];
      } else {
        let obj: unknown = scope[expr.callee[0]] ?? builtins[expr.callee[0]];
        for (let i = 1; i < expr.callee.length - 1; i++) {
          obj = (obj as Record<string, unknown>)[expr.callee[i]];
        }
        const method = expr.callee[expr.callee.length - 1];
        if (obj != null) {
          fn = (obj as Record<string, BuiltinFn>)[method];
          if (typeof fn === 'function') return (fn as BuiltinFn).apply(obj, args);
        }
      }

      if (typeof fn === 'function') return (fn as BuiltinFn)(...args);
      return undefined;
    }

    case 'AwaitExpr': {
      const val = await evalExpr(expr.value, scope, builtins);
      return val instanceof Promise ? await val : val;
    }

    case 'BinaryExpr': {
      const l = await evalExpr(expr.left,  scope, builtins);
      const r = await evalExpr(expr.right, scope, builtins);
      switch (expr.op) {
        case '==':  return l === r;
        case '!=':  return l !== r;
        case '<':   return (l as number) <  (r as number);
        case '>':   return (l as number) >  (r as number);
        case '<=':  return (l as number) <= (r as number);
        case '>=':  return (l as number) >= (r as number);
        case '+':   return (l as number) +  (r as number);
        case '-':   return (l as number) -  (r as number);
        case '*':   return (l as number) *  (r as number);
        case '/':   return (l as number) /  (r as number);
        case '&&':  return l && r;
        case '||':  return l || r;
      }
    }

    case 'ValidateExpr': {
      const validateFn = builtins['validate'] as BuiltinFn | undefined;
      if (!validateFn) return await evalExpr(expr.source, scope, builtins);
      const src    = await evalExpr(expr.source, scope, builtins);
      const schema = buildSchemaObj(expr.schema);
      return validateFn(src, schema);
    }

    case 'ObjectExpr': {
      const obj: Record<string, unknown> = {};
      for (const prop of expr.properties) {
        obj[prop.key] = await evalExpr(prop.value, scope, builtins);
      }
      return obj;
    }

    case 'ArrayExpr': {
      return await Promise.all(expr.elements.map(e => evalExpr(e, scope, builtins)));
    }
  }
}

// ─── Schema helper ────────────────────────────────────────────────────────────

function buildSchemaObj(fields: SchemaField[]): Record<string, unknown> {
  const obj: Record<string, unknown> = {};
  for (const f of fields) {
    const rule: Record<string, unknown> = {
      type:       f.domainType,
      constraint: f.constraint,
    };
    for (const arg of f.args) {
      if (arg.key) rule[arg.key] = arg.value;
      else         rule['value'] = arg.value;
    }
    obj[f.name] = rule;
  }
  return obj;
}
