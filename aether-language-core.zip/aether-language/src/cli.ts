#!/usr/bin/env node
/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description AETHER CLI — run, check, build, and REPL for .ae files.
 *
 * Usage:
 *   aether run <file.ae>        — parse + execute
 *   aether check <file.ae>      — type-check only, no execution
 *   aether build <file.ae>      — compile to JavaScript
 *   aether format <file.ae>     — format and print AETHER source
 *   aether repl                 — interactive REPL
 *   aether natural "<text>"     — parse natural language → AETHER code
 */

import * as fs        from 'fs';
import * as path      from 'path';
import * as readline  from 'readline';
import { parse, check, compileToJS, format, tokenize } from '../index';
import { naturalToAST }   from '../modes/natural';
import { regenerate }     from '../codegen/regenerate';
import { parseToRuntime } from '../integration/runtime-bridge';

// ─── Colours ─────────────────────────────────────────────────────────────────

const C = {
  cyan:   (s: string) => `\x1b[36m${s}\x1b[0m`,
  green:  (s: string) => `\x1b[32m${s}\x1b[0m`,
  red:    (s: string) => `\x1b[31m${s}\x1b[0m`,
  yellow: (s: string) => `\x1b[33m${s}\x1b[0m`,
  dim:    (s: string) => `\x1b[2m${s}\x1b[0m`,
  bold:   (s: string) => `\x1b[1m${s}\x1b[0m`,
};

// ─── Entry ───────────────────────────────────────────────────────────────────

const [,, cmd, ...rest] = process.argv;

async function main() {
  switch (cmd) {
    case 'run':     return cmdRun(rest[0]);
    case 'check':   return cmdCheck(rest[0]);
    case 'build':   return cmdBuild(rest[0], rest[1]);
    case 'format':  return cmdFormat(rest[0]);
    case 'tokens':  return cmdTokens(rest[0]);
    case 'ast':     return cmdAST(rest[0]);
    case 'natural': return cmdNatural(rest.join(' '));
    case 'repl':    return cmdREPL();
    default:        return printHelp();
  }
}

// ─── Commands ─────────────────────────────────────────────────────────────────

function cmdCheck(filePath?: string) {
  const src = readFile(filePath);
  const res = check(src);
  if (res.ok) {
    console.log(C.green('✓ No errors found'));
    const prog = parse(src);
    console.log(C.dim(`  ${prog.body.length} declaration(s)`));
    for (const d of prog.body) {
      if (d.kind === 'StreamDeclaration') {
        const mods = d.modifiers.length ? C.dim(` [${d.modifiers.join(', ')}]`) : '';
        console.log(C.cyan(`  stream ${d.name}${mods}`) + C.dim(` — ${d.handlers.length} handler(s)`));
        for (const h of d.handlers) {
          const hm = h.modifiers.length ? ` [${h.modifiers.join(', ')}]` : '';
          console.log(C.dim(`    on ${h.event}(${h.params.join(', ')})${hm} — ${h.body.length} statement(s)`));
        }
      }
    }
  } else {
    console.error(C.red('✗ ' + res.error));
    process.exit(1);
  }
}

function cmdBuild(filePath?: string, outPath?: string) {
  const src = readFile(filePath);
  const res = check(src);
  if (!res.ok) { console.error(C.red('✗ ' + res.error)); process.exit(1); }

  const js  = compileToJS(parse(src));
  const out = outPath ?? (filePath!.replace(/\.ae$/, '') + '.js');
  fs.writeFileSync(out, js, 'utf8');
  console.log(C.green(`✓ Compiled → ${out}`));
  console.log(C.dim(`  ${js.split('\n').length} lines of JavaScript`));
}

function cmdFormat(filePath?: string) {
  const src       = readFile(filePath);
  const formatted = format(src);
  console.log(formatted);
}

function cmdTokens(filePath?: string) {
  const src    = readFile(filePath);
  const tokens = tokenize(src).filter(t => t.kind !== 'EOF');
  console.log(C.bold('\nTokens:\n'));
  for (const tok of tokens) {
    console.log(`  ${String(tok.line).padStart(3)}:${String(tok.col).padEnd(3)}  ${C.cyan(tok.kind.padEnd(16))}  ${C.dim(JSON.stringify(tok.value))}`);
  }
  console.log(C.dim(`\n  Total: ${tokens.length} tokens`));
}

function cmdAST(filePath?: string) {
  const src  = readFile(filePath);
  const prog = parse(src);
  console.log(JSON.stringify(prog, null, 2));
}

function cmdNatural(text: string) {
  if (!text) {
    console.error(C.red('Usage: aether natural "<description>"'));
    process.exit(1);
  }
  const result = naturalToAST(text);
  const src    = regenerate(result.ast);

  console.log(C.bold('\n── Natural Language → AETHER ──\n'));
  console.log(C.dim('Input:      ') + text);
  console.log(C.dim('Stream:     ') + C.cyan(result.streamName));
  console.log(C.dim('Event:      ') + C.cyan(result.event));
  console.log(C.dim(`Confidence: `) + confidenceBar(result.confidence));

  if (result.suggestions.length > 0) {
    console.log(C.yellow('\n⚠ Low confidence — suggestions:'));
    result.suggestions.forEach(s => console.log(C.dim('  • ') + s));
  }

  console.log(C.bold('\n── Generated AETHER Code ──\n'));
  console.log(src);
}

async function cmdRun(filePath?: string) {
  const src = readFile(filePath);
  const res = check(src);
  if (!res.ok) { console.error(C.red('✗ ' + res.error)); process.exit(1); }

  console.log(C.cyan('▶ AETHER Runtime') + C.dim(` — ${filePath}`));

  // Built-in stubs for demonstration
  const builtins = {
    hash:     async (v: unknown) => `hashed:${String(v)}`,
    sign:     (id: unknown) => `token:${String(id)}`,
    verify:   (t: unknown) => ({ id: String(t).replace('token:', '') }),
    uuid:     () => Math.random().toString(36).slice(2),
    now:      () => new Date().toISOString(),
    log:      (...a: unknown[]) => console.log(C.dim('[log]'), ...a),
    validate: (data: unknown, schema: unknown) => {
      console.log(C.dim(`  [validate] schema:${JSON.stringify(schema)}`));
      return data;
    },
    emit: (signal: unknown, payload: unknown) => {
      console.log(C.green(`  [emit] ${signal}`), payload ?? '');
    },
    flow: {
      write: (store: unknown, data: unknown) => {
        console.log(C.cyan(`  [flow] ${store} ← `), JSON.stringify(data)?.slice(0, 60));
        return Promise.resolve();
      },
    },
    Response: {
      ok:      (data: unknown)          => ({ status: 200, data }),
      created: (data: unknown)          => ({ status: 201, data }),
      error:   (msg: unknown, _: unknown) => ({ status: 400, error: msg }),
      redirect:(url: unknown)           => ({ status: 302, url }),
    },
  };

  const { streams, errors, warnings } = parseToRuntime(src, builtins);

  for (const w of warnings) console.warn(C.yellow('⚠ ' + w));
  for (const e of errors)   console.error(C.red('✗ ' + e));
  if (errors.length > 0) process.exit(1);

  console.log(C.dim(`\nRegistered ${streams.length} stream(s):`));
  for (const s of streams) {
    console.log(C.cyan(`  stream ${s.name}`) + C.dim(` [${s.modifiers.join(', ')}]`));
    for (const h of s.handlers) {
      console.log(C.dim(`    on ${h.event}(${h.params.join(', ')})`));
    }
  }

  // Demo: fire the first handler with a sample request
  const first = streams[0];
  if (first?.handlers[0]) {
    const sampleReq = { email: 'test@example.com', password: 'SecurePass123', name: 'Alice' };
    console.log(C.bold('\n── Firing first handler (demo) ──'));
    console.log(C.dim(`  on ${first.handlers[0].event}(`), sampleReq, C.dim(')'));
    const result = await first.handlers[0].fn(sampleReq);
    console.log(C.green('\n  ✓ Result:'), result);
  }
}

async function cmdREPL() {
  const rl = readline.createInterface({
    input:   process.stdin,
    output:  process.stdout,
    prompt:  C.cyan('aether> '),
  });

  console.log(C.bold('\nAETHER REPL v1.0'));
  console.log(C.dim('Type AETHER code, then press Enter twice to run.'));
  console.log(C.dim('Commands: .exit .clear .ast .js .natural "<text>"\n'));

  rl.prompt();
  let buffer = '';

  rl.on('line', async (line: string) => {
    if (line.startsWith('.exit'))  { process.exit(0); }

    if (line.startsWith('.natural ')) {
      const text   = line.slice(9).trim();
      const result = naturalToAST(text);
      console.log(regenerate(result.ast));
      console.log(C.dim(`confidence: ${result.confidence}%`));
      rl.prompt(); return;
    }

    buffer += line + '\n';

    if (line === '') {
      const src = buffer.trim();
      buffer    = '';
      if (!src) { rl.prompt(); return; }

      const res = check(src);
      if (!res.ok) {
        console.error(C.red(res.error));
      } else {
        if (line.startsWith('.ast')) {
          console.log(JSON.stringify(parse(src), null, 2));
        } else if (line.startsWith('.js')) {
          console.log(compileToJS(parse(src)));
        } else {
          console.log(C.green('✓ Valid AETHER'));
          console.log(C.dim('  Formatted:'));
          console.log(format(src));
        }
      }
      rl.prompt();
    }
  });
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function readFile(filePath?: string): string {
  if (!filePath) { console.error(C.red('Error: No file specified')); process.exit(1); }
  const abs = path.resolve(process.cwd(), filePath);
  if (!fs.existsSync(abs)) {
    console.error(C.red(`Error: File not found — ${abs}`)); process.exit(1);
  }
  return fs.readFileSync(abs, 'utf8');
}

function confidenceBar(pct: number): string {
  const filled = Math.round(pct / 5);
  const bar    = '█'.repeat(filled) + '░'.repeat(20 - filled);
  const color  = pct >= 80 ? C.green : pct >= 60 ? C.yellow : C.red;
  return color(`${bar} ${pct}%`);
}

function printHelp() {
  console.log(`
${C.bold('AETHER Language CLI v1.0')}

${C.cyan('Usage:')}
  aether ${C.green('run')}     <file.ae>          Parse + execute .ae file
  aether ${C.green('check')}   <file.ae>          Type-check only
  aether ${C.green('build')}   <file.ae> [out.js] Compile to JavaScript
  aether ${C.green('format')}  <file.ae>          Format and print source
  aether ${C.green('tokens')}  <file.ae>          Show token stream
  aether ${C.green('ast')}     <file.ae>          Print AST as JSON
  aether ${C.green('natural')} "<description>"    Natural language → AETHER
  aether ${C.green('repl')}                       Interactive REPL

${C.cyan('Examples:')}
  aether run users.ae
  aether check auth.ae
  aether build api.ae dist/api.js
  aether natural "when user registers, validate email, save, send welcome"
  aether natural "عند تسجيل مستخدم، تحقق من البريد، احفظ، وأرسل ترحيباً"
`);
}

main().catch(e => { console.error(C.red(e.message)); process.exit(1); });
