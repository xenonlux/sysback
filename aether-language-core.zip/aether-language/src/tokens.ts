/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description Token type definitions for the AETHER language lexer.
 */

export const enum TT {
  // ── Literals ──────────────────────────────────────────
  StringLit = 'STRING',
  NumberLit = 'NUMBER',
  BoolLit   = 'BOOL',
  NullLit   = 'NULL',

  // ── Identifiers ───────────────────────────────────────
  Ident = 'IDENT',

  // ── Structure Keywords ────────────────────────────────
  Stream   = 'stream',
  On       = 'on',
  Let      = 'let',
  TypeKw   = 'type',

  // ── Statement Keywords ────────────────────────────────
  Validate = 'validate',
  Flow     = 'flow',
  Emit     = 'emit',
  Yield    = 'yield',
  Return   = 'return',
  If       = 'if',
  Else     = 'else',
  Await    = 'await',

  // ── Modifier Keywords ─────────────────────────────────
  Quantum     = 'quantum',
  Transparent = 'transparent',
  Parallel    = 'parallel',
  Cached      = 'cached',

  // ── Domain Type Keywords ──────────────────────────────
  Email    = 'Email',
  Password = 'Password',
  Url      = 'URL',
  Uuid     = 'UUID',
  DateType = 'Date',
  StringTy = 'String',
  IntTy    = 'Int',
  FloatTy  = 'Float',
  BoolTy   = 'Bool',
  Response = 'Response',

  // ── Operators ─────────────────────────────────────────
  Assign  = '=',
  EqEq    = '==',
  Neq     = '!=',
  Arrow   = '<-',  // flow write: flow.store <- data
  Lt      = '<',
  Gt      = '>',
  Lte     = '<=',
  Gte     = '>=',
  Plus    = '+',
  Minus   = '-',
  Star    = '*',
  Slash   = '/',
  And     = '&&',
  Or      = '||',
  Not     = '!',

  // ── Punctuation ───────────────────────────────────────
  Dot    = '.',
  Comma  = ',',
  Semi   = ';',
  Colon  = ':',
  LBrace = '{',
  RBrace = '}',
  LParen = '(',
  RParen = ')',
  LBrack = '[',
  RBrack = ']',

  // ── Special ───────────────────────────────────────────
  EOF = 'EOF',
}

/** A single lexed token with source position. */
export interface Token {
  readonly kind:  TT;
  readonly value: string;
  readonly line:  number;
  readonly col:   number;
}

/** Constructs a Token object. */
export function mkToken(kind: TT, value: string, line: number, col: number): Token {
  return { kind, value, line, col };
}

/** All reserved keyword → token-kind mappings. */
export const KEYWORDS: Readonly<Record<string, TT>> = {
  stream:      TT.Stream,
  on:          TT.On,
  let:         TT.Let,
  type:        TT.TypeKw,
  validate:    TT.Validate,
  flow:        TT.Flow,
  emit:        TT.Emit,
  yield:       TT.Yield,
  return:      TT.Return,
  if:          TT.If,
  else:        TT.Else,
  await:       TT.Await,
  quantum:     TT.Quantum,
  transparent: TT.Transparent,
  parallel:    TT.Parallel,
  cached:      TT.Cached,
  // Domain types (capital-case)
  Email:    TT.Email,
  Password: TT.Password,
  URL:      TT.Url,
  UUID:     TT.Uuid,
  Date:     TT.DateType,
  String:   TT.StringTy,
  Int:      TT.IntTy,
  Float:    TT.FloatTy,
  Bool:     TT.BoolTy,
  Response: TT.Response,
  // Bool literals
  true:  TT.BoolLit,
  false: TT.BoolLit,
  null:  TT.NullLit,
};

/** Modifier token kinds. */
export const MODIFIERS = new Set<TT>([
  TT.Quantum, TT.Transparent, TT.Parallel, TT.Cached,
]);

/** Domain type token kinds. */
export const DOMAIN_TYPES = new Set<TT>([
  TT.Email, TT.Password, TT.Url, TT.Uuid, TT.DateType,
  TT.StringTy, TT.IntTy, TT.FloatTy, TT.BoolTy, TT.Response,
]);
