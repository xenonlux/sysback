/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description AST → AETHER source regeneration.
 * Enables round-tripping: parse source → AST → regenerate source.
 */

import type {
  Program, Declaration, StreamDeclaration, HandlerDeclaration,
  Statement, Expression, SchemaField, CallArg, Modifier,
} from '../ast';

export function regenerate(program: Program): string {
  return program.body.map(genDecl).join('\n\n');
}

function genDecl(decl: Declaration): string {
  switch (decl.kind) {
    case 'StreamDeclaration': return genStream(decl);
    case 'TypeDeclaration': {
      const fields = decl.fields.map(f =>
        `  ${f.name}: ${f.domainType}${f.constraint ? `.${f.constraint}` : ''}`
      ).join(',\n');
      return `type ${decl.name} = {\n${fields}\n}`;
    }
  }
}

function genStream(s: StreamDeclaration): string {
  const mods     = s.modifiers.join(' ');
  const handlers = s.handlers.map(h => genHandler(h, 2)).join('\n');
  return `stream ${s.name}${mods ? ' ' + mods : ''} {\n${handlers}\n}`;
}

function genHandler(h: HandlerDeclaration, depth: number): string {
  const pad    = ' '.repeat(depth);
  const mods   = h.modifiers.join(' ');
  const params = h.params.join(', ');
  const body   = h.body.map(s => genStmt(s, depth + 2)).join('\n');
  return `${pad}on ${h.event}(${params})${mods ? ' ' + mods : ''} {\n${body}\n${pad}}`;
}

function genStmt(stmt: Statement, depth: number): string {
  const pad = ' '.repeat(depth);
  switch (stmt.kind) {
    case 'LetStatement':
      return `${pad}let ${stmt.name} = ${genExpr(stmt.value)}`;
    case 'ValidateStatement': {
      const schema = genSchema(stmt.schema, depth + 2);
      return `${pad}let ${stmt.target} = validate ${genExpr(stmt.source)} ${schema}`;
    }
    case 'FlowWriteStatement':
      return `${pad}flow.${stmt.store} <- ${genExpr(stmt.data)}`;
    case 'AssignStatement':
      return `${pad}${stmt.target.join('.')} = ${genExpr(stmt.value)}`;
    case 'EmitStatement': {
      const payload = stmt.payload ? `(${genExpr(stmt.payload)})` : '';
      return `${pad}emit ${stmt.namespace}.${stmt.signal}${payload}`;
    }
    case 'YieldStatement':
      return `${pad}yield ${genExpr(stmt.value)}`;
    case 'IfStatement': {
      const cond    = genExpr(stmt.condition);
      const cons    = stmt.consequent.map(s => genStmt(s, depth + 2)).join('\n');
      let   result  = `${pad}if (${cond}) {\n${cons}\n${pad}}`;
      if (stmt.alternate && stmt.alternate.length > 0) {
        const alt = stmt.alternate.map(s => genStmt(s, depth + 2)).join('\n');
        result   += ` else {\n${alt}\n${pad}}`;
      }
      return result;
    }
    case 'ExpressionStatement':
      return `${pad}${genExpr(stmt.expression)}`;
  }
}

function genExpr(expr: Expression): string {
  switch (expr.kind) {
    case 'Literal':
      if (expr.value === null)             return 'null';
      if (typeof expr.value === 'string')  return `"${expr.value}"`;
      return String(expr.value);
    case 'Identifier':  return expr.name;
    case 'MemberExpr':  return expr.object.join('.');
    case 'CallExpr': {
      const callee = expr.callee.join('.');
      const args   = expr.args.map(genCallArg).join(', ');
      return `${callee}(${args})`;
    }
    case 'AwaitExpr':   return `await ${genExpr(expr.value)}`;
    case 'BinaryExpr':  return `${genExpr(expr.left)} ${expr.op} ${genExpr(expr.right)}`;
    case 'ValidateExpr':
      return `validate ${genExpr(expr.source)} ${genSchema(expr.schema, 0)}`;
    case 'ObjectExpr': {
      const props = expr.properties.map(p => `${p.key}: ${genExpr(p.value)}`).join(', ');
      return `{ ${props} }`;
    }
    case 'ArrayExpr':
      return `[${expr.elements.map(genExpr).join(', ')}]`;
  }
}

function genCallArg(arg: CallArg): string {
  const val = genExpr(arg.value);
  return arg.label ? `${arg.label}: ${val}` : val;
}

function genSchema(fields: SchemaField[], depth: number): string {
  if (fields.length === 0) return '{}';
  const pad    = ' '.repeat(depth);
  const inner  = ' '.repeat(depth + 2);
  const lines  = fields.map(f => {
    let constraint = `${f.domainType}.${f.constraint}`;
    if (f.args.length > 0) {
      const args = f.args.map(a => a.key ? `${a.key}: ${a.value}` : String(a.value)).join(', ');
      constraint += `(${args})`;
    }
    return `${inner}${f.name}: ${constraint}`;
  });
  return `{\n${lines.join(',\n')}\n${pad}}`;
}
