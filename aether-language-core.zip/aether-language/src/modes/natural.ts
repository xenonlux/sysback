/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description Natural Language Bridge — converts plain Arabic/English text to AETHER AST.
 *
 * Pipeline:
 *   1. Tokenize input text into intent words
 *   2. Detect trigger (when/on/if/عند/إذا)
 *   3. Detect actions (validate/save/emit/return/تحقق/احفظ/أرسل)
 *   4. Detect entities (user/email/password/مستخدم/بريد)
 *   5. Map to AST nodes via templates
 *   6. Score confidence — low confidence returns suggestions
 */

import type {
  Program, StreamDeclaration, HandlerDeclaration,
  Statement, SchemaField,
} from '../ast';

// ─── Pattern library ─────────────────────────────────────────────────────────

interface ActionPattern {
  patterns: string[];
  kind: 'validate' | 'flow_write' | 'emit' | 'yield_created' | 'yield_ok' | 'yield_error';
}

const ACTION_PATTERNS: ActionPattern[] = [
  {
    patterns: ['validate','verify','check','تحقق','تأكد','فحص','اتحقق'],
    kind: 'validate',
  },
  {
    patterns: ['save','store','add','insert','persist','احفظ','خزّن','أضف','أدخل'],
    kind: 'flow_write',
  },
  {
    patterns: ['send','emit','notify','signal','أرسل','أطلق','أعلم','بلّغ'],
    kind: 'emit',
  },
  {
    patterns: ['return created','respond created','أرجع منشأ','رد بنجاح','أرجع رمز'],
    kind: 'yield_created',
  },
  {
    patterns: ['return ok','respond ok','return success','أرجع نجاح','رد ناجح'],
    kind: 'yield_ok',
  },
  {
    patterns: ['return error','respond error','أرجع خطأ','رد بخطأ'],
    kind: 'yield_error',
  },
];

interface EntityMap {
  raw:        string[];
  fieldName:  string;
  domainType: string;
  constraint: string;
}

const ENTITY_MAP: EntityMap[] = [
  {
    raw: ['email','mail','بريد','البريد','إيميل','ايميل'],
    fieldName: 'email', domainType: 'Email', constraint: 'format',
  },
  {
    raw: ['password','pass','كلمة مرور','كلمة السر','رمز المرور','باسورد'],
    fieldName: 'password', domainType: 'Password', constraint: 'strong',
  },
  {
    raw: ['name','username','اسم','الاسم','اسم المستخدم'],
    fieldName: 'name', domainType: 'String', constraint: 'min',
  },
  {
    raw: ['phone','mobile','رقم الهاتف','جوال','هاتف'],
    fieldName: 'phone', domainType: 'String', constraint: 'format',
  },
  {
    raw: ['age','عمر','السن'],
    fieldName: 'age', domainType: 'Int', constraint: 'min',
  },
  {
    raw: ['url','link','رابط','الرابط'],
    fieldName: 'url', domainType: 'URL', constraint: 'format',
  },
];

interface TriggerPattern {
  patterns: string[];
  event:    string;
  streamHint: string;
}

const TRIGGER_PATTERNS: TriggerPattern[] = [
  {
    patterns: ['register','signup','sign up','create account','تسجيل','إنشاء حساب','يسجل'],
    event: 'register', streamHint: 'users',
  },
  {
    patterns: ['login','sign in','authenticate','تسجيل دخول','يدخل','المصادقة'],
    event: 'login', streamHint: 'auth',
  },
  {
    patterns: ['update','modify','edit','تحديث','تعديل','يعدل'],
    event: 'update', streamHint: 'users',
  },
  {
    patterns: ['delete','remove','حذف','إزالة','يحذف'],
    event: 'delete', streamHint: 'users',
  },
  {
    patterns: ['request arrives','request received','طلب يصل','وصول طلب'],
    event: 'receive', streamHint: 'requests',
  },
  {
    patterns: ['error','fail','exception','خطأ','فشل','استثناء'],
    event: 'error', streamHint: 'errors',
  },
];

// ─── Public API ───────────────────────────────────────────────────────────────

export interface NLResult {
  ast:         Program;
  confidence:  number;             // 0–100
  suggestions: string[];           // shown when confidence < 70
  streamName:  string;
  event:       string;
}

/**
 * Convert natural language (Arabic or English) to a AETHER Program AST.
 */
export function naturalToAST(text: string): NLResult {
  const lower  = text.toLowerCase();
  const scores: number[] = [];

  // ── 1. Detect trigger ────────────────────────────────────────────────────
  let matchedTrigger: TriggerPattern | null = null;
  let triggerScore  = 0;

  for (const trigger of TRIGGER_PATTERNS) {
    for (const pattern of trigger.patterns) {
      if (lower.includes(pattern)) {
        matchedTrigger = trigger;
        triggerScore   = 90;
        break;
      }
    }
    if (matchedTrigger) break;
  }

  if (!matchedTrigger) {
    matchedTrigger = { event: 'receive', streamHint: 'requests', patterns: [] };
    triggerScore   = 40;
  }
  scores.push(triggerScore);

  // ── 2. Detect entities (schema fields) ──────────────────────────────────
  const detectedFields: SchemaField[] = [];
  let   entityScore = 0;

  for (const entity of ENTITY_MAP) {
    for (const raw of entity.raw) {
      if (lower.includes(raw)) {
        detectedFields.push({
          name:       entity.fieldName,
          domainType: entity.domainType,
          constraint: entity.constraint,
          args:       entity.constraint === 'min'
            ? [{ key: null, value: entity.fieldName === 'name' ? 2 : 1 }]
            : [],
        });
        entityScore += 15;
        break;
      }
    }
  }
  if (entityScore === 0) entityScore = 20;
  scores.push(Math.min(entityScore, 100));

  // ── 3. Detect actions → build statements ─────────────────────────────────
  const statements: Statement[] = [];
  let   actionScore = 0;

  for (const action of ACTION_PATTERNS) {
    const matched = action.patterns.some(p => lower.includes(p));
    if (!matched) continue;
    actionScore += 20;

    switch (action.kind) {
      case 'validate':
        if (detectedFields.length > 0) {
          statements.push({
            kind:   'LetStatement',
            name:   'data',
            value: {
              kind:   'ValidateExpr',
              source: { kind: 'Identifier', name: 'req', pos: { line: 0, col: 0 } },
              schema: detectedFields,
              pos:    { line: 0, col: 0 },
            },
            pos: { line: 0, col: 0 },
          });
        }
        break;

      case 'flow_write':
        statements.push({
          kind:  'FlowWriteStatement',
          store: matchedTrigger.streamHint,
          data:  { kind: 'Identifier', name: 'data', pos: { line: 0, col: 0 } },
          pos:   { line: 0, col: 0 },
        });
        break;

      case 'emit':
        statements.push({
          kind:      'EmitStatement',
          namespace: 'signal',
          signal:    `${matchedTrigger.event}_complete`,
          payload:   { kind: 'MemberExpr', object: ['data', 'id'], pos: { line: 0, col: 0 } },
          pos:       { line: 0, col: 0 },
        });
        break;

      case 'yield_created':
        statements.push({
          kind:  'YieldStatement',
          value: {
            kind:   'CallExpr',
            callee: ['Response', 'created'],
            args:   [{ label: 'token', value: {
              kind: 'CallExpr', callee: ['sign'],
              args: [{ label: null, value: { kind: 'MemberExpr', object: ['data', 'id'], pos: { line:0,col:0 } } }],
              pos: { line:0,col:0 },
            }}],
            pos: { line: 0, col: 0 },
          },
          pos: { line: 0, col: 0 },
        });
        break;

      case 'yield_ok':
        statements.push({
          kind:  'YieldStatement',
          value: {
            kind: 'CallExpr', callee: ['Response', 'ok'],
            args: [{ label: null, value: { kind: 'Identifier', name: 'data', pos: { line:0,col:0 } } }],
            pos: { line: 0, col: 0 },
          },
          pos: { line: 0, col: 0 },
        });
        break;

      case 'yield_error':
        statements.push({
          kind:  'YieldStatement',
          value: {
            kind: 'CallExpr', callee: ['Response', 'error'],
            args: [
              { label: null, value: { kind: 'Literal', value: 'Operation failed', pos: { line:0,col:0 } } },
              { label: null, value: { kind: 'Literal', value: null, pos: { line:0,col:0 } } },
            ],
            pos: { line: 0, col: 0 },
          },
          pos: { line: 0, col: 0 },
        });
        break;
    }
  }

  // Default yield if nothing matched
  if (!statements.some(s => s.kind === 'YieldStatement')) {
    statements.push({
      kind:  'YieldStatement',
      value: {
        kind: 'CallExpr', callee: ['Response', 'ok'],
        args: [{ label: null, value: { kind: 'Literal', value: null, pos: { line:0,col:0 } } }],
        pos: { line: 0, col: 0 },
      },
      pos: { line: 0, col: 0 },
    });
    actionScore += 10;
  }

  scores.push(Math.min(actionScore + 10, 100));

  // ── 4. Build Program AST ─────────────────────────────────────────────────
  const confidence = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);

  const handler: HandlerDeclaration = {
    kind:      'HandlerDeclaration',
    event:     matchedTrigger.event,
    params:    ['req'],
    modifiers: [],
    body:      statements,
    pos:       { line: 0, col: 0 },
  };

  const stream: StreamDeclaration = {
    kind:      'StreamDeclaration',
    name:      matchedTrigger.streamHint,
    modifiers: confidence >= 80 ? ['quantum'] : [],
    handlers:  [handler],
    pos:       { line: 0, col: 0 },
  };

  const ast: Program = { kind: 'Program', body: [stream] };

  // ── 5. Generate suggestions if low confidence ─────────────────────────────
  const suggestions: string[] = [];
  if (confidence < 70) {
    suggestions.push(`تم التعرف على الحدث: "${matchedTrigger.event}" في stream "${matchedTrigger.streamHint}"`);
    if (detectedFields.length === 0) {
      suggestions.push('لم يتم تحديد حقول التحقق — أضف: email, password, name');
    } else {
      suggestions.push(`حقول التحقق المكتشفة: ${detectedFields.map(f => f.name).join(', ')}`);
    }
    suggestions.push('هل تقصد: validate + save + emit + yield Response.created?');
  }

  return {
    ast,
    confidence,
    suggestions,
    streamName: matchedTrigger.streamHint,
    event:      matchedTrigger.event,
  };
}
