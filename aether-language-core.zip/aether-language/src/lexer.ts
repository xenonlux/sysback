/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description AETHER language lexer — converts source text to tokens.
 *
 * Handles:
 *   • All AETHER keywords and modifiers
 *   • `<-` as a single ARROW token (flow write operator)
 *   • `==`, `!=`, `<=`, `>=`, `&&`, `||` as compound operators
 *   • String literals with escape sequences (single + double quotes)
 *   • Numeric literals (integer + float)
 *   • Single-line `//` and block `/* * /` comments
 *   • Full line + column tracking for error reporting
 */

import { TT, Token, mkToken, KEYWORDS } from './tokens';

export class LexError extends Error {
  constructor(
    message: string,
    public readonly line: number,
    public readonly col:  number,
  ) {
    super(`[Lex Error] Line ${line}:${col} — ${message}`);
    this.name = 'LexError';
  }
}

export class Lexer {
  private readonly src: string;
  private pos  = 0;
  private line = 1;
  private col  = 1;

  constructor(src: string) {
    this.src = src;
  }

  // ─── Public API ──────────────────────────────────────────────────────────

  /** Tokenize the full source and return the token stream. */
  public tokenize(): Token[] {
    const tokens: Token[] = [];

    while (this.pos < this.src.length) {
      this.skipWhitespace();
      if (this.pos >= this.src.length) break;

      const c = this.src[this.pos];

      // Skip single-line comment
      if (c === '/' && this.peek(1) === '/') {
        this.skipLineComment();
        continue;
      }

      // Skip block comment
      if (c === '/' && this.peek(1) === '*') {
        this.skipBlockComment();
        continue;
      }

      const tok = this.nextToken();
      if (tok) tokens.push(tok);
    }

    tokens.push(mkToken(TT.EOF, '', this.line, this.col));
    return tokens;
  }

  // ─── Token Dispatch ──────────────────────────────────────────────────────

  private nextToken(): Token | null {
    const c   = this.src[this.pos];
    const ln  = this.line;
    const col = this.col;

    // ── String literals ──────────────────────────────────────────────────
    if (c === '"' || c === "'") return this.readString(c);

    // ── Numeric literals ─────────────────────────────────────────────────
    if (isDigit(c)) return this.readNumber();

    // ── Identifiers / keywords ───────────────────────────────────────────
    if (isAlpha(c)) return this.readWord();

    // ── `<-` flow-write arrow ────────────────────────────────────────────
    if (c === '<' && this.peek(1) === '-') {
      this.advance(2);
      return mkToken(TT.Arrow, '<-', ln, col);
    }

    // ── Two-char operators ───────────────────────────────────────────────
    const two = c + this.peek(1);
    switch (two) {
      case '==': this.advance(2); return mkToken(TT.EqEq,  '==', ln, col);
      case '!=': this.advance(2); return mkToken(TT.Neq,   '!=', ln, col);
      case '<=': this.advance(2); return mkToken(TT.Lte,   '<=', ln, col);
      case '>=': this.advance(2); return mkToken(TT.Gte,   '>=', ln, col);
      case '&&': this.advance(2); return mkToken(TT.And,   '&&', ln, col);
      case '||': this.advance(2); return mkToken(TT.Or,    '||', ln, col);
    }

    // ── Single-char tokens ───────────────────────────────────────────────
    this.advance(1);
    switch (c) {
      case '=': return mkToken(TT.Assign, '=', ln, col);
      case '<': return mkToken(TT.Lt,     '<', ln, col);
      case '>': return mkToken(TT.Gt,     '>', ln, col);
      case '+': return mkToken(TT.Plus,   '+', ln, col);
      case '-': return mkToken(TT.Minus,  '-', ln, col);
      case '*': return mkToken(TT.Star,   '*', ln, col);
      case '/': return mkToken(TT.Slash,  '/', ln, col);
      case '!': return mkToken(TT.Not,    '!', ln, col);
      case '.': return mkToken(TT.Dot,    '.', ln, col);
      case ',': return mkToken(TT.Comma,  ',', ln, col);
      case ';': return mkToken(TT.Semi,   ';', ln, col);
      case ':': return mkToken(TT.Colon,  ':', ln, col);
      case '{': return mkToken(TT.LBrace, '{', ln, col);
      case '}': return mkToken(TT.RBrace, '}', ln, col);
      case '(': return mkToken(TT.LParen, '(', ln, col);
      case ')': return mkToken(TT.RParen, ')', ln, col);
      case '[': return mkToken(TT.LBrack, '[', ln, col);
      case ']': return mkToken(TT.RBrack, ']', ln, col);
    }

    // Unknown character — skip with warning
    console.warn(`[Lexer] Unknown character '${c}' at ${ln}:${col} — skipped`);
    return null;
  }

  // ─── Readers ─────────────────────────────────────────────────────────────

  private readString(quote: string): Token {
    const ln  = this.line;
    const col = this.col;
    this.advance(1); // opening quote

    let value = '';
    while (this.pos < this.src.length && this.src[this.pos] !== quote) {
      if (this.src[this.pos] === '\\') {
        this.advance(1); // backslash
        const esc = this.src[this.pos];
        switch (esc) {
          case 'n':  value += '\n'; break;
          case 't':  value += '\t'; break;
          case 'r':  value += '\r'; break;
          case '"':  value += '"';  break;
          case "'":  value += "'";  break;
          case '\\': value += '\\'; break;
          default:   value += esc;
        }
        this.advance(1);
        continue;
      }
      value += this.src[this.pos];
      this.advance(1);
    }

    if (this.pos >= this.src.length) {
      throw new LexError('Unterminated string literal', ln, col);
    }

    this.advance(1); // closing quote
    return mkToken(TT.StringLit, value, ln, col);
  }

  private readNumber(): Token {
    const ln  = this.line;
    const col = this.col;
    let   raw = '';

    while (this.pos < this.src.length && isDigit(this.src[this.pos])) {
      raw += this.src[this.pos];
      this.advance(1);
    }

    // Optional decimal
    if (this.src[this.pos] === '.' && isDigit(this.src[this.pos + 1])) {
      raw += '.';
      this.advance(1);
      while (this.pos < this.src.length && isDigit(this.src[this.pos])) {
        raw += this.src[this.pos];
        this.advance(1);
      }
    }

    return mkToken(TT.NumberLit, raw, ln, col);
  }

  private readWord(): Token {
    const ln  = this.line;
    const col = this.col;
    let   raw = '';

    while (this.pos < this.src.length && isAlphaNum(this.src[this.pos])) {
      raw += this.src[this.pos];
      this.advance(1);
    }

    const kw = KEYWORDS[raw];
    if (kw !== undefined) {
      return mkToken(kw, raw, ln, col);
    }

    return mkToken(TT.Ident, raw, ln, col);
  }

  // ─── Utilities ───────────────────────────────────────────────────────────

  private peek(offset: number): string {
    return this.src[this.pos + offset] ?? '';
  }

  private advance(count: number): void {
    for (let i = 0; i < count; i++) {
      if (this.src[this.pos] === '\n') {
        this.line++;
        this.col = 1;
      } else {
        this.col++;
      }
      this.pos++;
    }
  }

  private skipWhitespace(): void {
    while (this.pos < this.src.length && /\s/.test(this.src[this.pos])) {
      this.advance(1);
    }
  }

  private skipLineComment(): void {
    while (this.pos < this.src.length && this.src[this.pos] !== '\n') {
      this.advance(1);
    }
  }

  private skipBlockComment(): void {
    this.advance(2); // /*
    while (this.pos < this.src.length) {
      if (this.src[this.pos] === '*' && this.src[this.pos + 1] === '/') {
        this.advance(2);
        return;
      }
      this.advance(1);
    }
    throw new LexError('Unterminated block comment', this.line, this.col);
  }
}

// ─── Character helpers ────────────────────────────────────────────────────

function isDigit(c: string):    boolean { return c >= '0' && c <= '9'; }
function isAlpha(c: string):    boolean { return /[a-zA-Z_]/.test(c); }
function isAlphaNum(c: string): boolean { return /[a-zA-Z0-9_]/.test(c); }
