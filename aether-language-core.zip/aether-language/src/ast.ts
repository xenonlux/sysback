/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description Complete AST node type definitions for the AETHER language.
 *
 * Hierarchy:
 *   Program
 *   └── Declaration[]
 *       ├── StreamDeclaration     stream users quantum { ... }
 *       └── TypeDeclaration      type User = { email: Email }
 *
 *   StreamDeclaration
 *   └── HandlerDeclaration[]     on register(req) transparent { ... }
 *       └── Statement[]
 *
 *   Statements:
 *     LetStatement               let user = validate req { ... }
 *     ValidateStatement          validate req { email: Email.format }
 *     FlowWriteStatement         flow.users <- user
 *     AssignStatement            user.password = await hash(...)
 *     EmitStatement              emit signal.welcome(user.id)
 *     YieldStatement             yield Response.created(...)
 *     IfStatement                if (cond) { ... } else { ... }
 *     ExpressionStatement        someCall()
 *
 *   Expressions:
 *     LiteralExpr
 *     IdentifierExpr
 *     MemberExpr                 user.password  /  Response.created
 *     CallExpr                   hash(user.password)  /  Response.ok({ ... })
 *     AwaitExpr                  await hash(x)
 *     BinaryExpr                 a == b  /  x && y
 *     ValidateExpr               validate req { email: Email.format }
 *     ObjectExpr                 { email: "a@b.com", name: "Alice" }
 *     ArrayExpr                  [1, 2, 3]
 */

// ─── Source position ─────────────────────────────────────────────────────

export interface SourcePos {
  line: number;
  col:  number;
}

// ─── Modifiers ────────────────────────────────────────────────────────────

export type Modifier = 'quantum' | 'transparent' | 'parallel' | `cached:${string}`;

// ─── Program ─────────────────────────────────────────────────────────────

export interface Program {
  kind: 'Program';
  body: Declaration[];
}

// ─── Declarations ─────────────────────────────────────────────────────────

export type Declaration = StreamDeclaration | TypeDeclaration;

export interface StreamDeclaration {
  kind:      'StreamDeclaration';
  name:      string;
  modifiers: Modifier[];
  handlers:  HandlerDeclaration[];
  pos:       SourcePos;
}

export interface HandlerDeclaration {
  kind:      'HandlerDeclaration';
  event:     string;
  params:    string[];
  modifiers: Modifier[];
  body:      Statement[];
  pos:       SourcePos;
}

export interface TypeDeclaration {
  kind:   'TypeDeclaration';
  name:   string;
  fields: TypeField[];
  pos:    SourcePos;
}

export interface TypeField {
  name:       string;
  domainType: string;
  constraint: string | null;
  args:       ConstraintArg[];
}

// ─── Statements ──────────────────────────────────────────────────────────

export type Statement
  = LetStatement
  | ValidateStatement
  | FlowWriteStatement
  | AssignStatement
  | EmitStatement
  | YieldStatement
  | IfStatement
  | ExpressionStatement;

export interface LetStatement {
  kind:  'LetStatement';
  name:  string;
  value: Expression;
  pos:   SourcePos;
}

export interface ValidateStatement {
  kind:   'ValidateStatement';
  target: string;              // variable being validated
  source: Expression;          // the request/data source
  schema: SchemaField[];
  pos:    SourcePos;
}

export interface FlowWriteStatement {
  kind:  'FlowWriteStatement';
  store: string;               // flow.<store>
  data:  Expression;
  pos:   SourcePos;
}

export interface AssignStatement {
  kind:   'AssignStatement';
  target: string[];            // ["user", "password"]
  value:  Expression;
  pos:    SourcePos;
}

export interface EmitStatement {
  kind:      'EmitStatement';
  namespace: string;           // "signal"
  signal:    string;           // "welcome"
  payload:   Expression | null;
  pos:       SourcePos;
}

export interface YieldStatement {
  kind:  'YieldStatement';
  value: Expression;
  pos:   SourcePos;
}

export interface IfStatement {
  kind:       'IfStatement';
  condition:  Expression;
  consequent: Statement[];
  alternate:  Statement[] | null;
  pos:        SourcePos;
}

export interface ExpressionStatement {
  kind:       'ExpressionStatement';
  expression: Expression;
  pos:        SourcePos;
}

// ─── Schema (for validate) ────────────────────────────────────────────────

export interface SchemaField {
  name:       string;         // "email"
  domainType: string;         // "Email"
  constraint: string;         // "format" | "strong" | "min" | "max" | ...
  args:       ConstraintArg[];
}

export interface ConstraintArg {
  key:   string | null;       // named arg: "min" | null for positional
  value: string | number;
}

// ─── Expressions ─────────────────────────────────────────────────────────

export type Expression
  = LiteralExpr
  | IdentifierExpr
  | MemberExpr
  | CallExpr
  | AwaitExpr
  | BinaryExpr
  | ValidateExpr
  | ObjectExpr
  | ArrayExpr;

export interface LiteralExpr {
  kind:  'Literal';
  value: string | number | boolean | null;
  pos:   SourcePos;
}

export interface IdentifierExpr {
  kind: 'Identifier';
  name: string;
  pos:  SourcePos;
}

export interface MemberExpr {
  kind:   'MemberExpr';
  object: string[];          // ["Response", "created"] | ["user", "id"]
  pos:    SourcePos;
}

export interface CallExpr {
  kind:   'CallExpr';
  callee: string[];          // ["hash"] | ["Response", "created"] | ["sign"]
  args:   CallArg[];
  pos:    SourcePos;
}

export interface CallArg {
  label: string | null;      // named: "token:" | null for positional
  value: Expression;
}

export interface AwaitExpr {
  kind:  'AwaitExpr';
  value: Expression;
  pos:   SourcePos;
}

export interface BinaryExpr {
  kind:     'BinaryExpr';
  op:       BinaryOp;
  left:     Expression;
  right:    Expression;
  pos:      SourcePos;
}

export type BinaryOp = '==' | '!=' | '<' | '>' | '<=' | '>=' | '+' | '-' | '*' | '/' | '&&' | '||';

export interface ValidateExpr {
  kind:   'ValidateExpr';
  source: Expression;
  schema: SchemaField[];
  pos:    SourcePos;
}

export interface ObjectExpr {
  kind:       'ObjectExpr';
  properties: ObjectProp[];
  pos:        SourcePos;
}

export interface ObjectProp {
  key:   string;
  value: Expression;
}

export interface ArrayExpr {
  kind:     'ArrayExpr';
  elements: Expression[];
  pos:      SourcePos;
}
