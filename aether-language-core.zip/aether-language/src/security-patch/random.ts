/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/guard
 * @description CRITICAL SECURITY PATCH — crypto/random.ts
 *
 * Replace ALL uses of Math.random() in the AETHER codebase with
 * cryptographically secure randomness.
 *
 * ⚠️ CRITICAL: Math.random() is NOT cryptographically secure.
 *    It is predictable and MUST NOT be used for:
 *    - Key generation
 *    - Nonce/IV generation
 *    - Token generation
 *    - Any security-sensitive operation
 *
 * This module is the SINGLE source of truth for all random values
 * in the AETHER security layer.
 */

/**
 * Generate `count` cryptographically secure random bytes.
 * Works in Node.js ≥ 18 and all modern browsers.
 */
export function randomBytes(count: number): Uint8Array {
  const buf = new Uint8Array(count);

  if (typeof globalThis.crypto?.getRandomValues === 'function') {
    // Browser + Node.js 18+ Web Crypto API
    globalThis.crypto.getRandomValues(buf);
  } else {
    // Node.js fallback (older than 18)
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const nodeCrypto = require('crypto') as typeof import('crypto');
    const nodeBytes  = nodeCrypto.randomBytes(count);
    buf.set(nodeBytes);
  }

  return buf;
}

/**
 * Generate a single cryptographically secure random byte.
 */
export function randomByte(): number {
  return randomBytes(1)[0];
}

/**
 * Generate a secure random integer in range [0, max).
 * Uses rejection sampling to avoid modulo bias.
 */
export function randomInt(max: number): number {
  if (max <= 0)  throw new RangeError('max must be > 0');
  if (max === 1) return 0;

  // Compute the largest multiple of max that fits in a byte
  const limit = 256 - (256 % max);

  while (true) {
    const byte = randomByte();
    if (byte < limit) return byte % max;
    // Reject values that would introduce bias — try again
  }
}

/**
 * Generate a secure random 32-bit unsigned integer.
 */
export function randomUint32(): number {
  const bytes = randomBytes(4);
  return (bytes[0] << 24 | bytes[1] << 16 | bytes[2] << 8 | bytes[3]) >>> 0;
}

/**
 * Generate a cryptographically secure UUID v4.
 */
export function secureUUID(): string {
  const bytes = randomBytes(16);
  // Set version (4) and variant bits
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;

  const hex = Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
  return [
    hex.slice(0,  8),
    hex.slice(8,  12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20),
  ].join('-');
}

/**
 * Generate a secure random bit (0 or 1).
 * Safe replacement for: Math.random() > 0.5 ? 1 : 0
 */
export function randomBit(): 0 | 1 {
  return (randomByte() & 1) as 0 | 1;
}

/**
 * Fill an array with secure random bits.
 * Used by Kyber KEM for polynomial coefficient generation.
 */
export function randomBits(count: number): (0 | 1)[] {
  const bytes  = randomBytes(Math.ceil(count / 8));
  const result: (0 | 1)[] = [];
  for (let i = 0; i < count; i++) {
    result.push(((bytes[Math.floor(i / 8)] >> (i % 8)) & 1) as 0 | 1);
  }
  return result;
}

/**
 * PATCH INSTRUCTIONS for existing kyber.ts:
 *
 * Find every occurrence of:
 *   Math.random() > 0.5 ? 1 : 0
 *   Math.random() * N
 *   Math.floor(Math.random() * N)
 *
 * Replace with:
 *   randomBit()          // for 0 or 1 values
 *   randomInt(N)         // for integers in [0, N)
 *   randomBytes(N)       // for raw byte arrays
 *
 * Import at top of kyber.ts:
 *   import { randomBit, randomInt, randomBytes } from './random';
 */
