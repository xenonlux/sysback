/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @version 1.0.0
 *
 * @aether/language — The AETHER language core.
 *
 * Provides: lexer, parser, AST types, and code generators.
 *
 * @example
 * import { parse, generateJS, regenerate } from '@aether/language';
 *
 * const source = `
 *   stream users quantum {
 *     on register(req) {
 *       let user = validate req {
 *         email: Email.format,
 *         password: Password.strong(min: 8)
 *       }
 *       flow.users <- user
 *       emit signal.welcome(user.id)
 *       yield Response.created(token: sign(user.id))
 *     }
 *   }
 * `;
 *
 * const ast = parse(source);                // → Program AST
 * const js  = generateJS(ast);              // → JavaScript string
 * const src = regenerate(ast);              // → AETHER source (round-trip)
 *
 * console.log(ast.body[0].kind);            // "StreamDeclaration"
 * console.log(ast.body[0].name);            // "users"
 * console.log(ast.body[0].modifiers);       // ["quantum"]
 */

import { Lexer }      from './lexer';
import { Parser }     from './parser';
import { generateJS } from './codegen/js';
import { regenerate } from './codegen/regenerate';

export { Lexer }                    from './lexer';
export { Parser }                   from './parser';
export { LexError }                 from './lexer';
export { ParseError }               from './parser';
export { generateJS }               from './codegen/js';
export { regenerate }               from './codegen/regenerate';
export { TT }                       from './tokens';
export type { Token }               from './tokens';
export type {
  Program,
  Declaration,
  StreamDeclaration,
  HandlerDeclaration,
  TypeDeclaration,
  TypeField,
  Statement,
  LetStatement,
  ValidateStatement,
  FlowWriteStatement,
  AssignStatement,
  EmitStatement,
  YieldStatement,
  IfStatement,
  ExpressionStatement,
  Expression,
  LiteralExpr,
  IdentifierExpr,
  MemberExpr,
  CallExpr,
  CallArg,
  AwaitExpr,
  BinaryExpr,
  BinaryOp,
  ValidateExpr,
  ObjectExpr,
  ObjectProp,
  ArrayExpr,
  SchemaField,
  ConstraintArg,
  Modifier,
  SourcePos,
} from './ast';

// ─── Primary convenience functions ───────────────────────────────────────────

/**
 * Parse AETHER source code into a typed Program AST.
 * @throws {LexError}   on lexical errors
 * @throws {ParseError} on syntactic errors
 */
export function parse(source: string): import('./ast').Program {
  const tokens = new Lexer(source).tokenize();
  return new Parser(tokens).parse();
}

/**
 * Tokenize AETHER source code (without parsing).
 */
export function tokenize(source: string): import('./tokens').Token[] {
  return new Lexer(source).tokenize();
}

/**
 * Full pipeline: source → AST → JavaScript.
 */
export function compileToJS(source: string): string {
  return generateJS(parse(source));
}

/**
 * Full pipeline: source → AST → AETHER source (round-trip).
 */
export function format(source: string): string {
  return regenerate(parse(source));
}

/**
 * Parse and validate without generating output.
 * Returns `{ ok: true }` or `{ ok: false, error: string }`.
 */
export function check(source: string): { ok: true } | { ok: false; error: string } {
  try {
    parse(source);
    return { ok: true };
  } catch (e: unknown) {
    return { ok: false, error: (e as Error).message };
  }
}
