/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description AETHER language recursive-descent parser.
 *
 * Parses the full AETHER language grammar including:
 *   stream declarations with modifiers
 *   handler declarations (on event(params) modifier { body })
 *   validate statements with schema definitions
 *   flow write statements (flow.store <- data)
 *   assignment statements (user.password = await hash(...))
 *   emit, yield, if/else statements
 *   await expressions, binary expressions, call expressions
 *   named call arguments: Response.created(token: sign(user.id))
 *   object literals, array literals
 *   type declarations
 */

import { TT, Token, MODIFIERS, DOMAIN_TYPES } from './tokens';
import type {
  Program, Declaration, StreamDeclaration, HandlerDeclaration,
  TypeDeclaration, TypeField, Statement, LetStatement, ValidateStatement,
  FlowWriteStatement, AssignStatement, EmitStatement, YieldStatement,
  IfStatement, ExpressionStatement, Expression, LiteralExpr, IdentifierExpr,
  MemberExpr, CallExpr, CallArg, AwaitExpr, BinaryExpr, BinaryOp,
  ValidateExpr, ObjectExpr, ObjectProp, ArrayExpr, SchemaField, ConstraintArg,
  Modifier, SourcePos,
} from './ast';

export class ParseError extends Error {
  constructor(
    message: string,
    public readonly line: number,
    public readonly col:  number,
  ) {
    super(`[Parse Error] Line ${line}:${col} — ${message}`);
    this.name = 'ParseError';
  }
}

export class Parser {
  private readonly tokens: Token[];
  private idx = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens;
  }

  // ─── Public entry ────────────────────────────────────────────────────────

  public parse(): Program {
    const body: Declaration[] = [];

    while (!this.atEOF()) {
      if (this.is(TT.Stream)) {
        body.push(this.parseStream());
      } else if (this.is(TT.TypeKw)) {
        body.push(this.parseTypeDecl());
      } else {
        this.error(`Expected 'stream' or 'type' declaration, got '${this.cur().value}'`);
      }
    }

    return { kind: 'Program', body };
  }

  // ─── Declarations ────────────────────────────────────────────────────────

  private parseStream(): StreamDeclaration {
    const pos = this.pos();
    this.eat(TT.Stream);
    const name      = this.eatIdent('stream name');
    const modifiers = this.parseModifiers();
    this.eat(TT.LBrace);

    const handlers: HandlerDeclaration[] = [];
    while (!this.is(TT.RBrace) && !this.atEOF()) {
      handlers.push(this.parseHandler());
    }

    this.eat(TT.RBrace);
    return { kind: 'StreamDeclaration', name, modifiers, handlers, pos };
  }

  private parseHandler(): HandlerDeclaration {
    const pos = this.pos();
    this.eat(TT.On);
    const event = this.eatIdent('event name');
    this.eat(TT.LParen);

    const params: string[] = [];
    while (!this.is(TT.RParen) && !this.atEOF()) {
      params.push(this.eatIdent('parameter name'));
      if (this.is(TT.Comma)) this.advance();
    }
    this.eat(TT.RParen);

    const modifiers = this.parseModifiers();
    this.eat(TT.LBrace);

    const body: Statement[] = [];
    while (!this.is(TT.RBrace) && !this.atEOF()) {
      body.push(this.parseStatement());
    }

    this.eat(TT.RBrace);
    return { kind: 'HandlerDeclaration', event, params, modifiers, body, pos };
  }

  private parseTypeDecl(): TypeDeclaration {
    const pos = this.pos();
    this.eat(TT.TypeKw);
    const name = this.eatIdent('type name');
    this.eat(TT.Assign);
    this.eat(TT.LBrace);

    const fields: TypeField[] = [];
    while (!this.is(TT.RBrace) && !this.atEOF()) {
      const fieldName = this.eatIdent('field name');
      this.eat(TT.Colon);
      const { domainType, constraint, args } = this.parseTypeConstraint();
      fields.push({ name: fieldName, domainType, constraint, args });
      if (this.is(TT.Comma)) this.advance();
    }

    this.eat(TT.RBrace);
    return { kind: 'TypeDeclaration', name, fields, pos };
  }

  // ─── Modifiers ───────────────────────────────────────────────────────────

  private parseModifiers(): Modifier[] {
    const mods: Modifier[] = [];
    while (MODIFIERS.has(this.cur().kind as TT)) {
      if (this.is(TT.Cached)) {
        this.advance();
        this.eat(TT.LParen);
        const ttl = this.cur().value;
        this.advance();
        this.eat(TT.RParen);
        mods.push(`cached:${ttl}` as Modifier);
      } else {
        mods.push(this.cur().value as Modifier);
        this.advance();
      }
    }
    return mods;
  }

  // ─── Statements ──────────────────────────────────────────────────────────

  private parseStatement(): Statement {
    const tok = this.cur();

    // let x = ...
    if (tok.kind === TT.Let) return this.parseLetStatement();

    // validate <source> { ... }  (standalone validate)
    if (tok.kind === TT.Validate) return this.parseValidateStatement();

    // flow.store <- data
    if (tok.kind === TT.Flow) return this.parseFlowWriteStatement();

    // emit signal.name(payload)
    if (tok.kind === TT.Emit) return this.parseEmitStatement();

    // yield <expr>
    if (tok.kind === TT.Yield) return this.parseYieldStatement();

    // if (cond) { } else { }
    if (tok.kind === TT.If) return this.parseIfStatement();

    // Could be an assignment: user.password = await hash(...)
    // or a bare expression statement: someCall()
    return this.parseAssignOrExprStatement();
  }

  private parseLetStatement(): LetStatement {
    const pos = this.pos();
    this.eat(TT.Let);
    const name = this.eatIdent('variable name');
    this.eat(TT.Assign);

    let value: Expression;

    // let user = validate req { ... }
    if (this.is(TT.Validate)) {
      value = this.parseValidateExpr();
    } else {
      value = this.parseExpr();
    }

    this.eatOptional(TT.Semi);
    return { kind: 'LetStatement', name, value, pos };
  }

  private parseValidateStatement(): ValidateStatement {
    const pos = this.pos();
    this.eat(TT.Validate);
    const targetName = this.eatIdent('validate target');
    const schema     = this.parseSchema();
    this.eatOptional(TT.Semi);
    return {
      kind: 'ValidateStatement',
      target: targetName,
      source: { kind: 'Identifier', name: targetName, pos },
      schema,
      pos,
    };
  }

  private parseFlowWriteStatement(): FlowWriteStatement {
    const pos = this.pos();
    this.eat(TT.Flow);
    this.eat(TT.Dot);
    const store = this.eatIdent('flow store name');
    this.eat(TT.Arrow);
    const data = this.parseExpr();
    this.eatOptional(TT.Semi);
    return { kind: 'FlowWriteStatement', store, data, pos };
  }

  private parseEmitStatement(): EmitStatement {
    const pos = this.pos();
    this.eat(TT.Emit);
    const namespace = this.eatIdent('emit namespace');
    this.eat(TT.Dot);
    const signal = this.eatIdent('signal name');

    let payload: Expression | null = null;
    if (this.is(TT.LParen)) {
      this.advance();
      if (!this.is(TT.RParen)) {
        payload = this.parseExpr();
      }
      this.eat(TT.RParen);
    }

    this.eatOptional(TT.Semi);
    return { kind: 'EmitStatement', namespace, signal, payload, pos };
  }

  private parseYieldStatement(): YieldStatement {
    const pos = this.pos();
    this.eat(TT.Yield);
    const value = this.parseExpr();
    this.eatOptional(TT.Semi);
    return { kind: 'YieldStatement', value, pos };
  }

  private parseIfStatement(): IfStatement {
    const pos = this.pos();
    this.eat(TT.If);
    this.eat(TT.LParen);
    const condition = this.parseExpr();
    this.eat(TT.RParen);

    this.eat(TT.LBrace);
    const consequent: Statement[] = [];
    while (!this.is(TT.RBrace) && !this.atEOF()) {
      consequent.push(this.parseStatement());
    }
    this.eat(TT.RBrace);

    let alternate: Statement[] | null = null;
    if (this.is(TT.Else)) {
      this.advance();
      this.eat(TT.LBrace);
      alternate = [];
      while (!this.is(TT.RBrace) && !this.atEOF()) {
        alternate.push(this.parseStatement());
      }
      this.eat(TT.RBrace);
    }

    return { kind: 'IfStatement', condition, consequent, alternate, pos };
  }

  /**
   * Parse either:
   *   user.password = await hash(...)   →  AssignStatement
   *   someCall()                         →  ExpressionStatement
   */
  private parseAssignOrExprStatement(): AssignStatement | ExpressionStatement {
    const pos  = this.pos();
    const expr = this.parseExpr();

    // Check for assignment: <member> = <expr>
    if (this.is(TT.Assign)) {
      this.advance();
      const value = this.parseExpr();
      this.eatOptional(TT.Semi);

      // Extract target path from left-hand side
      const target = this.memberPath(expr);
      return { kind: 'AssignStatement', target, value, pos };
    }

    this.eatOptional(TT.Semi);
    return { kind: 'ExpressionStatement', expression: expr, pos };
  }

  // ─── Expressions ─────────────────────────────────────────────────────────

  private parseExpr(): Expression {
    return this.parseBinary();
  }

  private parseBinary(): Expression {
    let left = this.parseUnary();

    while (this.isBinaryOp()) {
      const pos = this.pos();
      const op  = this.cur().value as BinaryOp;
      this.advance();
      const right = this.parseUnary();
      left = { kind: 'BinaryExpr', op, left, right, pos };
    }

    return left;
  }

  private parseUnary(): Expression {
    if (this.is(TT.Await)) {
      const pos = this.pos();
      this.advance();
      return { kind: 'AwaitExpr', value: this.parseCallOrMember(), pos };
    }
    return this.parseCallOrMember();
  }

  private parseCallOrMember(): Expression {
    const pos = this.pos();

    // validate <source> { ... }
    if (this.is(TT.Validate)) return this.parseValidateExpr();

    // Object literal
    if (this.is(TT.LBrace)) return this.parseObjectExpr();

    // Array literal
    if (this.is(TT.LBrack)) return this.parseArrayExpr();

    // String literal
    if (this.is(TT.StringLit)) {
      const v = this.cur().value; this.advance();
      return { kind: 'Literal', value: v, pos };
    }

    // Number literal
    if (this.is(TT.NumberLit)) {
      const v = Number(this.cur().value); this.advance();
      return { kind: 'Literal', value: v, pos };
    }

    // Bool literal
    if (this.is(TT.BoolLit)) {
      const v = this.cur().value === 'true'; this.advance();
      return { kind: 'Literal', value: v, pos };
    }

    // Null literal
    if (this.is(TT.NullLit)) {
      this.advance();
      return { kind: 'Literal', value: null, pos };
    }

    // Identifier, domain type, Response, etc. → can be member access or call
    if (this.isIdentLike()) {
      return this.parseMemberOrCall(pos);
    }

    // Grouped expression
    if (this.is(TT.LParen)) {
      this.advance();
      const inner = this.parseExpr();
      this.eat(TT.RParen);
      return inner;
    }

    this.error(`Unexpected token in expression: '${this.cur().value}'`);
  }

  private parseMemberOrCall(pos: SourcePos): Expression {
    // Collect dotted path: Response.created, user.id, hash, etc.
    const path: string[] = [];
    path.push(this.cur().value);
    this.advance();

    while (this.is(TT.Dot) && this.isIdentLikeAt(1)) {
      this.advance(); // dot
      path.push(this.cur().value);
      this.advance();
    }

    // If followed by '(', it's a call expression
    if (this.is(TT.LParen)) {
      this.advance();
      const args = this.parseCallArgs();
      this.eat(TT.RParen);
      return { kind: 'CallExpr', callee: path, args, pos };
    }

    // Otherwise it's a member expression (or plain identifier)
    if (path.length === 1) {
      return { kind: 'Identifier', name: path[0], pos };
    }
    return { kind: 'MemberExpr', object: path, pos };
  }

  private parseCallArgs(): CallArg[] {
    const args: CallArg[] = [];
    if (this.is(TT.RParen)) return args;

    do {
      // Check for named argument: key: value
      if (this.isIdentLike() && this.peekKind(1) === TT.Colon) {
        const label = this.cur().value;
        this.advance();  // key
        this.advance();  // colon
        const value = this.parseExpr();
        args.push({ label, value });
      } else {
        const value = this.parseExpr();
        args.push({ label: null, value });
      }

      if (!this.is(TT.Comma)) break;
      this.advance();
    } while (!this.is(TT.RParen) && !this.atEOF());

    return args;
  }

  private parseValidateExpr(): ValidateExpr {
    const pos = this.pos();
    this.eat(TT.Validate);
    const source = this.parseCallOrMember();
    const schema = this.parseSchema();
    return { kind: 'ValidateExpr', source, schema, pos };
  }

  private parseObjectExpr(): ObjectExpr {
    const pos = this.pos();
    this.eat(TT.LBrace);
    const properties: ObjectProp[] = [];

    while (!this.is(TT.RBrace) && !this.atEOF()) {
      const key = this.isIdentLike()
        ? this.cur().value
        : this.cur().value;
      this.advance();
      this.eat(TT.Colon);
      const value = this.parseExpr();
      properties.push({ key, value });
      if (this.is(TT.Comma)) this.advance();
    }

    this.eat(TT.RBrace);
    return { kind: 'ObjectExpr', properties, pos };
  }

  private parseArrayExpr(): ArrayExpr {
    const pos = this.pos();
    this.eat(TT.LBrack);
    const elements: Expression[] = [];

    while (!this.is(TT.RBrack) && !this.atEOF()) {
      elements.push(this.parseExpr());
      if (this.is(TT.Comma)) this.advance();
    }

    this.eat(TT.RBrack);
    return { kind: 'ArrayExpr', elements, pos };
  }

  // ─── Schema parsing ──────────────────────────────────────────────────────

  private parseSchema(): SchemaField[] {
    this.eat(TT.LBrace);
    const fields: SchemaField[] = [];

    while (!this.is(TT.RBrace) && !this.atEOF()) {
      const fieldName = this.eatIdent('schema field name');
      this.eat(TT.Colon);
      const { domainType, constraint, args } = this.parseTypeConstraint();
      fields.push({ name: fieldName, domainType, constraint: constraint ?? 'required', args });
      if (this.is(TT.Comma)) this.advance();
    }

    this.eat(TT.RBrace);
    return fields;
  }

  /**
   * Parses: Email.format | Password.strong(min: 8) | String.min(2) | Int | Bool
   */
  private parseTypeConstraint(): { domainType: string; constraint: string | null; args: ConstraintArg[] } {
    if (!this.isIdentLike()) this.error(`Expected type name, got '${this.cur().value}'`);

    const domainType = this.cur().value;
    this.advance();

    if (!this.is(TT.Dot)) {
      return { domainType, constraint: null, args: [] };
    }

    this.advance(); // dot
    const constraint = this.eatIdent('constraint name');

    if (!this.is(TT.LParen)) {
      return { domainType, constraint, args: [] };
    }

    // Parse constraint arguments: (min: 8) | (8) | ("value")
    this.advance(); // (
    const args: ConstraintArg[] = [];

    while (!this.is(TT.RParen) && !this.atEOF()) {
      if (this.isIdentLike() && this.peekKind(1) === TT.Colon) {
        const key = this.cur().value;
        this.advance(); // key
        this.advance(); // colon
        const raw = this.cur().value;
        this.advance();
        args.push({ key, value: isNaN(Number(raw)) ? raw : Number(raw) });
      } else {
        const raw = this.cur().value;
        this.advance();
        args.push({ key: null, value: isNaN(Number(raw)) ? raw : Number(raw) });
      }
      if (this.is(TT.Comma)) this.advance();
    }

    this.eat(TT.RParen);
    return { domainType, constraint, args };
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────

  private cur(): Token {
    return this.tokens[this.idx] ?? this.tokens[this.tokens.length - 1];
  }

  private pos(): SourcePos {
    return { line: this.cur().line, col: this.cur().col };
  }

  private advance(): void {
    if (this.idx < this.tokens.length - 1) this.idx++;
  }

  private atEOF(): boolean {
    return this.cur().kind === TT.EOF;
  }

  private is(kind: TT): boolean {
    return this.cur().kind === kind;
  }

  private peekKind(offset: number): TT {
    return this.tokens[this.idx + offset]?.kind ?? TT.EOF;
  }

  private eat(kind: TT): Token {
    if (!this.is(kind)) {
      this.error(`Expected '${kind}', got '${this.cur().value}' (${this.cur().kind})`);
    }
    const tok = this.cur();
    this.advance();
    return tok;
  }

  private eatIdent(context: string): string {
    if (!this.isIdentLike()) {
      this.error(`Expected identifier for ${context}, got '${this.cur().value}'`);
    }
    const name = this.cur().value;
    this.advance();
    return name;
  }

  private eatOptional(kind: TT): void {
    if (this.is(kind)) this.advance();
  }

  /** True if current token is a plain identifier or a domain type keyword. */
  private isIdentLike(): boolean {
    const k = this.cur().kind;
    return k === TT.Ident || DOMAIN_TYPES.has(k as TT);
  }

  /** True if token at idx+offset is ident-like. */
  private isIdentLikeAt(offset: number): boolean {
    const k = this.tokens[this.idx + offset]?.kind ?? TT.EOF;
    return k === TT.Ident || DOMAIN_TYPES.has(k as TT);
  }

  private isBinaryOp(): boolean {
    switch (this.cur().kind) {
      case TT.EqEq: case TT.Neq: case TT.Lt:  case TT.Gt:
      case TT.Lte:  case TT.Gte: case TT.Plus: case TT.Minus:
      case TT.Star: case TT.Slash:
      case TT.And:  case TT.Or:
        return true;
      default:
        return false;
    }
  }

  /** Extract a dotted path from a MemberExpr or Identifier for AssignStatement target. */
  private memberPath(expr: Expression): string[] {
    if (expr.kind === 'Identifier') return [expr.name];
    if (expr.kind === 'MemberExpr') return expr.object;
    this.error('Invalid assignment target — expected identifier or member expression');
  }

  private error(msg: string): never {
    throw new ParseError(msg, this.cur().line, this.cur().col);
  }
}
