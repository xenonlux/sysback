# @aether/language

> The AETHER Language Core — Lexer · Parser · AST · Code Generators · CLI

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](../../LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-strict-blue.svg)](https://www.typescriptlang.org/)
[![Zero Dependencies](https://img.shields.io/badge/production%20deps-zero-green.svg)]()

---

## What is this?

`@aether/language` is the **Language Core** of the AETHER system — Layer 01 of 07.

It transforms AETHER source code into a typed AST, and from there into:
- **JavaScript** (for execution in Node.js or browsers)
- **AETHER source** (for round-trip formatting)
- **Runtime definitions** (for the `@aether/runtime` Executor)

Supports **3 input modes**:
1. **Code Mode** — AETHER text syntax
2. **Natural Mode** — plain Arabic or English description
3. **Visual Mode** — JSON flow graph (via `@aether/shell`)

---

## Install

```bash
npm install @aether/language
# or
pnpm add @aether/language
```

---

## Quick Start

```typescript
import { parse, compileToJS, check, format } from '@aether/language';

const source = `
  stream users quantum {
    on register(req) {
      let user = validate req {
        email:    Email.format,
        password: Password.strong(min: 8),
        name:     String.min(2)
      }
      user.password = await hash(user.password)
      flow.users <- user
      emit signal.welcome(user.id)
      yield Response.created(token: sign(user.id))
    }
    on error(e) transparent {
      yield Response.error(e.trace)
    }
  }
`;

// 1. Type-check only
const result = check(source);
// → { ok: true }

// 2. Parse to AST
const ast = parse(source);
console.log(ast.body[0].kind);       // "StreamDeclaration"
console.log(ast.body[0].name);       // "users"
console.log(ast.body[0].modifiers);  // ["quantum"]

// 3. Compile to JavaScript
const js = compileToJS(source);
console.log(js); // → registry.register("users", { handlers: { register: async (req) => { ... } } })

// 4. Format (round-trip)
const formatted = format(source);
console.log(formatted); // → clean AETHER source
```

---

## CLI

```bash
# Install globally
npm install -g @aether/language

# Run an AETHER file
aether run users.ae

# Type-check
aether check users.ae

# Compile to JavaScript
aether build users.ae dist/users.js

# Format source
aether format users.ae

# Show token stream
aether tokens users.ae

# Show AST as JSON
aether ast users.ae

# Natural language → AETHER (English)
aether natural "when a user registers, validate email and password, save, send welcome signal"

# Natural language → AETHER (Arabic)
aether natural "عند تسجيل مستخدم جديد، تحقق من البريد وكلمة السر، احفظه، وأرسل ترحيباً"

# Interactive REPL
aether repl
```

---

## Language Reference

### Stream Declaration

```aether
stream <name> [modifiers] {
  on <event>(<params>) [modifiers] {
    <statements>
  }
}
```

**Modifiers:** `quantum` `transparent` `parallel` `cached(ttl)`

### Statements

| Statement | Syntax |
|-----------|--------|
| Let | `let user = validate req { ... }` |
| Validate | `validate req { email: Email.format }` |
| Flow Write | `flow.users <- user` |
| Assign | `user.password = await hash(user.password)` |
| Emit | `emit signal.welcome(user.id)` |
| Yield | `yield Response.created(token: sign(user.id))` |
| If/Else | `if (cond) { ... } else { ... }` |

### Types

| Domain Type | Constraints |
|-------------|-------------|
| `Email` | `.format` |
| `Password` | `.strong(min: N)` |
| `String` | `.min(N)` `.max(N)` |
| `Int` | `.min(N)` `.max(N)` |
| `Float` | `.min(N)` `.max(N)` |
| `URL` | `.format` |
| `UUID` | `.format` |
| `Bool` | — |
| `Date` | `.future` `.past` |

### Response Types

```aether
yield Response.ok(data)
yield Response.created(token: sign(user.id))
yield Response.error("message", trace)
yield Response.redirect(url)
```

---

## Natural Language Mode

```typescript
import { naturalToAST } from '@aether/language/modes/natural';

const result = naturalToAST("when a user registers, validate email and password, save them, send welcome");

console.log(result.confidence);   // 85
console.log(result.streamName);   // "users"
console.log(result.event);        // "register"

import { regenerate } from '@aether/language';
console.log(regenerate(result.ast));
// → stream users quantum {
//     on register(req) {
//       let data = validate req { email: Email.format, password: Password.strong }
//       flow.users <- data
//       emit signal.register_complete(data.id)
//       yield Response.created(token: sign(data.id))
//     }
//   }
```

---

## Runtime Integration

```typescript
import { parseToRuntime } from '@aether/language/integration/runtime-bridge';

const source = `
  stream users {
    on create(req) {
      flow.users <- req
      yield Response.created(req)
    }
  }
`;

const builtins = {
  validate: async (data, schema) => data,
  hash:     async (v) => `hash:${v}`,
  sign:     (id) => `token:${id}`,
  emit:     (signal, payload) => console.log(signal, payload),
  flow:     { write: (store, data) => console.log(`flow.${store} ←`, data) },
  Response: {
    created: (data) => ({ status: 201, data }),
    ok:      (data) => ({ status: 200, data }),
    error:   (msg)  => ({ status: 400, error: msg }),
  },
};

const { streams, errors, warnings } = parseToRuntime(source, builtins);

// Execute a handler directly
const result = await streams[0].handlers[0].fn({ email: 'a@b.com' });
// → { status: 201, data: { email: 'a@b.com' } }
```

---

## Architecture

```
@aether/language
├── src/
│   ├── tokens.ts              Token type definitions (TT enum)
│   ├── lexer.ts               Source → Token[]
│   ├── ast.ts                 All AST node types
│   ├── parser.ts              Token[] → Program AST
│   ├── index.ts               Public API (parse, check, compileToJS, format)
│   ├── codegen/
│   │   ├── js.ts              AST → JavaScript
│   │   └── regenerate.ts      AST → AETHER source (round-trip)
│   ├── modes/
│   │   └── natural.ts         Natural language → AST
│   ├── integration/
│   │   └── runtime-bridge.ts  AST → Runtime-executable functions
│   ├── security-patch/
│   │   └── random.ts          Cryptographically secure randomness
│   └── cli.ts                 CLI entry point
├── tests/
│   └── language.test.ts       Full test suite (>90% coverage target)
├── examples/
│   └── users.ae               Example AETHER program
├── package.json
└── tsconfig.json
```

---

## Build

```bash
pnpm install
pnpm build    # tsc
pnpm test     # jest --coverage
pnpm lint     # tsc --noEmit
```

---

## License

Apache 2.0 — Free to use, modify, and distribute.

---

## AETHER Project

| Package | Status | Description |
|---------|--------|-------------|
| `@aether/language` | ✅ **This package** | Language Core |
| `@aether/runtime` | ✅ 82% | AST Executor + EventBus |
| `@aether/flow` | ✅ 88% | Event Stream Data Engine |
| `@aether/network` | 🔄 42% | Adaptive Protocol Mesh |
| `@aether/guard` | 🔄 58% | Post-Quantum Security |
| `@aether/shell` | 🔄 30% | Browser IDE + Desktop + CLI |
| `@aether/evolution` | 🔄 65% | Self-Learning Optimizer |
