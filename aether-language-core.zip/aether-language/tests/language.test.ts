/**
 * @license SPDX-License-Identifier: Apache-2.0
 * @package @aether/language
 * @description Comprehensive test suite for the AETHER language core.
 */

import { parse, tokenize, compileToJS, format, check, TT } from '../src/index';
import type { StreamDeclaration, HandlerDeclaration, FlowWriteStatement } from '../src/ast';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function firstStream(src: string): StreamDeclaration {
  const program = parse(src);
  const decl    = program.body[0];
  if (decl.kind !== 'StreamDeclaration') throw new Error('Expected StreamDeclaration');
  return decl;
}

function firstHandler(src: string): HandlerDeclaration {
  return firstStream(src).handlers[0];
}

// ─── Lexer Tests ─────────────────────────────────────────────────────────────

describe('Lexer', () => {
  test('tokenizes keywords', () => {
    const tokens = tokenize('stream on let validate flow emit yield if else await quantum transparent');
    const kinds  = tokens.filter(t => t.kind !== TT.EOF).map(t => t.kind);
    expect(kinds).toContain(TT.Stream);
    expect(kinds).toContain(TT.On);
    expect(kinds).toContain(TT.Let);
    expect(kinds).toContain(TT.Validate);
    expect(kinds).toContain(TT.Flow);
    expect(kinds).toContain(TT.Emit);
    expect(kinds).toContain(TT.Yield);
    expect(kinds).toContain(TT.If);
    expect(kinds).toContain(TT.Else);
    expect(kinds).toContain(TT.Await);
    expect(kinds).toContain(TT.Quantum);
    expect(kinds).toContain(TT.Transparent);
  });

  test('tokenizes <- as single Arrow token', () => {
    const tokens = tokenize('flow.users <- user');
    const arrow  = tokens.find(t => t.kind === TT.Arrow);
    expect(arrow).toBeDefined();
    expect(arrow!.value).toBe('<-');
    // Must NOT have separate < and - tokens
    expect(tokens.some(t => t.kind === TT.Lt)).toBe(false);
  });

  test('tokenizes compound operators', () => {
    const tokens = tokenize('== != <= >= && ||');
    const kinds  = tokens.filter(t => t.kind !== TT.EOF).map(t => t.kind);
    expect(kinds).toContain(TT.EqEq);
    expect(kinds).toContain(TT.Neq);
    expect(kinds).toContain(TT.Lte);
    expect(kinds).toContain(TT.Gte);
    expect(kinds).toContain(TT.And);
    expect(kinds).toContain(TT.Or);
  });

  test('tokenizes string literals with escapes', () => {
    const tokens = tokenize('"hello\\nworld"');
    const str    = tokens.find(t => t.kind === TT.StringLit);
    expect(str?.value).toBe('hello\nworld');
  });

  test('tokenizes number literals', () => {
    const tokens = tokenize('42 3.14');
    const nums   = tokens.filter(t => t.kind === TT.NumberLit);
    expect(nums[0].value).toBe('42');
    expect(nums[1].value).toBe('3.14');
  });

  test('tracks line and column numbers', () => {
    const tokens = tokenize('stream\n  users');
    expect(tokens[0].line).toBe(1);
    expect(tokens[0].col).toBe(1);
    expect(tokens[1].line).toBe(2);
  });

  test('skips single-line comments', () => {
    const tokens = tokenize('stream // this is a comment\nusers');
    const kinds  = tokens.filter(t => t.kind !== TT.EOF).map(t => t.kind);
    expect(kinds).toEqual([TT.Stream, TT.Ident]);
  });

  test('skips block comments', () => {
    const tokens = tokenize('stream /* block\n comment */ users');
    const kinds  = tokens.filter(t => t.kind !== TT.EOF).map(t => t.kind);
    expect(kinds).toEqual([TT.Stream, TT.Ident]);
  });

  test('tokenizes domain types', () => {
    const tokens = tokenize('Email Password URL UUID String Int Float Bool Response');
    const kinds  = tokens.filter(t => t.kind !== TT.EOF).map(t => t.kind);
    expect(kinds).toContain(TT.Email);
    expect(kinds).toContain(TT.Password);
    expect(kinds).toContain(TT.Response);
  });
});

// ─── Parser: Stream Declaration ──────────────────────────────────────────────

describe('Parser — StreamDeclaration', () => {
  const src = `
    stream users quantum transparent {
      on register(req) {
        yield Response.ok(null)
      }
    }
  `;

  test('parses stream name', () => {
    expect(firstStream(src).name).toBe('users');
  });

  test('parses modifiers', () => {
    expect(firstStream(src).modifiers).toContain('quantum');
    expect(firstStream(src).modifiers).toContain('transparent');
  });

  test('parses handler event name', () => {
    expect(firstHandler(src).event).toBe('register');
  });

  test('parses handler params', () => {
    expect(firstHandler(src).params).toEqual(['req']);
  });

  test('multiple handlers', () => {
    const multi = `
      stream auth {
        on login(req) { yield Response.ok(null) }
        on logout(req) { yield Response.ok(null) }
      }
    `;
    expect(firstStream(multi).handlers.length).toBe(2);
    expect(firstStream(multi).handlers[1].event).toBe('logout');
  });
});

// ─── Parser: Statements ───────────────────────────────────────────────────────

describe('Parser — LetStatement', () => {
  test('parses simple let', () => {
    const src = `stream s { on e(r) { let x = "hello" } }`;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('LetStatement');
    if (stmt.kind === 'LetStatement') {
      expect(stmt.name).toBe('x');
      expect(stmt.value.kind).toBe('Literal');
    }
  });

  test('parses let with call expression', () => {
    const src = `stream s { on e(r) { let tok = sign(user.id) } }`;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('LetStatement');
    if (stmt.kind === 'LetStatement') {
      expect(stmt.value.kind).toBe('CallExpr');
    }
  });

  test('parses let with validate expression', () => {
    const src = `
      stream s { on e(req) {
        let user = validate req {
          email: Email.format,
          password: Password.strong(min: 8)
        }
      }}
    `;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('LetStatement');
    if (stmt.kind === 'LetStatement') {
      expect(stmt.value.kind).toBe('ValidateExpr');
      if (stmt.value.kind === 'ValidateExpr') {
        expect(stmt.value.schema.length).toBe(2);
        expect(stmt.value.schema[0].name).toBe('email');
        expect(stmt.value.schema[0].domainType).toBe('Email');
        expect(stmt.value.schema[0].constraint).toBe('format');
        expect(stmt.value.schema[1].args[0]).toEqual({ key: 'min', value: 8 });
      }
    }
  });
});

describe('Parser — FlowWriteStatement', () => {
  test('parses flow.store <- data', () => {
    const src = `stream s { on e(r) { flow.users <- user } }`;
    const stmt = firstHandler(src).body[0] as FlowWriteStatement;
    expect(stmt.kind).toBe('FlowWriteStatement');
    expect(stmt.store).toBe('users');
    expect(stmt.data.kind).toBe('Identifier');
    if (stmt.data.kind === 'Identifier') expect(stmt.data.name).toBe('user');
  });
});

describe('Parser — EmitStatement', () => {
  test('parses emit signal.welcome(user.id)', () => {
    const src = `stream s { on e(r) { emit signal.welcome(user.id) } }`;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('EmitStatement');
    if (stmt.kind === 'EmitStatement') {
      expect(stmt.namespace).toBe('signal');
      expect(stmt.signal).toBe('welcome');
      expect(stmt.payload?.kind).toBe('MemberExpr');
    }
  });

  test('parses emit without payload', () => {
    const src = `stream s { on e(r) { emit network.ready } }`;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('EmitStatement');
    if (stmt.kind === 'EmitStatement') {
      expect(stmt.payload).toBeNull();
    }
  });
});

describe('Parser — YieldStatement', () => {
  test('parses yield Response.created(...)', () => {
    const src = `stream s { on e(r) { yield Response.created(token: sign(user.id)) } }`;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('YieldStatement');
    if (stmt.kind === 'YieldStatement') {
      expect(stmt.value.kind).toBe('CallExpr');
      if (stmt.value.kind === 'CallExpr') {
        expect(stmt.value.callee).toEqual(['Response', 'created']);
        expect(stmt.value.args[0].label).toBe('token');
      }
    }
  });
});

describe('Parser — AssignStatement', () => {
  test('parses user.password = await hash(...)', () => {
    const src = `stream s { on e(r) { user.password = await hash(user.password) } }`;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('AssignStatement');
    if (stmt.kind === 'AssignStatement') {
      expect(stmt.target).toEqual(['user', 'password']);
      expect(stmt.value.kind).toBe('AwaitExpr');
    }
  });
});

describe('Parser — IfStatement', () => {
  test('parses if/else', () => {
    const src = `
      stream s { on e(r) {
        if (r.active == true) {
          yield Response.ok(null)
        } else {
          yield Response.error("inactive", null)
        }
      }}
    `;
    const stmt = firstHandler(src).body[0];
    expect(stmt.kind).toBe('IfStatement');
    if (stmt.kind === 'IfStatement') {
      expect(stmt.condition.kind).toBe('BinaryExpr');
      expect(stmt.consequent.length).toBe(1);
      expect(stmt.alternate?.length).toBe(1);
    }
  });
});

// ─── Full pipeline: Golden Source ────────────────────────────────────────────

describe('Full Pipeline', () => {
  const GOLDEN = `
stream users quantum transparent {
  on register(req) {
    let user = validate req {
      email: Email.format,
      password: Password.strong(min: 8),
      name: String.min(2)
    }
    user.password = await hash(user.password)
    flow.users <- user
    emit signal.welcome(user.id)
    yield Response.created(token: sign(user.id))
  }
  on error(e) transparent {
    yield Response.error(e.trace)
  }
}
  `.trim();

  test('parses without error', () => {
    expect(() => parse(GOLDEN)).not.toThrow();
  });

  test('check() returns ok', () => {
    expect(check(GOLDEN)).toEqual({ ok: true });
  });

  test('check() returns error for invalid code', () => {
    const result = check('stream { broken }');
    expect(result.ok).toBe(false);
  });

  test('compiles to JS without error', () => {
    const js = compileToJS(GOLDEN);
    expect(js).toContain('registry.register("users"');
    expect(js).toContain('async (req) =>');
    expect(js).toContain('await validate(');
    expect(js).toContain('flow.write("users"');
    expect(js).toContain('emit("signal.welcome"');
    expect(js).toContain('return Response.created');
  });

  test('regenerates valid AETHER source (round-trip)', () => {
    const ast  = parse(GOLDEN);
    const src2 = format(GOLDEN);
    // Re-parse the regenerated source — must not throw
    expect(() => parse(src2)).not.toThrow();
    // Must preserve stream name and modifiers
    const ast2 = parse(src2);
    const s2   = ast2.body[0] as StreamDeclaration;
    expect(s2.name).toBe('users');
    expect(s2.modifiers).toContain('quantum');
    expect(s2.modifiers).toContain('transparent');
    expect(s2.handlers.length).toBe(ast.body[0].kind === 'StreamDeclaration' ? (ast.body[0] as StreamDeclaration).handlers.length : 0);
  });

  test('multiple streams parse correctly', () => {
    const multi = `
      stream auth { on login(req) { yield Response.ok(null) } }
      stream data { on write(req) { flow.store <- req.data } }
    `;
    const prog = parse(multi);
    expect(prog.body.length).toBe(2);
    expect((prog.body[0] as StreamDeclaration).name).toBe('auth');
    expect((prog.body[1] as StreamDeclaration).name).toBe('data');
  });
});

// ─── Type declarations ────────────────────────────────────────────────────────

describe('Parser — TypeDeclaration', () => {
  test('parses type User = { ... }', () => {
    const src  = `type User = { email: Email, name: String, age: Int }`;
    const prog = parse(src);
    expect(prog.body[0].kind).toBe('TypeDeclaration');
    if (prog.body[0].kind === 'TypeDeclaration') {
      expect(prog.body[0].name).toBe('User');
      expect(prog.body[0].fields.length).toBe(3);
      expect(prog.body[0].fields[0].domainType).toBe('Email');
    }
  });
});
