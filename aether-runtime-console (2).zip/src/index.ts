/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Public API exports for Aether Runtime Engine
export type { ASTNode, Statement, Expression, AetherEvent, StreamListener } from './runtime/types';
export { ValidationError } from './runtime/types';
export { Environment } from './runtime/environment';
export { EventBus } from './runtime/event-bus';
export { StreamRegistry } from './runtime/stream-registry';
export type { StreamDef } from './runtime/stream-registry';
export { Executor } from './runtime/executor';
export type { ExecutionTraceLog } from './runtime/executor';

// Builtins
export { hash, sign, verify, uuid, now } from './builtins/crypto';
export { validate } from './builtins/validate';
export { AetherResponse } from './builtins/response';

// Targets
export { NodeRuntimeAdapter } from './targets/node';
export { BrowserRuntimeAdapter } from './targets/browser';
export { WorkerRuntimeAdapter } from './targets/worker';

// Compiler
export { ASTOptimizer } from './compiler/optimizer';
export { JSEmitter } from './compiler/js-emit';

// AETHER Flow Data Engine exports
export type { FlowEvent } from './flow/event';
export { deepFreeze, createFlowEvent } from './flow/event';
export { BTree, BTreeNode } from './flow/btree';
export { FlowQuery } from './flow/query';
export { FlowSnapshot, SnapshotEngine } from './flow/snapshot';
export { Flow } from './flow/flow';
export { FlowStore } from './flow/store';
export type { StorageBackend } from './storage/interface';
export { MemoryStore } from './storage/memory';
export { FileStore } from './storage/file';
export { Observable, BufferedSubscriber } from './reactive/observable';

import { EventBus } from './runtime/event-bus';
import { StreamRegistry } from './runtime/stream-registry';
import { NodeRuntimeAdapter } from './targets/node';
import { BrowserRuntimeAdapter } from './targets/browser';
import { WorkerRuntimeAdapter } from './targets/worker';
import { MemoryStore } from './storage/memory';
import { FlowStore } from './flow/store';

/**
 * Main factory to bootstrap an Aether instance
 */
export function createAetherRuntime(config?: { envVars?: Record<string, string> }) {
  const eventBus = new EventBus();
  const streamRegistry = new StreamRegistry(eventBus);

  const nodeAdapter = new NodeRuntimeAdapter(eventBus, config?.envVars);
  const browserAdapter = new BrowserRuntimeAdapter(eventBus);
  const workerAdapter = new WorkerRuntimeAdapter(eventBus);

  // Flow service integration
  const memoryStore = new MemoryStore();
  const flowStore = new FlowStore(memoryStore);

  return {
    eventBus,
    streamRegistry,
    flow: flowStore,
    adapters: {
      node: nodeAdapter,
      browser: browserAdapter,
      worker: workerAdapter
    }
  };
}

// AETHER Network Mesh Framework exports
export type { AetherMessage, AetherMessageMeta, AetherMessageType } from './mesh/message';
export { createAetherMessage, validateAetherMessage } from './mesh/message';
export { MeshRouter } from './mesh/router';
export type { TransportType } from './mesh/router';
export type { Transport, TransportServer } from './transports/interface';
export { LocalTransport, LocalTransportServer } from './transports/local';
export { TcpTransport, TcpTransportServer } from './transports/tcp';
export { HttpTransport, HttpTransportServer } from './transports/http';
export { WebSocketTransport, WebSocketTransportServer } from './transports/websocket';
export { WebrtcTransport, WebrtcTransportServer } from './transports/webrtc';
export type { Codec } from './protocols/codec';
export { JSONCodec, MessagePackCodec } from './protocols/codec';
export { frame, LengthPrefixedUnframer } from './protocols/framing';
export { createAetherClientProxy } from './client/proxy';
export type { ProxyClientConfig } from './client/proxy';
export { CircuitBreaker, retryWithBackoff } from './client/retry';
export type { CircuitBreakerConfig } from './client/retry';
export { LoadBalancer } from './client/load-balancer';
export type { LoadBalancingStrategy } from './client/load-balancer';
export { HandlerRegistry } from './server/handler-registry';
export type { HandlerFn } from './server/handler-registry';
export { MultiTransportServer } from './server/listener';
export type { ServerEventLog } from './server/listener';


